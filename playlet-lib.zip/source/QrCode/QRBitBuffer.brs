function __QrCode_QRBitBuffer_method_new()
    m.buffer = []
    m.numberOfBits = 0
end function
function __QrCode_QRBitBuffer_method_getBufferIndex(bitIndex as integer) as integer
    return int(bitIndex / 8)
end function
function __QrCode_QRBitBuffer_method_getBuffer() as object
    return m.buffer
end function
function __QrCode_QRBitBuffer_method_getBit(index as integer) as integer
    if ((m.buffer[m.getBufferIndex(index)] >> (7 - index mod 8)) and 1) = 1
        return 1
    else
        return 0
    end if
end function
function __QrCode_QRBitBuffer_method_getLengthInBits() as integer
    return m.numberOfBits
end function
function __QrCode_QRBitBuffer_method_put(num as integer, length as integer)
    for i = 0 to length - 1 step 1
        m.pushBit(((num >> (length - i - 1)) and 1) = 1)
    end for
end function
function __QrCode_QRBitBuffer_method_pushBit(isSet as boolean)
    bufIndex = m.getBufferIndex(m.numberOfBits)
    if m.buffer.count() <= bufIndex
        m.buffer.push(0)
    end if
    if isSet = true
        m.buffer[bufIndex] = m.buffer[bufIndex] or (&H80 >> (m.numberOfBits mod 8))
    end if
    m.numberOfBits += 1
end function
function __QrCode_QRBitBuffer_builder()
    instance = {}
    instance.new = __QrCode_QRBitBuffer_method_new
    instance.getBufferIndex = __QrCode_QRBitBuffer_method_getBufferIndex
    instance.getBuffer = __QrCode_QRBitBuffer_method_getBuffer
    instance.getBit = __QrCode_QRBitBuffer_method_getBit
    instance.getLengthInBits = __QrCode_QRBitBuffer_method_getLengthInBits
    instance.put = __QrCode_QRBitBuffer_method_put
    instance.pushBit = __QrCode_QRBitBuffer_method_pushBit
    return instance
end function
function QrCode_QRBitBuffer()
    instance = __QrCode_QRBitBuffer_builder()
    instance.new()
    return instance
end function