function __QrCode_QRData_AlphaNumeric_method_new()
    m.mode = 2
    m.CHAR_TABLE = {
        "0": 0
        "1": 1
        "2": 2
        "3": 3
        "4": 4
        "5": 5
        "6": 6
        "7": 7
        "8": 8
        "9": 9
        "A": 10
        "B": 11
        "C": 12
        "D": 13
        "E": 14
        "F": 15
        "G": 16
        "H": 17
        "I": 18
        "J": 19
        "K": 20
        "L": 21
        "M": 22
        "N": 23
        "O": 24
        "P": 25
        "Q": 26
        "R": 27
        "S": 28
        "T": 29
        "U": 30
        "V": 31
        "W": 32
        "X": 33
        "Y": 34
        "Z": 35
        " ": 36
        "$": 37
        "%": 38
        "*": 39
        "+": 40
        "-": 41
        ".": 42
        "/": 43
        ":": 44
    }
end function
function __QrCode_QRData_AlphaNumeric_method_setData(data as string)
    m.data = data
    m.length = data.len()
end function
function __QrCode_QRData_AlphaNumeric_method_writeToBuffer(buffer as object)
    i = 0
    data = m.data
    length = data.len()
    while i + 1 < length
        code1 = m.getCode(data.mid(i, 1))
        code2 = m.getCode(data.mid(i + 1, 1))
        buffer.put(code1 * 45 + code2, 11)
        i += 2
    end while
    if i < length
        buffer.put(m.getCode(data.mid(i, 1)), 6)
    end if
end function
function __QrCode_QRData_AlphaNumeric_method_getCode(char as string) as integer
    result = m.CHAR_TABLE[char]
    if result = invalid
        
        return 0
    end if
    return result
end function
function __QrCode_QRData_AlphaNumeric_builder()
    instance = {}
    instance.new = __QrCode_QRData_AlphaNumeric_method_new
    instance.setData = __QrCode_QRData_AlphaNumeric_method_setData
    instance.writeToBuffer = __QrCode_QRData_AlphaNumeric_method_writeToBuffer
    instance.getCode = __QrCode_QRData_AlphaNumeric_method_getCode
    return instance
end function
function QrCode_QRData_AlphaNumeric()
    instance = __QrCode_QRData_AlphaNumeric_builder()
    instance.new()
    return instance
end function