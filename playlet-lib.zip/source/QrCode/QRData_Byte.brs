function __QrCode_QRData_Byte_method_new()
    m.mode = 4
end function
function __QrCode_QRData_Byte_method_setData(data as string)
    m.bytes = m.stringToBytes(data)
    m.length = m.bytes.count()
end function
function __QrCode_QRData_Byte_method_writeToBuffer(buffer as object)
    for each byte in m.bytes
        buffer.put(byte, 8)
    end for
end function
function __QrCode_QRData_Byte_method_stringToBytes(text as string) as object
    result = CreateObject("roByteArray")
    result.fromAsciiString(text)
    return result
end function
function __QrCode_QRData_Byte_builder()
    instance = {}
    instance.new = __QrCode_QRData_Byte_method_new
    instance.setData = __QrCode_QRData_Byte_method_setData
    instance.writeToBuffer = __QrCode_QRData_Byte_method_writeToBuffer
    instance.stringToBytes = __QrCode_QRData_Byte_method_stringToBytes
    return instance
end function
function QrCode_QRData_Byte()
    instance = __QrCode_QRData_Byte_builder()
    instance.new()
    return instance
end function