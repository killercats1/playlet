function __QrCode_QRUtil_method_new(math as object)
    m.math = math
    m.PATTERN_POSITION_TABLE = [
        []
        [
            6
            18
        ]
        [
            6
            22
        ]
        [
            6
            26
        ]
        [
            6
            30
        ]
        [
            6
            34
        ]
        [
            6
            22
            38
        ]
        [
            6
            24
            42
        ]
        [
            6
            26
            46
        ]
        [
            6
            28
            50
        ]
        [
            6
            30
            54
        ]
        [
            6
            32
            58
        ]
        [
            6
            34
            62
        ]
        [
            6
            26
            46
            66
        ]
        [
            6
            26
            48
            70
        ]
        [
            6
            26
            50
            74
        ]
        [
            6
            30
            54
            78
        ]
        [
            6
            30
            56
            82
        ]
        [
            6
            30
            58
            86
        ]
        [
            6
            34
            62
            90
        ]
        [
            6
            28
            50
            72
            94
        ]
        [
            6
            26
            50
            74
            98
        ]
        [
            6
            30
            54
            78
            102
        ]
        [
            6
            28
            54
            80
            106
        ]
        [
            6
            32
            58
            84
            110
        ]
        [
            6
            30
            58
            86
            114
        ]
        [
            6
            34
            62
            90
            118
        ]
        [
            6
            26
            50
            74
            98
            122
        ]
        [
            6
            30
            54
            78
            102
            126
        ]
        [
            6
            26
            52
            78
            104
            130
        ]
        [
            6
            30
            56
            82
            108
            134
        ]
        [
            6
            34
            60
            86
            112
            138
        ]
        [
            6
            30
            58
            86
            114
            142
        ]
        [
            6
            34
            62
            90
            118
            146
        ]
        [
            6
            30
            54
            78
            102
            126
            150
        ]
        [
            6
            24
            50
            76
            102
            128
            154
        ]
        [
            6
            28
            54
            80
            106
            132
            158
        ]
        [
            6
            32
            58
            84
            110
            136
            162
        ]
        [
            6
            26
            54
            82
            110
            138
            166
        ]
        [
            6
            30
            58
            86
            114
            142
            170
        ]
    ]
    m.G15 = (1 << 10) or (1 << 8) or (1 << 5) or (1 << 4) or (1 << 2) or (1 << 1) or (1 << 0)
    m.G18 = (1 << 12) or (1 << 11) or (1 << 10) or (1 << 9) or (1 << 8) or (1 << 5) or (1 << 2) or (1 << 0)
    m.G15_MASK = (1 << 14) or (1 << 12) or (1 << 10) or (1 << 4) or (1 << 1)
    m.G15_BCHDigit = m.getBCHDigit(m.G15)
    m.G18_BCHDigit = m.getBCHDigit(m.G18)
end function
function __QrCode_QRUtil_method_getBCHDigit(data as integer) as integer
    digit = 0
    data = abs(data)
    while data <> 0
        digit += 1
        data >>= 1
    end while
    return digit
end function
function __QrCode_QRUtil_method_getBCHTypeInfo(data as integer) as integer
    d = data << 10
    while m.getBCHDigit(d) - m.G15_BCHDigit >= 0
        d = QrCode_qrXOR(d, (m.G15 << (m.getBCHDigit(d) - m.G15_BCHDigit)))
    end while
    return QrCode_qrXOR((data << 10) or d, m.G15_MASK)
end function
function __QrCode_QRUtil_method_getBCHTypeNumber(data as integer) as integer
    d = data << 12
    while m.getBCHDigit(d) - m.G18_BCHDigit >= 0
        d = QrCode_qrXOR(d, (m.G18 << (m.getBCHDigit(d) - m.G18_BCHDigit)))
    end while
    return (data << 12) or d
end function
function __QrCode_QRUtil_method_getPatternPosition(typeNumber as integer) as object
    return m.PATTERN_POSITION_TABLE[typeNumber - 1]
end function
function __QrCode_QRUtil_method_getMaskFunction(maskPattern as integer) as Function
    masks = QrCode_QRMaskFunctions()
    patterns = QrCode_QRMaskPatterns()
    maskId = patterns[maskPattern]
    if maskId = invalid or masks[maskId] = invalid
        
        return function(_i as dynamic, _j as dynamic) as boolean
            
            return false
        end function
    end if
    return masks[maskId]
end function
function __QrCode_QRUtil_method_getErrorCorrectPolynomial(errorCorrectLength as integer) as object
    a = QrCode_QRPolynomial(m.math, [
        1
    ], 0)
    for i = 0 to errorCorrectLength - 1 step 1
        a = a.multiply(QrCode_QRPolynomial(m.math, [
            1
            m.math.gexp(i)
        ], 0))
    end for
    return a
end function
function __QrCode_QRUtil_method_getLengthInBits(mode as integer, typeNumber as integer) as integer
    if 1 <= typeNumber and typeNumber < 10
        
        if mode = 1
            return 10
        end if
        if mode = 2
            return 9
        end if
        if mode = 4
            return 8
        end if
    else if typeNumber < 27
        
        if mode = 1
            return 12
        end if
        if mode = 2
            return 11
        end if
        if mode = 4
            return 16
        end if
    else if typeNumber < 41
        
        if mode = 1
            return 14
        end if
        if mode = 2
            return 13
        end if
        if mode = 4
            return 16
        end if
    end if
    
    return 0
end function
function __QrCode_QRUtil_builder()
    instance = {}
    instance.new = __QrCode_QRUtil_method_new
    instance.getBCHDigit = __QrCode_QRUtil_method_getBCHDigit
    instance.getBCHTypeInfo = __QrCode_QRUtil_method_getBCHTypeInfo
    instance.getBCHTypeNumber = __QrCode_QRUtil_method_getBCHTypeNumber
    instance.getPatternPosition = __QrCode_QRUtil_method_getPatternPosition
    instance.getMaskFunction = __QrCode_QRUtil_method_getMaskFunction
    instance.getErrorCorrectPolynomial = __QrCode_QRUtil_method_getErrorCorrectPolynomial
    instance.getLengthInBits = __QrCode_QRUtil_method_getLengthInBits
    return instance
end function
function QrCode_QRUtil(math as object)
    instance = __QrCode_QRUtil_builder()
    instance.new(math)
    return instance
end function