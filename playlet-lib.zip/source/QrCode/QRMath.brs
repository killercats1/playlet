function __QrCode_QRMath_method_new()
    EXP_TABLE = createObject("roArray", 256, false)
    LOG_TABLE = createObject("roArray", 256, false)
    
    for i = 0 to 7 step 1
        EXP_TABLE[i] = 1 << i
    end for
    for i = 8 to 255 step 1
        EXP_TABLE[i] = QrCode_qrXOR(QrCode_qrXOR(QrCode_qrXOR(EXP_TABLE[i - 4], EXP_TABLE[i - 5]), EXP_TABLE[i - 6]), EXP_TABLE[i - 8])
    end for
    for i = 0 to 254 step 1
        LOG_TABLE[EXP_TABLE[i]] = i
    end for
    m.EXP_TABLE = EXP_TABLE
    m.LOG_TABLE = LOG_TABLE
end function
function __QrCode_QRMath_method_glog(n as integer) as dynamic
    if n < 1
        
        return invalid
    end if
    return m.LOG_TABLE[n]
end function
function __QrCode_QRMath_method_gexp(n as integer) as integer
    while n < 0
        n += 255
    end while
    while n >= 256
        n -= 255
    end while
    return m.EXP_TABLE[n]
end function
function __QrCode_QRMath_builder()
    instance = {}
    instance.new = __QrCode_QRMath_method_new
    instance.glog = __QrCode_QRMath_method_glog
    instance.gexp = __QrCode_QRMath_method_gexp
    return instance
end function
function QrCode_QRMath()
    instance = __QrCode_QRMath_builder()
    instance.new()
    return instance
end function