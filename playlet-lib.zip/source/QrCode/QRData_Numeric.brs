function __QrCode_QRData_Numeric_method_new()
    m.mode = 1
    m.CHAR_TABLE = {
        "0": 0
        "1": 1
        "2": 2
        "3": 3
        "4": 4
        "5": 5
        "6": 6
        "7": 7
        "8": 8
        "9": 9
    }
end function
function __QrCode_QRData_Numeric_method_setData(data as string)
    m.data = data
    m.length = data.len()
end function
function __QrCode_QRData_Numeric_method_writeToBuffer(buffer as object) as void
    i = 0
    data = m.data
    length = data.len()
    while i + 2 < length
        buffer.put(m.strToNum(data.mid(i, i + 3)), 10)
        i += 3
    end while
    leftovers = length - i
    if leftovers <= 0
        return
    end if
    if leftovers = 1
        buffer.put(m.strToNum(data.mid(i, i + 1)), 4)
    else if leftovers = 2
        buffer.put(m.strToNum(data.mid(i, i + 2)), 7)
    end if
end function
function __QrCode_QRData_Numeric_method_strToNum(text as string) as integer
    num = 0
    for i = 0 to text.len() - 1 step 1
        digit = m.CHAR_TABLE[text.mid(i, 1)]
        if digit = invalid
            
            return 0
        end if
        num = num * 10 + digit
    end for
    return num
end function
function __QrCode_QRData_Numeric_builder()
    instance = {}
    instance.new = __QrCode_QRData_Numeric_method_new
    instance.setData = __QrCode_QRData_Numeric_method_setData
    instance.writeToBuffer = __QrCode_QRData_Numeric_method_writeToBuffer
    instance.strToNum = __QrCode_QRData_Numeric_method_strToNum
    return instance
end function
function QrCode_QRData_Numeric()
    instance = __QrCode_QRData_Numeric_builder()
    instance.new()
    return instance
end function