function __QrCode_QRPolynomial_method_new(math as object, num as object, shift as integer)
    if type(num) <> "roArray"
        throw ("Invalid num " + bslib_toString(num) + "/" + bslib_toString(shift))
    end if
    offset = 0
    while offset < num.count() and num[offset] = 0
        offset += 1
    end while
    _numSize = num.count() - offset + shift
    _num = createObject("roArray", _numSize, false)
    for i = 0 to num.count() - offset - 1 step 1
        _num[i] = num[i + offset]
    end for
    
    if _num.count() < _numSize
        for i = _num.count() to _numSize - 1 step 1
            _num[i] = invalid
        end for
    end if
    m._num = _num
    m.math = math
end function
function __QrCode_QRPolynomial_method_getAt(index as integer) as integer
    return (function(index, m)
            __bsConsequent = m._num[index]
            if __bsConsequent <> invalid then
                return __bsConsequent
            else
                return 0
            end if
        end function)(index, m)
end function
function __QrCode_QRPolynomial_method_getLength() as integer
    return m._num.count()
end function
function __QrCode_QRPolynomial_method_multiply(e as object) as object
    num = createObject("roArray", m.getLength() + e.getLength() - 1, false)
    for i = 0 to m.getLength() - 1 step 1
        for j = 0 to e.getLength() - 1 step 1
            if num[i + j] = invalid
                num[i + j] = 0
            end if
            num[i + j] = QrCode_qrXOR(num[i + j], m.math.gexp(m.math.glog(m.getAt(i)) + m.math.glog(e.getAt(j))))
        end for
    end for
    return QrCode_QRPolynomial(m.math, num, 0)
end function
function __QrCode_QRPolynomial_method_modulo(e as object) as object
    if m.getLength() - e.getLength() < 0
        return m
    end if
    ratio = m.math.glog(m.getAt(0)) - m.math.glog(e.getAt(0))
    num = createObject("roArray", m.getLength(), false)
    for i = 0 to m.getLength() - 1 step 1
        num[i] = m.getAt(i)
    end for
    for i = 0 to e.getLength() - 1 step 1
        num[i] = QrCode_qrXOR(num[i], m.math.gexp(m.math.glog(e.getAt(i)) + ratio))
    end for
    
    return (QrCode_QRPolynomial(m.math, num, 0)).modulo(e)
end function
function __QrCode_QRPolynomial_builder()
    instance = {}
    instance.new = __QrCode_QRPolynomial_method_new
    instance.getAt = __QrCode_QRPolynomial_method_getAt
    instance.getLength = __QrCode_QRPolynomial_method_getLength
    instance.multiply = __QrCode_QRPolynomial_method_multiply
    instance.modulo = __QrCode_QRPolynomial_method_modulo
    return instance
end function
function QrCode_QRPolynomial(math as object, num as object, shift as integer)
    instance = __QrCode_QRPolynomial_builder()
    instance.new(math, num, shift)
    return instance
end function