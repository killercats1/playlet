' DISABLE_CACHE will force the generation of the QRCode every time.
' Only use this for debugging purposes.
'import "pkg:/source/utils/CryptoUtils.bs"
'import "QRCode.bs"
sub __QrCode_QRImage_method_new()
end sub
function __QrCode_QRImage_method_Generate(text as string, size as integer, padding as integer, mode = 4 as object) as string
    fileName = m.GetFileName(text, mode, size, padding)
    fs = CreateObject("roFileSystem")
    if fs.exists(fileName)
        return fileName
    end if
    qr = QrCode_QRCode()
    qr.addData(text, mode)
    qr.make()
    if qr.status = "ready"
        return m.toPNG(qr, size, padding, fileName)
    end if
    return ""
end function
function __QrCode_QRImage_method_GetFileName(text as string, mode as object, size as integer, padding as integer) as string
    key = ("v1-" + bslib_toString(text) + "-" + bslib_toString(mode) + "-" + bslib_toString(size) + "-" + bslib_toString(padding))
    key = CryptoUtils_GetMd5(key)
    return "cachefs:/" + key + ".png"
end function
function __QrCode_QRImage_method_toPNG(qr as object, qrSize as integer, padding as integer, fileName as string) as string
    
    moduleCount = qr.moduleCount
    maxSize = fix(qrSize - padding - padding)
    if maxSize < moduleCount
        return ""
    end if
    cellSize = maxSize \ moduleCount
    size = cellSize * moduleCount
    center = size \ 2
    left = (fix(qrSize - padding - padding) \ 2) - center + padding
    top = left
    
    white = &Hffffffff
    black = &H000000ff
    bitmap = createObject("roBitmap", {
        width: qrSize
        height: qrSize
        AlphaEnable: false
    })
    bitmap.clear(white)
    
    y = top
    for row = 0 to moduleCount - 1 step 1
        x = left
        for col = 0 to moduleCount - 1 step 1
            if qr.isDark(row, col)
                bitmap.drawRect(x, y, cellSize, cellSize, black)
            end if
            x += cellSize
        end for
        y += cellSize
    end for
    bitmap.finish()
    
    pngData = bitmap.getPNG(0, 0, qrSize, qrSize)
    pngData.writeFile(fileName)
    return fileName
end function
function __QrCode_QRImage_builder()
    instance = {}
    instance.new = __QrCode_QRImage_method_new
    instance.Generate = __QrCode_QRImage_method_Generate
    instance.GetFileName = __QrCode_QRImage_method_GetFileName
    instance.toPNG = __QrCode_QRImage_method_toPNG
    return instance
end function
function QrCode_QRImage()
    instance = __QrCode_QRImage_builder()
    instance.new()
    return instance
end function