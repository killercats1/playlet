sub __Protobuf_BinaryWriter_method_new()
    m.buffer = invalid
    m.position = invalid
end sub
function __Protobuf_BinaryWriter_method_SetBuffer(buffer as dynamic) as void
    if buffer = invalid
        return
    end if
    if GetInterface(buffer, "ifString") <> invalid
        b = CreateObject("roByteArray")
        b.FromBase64String(buffer.DecodeUriComponent())
        buffer = b
    end if
    m.buffer = buffer
    m.position = 0
end function
function __Protobuf_BinaryWriter_method_WriteByte(byte as dynamic) as void
    m.buffer[m.position] = byte
    m.position += 1
end function
function __Protobuf_BinaryWriter_method_WriteInt32(value as dynamic) as void
    m.buffer[m.position] = value and &hFF
    m.buffer[m.position + 1] = (value >> 8) and &hFF
    m.buffer[m.position + 2] = (value >> 16) and &hFF
    m.buffer[m.position + 3] = (value >> 24) and &hFF
    m.position += 4
end function
function __Protobuf_BinaryWriter_method_WriteVarInt(value as dynamic) as void
    while true
        byte = value and &h7F
        value >>= 7
        if value = 0
            m.WriteByte(byte)
            return
        end if
        m.WriteByte(byte or &h80)
    end while
end function
function __Protobuf_BinaryWriter_method_WriteString(value as dynamic) as void
    strBuffer = CreateObject("roByteArray")
    strBuffer.FromAsciiString(value)
    m.WriteVarInt(strBuffer.Count())
    m.WriteByteArrayRaw(strBuffer, 0, strBuffer.Count())
end function
function __Protobuf_BinaryWriter_method_WriteProtoByteArray(value as dynamic) as void
    m.WriteVarInt(value.Count())
    m.WriteByteArrayRaw(value, 0, value.Count())
end function
function __Protobuf_BinaryWriter_method_WriteBool(value as dynamic) as void
    if value = true
        m.WriteByte(1)
    else
        m.WriteByte(0)
    end if
end function
function __Protobuf_BinaryWriter_method_WriteByteArrayRaw(buffer as dynamic, index as dynamic, size as dynamic) as void
    position = m.position
    for i = 0 to size - 1
        m.buffer[position + i] = buffer[index + i]
    end for
    m.position += size
end function
function __Protobuf_BinaryWriter_builder()
    instance = {}
    instance.new = __Protobuf_BinaryWriter_method_new
    instance.SetBuffer = __Protobuf_BinaryWriter_method_SetBuffer
    instance.WriteByte = __Protobuf_BinaryWriter_method_WriteByte
    instance.WriteInt32 = __Protobuf_BinaryWriter_method_WriteInt32
    instance.WriteVarInt = __Protobuf_BinaryWriter_method_WriteVarInt
    instance.WriteString = __Protobuf_BinaryWriter_method_WriteString
    instance.WriteProtoByteArray = __Protobuf_BinaryWriter_method_WriteProtoByteArray
    instance.WriteBool = __Protobuf_BinaryWriter_method_WriteBool
    instance.WriteByteArrayRaw = __Protobuf_BinaryWriter_method_WriteByteArrayRaw
    return instance
end function
function Protobuf_BinaryWriter()
    instance = __Protobuf_BinaryWriter_builder()
    instance.new()
    return instance
end function