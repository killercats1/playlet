function __Protobuf_Decoder_method_new(reader as object)
    m.reader = invalid
    m.reader = reader
end function
function __Protobuf_Decoder_method_DecodeMessage(buffer as object) as dynamic
    m.reader.SetBuffer(buffer)
    message = {}
    while true
        field = m.reader.ReadByte()
        if field = invalid
            exit while
        end if
        tag = field >> 3
        wire_type = field and &h7
        value = invalid
        if wire_type = 0
            value = m.reader.ReadVarInt()
        else if wire_type = 1
            value = m.reader.ReadInt64()
        else if wire_type = 2
            value = m.reader.ReadString()
        else if wire_type = 5
            value = m.reader.ReadInt32()
        end if
        if value = invalid
            return invalid
        end if
        tagStr = (bslib_toString(tag))
        if message[tagStr] = invalid
            message[tagStr] = value
        else if GetInterface(message[tagStr], "ifArray") <> invalid
            message[tagStr].Push(value)
        else
            message[tagStr] = [
                message[tagStr]
                value
            ]
        end if
    end while
    return message
end function
function __Protobuf_Decoder_builder()
    instance = {}
    instance.new = __Protobuf_Decoder_method_new
    ' TODO:P2 decoder is not finished, does not work properly
    instance.DecodeMessage = __Protobuf_Decoder_method_DecodeMessage
    return instance
end function
function Protobuf_Decoder(reader as object)
    instance = __Protobuf_Decoder_builder()
    instance.new(reader)
    return instance
end function