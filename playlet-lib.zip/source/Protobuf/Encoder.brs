function __Protobuf_Encoder_method_new(writer as object) as void
    m.writer = invalid
    m.writer = writer
end function
function __Protobuf_Encoder_method_EncodeString(tag as integer, value as dynamic) as void
    m.writer.WriteByte((tag << 3) or 2)
    m.writer.WriteString(value)
end function
function __Protobuf_Encoder_method_EncodeInt32(tag as integer, value as dynamic) as void
    m.writer.WriteByte((tag << 3) or 0)
    m.writer.WriteVarInt(value)
end function
function __Protobuf_Encoder_method_EncodeInt64(tag as integer, value as dynamic) as void
    m.writer.WriteByte((tag << 3) or 0)
    
    m.writer.WriteInt64(value)
end function
function __Protobuf_Encoder_method_EncodeFloat(tag as integer, value as dynamic) as void
    m.writer.WriteByte((tag << 3) or 5)
    
    m.writer.WriteFloat(value)
end function
function __Protobuf_Encoder_method_EncodeDouble(tag as integer, value as dynamic) as void
    m.writer.WriteByte((tag << 3) or 1)
    
    m.writer.WriteDouble(value)
end function
function __Protobuf_Encoder_method_EncodeBool(tag as integer, value as dynamic) as void
    m.writer.WriteByte((tag << 3) or 0)
    m.writer.WriteBool(value)
end function
function __Protobuf_Encoder_method_EncodeMessage(tag as integer, value as dynamic) as void
    m.writer.WriteByte((tag << 3) or 2)
    m.writer.WriteProtoByteArray(value)
end function
function __Protobuf_Encoder_builder()
    instance = {}
    instance.new = __Protobuf_Encoder_method_new
    instance.EncodeString = __Protobuf_Encoder_method_EncodeString
    instance.EncodeInt32 = __Protobuf_Encoder_method_EncodeInt32
    instance.EncodeInt64 = __Protobuf_Encoder_method_EncodeInt64
    instance.EncodeFloat = __Protobuf_Encoder_method_EncodeFloat
    instance.EncodeDouble = __Protobuf_Encoder_method_EncodeDouble
    instance.EncodeBool = __Protobuf_Encoder_method_EncodeBool
    instance.EncodeMessage = __Protobuf_Encoder_method_EncodeMessage
    return instance
end function
function Protobuf_Encoder(writer as object)
    instance = __Protobuf_Encoder_builder()
    instance.new(writer)
    return instance
end function