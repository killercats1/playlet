function CryptoUtils_GetSha256(input as string) as string
    return CryptoUtils_GetEvpDigest(input, "sha256")
end function

function CryptoUtils_GetSha1(input as string) as string
    return CryptoUtils_GetEvpDigest(input, "sha1")
end function

function CryptoUtils_GetMd5(input as string) as string
    return CryptoUtils_GetEvpDigest(input, "md5")
end function

function CryptoUtils_GetEvpDigest(input as string, method as string) as string
    buffer = CreateObject("roByteArray")
    buffer.FromAsciiString(input)
    digest = CreateObject("roEVPDigest")
    digest.Setup(method)
    return digest.Process(buffer)
end function