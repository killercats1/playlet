function ColorUtils_HexToInt(color as dynamic) as integer
    if color = invalid
        return 0
    end if
    if color.left(1) = "#"
        color = color.mid(1)
    end if
    return Val(color, 16)
end function

function ColorUtils_IntToHex(color as integer) as string
    hex = UCase(StrI(color, 16))
    length = Len(hex)
    for i = 0 to 7 - length
        hex = "0" + hex
    end for
    return "#" + hex
end function

function ColorUtils_RgbaToInt(r as integer, g as integer, b as integer, a = 255 as integer) as integer
    return r * 16777216 + g * 65536 + b * 256 + a
end function

function ColorUtils_RandomColorInt() as integer
    return ColorUtils_RgbaToInt(Rnd(256), Rnd(256), Rnd(256))
end function

function ColorUtils_RandomSoftColorInt() as integer
    return ColorUtils_RgbaToInt(Rnd(100) + 100, Rnd(100) + 100, Rnd(100) + 100)
end function

function ColorUtils_RandomSoftColorHex() as string
    return ColorUtils_IntToHex(ColorUtils_RandomSoftColorInt())
end function