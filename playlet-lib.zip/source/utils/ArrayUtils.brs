'import "pkg:/source/utils/Types.bs"
function ArrayUtils_IndexOfString(array as object, value as dynamic) as integer
    if not IsString(value)
        return -1
    end if
    for i = 0 to array.Count() - 1
        if array[i] = value
            return i
        end if
    end for
    return -1
end function

function ArrayUtils_IndexOfNode(array as object, value as dynamic) as integer
    if not IsNode(value)
        return -1
    end if
    for i = 0 to array.Count() - 1
        if value.isSameNode(array[i])
            return i
        end if
    end for
    return -1
end function

function ArrayUtils_Insert(array as object, value as dynamic, index as integer) as void
    if index = 0
        array.Unshift(value)
        return
    end if
    if index < array.Count()
        for i = array.Count() - 1 to index step -1
            array[i + 1] = array[i]
        end for
    end if
    array[index] = value
end function