'import "AssertUtils.bs"
function MessagePortUtils_ObserveFieldScopedExSafe(node as dynamic, field as string, port as dynamic) as void
    
    if FindMemberFunction(node, "ObserveFieldScopedEx") <> invalid
        
        node.ObserveFieldScopedEx(field, port)
    else
        node.ObserveFieldScoped(field, port)
    end if
end function