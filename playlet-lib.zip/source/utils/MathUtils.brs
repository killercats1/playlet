function MathUtils_Max(a as dynamic, b as dynamic) as dynamic
    if a > b
        return a
    else
        return b
    end if
end function

function MathUtils_Min(a as dynamic, b as dynamic) as dynamic
    if a < b
        return a
    else
        return b
    end if
end function

function MathUtils_Clamp(value as dynamic, minValue as dynamic, maxValue as dynamic) as dynamic
    return MathUtils_Max(MathUtils_Min(value, maxValue), minValue)
end function

function MathUtils_FormatFloat(X as float) as float
    X = X * 10
    X = X + 0.5
    X = Fix(X)
    X = X / 10
    return X
end function