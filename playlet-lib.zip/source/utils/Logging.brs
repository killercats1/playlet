

function LogError(_arg1 = invalid as dynamic, _arg2 = invalid as dynamic, _arg3 = invalid as dynamic, _arg4 = invalid as dynamic, _arg5 = invalid as dynamic, _arg6 = invalid as dynamic, _arg7 = invalid as dynamic, _arg8 = invalid as dynamic, _arg9 = invalid as dynamic, _arg10 = invalid as dynamic, _arg11 = invalid as dynamic, _arg12 = invalid as dynamic, _arg13 = invalid as dynamic, _arg14 = invalid as dynamic, _arg15 = invalid as dynamic, _arg16 = invalid as dynamic) as void
    throw "FATAL: Calling LogError() which is a stub function"
end function

function LogErrorNoTelemetry(_arg1 = invalid as dynamic, _arg2 = invalid as dynamic, _arg3 = invalid as dynamic, _arg4 = invalid as dynamic, _arg5 = invalid as dynamic, _arg6 = invalid as dynamic, _arg7 = invalid as dynamic, _arg8 = invalid as dynamic, _arg9 = invalid as dynamic, _arg10 = invalid as dynamic, _arg11 = invalid as dynamic, _arg12 = invalid as dynamic, _arg13 = invalid as dynamic, _arg14 = invalid as dynamic, _arg15 = invalid as dynamic, _arg16 = invalid as dynamic) as void
    throw "FATAL: Calling LogErrorNoTelemetry() which is a stub function"
end function

function LogWarn(_arg1 = invalid as dynamic, _arg2 = invalid as dynamic, _arg3 = invalid as dynamic, _arg4 = invalid as dynamic, _arg5 = invalid as dynamic, _arg6 = invalid as dynamic, _arg7 = invalid as dynamic, _arg8 = invalid as dynamic, _arg9 = invalid as dynamic, _arg10 = invalid as dynamic, _arg11 = invalid as dynamic, _arg12 = invalid as dynamic, _arg13 = invalid as dynamic, _arg14 = invalid as dynamic, _arg15 = invalid as dynamic, _arg16 = invalid as dynamic) as void
    throw "FATAL: Calling LogWarn() which is a stub function"
end function

function LogWarnNoTelemetry(_arg1 = invalid as dynamic, _arg2 = invalid as dynamic, _arg3 = invalid as dynamic, _arg4 = invalid as dynamic, _arg5 = invalid as dynamic, _arg6 = invalid as dynamic, _arg7 = invalid as dynamic, _arg8 = invalid as dynamic, _arg9 = invalid as dynamic, _arg10 = invalid as dynamic, _arg11 = invalid as dynamic, _arg12 = invalid as dynamic, _arg13 = invalid as dynamic, _arg14 = invalid as dynamic, _arg15 = invalid as dynamic, _arg16 = invalid as dynamic) as void
    throw "FATAL: Calling LogWarnNoTelemetry() which is a stub function"
end function

function LogInfo(_arg1 = invalid as dynamic, _arg2 = invalid as dynamic, _arg3 = invalid as dynamic, _arg4 = invalid as dynamic, _arg5 = invalid as dynamic, _arg6 = invalid as dynamic, _arg7 = invalid as dynamic, _arg8 = invalid as dynamic, _arg9 = invalid as dynamic, _arg10 = invalid as dynamic, _arg11 = invalid as dynamic, _arg12 = invalid as dynamic, _arg13 = invalid as dynamic, _arg14 = invalid as dynamic, _arg15 = invalid as dynamic, _arg16 = invalid as dynamic) as void
    throw "FATAL: Calling LogInfo() which is a stub function"
end function

function LogDebug(_arg1 = invalid as dynamic, _arg2 = invalid as dynamic, _arg3 = invalid as dynamic, _arg4 = invalid as dynamic, _arg5 = invalid as dynamic, _arg6 = invalid as dynamic, _arg7 = invalid as dynamic, _arg8 = invalid as dynamic, _arg9 = invalid as dynamic, _arg10 = invalid as dynamic, _arg11 = invalid as dynamic, _arg12 = invalid as dynamic, _arg13 = invalid as dynamic, _arg14 = invalid as dynamic, _arg15 = invalid as dynamic, _arg16 = invalid as dynamic) as void
    throw "FATAL: Calling LogDebug() which is a stub function"
end function

function LogTelemetryEvent(event as object)
    m.global.telemetry.LogEvent = event
end function

function ToString(value as dynamic) as string
    if getInterface(value, "ifString") <> invalid
        return value
    end if
    valueType = type(value)
    if valueType = "<uninitialized>"
        return valueType
    else if value = invalid
        return "<invalid>"
    else if GetInterface(value, "ifToStr") <> invalid
        return value.toStr()
    else if valueType = "roSGNode"
        return "Node(" + value.subType() + ":" + value.id + ")"
    else if valueType = "roAssociativeArray"
        return AssocArrayToString(value)
    else if valueType = "roArray"
        return ArrayToString(value)
    else if valueType = "roDateTime"
        return value.ToISOString()
    end if
    return "<" + valueType + ">"
end function

function AssocArrayToString(dict as object) as string
    result = "{"
    
    count = dict.ifAssociativeArray.count()
    i = 0
    for each key in dict
        result += key + ": " + ToString(dict[key])
        if i < count - 1
            result += ", "
        end if
        i++
    end for
    result += "}"
    return result
end function

function ArrayToString(array as object) as string
    result = "["
    count = array.count()
    i = 0
    for each item in array
        result += ToString(item)
        if i < count - 1
            result += ", "
        end if
        i++
    end for
    result += "]"
    return result
end function

' Start of auto-generated functions
function LogInfo2(arg0, arg1) as void
    logger = m.global.logger
    if logger.logLevel < 2
        return
    end if
    line = "[INFO]" + ToString(arg0) + " " + ToString(arg1)
    logger.logLine = line
end function

function LogError3(arg0, arg1, arg2) as void
    logger = m.global.logger
    if logger.logLevel < 0
        return
    end if
    line = "[ERROR]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2)
    logger.logLine = line
    telemetry = m.global.telemetry
    if telemetry <> invalid
        telemetry.LogError = line
    end if
end function

function LogError2(arg0, arg1) as void
    logger = m.global.logger
    if logger.logLevel < 0
        return
    end if
    line = "[ERROR]" + ToString(arg0) + " " + ToString(arg1)
    logger.logLine = line
    telemetry = m.global.telemetry
    if telemetry <> invalid
        telemetry.LogError = line
    end if
end function

function LogInfo3(arg0, arg1, arg2) as void
    logger = m.global.logger
    if logger.logLevel < 2
        return
    end if
    line = "[INFO]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2)
    logger.logLine = line
end function

function LogWarn2(arg0, arg1) as void
    logger = m.global.logger
    if logger.logLevel < 1
        return
    end if
    line = "[WARN]" + ToString(arg0) + " " + ToString(arg1)
    logger.logLine = line
    telemetry = m.global.telemetry
    if telemetry <> invalid
        telemetry.LogWarn = line
    end if
end function

function LogInfo5(arg0, arg1, arg2, arg3, arg4) as void
    logger = m.global.logger
    if logger.logLevel < 2
        return
    end if
    line = "[INFO]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4)
    logger.logLine = line
end function

function LogDebug5(arg0, arg1, arg2, arg3, arg4) as void
    logger = m.global.logger
    if logger.logLevel < 3
        return
    end if
    line = "[DEBUG]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4)
    logger.logLine = line
end function

function LogWarn5(arg0, arg1, arg2, arg3, arg4) as void
    logger = m.global.logger
    if logger.logLevel < 1
        return
    end if
    line = "[WARN]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4)
    logger.logLine = line
    telemetry = m.global.telemetry
    if telemetry <> invalid
        telemetry.LogWarn = line
    end if
end function

function LogWarn3(arg0, arg1, arg2) as void
    logger = m.global.logger
    if logger.logLevel < 1
        return
    end if
    line = "[WARN]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2)
    logger.logLine = line
    telemetry = m.global.telemetry
    if telemetry <> invalid
        telemetry.LogWarn = line
    end if
end function

function LogInfo4(arg0, arg1, arg2, arg3) as void
    logger = m.global.logger
    if logger.logLevel < 2
        return
    end if
    line = "[INFO]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3)
    logger.logLine = line
end function

function LogDebug3(arg0, arg1, arg2) as void
    logger = m.global.logger
    if logger.logLevel < 3
        return
    end if
    line = "[DEBUG]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2)
    logger.logLine = line
end function

function LogDebug2(arg0, arg1) as void
    logger = m.global.logger
    if logger.logLevel < 3
        return
    end if
    line = "[DEBUG]" + ToString(arg0) + " " + ToString(arg1)
    logger.logLine = line
end function

function LogDebug4(arg0, arg1, arg2, arg3) as void
    logger = m.global.logger
    if logger.logLevel < 3
        return
    end if
    line = "[DEBUG]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3)
    logger.logLine = line
end function

function LogErrorNoTelemetry2(arg0, arg1) as void
    logger = m.global.logger
    if logger.logLevel < 0
        return
    end if
    line = "[ERROR]" + ToString(arg0) + " " + ToString(arg1)
    logger.logLine = line
end function

function LogWarnNoTelemetry3(arg0, arg1, arg2) as void
    logger = m.global.logger
    if logger.logLevel < 1
        return
    end if
    line = "[WARN]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2)
    logger.logLine = line
end function

function LogWarnNoTelemetry4(arg0, arg1, arg2, arg3) as void
    logger = m.global.logger
    if logger.logLevel < 1
        return
    end if
    line = "[WARN]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3)
    logger.logLine = line
end function

function LogWarnNoTelemetry2(arg0, arg1) as void
    logger = m.global.logger
    if logger.logLevel < 1
        return
    end if
    line = "[WARN]" + ToString(arg0) + " " + ToString(arg1)
    logger.logLine = line
end function

function LogError7(arg0, arg1, arg2, arg3, arg4, arg5, arg6) as void
    logger = m.global.logger
    if logger.logLevel < 0
        return
    end if
    line = "[ERROR]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4) + " " + ToString(arg5) + " " + ToString(arg6)
    logger.logLine = line
    telemetry = m.global.telemetry
    if telemetry <> invalid
        telemetry.LogError = line
    end if
end function

function LogWarn4(arg0, arg1, arg2, arg3) as void
    logger = m.global.logger
    if logger.logLevel < 1
        return
    end if
    line = "[WARN]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3)
    logger.logLine = line
    telemetry = m.global.telemetry
    if telemetry <> invalid
        telemetry.LogWarn = line
    end if
end function

function LogDebug6(arg0, arg1, arg2, arg3, arg4, arg5) as void
    logger = m.global.logger
    if logger.logLevel < 3
        return
    end if
    line = "[DEBUG]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4) + " " + ToString(arg5)
    logger.logLine = line
end function

function LogErrorNoTelemetry3(arg0, arg1, arg2) as void
    logger = m.global.logger
    if logger.logLevel < 0
        return
    end if
    line = "[ERROR]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2)
    logger.logLine = line
end function

function LogDebug17(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16) as void
    logger = m.global.logger
    if logger.logLevel < 3
        return
    end if
    line = "[DEBUG]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4) + " " + ToString(arg5) + " " + ToString(arg6) + " " + ToString(arg7) + " " + ToString(arg8) + " " + ToString(arg9) + " " + ToString(arg10) + " " + ToString(arg11) + " " + ToString(arg12) + " " + ToString(arg13) + " " + ToString(arg14) + " " + ToString(arg15) + " " + ToString(arg16)
    logger.logLine = line
end function

function LogDebug9(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) as void
    logger = m.global.logger
    if logger.logLevel < 3
        return
    end if
    line = "[DEBUG]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4) + " " + ToString(arg5) + " " + ToString(arg6) + " " + ToString(arg7) + " " + ToString(arg8)
    logger.logLine = line
end function

function LogError4(arg0, arg1, arg2, arg3) as void
    logger = m.global.logger
    if logger.logLevel < 0
        return
    end if
    line = "[ERROR]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3)
    logger.logLine = line
    telemetry = m.global.telemetry
    if telemetry <> invalid
        telemetry.LogError = line
    end if
end function

function LogWarnNoTelemetry9(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) as void
    logger = m.global.logger
    if logger.logLevel < 1
        return
    end if
    line = "[WARN]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4) + " " + ToString(arg5) + " " + ToString(arg6) + " " + ToString(arg7) + " " + ToString(arg8)
    logger.logLine = line
end function

function LogInfo14(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13) as void
    logger = m.global.logger
    if logger.logLevel < 2
        return
    end if
    line = "[INFO]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4) + " " + ToString(arg5) + " " + ToString(arg6) + " " + ToString(arg7) + " " + ToString(arg8) + " " + ToString(arg9) + " " + ToString(arg10) + " " + ToString(arg11) + " " + ToString(arg12) + " " + ToString(arg13)
    logger.logLine = line
end function

function LogErrorNoTelemetry5(arg0, arg1, arg2, arg3, arg4) as void
    logger = m.global.logger
    if logger.logLevel < 0
        return
    end if
    line = "[ERROR]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4)
    logger.logLine = line
end function

function LogInfo9(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8) as void
    logger = m.global.logger
    if logger.logLevel < 2
        return
    end if
    line = "[INFO]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4) + " " + ToString(arg5) + " " + ToString(arg6) + " " + ToString(arg7) + " " + ToString(arg8)
    logger.logLine = line
end function

function LogInfo6(arg0, arg1, arg2, arg3, arg4, arg5) as void
    logger = m.global.logger
    if logger.logLevel < 2
        return
    end if
    line = "[INFO]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4) + " " + ToString(arg5)
    logger.logLine = line
end function

function LogWarnNoTelemetry7(arg0, arg1, arg2, arg3, arg4, arg5, arg6) as void
    logger = m.global.logger
    if logger.logLevel < 1
        return
    end if
    line = "[WARN]" + ToString(arg0) + " " + ToString(arg1) + " " + ToString(arg2) + " " + ToString(arg3) + " " + ToString(arg4) + " " + ToString(arg5) + " " + ToString(arg6)
    logger.logLine = line
end function
' End of auto-generated functions