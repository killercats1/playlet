'import "pkg:/source/utils/Types.bs"
function ErrorUtils_Format(error as dynamic) as string
    if error = invalid
        return "<invalid>"
    end if
    if IsString(error)
        return error
    end if
    if IsAssociativeArray(error) and error.DoesExist("message") and error.DoesExist("number") and error.DoesExist("backtrace")
        result = (bslib_toString(error.message) + " (0x" + bslib_toString(StrI(error.number, 16)) + "). backtrace:")
        for i = error.backtrace.count() - 1 to 0 step -1
            backtrace = error.backtrace[i]
            result += (chr(10) + "  " + bslib_toString(backtrace.function) + " @" + bslib_toString(backtrace.filename) + ":" + bslib_toString(backtrace.line_number))
        end for
        return result
    end if
    return (bslib_toString(error))
end function