'import "pkg:/source/utils/ArrayUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
function __RingBuffer_method_new(size as integer)
    m.array = invalid
    m.size = invalid
    m.index = invalid
    m.array = CreateObject("roArray", size, false)
    m.size = size
    m.index = 0
end function
function __RingBuffer_method_Push(tvalue as dynamic) as void
    if StringUtils_IsNullOrEmpty(tvalue)
        return
    end if
    m.array[m.index] = tvalue
    m.index = (m.index + 1) mod m.size
end function
function __RingBuffer_method_Contains(tvalue as dynamic) as boolean
    if StringUtils_IsNullOrEmpty(tvalue)
        return false
    end if
    return ArrayUtils_IndexOfString(m.array, tvalue) <> -1
end function
function __RingBuffer_builder()
    instance = {}
    instance.new = __RingBuffer_method_new
    instance.Push = __RingBuffer_method_Push
    instance.Contains = __RingBuffer_method_Contains
    return instance
end function
function RingBuffer(size as integer)
    instance = __RingBuffer_builder()
    instance.new(size)
    return instance
end function