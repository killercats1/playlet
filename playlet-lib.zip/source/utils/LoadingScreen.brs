function ShowLoadingScreen()
    m.global.loadingIndicator.visible = true
end function

function HideLoadingScreen()
    loadingIndicator = m.global.loadingIndicator
    loadingIndicator.visible = false
    if loadingIndicator.hasField("message")
        loadingIndicator.message = ""
    end if
end function

function CopyLoadingMessagesToCache()
    deviceInfo = CreateObject("roDeviceInfo")
    currentLocale = deviceInfo.GetCurrentLocale()
    if not CopyFile(("libpkg:/locale/" + bslib_toString(currentLocale) + "/loading-messages.json5"), "cachefs:/loading_messages_v1.json")
        CopyFile("libpkg:/locale/en_US/loading-messages.json5", "cachefs:/loading_messages_v1.json")
    end if
end function