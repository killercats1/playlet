'import "StringUtils.bs"
function ByteArrayUtils_Slice(bytearray as object, start_pos = 0 as dynamic, end_pos = invalid as dynamic) as object
    if FindMemberFunction(bytearray, "Slice") <> invalid
        start_pos = ValidInt(start_pos)
        if end_pos = invalid
            return bytearray.Slice(start_pos)
        end if
        return bytearray.Slice(start_pos, end_pos)
    end if
    return ByteArrayUtils_SliceFallback(bytearray, start_pos, end_pos)
end function

function ByteArrayUtils_SliceFallback(bytearray as object, start_pos = 0 as dynamic, end_pos = invalid as dynamic) as object
    copy = CreateObject("roByteArray")
    arrCount = bytearray.Count()
    
    if end_pos = invalid
        end_pos = arrCount
    end if
    start_pos = ValidInt(start_pos)
    
    if start_pos < 0
        start_pos = arrCount + start_pos
    end if
    
    if end_pos < 0
        end_pos = arrCount + end_pos
    end if
    
    if start_pos < 0
        start_pos = 0
    else if start_pos > arrCount
        start_pos = arrCount
    end if
    
    if end_pos < 0
        end_pos = 0
    else if end_pos > arrCount
        end_pos = arrCount
    end if
    count = end_pos - start_pos
    if count <= 0
        return copy
    end if
    tmp = ("tmp:/" + bslib_toString(StringUtils_RandomId()) + ".bin")
    if not bytearray.WriteFile(tmp, start_pos, count)
        DeleteFile(tmp)
        return copy
    end if
    copy.ReadFile(tmp)
    DeleteFile(tmp)
    return copy
end function