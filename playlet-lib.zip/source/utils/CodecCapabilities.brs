' YouTube serves streams above 1080p only as AV1 (mp4) and VP9 (webm), and the
' player only plays fragmented MP4 in DASH - so AV1 decoding is what decides
' whether the device can play 4K.
function CodecCapabilities_CanDecodeAv1() as boolean
    devInfo = CreateObject("roDeviceInfo")
    canDecode = devInfo.CanDecodeVideo({
        "codec": "av1"
    })
    return canDecode.result = true
end function