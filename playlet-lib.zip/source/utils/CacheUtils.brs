'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
function CacheUtils_Clear(jobQueue as object)
    JobSystem_QueueJob(jobQueue, "ClearCacheJob")
end function