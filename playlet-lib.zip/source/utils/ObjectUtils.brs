function ObjectUtils_Dig(obj as object, keys as object) as object
    if obj = invalid
        return invalid
    end if
    for each key in keys
        if (GetInterface(obj, "ifAssociativeArray") <> invalid) and (GetInterface(key, "ifString") <> invalid) and obj.DoesExist(key)
            obj = obj[key]
            continue for
        end if
        if (GetInterface(obj, "ifArray") <> invalid) and (GetInterface(key, "ifInt") <> invalid) and key >= 0 and key < obj.Count()
            obj = obj[key]
            continue for
        end if
        return invalid
    end for
    return obj
end function

function ObjectUtils_DigUnsafe(obj as object, keys as object) as object
    for each key in keys
        if obj <> invalid
            obj = obj[key]
            continue for
        end if
        return invalid
    end for
    return obj
end function

function ObjectUtils_DigWithDefault(obj as object, keys as object, defaultValue as dynamic) as dynamic
    result = ObjectUtils_Dig(obj, keys)
    if result = invalid
        return defaultValue
    end if
    return result
end function