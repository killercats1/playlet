'import "pkg:/source/utils/MessagePortUtils.bs"
'import "pkg:/source/utils/Types.bs"
function CancellationUtils_CreateCancellation(node as dynamic, field as string, value as dynamic) as dynamic
    if node = invalid or field = invalid
        return invalid
    end if
    return {
        "node": node
        "field": field
        "value": value
    }
end function

function CancellationUtils_IsCancelled(cancellation as dynamic) as boolean
    if cancellation = invalid or cancellation.node = invalid or cancellation.field = invalid
        return false
    end if
    return cancellation.node[cancellation.field] = cancellation.value
end function

function CancellationUtils_ObserveCancellationScoped(cancellation as dynamic, messagePort as dynamic) as void
    if cancellation = invalid or cancellation.node = invalid or cancellation.field = invalid
        return
    end if
    MessagePortUtils_ObserveFieldScopedExSafe(cancellation.node, cancellation.field, messagePort)
end function

function CancellationUtils_UnobserveCancellationScoped(cancellation as dynamic) as void
    if cancellation = invalid or cancellation.node = invalid or cancellation.field = invalid
        return
    end if
    cancellation.node.UnobserveFieldScoped(cancellation.field)
end function

function CancellationUtils_IsCancellationEvent(cancellation as dynamic, message as dynamic) as boolean
    messageType = type(message)
    if messageType <> "roSGNodeEvent"
        return false
    end if
    if cancellation = invalid or cancellation.node = invalid or cancellation.field = invalid
        return false
    end if
    node = message.getRoSGNode()
    if node = invalid or not node.isSameNode(cancellation.node)
        return false
    end if
    return cancellation.field = message.getField() and cancellation.value = message.getData()
end function