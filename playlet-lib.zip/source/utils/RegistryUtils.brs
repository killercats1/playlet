












' "invidious_instances" is deprecated, but we keep for migration purposes

' "invidious_token" is deprecated, but we keep for migration purposes


function RegistryUtils_Read(key as string, sectionName = "Playlet" as string) as dynamic
    section = CreateObject("roRegistrySection", sectionName)
    if section.Exists(key)
        return section.Read(key)
    end if
    return invalid
end function

function RegistryUtils_Write(key as string, value as string, sectionName = "Playlet" as string)
    section = CreateObject("roRegistrySection", sectionName)
    section.Write(key, value)
    section.Flush()
end function

function RegistryUtils_Delete(key as string, sectionName = "Playlet" as string)
    section = CreateObject("roRegistrySection", sectionName)
    section.Delete(key)
    section.Flush()
end function

function RegistryUtils_ReadAll() as object
    result = {}
    registry = CreateObject("roRegistry")
    sectionNames = registry.GetSectionList()
    for each sectionName in sectionNames
        section = CreateObject("roRegistrySection", sectionName)
        keys = section.GetKeyList()
        values = section.ReadMulti(keys)
        result[sectionName] = values
    end for
    return result
end function

function RegistryUtils_WriteAll(values as object) as void
    RegistryUtils_DeleteAll()
    for each sectionName in values
        section = CreateObject("roRegistrySection", sectionName)
        section.WriteMulti(values[sectionName])
        section.Flush()
    end for
end function

function RegistryUtils_DeleteAll() as void
    registry = CreateObject("roRegistry")
    sectionNames = registry.GetSectionList()
    for each sectionName in sectionNames
        registry.Delete(sectionName)
    end for
    registry.Flush()
end function