'import "Types.bs"
' Helper function convert seconds to [hh:]mm:ss format
' GetFormattedTime(138) returns 2:18
function TimeUtils_GetFormattedTime(length as dynamic) as string
    if length = invalid or length <= 0
        return ""
    end if
    hours = length \ 3600
    minutes = (length \ 60) mod 60
    seconds = length mod 60
    seconds = seconds.ToStr("%02d")
    if hours > 0
        minutes = minutes.ToStr("%02d")
    else
        minutes = minutes.ToStr()
    end if
    formattedTime = minutes + ":" + seconds
    if hours > 0
        formattedTime = hours.ToStr() + ":" + formattedTime
    end if
    return formattedTime
end function

function TimeUtils_Now() as object
    this = m.now
    if this = invalid
        this = CreateObject("roDateTime")
        m.now = this
    end if
    this.mark()
    return this
end function

function TimeUtils_RFC1123_Date(when as object) as string
    wd = when.getWeekday().left(3)
    dom = when.getDayOfMonth()
    mon = Ucase(TimeUtils_MonthStr(when.getMonth()).left(3))
    yr = when.getYear()
    hr = when.getHours()
    mn = when.getMinutes()
    sc = when.getSeconds()
    date = (bslib_toString(wd) + ", " + bslib_toString(dom) + " " + bslib_toString(mon) + " " + bslib_toString(yr) + " " + bslib_toString(hr) + ":" + bslib_toString(mn) + ":" + bslib_toString(sc) + " GMT" + chr(34))
    return date
end function

function TimeUtils_MonthStr(mNum as integer) as string
    ma = m.Num2Month
    if ma = invalid
        ma = [
            "jan"
            "feb"
            "mar"
            "apr"
            "may"
            "jun"
            "jul"
            "aug"
            "sep"
            "oct"
            "nov"
            "dec"
        ]
        m.Num2Month = ma
    end if
    return ValidString(ma[mNum - 1])
end function