function NodeSetFocus(node as object, focus as boolean) as void
    if node = invalid
        return
    end if
    if node.hasField("focus")
        node.focus = focus
        return
    end if
    
    node.SetFocus(focus)
end function

function GetFocusedNode() as object
    node = m.top.getScene()
    while true
        child = node.focusedChild
        if child <> invalid and not node.isSameNode(child)
            node = child
        else
            exit while
        end if
    end while
    return node
end function