'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"


function UrlUtils_BuildUrl(url as string, pathParams as object, queryParams as object) as string
    url = UrlUtils_SetPathParams(url, pathParams)
    url = UrlUtils_AppendQueryParams(url, queryParams)
    return url
end function

function UrlUtils_SetPathParams(url as string, pathParams as object) as string
    if pathParams = invalid
        return url
    end if
    for each key in pathParams
        value = pathParams[key]
        if value = invalid
            continue for
        end if
        if not IsString(value)
            value = (bslib_toString(value))
        end if
        url = url.Replace(("{" + bslib_toString(key) + "}"), value.EncodeUriComponent())
    end for
    return url
end function

function UrlUtils_SetQueryParams(url as string, queryParams as object) as string
    questionMarkIndex = url.InStr("?")
    if questionMarkIndex <> -1
        url = url.Left(questionMarkIndex)
    end if
    return UrlUtils_AppendQueryParams(url, queryParams)
end function

function UrlUtils_AppendQueryParams(url as string, queryParams as object) as string
    if queryParams = invalid or queryParams.Count() = 0
        return url
    end if
    hasQueryParams = url.InStr("?") <> -1
    for each key in queryParams
        value = queryParams[key]
        if value = invalid
            continue for
        end if
        if hasQueryParams
            url += "&" + UrlUtils_GetEncodedQueryParam(key, value)
        else
            url += "?" + UrlUtils_GetEncodedQueryParam(key, value)
            hasQueryParams = true
        end if
    end for
    return url
end function

function UrlUtils_GetUrlEncodedForm(fields as object) as string
    form = ""
    if IsArray(fields)
        for each item in fields
            key = item.key
            value = item.value
            if key = invalid or value = invalid
                continue for
            end if
            if form <> ""
                form += "&"
            end if
            if not IsString(value)
                value = (bslib_toString(value))
            end if
            form += key.EncodeUriComponent() + "=" + value.EncodeUriComponent()
        end for
    else if IsAssociativeArray(fields)
        for each key in fields
            value = fields[key]
            if value = invalid
                continue for
            end if
            if form <> ""
                form += "&"
            end if
            if not IsString(value)
                value = (bslib_toString(value))
            end if
            form += key.EncodeUriComponent() + "=" + value.EncodeUriComponent()
        end for
    end if
    return form
end function

function UrlUtils_GetUrlDecodedForm(body as string) as object
    fields = {}
    components = body.split("&")
    for each component in components
        keyValue = component.split("=")
        key = keyValue[0].DecodeUriComponent()
        value = keyValue[1].DecodeUriComponent()
        fields[key] = value
    end for
    return fields
end function

function UrlUtils_GetEncodedQueryParam(key as string, value as dynamic) as string
    if IsString(value)
        return key.EncodeUriComponent() + "=" + value.EncodeUriComponent()
    else if IsAssociativeArray(value) and IsArray(value.value)
        return UrlUtils_GetEncodedQueryParamArray(key, value)
    else
        value = (bslib_toString(value))
        return key.EncodeUriComponent() + "=" + value.EncodeUriComponent()
    end if
end function

function UrlUtils_GetEncodedQueryParamArray(key as string, value as object) as string
    if value.arrayType = "Repeated"
        return UrlUtils_GetEncodedQueryParamArrayRepeated(key, value)
    else if value.arrayType = "CommaSeparated"
        return UrlUtils_GetEncodedQueryParamArrayCommaSeparated(key, value)
    else
        throw "Invalid query param array type"
    end if
end function

function UrlUtils_GetEncodedQueryParamArrayRepeated(key as string, value as object) as string
    repeatedParams = []
    valueArray = value.value
    key = key.EncodeUriComponent()
    for each item in valueArray
        if not IsString(item)
            item = (bslib_toString(item))
        end if
        repeatedParams.push(key + "=" + item.EncodeUriComponent())
    end for
    return repeatedParams.join("&")
end function

function UrlUtils_GetEncodedQueryParamArrayCommaSeparated(key as string, value as object) as string
    valueArray = value.value
    key = key.EncodeUriComponent()
    for i = 0 to valueArray.Count() - 1
        item = valueArray[i]
        if not IsString(item)
            item = (bslib_toString(item))
        end if
        valueArray[i] = item.EncodeUriComponent()
    end for
    return key + "=" + valueArray.join(",")
end function

function UrlUtils_ParseQueryComponents(url as string) as object
    query = {}
    index = Instr(0, url, "?")
    url = Mid(url, index + 1)
    components = url.split("&")
    for each component in components
        key = component
        value = ""
        hasValue = false
        equalSignIndex = component.InStr("=")
        if equalSignIndex <> -1
            key = component.Left(equalSignIndex)
            value = component.Mid(equalSignIndex + 1).DecodeUriComponent()
            hasValue = true
        end if
        if query.DoesExist(key) and hasValue
            oldValue = query[key]
            if GetInterface(oldValue, "ifArray") = invalid
                oldValue = [
                    oldValue
                ]
            end if
            oldValue.push(value.DecodeUriComponent())
            value = oldValue
        end if
        if key <> ""
            query[key] = value
        end if
    end for
    return query
end function

' Parses the URL into protocol, host, port, and path
function UrlUtils_ParseUrl(url as string) as object
    protocol = invalid
    port = invalid
    path = "/"
    index = url.InStr("://")
    if index > 0
        protocol = url.Left(index)
        url = url.Mid(index + 3)
    else
        protocol = "http"
    end if
    index = url.InStr("/")
    if index > 0
        host = url.Left(index)
        path = url.Mid(index)
    else
        host = url
    end if
    index = host.InStr(":")
    if index > 0
        port = host.Mid(index + 1)
        host = host.Left(index)
    else
        if protocol = "http"
            port = "80"
        else if protocol = "https"
            port = "443"
        end if
    end if
    return {
        protocol: protocol
        host: host
        port: port
        path: path
    }
end function

function UrlUtils_BuildUrlFromParts(parts as object) as string
    url = ""
    if not StringUtils_IsNullOrEmpty(parts.protocol)
        url += parts.protocol + "://"
    end if
    if not StringUtils_IsNullOrEmpty(parts.host)
        url += parts.host
    end if
    if (not StringUtils_IsNullOrEmpty(parts.port)) and ((parts.protocol = "http" and parts.port <> "80") or (parts.protocol = "https" and parts.port <> "443") or (parts.protocol <> "http" and parts.protocol <> "https"))
        url += ":" + parts.port
    end if
    if not StringUtils_IsNullOrEmpty(parts.path)
        if not parts.path.StartsWith("/")
            url += "/"
        end if
        url += parts.path
    end if
    return url
end function