function FuncName(func as Function) as string
    return (LCase((bslib_toString(func)))).replace("function:", "").trim()
end function

' Returns true if the given object is of type Bool, false otherwise
function IsBool(obj as dynamic) as boolean
    return obj <> invalid and GetInterface(obj, "ifBoolean") <> invalid
end function

' Returns the given object if it is of type Bool, otherwise returns the default value `false`
function ValidBool(obj as dynamic) as boolean
    if obj <> invalid and GetInterface(obj, "ifBoolean") <> invalid
        return obj
    else
        return false
    end if
end function

' Returns true if the given object is of type Int, false otherwise
function IsInt(obj as dynamic) as boolean
    return obj <> invalid and GetInterface(obj, "ifInt") <> invalid
end function

' Returns the given object if it is of type Int, otherwise returns the default value `0%`
function ValidInt(obj as dynamic) as integer
    if obj <> invalid and GetInterface(obj, "ifInt") <> invalid
        return obj
    else
        return 0%
    end if
end function

' Returns true if the given object is of type Float, false otherwise
function IsFloat(obj as dynamic) as boolean
    return obj <> invalid and GetInterface(obj, "ifFloat") <> invalid
end function

' Returns the given object if it is of type Float, otherwise returns the default value `0!`
function ValidFloat(obj as dynamic) as float
    if obj <> invalid and GetInterface(obj, "ifFloat") <> invalid
        return obj
    else
        return 0!
    end if
end function

' Returns true if the given object is of type Double, false otherwise
function IsDouble(obj as dynamic) as boolean
    return obj <> invalid and GetInterface(obj, "ifDouble") <> invalid
end function

' Returns the given object if it is of type Double, otherwise returns the default value `0#`
function ValidDouble(obj as dynamic) as double
    if obj <> invalid and GetInterface(obj, "ifDouble") <> invalid
        return obj
    else
        return 0#
    end if
end function

' Returns true if the given object is numeric (Integer, LongInteger, Float, or Double)
function IsNumber(obj as dynamic) as boolean
    return obj <> invalid and (GetInterface(obj, "ifInt") <> invalid or GetInterface(obj, "ifLongInt") <> invalid or GetInterface(obj, "ifFloat") <> invalid or GetInterface(obj, "ifDouble") <> invalid)
end function

' Returns true if the given object is of type String, false otherwise
function IsString(obj as dynamic) as boolean
    return obj <> invalid and GetInterface(obj, "ifString") <> invalid
end function

' Returns the given object if it is of type String, otherwise returns the default value `""`
function ValidString(obj as dynamic) as string
    if obj <> invalid and GetInterface(obj, "ifString") <> invalid
        return obj
    else
        return ""
    end if
end function

' Returns true if the given object is of type Array, false otherwise
function IsArray(obj as dynamic) as boolean
    return obj <> invalid and GetInterface(obj, "ifArray") <> invalid
end function

' Returns the given object if it is of type Array, otherwise returns the default value `CreateObject("roArray", 0, true)`
function ValidArray(obj as dynamic) as object
    if obj <> invalid and GetInterface(obj, "ifArray") <> invalid
        return obj
    else
        return CreateObject("roArray", 0, true)
    end if
end function

' Returns true if the given object is of type AssociativeArray, false otherwise
function IsAssociativeArray(obj as dynamic) as boolean
    return obj <> invalid and GetInterface(obj, "ifAssociativeArray") <> invalid
end function

' Returns the given object if it is of type AssociativeArray, otherwise returns the default value `{}`
function ValidAssociativeArray(obj as dynamic) as object
    if obj <> invalid and GetInterface(obj, "ifAssociativeArray") <> invalid
        return obj
    else
        return {}
    end if
end function

' Returns true if the given object is of type ByteArray, false otherwise
function IsByteArray(obj as dynamic) as boolean
    return obj <> invalid and GetInterface(obj, "ifByteArray") <> invalid
end function

' Returns true if the given object is of type Function, false otherwise
function IsFunction(obj as dynamic) as boolean
    return obj <> invalid and GetInterface(obj, "ifFunction") <> invalid
end function

' Returns true if the given object is of type Node, false otherwise
function IsNode(obj as dynamic) as boolean
    return obj <> invalid and GetInterface(obj, "ifSGNodeDict") <> invalid
end function