' DISABLE_CACHE will disable all caching for all requests.
' Only use this for debugging purposes.
' NETWORK_THROTTLE will add a random delay to all requests to simulate network latency.
' Only use this for debugging purposes.
'import "pkg:/source/services/HttpCache.bs"
'import "pkg:/source/utils/AssertUtils.bs"
'import "pkg:/source/utils/CancellationUtils.bs"
'import "pkg:/source/utils/ErrorUtils.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
'import "pkg:/source/utils/UrlUtils.bs"
' A Request holds what to send. Sending it starts a Fetch, which ends in one Response:
'
'   response = HttpClient.Get(url).Await()                ' blocks until the response
'
'   pending = HttpClient.Get(url).Send()                  ' a Fetch on a port of its own
'   response = pending.Wait(2000)                         ' the response, or invalid after 2s; the fetch goes on
'   response = pending.Poll()                             ' the response, or invalid; never blocks
'
'   pending = HttpClient.Post(url).SendOn(port)           ' in a task loop: a Fetch on the loop's own port
'   while true
'       message = wait(pending.MaxWaitMs(), port)         ' wakes for the answer, the attempt's deadline or a retry
'       response = pending.Handle(message)                ' the response once it is in; the loop's messages are ignored
'       ...                                               ' the loop's own messages
'       if response <> invalid then exit while
'
' Retries run inside the fetch, on the thread that started it, while Await, Wait, Poll or Handle runs.



' The id of every cancellation observer, which tells its events from the other node events on a shared port.

' https://developer.roku.com/en-ca/docs/references/brightscript/events/rourlevent.md#getresponsecode-as-integer
' Seem to mirror the curl error codes https://curl.se/libcurl/c/libcurl-errors.html


function HttpClient_Get(url as string) as object
    return HttpClient_Request("GET", url)
end function

function HttpClient_Head(url as string) as object
    return HttpClient_Request("HEAD", url)
end function

function HttpClient_Post(url as string) as object
    return HttpClient_Request("POST", url)
end function

function HttpClient_Put(url as string) as object
    return HttpClient_Request("PUT", url)
end function

function HttpClient_Delete(url as string) as object
    return HttpClient_Request("DELETE", url)
end function
function __HttpClient_Request_method_new(method as string, url as string)
    m._method = UCase(method)
    m._url = url
    m._headers = {}
    m._attemptTimeoutMs = 30000
    m._retryCount = 0
    m._retryDelayMs = 1000
end function
function __HttpClient_Request_method_Header(key as string, value as string) as object
    m._headers[key] = value
    return m
end function
function __HttpClient_Request_method_Headers(headers as object) as object
    m._headers.Append(headers)
    return m
end function
function __HttpClient_Request_method_QueryParam(key as string, value as dynamic) as object
    if m._queryParams = invalid
        m._queryParams = {}
    end if
    m._queryParams[key] = value
    m._fullUrl = invalid
    return m
end function
function __HttpClient_Request_method_QueryParams(queryParams as object) as object
    if m._queryParams = invalid
        m._queryParams = {}
    end if
    m._queryParams.Append(queryParams)
    m._fullUrl = invalid
    return m
end function
function __HttpClient_Request_method_QueryParamArray(key as string, values as object, arrayType as object) as object
    return m.QueryParam(key, {
        value: values
        arrayType: arrayType
    })
end function
function __HttpClient_Request_method_PathParam(key as string, value as string) as object
    if m._pathParams = invalid
        m._pathParams = {}
    end if
    m._pathParams[key] = value
    m._fullUrl = invalid
    return m
end function
function __HttpClient_Request_method_PathParams(pathParams as object) as object
    if m._pathParams = invalid
        m._pathParams = {}
    end if
    m._pathParams.Append(pathParams)
    m._fullUrl = invalid
    return m
end function
function __HttpClient_Request_method_TextBody(text as string) as object
    m._textBody = text
    m._fileBodyPath = invalid
    return m
end function
function __HttpClient_Request_method_JsonBody(value as object) as object
    m._textBody = FormatJson(value)
    m._fileBodyPath = invalid
    m._headers["Content-Type"] = "application/json"
    return m
end function
function __HttpClient_Request_method_FormBody(fields as object) as object
    m._textBody = UrlUtils_GetUrlEncodedForm(fields)
    m._fileBodyPath = invalid
    m._headers["Content-Type"] = "application/x-www-form-urlencoded"
    return m
end function
function __HttpClient_Request_method_FileBody(filePath as string) as object
    m._fileBodyPath = filePath
    m._textBody = invalid
    return m
end function
function __HttpClient_Request_method_AttemptTimeoutMs(timeoutMs as integer) as object
    m._attemptTimeoutMs = timeoutMs
    return m
end function
function __HttpClient_Request_method_RetryCount(retryCount as integer) as object
    m._retryCount = retryCount
    return m
end function
function __HttpClient_Request_method_RetryDelayMs(delayMs as integer) as object
    m._retryDelayMs = delayMs
    return m
end function
function __HttpClient_Request_method_RetryIf(predicate as Function) as object
    m._retryPredicate = predicate
    return m
end function
function __HttpClient_Request_method_NoTelemetry() as object
    m._noTelemetry = true
    return m
end function
function __HttpClient_Request_method_CacheForSeconds(seconds as integer) as object
    m._cacheSeconds = seconds
    return m
end function
function __HttpClient_Request_method_NoCache() as object
    m._noCache = true
    return m
end function
function __HttpClient_Request_method_SaveBodyToFile(filePath as string) as object
    m._saveBodyToFilePath = filePath
    return m
end function
function __HttpClient_Request_method_Cancellation(cancellation as dynamic) as object
    m._cancellation = cancellation
    return m
end function
function __HttpClient_Request_method_LogCurlCommand(enabled = true as boolean) as object
    m._logCurlCommand = enabled
    return m
end function
function __HttpClient_Request_method_GetFullUrl() as string
    if m._fullUrl = invalid
        m._fullUrl = UrlUtils_BuildUrl(m._url, m._pathParams, m._queryParams)
    end if
    return m._fullUrl
end function
function __HttpClient_Request_method_GetMethod() as string
    return m._method
end function
function __HttpClient_Request_method_GetHeaders() as object
    return m._headers
end function
function __HttpClient_Request_method_GetTextBody() as dynamic
    return m._textBody
end function
function __HttpClient_Request_method_ToCurlCommand() as string
    command = ("curl " + chr(34) + bslib_toString(m.GetFullUrl()) + chr(34))
    if m._method = "HEAD"
        command += (" " + chr(92) + chr(10) + "  --head")
    else if m._method <> "GET"
        command += (" " + chr(92) + chr(10) + "  --request " + bslib_toString(m._method))
    end if
    command += (" " + chr(92) + chr(10) + "  --max-time " + bslib_toString(m._attemptTimeoutMs / 1000))
    command += (" " + chr(92) + chr(10) + "  --location " + chr(92) + chr(10) + "  --show-error")
    if true
        command += (" " + chr(92) + chr(10) + "  --compressed")
    end if
    for each key in m._headers
        value = m._headers[key]
        if LCase(key) = "authorization"
            value = "<REDACTED>"
        end if
        command += (" " + chr(92) + chr(10) + "  -H '" + bslib_toString(key) + ": " + bslib_toString(value) + "'")
    end for
    if not StringUtils_IsNullOrEmpty(m._textBody)
        command += (" " + chr(92) + chr(10) + "  -d '" + bslib_toString(m._textBody) + "'")
    end if
    if m._fileBodyPath <> invalid
        command += (" " + chr(92) + chr(10) + "  --data-binary @" + bslib_toString(m._fileBodyPath))
    end if
    return command
end function
function __HttpClient_Request_method_Await() as object
    return m.Send().Await()
end function
function __HttpClient_Request_method_Send() as object
    return m.StartFetch(CreateObject("roMessagePort"), true)
end function
function __HttpClient_Request_method_SendOn(messagePort as object) as object
    return m.StartFetch(messagePort, false)
end function
function __HttpClient_Request_method_StartFetch(messagePort as object, ownsPort as boolean) as object
    
    cancellationObserver = invalid
    if m._cancellation <> invalid
        cancellationObserver = CreateObject("roSGNode", "NodeObserver")
        cancellationObserver.id = "HttpClient.CancellationObserver"
        
        cancellationObserver.ObserveField("changed", messagePort)
        cancellationObserver.target = {
            node: m._cancellation.node
            fieldName: m._cancellation.field
        }
    end if
    startedFetch = HttpClient_Fetch(m, messagePort)
    startedFetch.Start()
    return HttpClient_PendingResponse(startedFetch, messagePort, ownsPort, m._cancellation, cancellationObserver)
end function
function __HttpClient_Request_builder()
    instance = {}
    ' For any method, such as a proxied request's; Get, Head, Post, Put and Delete are shorter.
    instance.new = __HttpClient_Request_method_new
    instance.Header = __HttpClient_Request_method_Header
    instance.Headers = __HttpClient_Request_method_Headers
    instance.QueryParam = __HttpClient_Request_method_QueryParam
    instance.QueryParams = __HttpClient_Request_method_QueryParams
    instance.QueryParamArray = __HttpClient_Request_method_QueryParamArray
    ' Fills {key} in the url.
    instance.PathParam = __HttpClient_Request_method_PathParam
    instance.PathParams = __HttpClient_Request_method_PathParams
    instance.TextBody = __HttpClient_Request_method_TextBody
    instance.JsonBody = __HttpClient_Request_method_JsonBody
    ' fields: an AA, or an array of { key, value } where the order matters.
    instance.FormBody = __HttpClient_Request_method_FormBody
    instance.FileBody = __HttpClient_Request_method_FileBody
    ' How long one attempt may take, from when it is sent. The deadline is checked only when the response is
    ' waited on or polled, after the answer already in, if any: that answer is returned even if it came after the
    ' deadline, as an roUrlEvent carries no arrival time. Await and Wait time out on time; a late Poll can return
    ' a late answer, for the caller to judge whether it is too stale.
    instance.AttemptTimeoutMs = __HttpClient_Request_method_AttemptTimeoutMs
    ' How many more attempts may follow a failed one. A timed-out attempt is never retried: after AttemptTimeoutMs
    ' the user needs an answer, not another wait. The first attempt is retried on any failure (anything not 2xx
    ' or 3xx) except a request roUrlTransfer couldn't send, which completes at once; a later one only on a 5xx or a
    ' network failure, as a 2xx-4xx answer to a retry is final. RetryIf picks among those.
    instance.RetryCount = __HttpClient_Request_method_RetryCount
    ' Each retry is sent delayMs to 2 × delayMs after the previous attempt ended.
    instance.RetryDelayMs = __HttpClient_Request_method_RetryDelayMs
    ' Picks the attempts to retry instead of every failed one: predicate(response) returns the reason to retry,
    ' which the retry's warning reports, or "" or invalid not to. It sees the attempts RetryCount allows to retry,
    ' the first one's success included. A cancelled fetch never retries. A predicate that throws is logged as an
    ' error, and its attempt retries if it failed; DEBUG builds rethrow.
    instance.RetryIf = __HttpClient_Request_method_RetryIf
    ' A retried attempt, or a failure RetryIf declines to retry, is logged without a telemetry event: for requests
    ' where failing and retrying is normal.
    instance.NoTelemetry = __HttpClient_Request_method_NoTelemetry
    ' A successful GET is served from disk for that many seconds, instead of its Cache-Control max-age.
    instance.CacheForSeconds = __HttpClient_Request_method_CacheForSeconds
    ' A successful GET is served from disk for its Cache-Control max-age by default; NoCache turns that off,
    ' CacheForSeconds included.
    instance.NoCache = __HttpClient_Request_method_NoCache
    ' The response's body goes to filePath instead of its Text.
    instance.SaveBodyToFile = __HttpClient_Request_method_SaveBodyToFile
    ' cancellation: from CancellationUtils.CreateCancellation, or invalid for none.
    instance.Cancellation = __HttpClient_Request_method_Cancellation
    instance.LogCurlCommand = __HttpClient_Request_method_LogCurlCommand
    ' The url as given, with its path params filled in and its query params appended.
    instance.GetFullUrl = __HttpClient_Request_method_GetFullUrl
    instance.GetMethod = __HttpClient_Request_method_GetMethod
    instance.GetHeaders = __HttpClient_Request_method_GetHeaders
    ' invalid when the body is a file, or there is none.
    instance.GetTextBody = __HttpClient_Request_method_GetTextBody
    instance.ToCurlCommand = __HttpClient_Request_method_ToCurlCommand
    instance.Await = __HttpClient_Request_method_Await
    ' Starts a fetch on a port of its own, which Await, Wait or Poll runs: a request never waited on or polled may
    ' be dropped when its task ends, and its retries never run.
    instance.Send = __HttpClient_Request_method_Send
    ' Starts a fetch on a task loop's port: the loop caps each wait with MaxWaitMs and hands Handle every message
    ' it takes, so it wakes as soon as the answer is in, and the fetch's deadline and retries run on time.
    instance.SendOn = __HttpClient_Request_method_SendOn
    instance.StartFetch = __HttpClient_Request_method_StartFetch
    return instance
end function
function HttpClient_Request(method as string, url as string)
    instance = __HttpClient_Request_builder()
    instance.new(method, url)
    return instance
end function
' A request being sent: its attempts, timeouts, retries and cache, run by the PendingResponse that Send or SendOn
' returns. It reads the request as it goes, so the request isn't changed after it is sent. Of the messages it is
' handed, it takes only its current attempt's answer.
function __HttpClient_Fetch_method_new(request as object, messagePort as object)
    m._request = request
    m._messagePort = messagePort
    m._attemptCount = 0
    m._transferId = invalid
end function
function __HttpClient_Fetch_method_Start() as void
    m._clock = CreateObject("roTimespan")
    request = m._request
    if CancellationUtils_IsCancelled(request._cancellation)
        m.Cancel()
        return
    end if
    cacheable = request._method = "GET" and request._noCache <> true
    if cacheable
        m._cacheFilePath = HttpCache_GetFilePath(request.GetFullUrl(), request._headers, request._saveBodyToFilePath)
        cached = HttpCache_Read(m._cacheFilePath, request._saveBodyToFilePath)
        if cached <> invalid
            m._response = m.NewResponse({
                cached: true
                statusCode: cached.statusCode
                headers: cached.headers
                text: cached.text
                bodyFilePath: request._saveBodyToFilePath
            })
            LogInfo4("[HttpClient.bs:453]", "Cache hit", request._method, request.GetFullUrl())
            m.Throttle()
            return
        end if
    end if
    m.StartAttempt()
end function
function __HttpClient_Fetch_method_MaxWaitMs() as integer
    if m._response <> invalid
        return 1
    end if
    if m._urlTransfer <> invalid
        waitMs = m._attemptDeadlineMs - m._clock.TotalMilliseconds()
    else
        waitMs = m._retryAtMs - m._clock.TotalMilliseconds()
    end if
    if waitMs < 1
        return 1
    end if
    return waitMs
end function
function __HttpClient_Fetch_method_HandleMessage(message as dynamic) as dynamic
    if m._response = invalid
        
        if type(message) = "roUrlEvent" and m._urlTransfer <> invalid and message.GetInt() = 1 and message.GetSourceIdentity() = m._urlTransfer.GetIdentity()
            m.OnAttemptEnded(m.NewResponse({
                urlEvent: message
                bodyFilePath: m._request._saveBodyToFilePath
            }))
        end if
        if m._urlTransfer <> invalid and m._clock.TotalMilliseconds() >= m._attemptDeadlineMs
            m.OnAttemptTimeout()
        end if
        if m._response = invalid and m._urlTransfer = invalid and m._clock.TotalMilliseconds() >= m._retryAtMs
            
            if CancellationUtils_IsCancelled(m._request._cancellation)
                m.Cancel()
            else
                m.StartAttempt()
            end if
        end if
    end if
    return m._response
end function
function __HttpClient_Fetch_method_Cancel() as void
    if m._response <> invalid
        return
    end if
    if m._urlTransfer <> invalid
        m._urlTransfer.AsyncCancel()
        m._urlTransfer = invalid
    else
        
        m._transferId = invalid
    end if
    LogInfo3("[HttpClient.bs:516]", "Cancelled", m.Describe())
    m.Complete(m.NewResponse({
        cancelled: true
    }))
end function
function __HttpClient_Fetch_method_StartAttempt() as void
    m._attemptCount += 1
    m._transferId = invalid
    request = m._request
    method = request._method
    urlTransfer = HttpClient_CreateUrlTransfer(request.GetFullUrl(), request._headers, m._messagePort)
    if urlTransfer = invalid
        LogError2("[HttpClient.bs:527]", "Failed to create roUrlTransfer")
        m.Throttle()
        m.Complete(m.NewResponse({
            notSentReason: "roUrlTransfer couldn't be created"
        }))
        return
    end if
    LogInfo6("[HttpClient.bs:533]", "Sending", method, request.GetFullUrl(), "ID:", urlTransfer.GetIdentity())
    if request._logCurlCommand = true
        LogInfo2("[HttpClient.bs:540]", ("======== curl command ========" + chr(10) + bslib_toString(request.ToCurlCommand()) + chr(10) + "=============================="))
    end if
    if method = "GET"
        if request._saveBodyToFilePath <> invalid
            sent = urlTransfer.AsyncGetToFile(request._saveBodyToFilePath)
        else
            sent = urlTransfer.AsyncGetToString()
        end if
    else if method = "HEAD"
        sent = urlTransfer.AsyncHead()
    else
        if method <> "POST"
            urlTransfer.SetRequest(method)
        end if
        if request._fileBodyPath <> invalid
            sent = urlTransfer.AsyncPostFromFile(request._fileBodyPath)
        else
            sent = urlTransfer.AsyncPostFromString(ValidString(request._textBody))
        end if
    end if
    if not sent
        LogError2("[HttpClient.bs:564]", "Failed to send request")
        m.Throttle()
        m.Complete(m.NewResponse({
            notSentReason: "roUrlTransfer refused the request"
        }))
        return
    end if
    m._urlTransfer = urlTransfer
    m._transferId = urlTransfer.GetIdentity()
    m._attemptDeadlineMs = m._clock.TotalMilliseconds() + request._attemptTimeoutMs
end function
function __HttpClient_Fetch_method_NewResponse(properties as object) as object
    properties.cancellation = m._request._cancellation
    return HttpClient_Response(properties)
end function
function __HttpClient_Fetch_method_OnAttemptTimeout() as void
    LogInfo6("[HttpClient.bs:581]", "Timeout", m.Describe(), "after", m._request._attemptTimeoutMs, "ms")
    m._urlTransfer.AsyncCancel()
    m.OnAttemptEnded(m.NewResponse({
        timedOut: true
    }))
end function
function __HttpClient_Fetch_method_OnAttemptEnded(response as object) as void
    m._urlTransfer = invalid
    m.Throttle()
    request = m._request
    
    if m._attemptCount > request._retryCount or not m.MayRetry(response) or (request._retryPredicate = invalid and response.IsSuccess())
        m.Complete(response)
        return
    end if
    
    if response.IsCancelled()
        m.Complete(response)
        return
    end if
    retryReason = m.RetryReason(response)
    if retryReason = ""
        if not response.IsSuccess()
            m.ReportAttempt(response.ErrorMessage(), (chr(10) + "Not retrying: the retry callback declined"))
        end if
        m.Complete(response)
        return
    end if
    delayMs = request._retryDelayMs + Rnd(request._retryDelayMs + 1) - 1
    m.ReportAttempt(retryReason, (chr(10) + "Retrying in " + bslib_toString(delayMs) + " ms"))
    m._retryAtMs = m._clock.TotalMilliseconds() + delayMs
end function
function __HttpClient_Fetch_method_ReportAttempt(message as string, outcome as string) as void
    request = m._request
    LogWarnNoTelemetry7("[HttpClient.bs:617]", m.Describe(), "attempt", m._attemptCount, "ended:", message, outcome)
    if request._noTelemetry = true
        return
    end if
    LogTelemetryEvent({
        level: "warning"
        message: message
        attachments: [
            {
                filename: "request.txt"
                content_type: "text/plain"
                data: request.ToCurlCommand()
            }
        ]
    })
end function
function __HttpClient_Fetch_method_Throttle() as void
end function
function __HttpClient_Fetch_method_MayRetry(response as object) as boolean
    if response.IsTimedOut()
        return false
    end if
    if m._attemptCount = 1
        return true
    end if
    statusCode = response.StatusCode()
    return statusCode < 200 or statusCode >= 500
end function
function __HttpClient_Fetch_method_RetryReason(response as object) as string
    
    retryPredicate = m._request._retryPredicate
    if retryPredicate = invalid
        return response.ErrorMessage()
    end if
    try
        reason = retryPredicate(response)
    catch error
        LogError3("[HttpClient.bs:666]", "RetryIf failed:", ErrorUtils_Format(error))
        return response.ErrorMessage()
    end try
    if not IsString(reason)
        return ""
    end if
    return reason
end function
function __HttpClient_Fetch_method_Describe() as string
    description = (bslib_toString(m._request._method) + " " + bslib_toString(m._request.GetFullUrl()))
    if m._transferId <> invalid
        description += (" ID: " + bslib_toString(m._transferId))
    end if
    return description
end function
function __HttpClient_Fetch_method_Complete(response as object) as void
    m._response = response
    LogInfo9("[HttpClient.bs:691]", "Completed", m.Describe(), response.StatusCode(), "after", m._clock.TotalMilliseconds(), "ms,", m._attemptCount, "attempt(s)")
    
    if m._cacheFilePath = invalid or response.StatusCode() < 200 or response.StatusCode() >= 300
        return
    end if
    
    body = ""
    if response._bodyFilePath = invalid
        body = response.Text()
        if body = ""
            return
        end if
    end if
    HttpCache_Write(m._cacheFilePath, m._request._cacheSeconds, response.StatusCode(), response.Headers(), body)
end function
function __HttpClient_Fetch_builder()
    instance = {}
    instance.new = __HttpClient_Fetch_method_new
    instance.Start = __HttpClient_Fetch_method_Start
    ' How long a wait on the port may last before the next HandleMessage: until the attempt's deadline while it is
    ' sent, until the retry is due between attempts, 1 once complete, as a cache hit, a request not sent and a
    ' cancellation before the first attempt complete with no message on the port. At least 1, as wait(0) has no
    ' time limit.
    instance.MaxWaitMs = __HttpClient_Fetch_method_MaxWaitMs
    ' message: what was taken from the port, invalid when nothing was. The deadline is checked after the message:
    ' an answer is taken even past the deadline; past it, any other message, or none, times the attempt out.
    ' Returns the response once the fetch completed, invalid until then.
    instance.HandleMessage = __HttpClient_Fetch_method_HandleMessage
    ' Completes the fetch as cancelled, unless it already completed.
    instance.Cancel = __HttpClient_Fetch_method_Cancel
    instance.StartAttempt = __HttpClient_Fetch_method_StartAttempt
    ' A response that reads the request's cancellation when asked whether it is cancelled.
    instance.NewResponse = __HttpClient_Fetch_method_NewResponse
    instance.OnAttemptTimeout = __HttpClient_Fetch_method_OnAttemptTimeout
    instance.OnAttemptEnded = __HttpClient_Fetch_method_OnAttemptEnded
    ' A warning, and a telemetry event unless NoTelemetry, for an attempt that could have been retried.
    instance.ReportAttempt = __HttpClient_Fetch_method_ReportAttempt
    ' NETWORK_THROTTLE: a cache hit, an attempt not sent, and every attempt's end come 1 to 3s late.
    instance.Throttle = __HttpClient_Fetch_method_Throttle
    ' The attempts RetryCount allows to retry: not a timed-out one; after the first, only a 5xx or a network failure.
    instance.MayRetry = __HttpClient_Fetch_method_MayRetry
    ' Why to retry the attempt, "" not to: RetryIf's reason, or else the failure's error message.
    instance.RetryReason = __HttpClient_Fetch_method_RetryReason
    ' The method and url, then the transfer ID of the attempt sent last, the RequestId of its error message: none
    ' for a cache hit, an attempt not sent, or a cancellation outside an attempt.
    instance.Describe = __HttpClient_Fetch_method_Describe
    instance.Complete = __HttpClient_Fetch_method_Complete
    return instance
end function
function HttpClient_Fetch(request as object, messagePort as object)
    instance = __HttpClient_Fetch_builder()
    instance.new(request, messagePort)
    return instance
end function
' A fetch on a port of its own (Send), which Await, Wait and Poll wait on, or on a task loop's port (SendOn), whose
' messages the loop hands to Handle. Each returns the same response once it is in. Whoever sends the request takes
' its response or calls Cancel(): either ends the observation of its cancellation.
function __HttpClient_PendingResponse_method_new(startedFetch as object, messagePort as object, ownsPort as boolean, cancellation as dynamic, cancellationObserver as dynamic)
    m._fetch = startedFetch
    m._messagePort = messagePort
    m._ownsPort = ownsPort
    m._cancellation = cancellation
    m._cancellationObserver = cancellationObserver
    m._clock = CreateObject("roTimespan")
end function
function __HttpClient_PendingResponse_method_Await() as object
    return m.WaitForResponse(-1)
end function
function __HttpClient_PendingResponse_method_Wait(timeoutMs as integer) as dynamic
    return m.WaitForResponse(timeoutMs)
end function
function __HttpClient_PendingResponse_method_Poll() as dynamic
    return m.WaitForResponse(0)
end function
function __HttpClient_PendingResponse_method_Handle(message as dynamic) as dynamic
    if m._response <> invalid
        return m._response
    end if
    if type(message) = "roSGNodeEvent" and message.GetNode() = "HttpClient.CancellationObserver" and CancellationUtils_IsCancelled(m._cancellation)
        m._fetch.Cancel()
    end if
    m._response = m._fetch.HandleMessage(message)
    if m._response <> invalid
        m.StopObservingCancellation()
    end if
    return m._response
end function
function __HttpClient_PendingResponse_method_MaxWaitMs() as integer
    return m._fetch.MaxWaitMs()
end function
function __HttpClient_PendingResponse_method_Cancel() as void
    m._fetch.Cancel()
    m.StopObservingCancellation()
end function
function __HttpClient_PendingResponse_method_WaitForResponse(timeoutMs as integer) as dynamic
    m._clock.Mark()
    
    response = m.Handle(m._messagePort.GetMessage())
    while response = invalid
        message = m._messagePort.GetMessage()
        if message = invalid
            waitMs = m.MaxWaitMs()
            if timeoutMs >= 0
                remainingMs = timeoutMs - m._clock.TotalMilliseconds()
                if remainingMs <= 0
                    return invalid
                end if
                if remainingMs < waitMs
                    waitMs = remainingMs
                end if
            end if
            message = wait(waitMs, m._messagePort)
        end if
        response = m.Handle(message)
    end while
    return response
end function
function __HttpClient_PendingResponse_method_StopObservingCancellation() as void
    if m._cancellationObserver <> invalid
        m._cancellationObserver.nodeDestroy = true
        m._cancellationObserver = invalid
    end if
end function
function __HttpClient_PendingResponse_builder()
    instance = {}
    instance.new = __HttpClient_PendingResponse_method_new
    instance.Await = __HttpClient_PendingResponse_method_Await
    ' The response, or invalid if it isn't in within timeoutMs.
    instance.Wait = __HttpClient_PendingResponse_method_Wait
    instance.Poll = __HttpClient_PendingResponse_method_Poll
    ' message: what the loop took from the port, invalid when its wait timed out. Returns the response once it is
    ' in, invalid until then.
    instance.Handle = __HttpClient_PendingResponse_method_Handle
    ' How long the loop may wait on the port before the next Handle; 1 once the response is in.
    instance.MaxWaitMs = __HttpClient_PendingResponse_method_MaxWaitMs
    instance.Cancel = __HttpClient_PendingResponse_method_Cancel
    ' timeoutMs: -1 for as long as it takes, 0 to take only what is already on the port.
    instance.WaitForResponse = __HttpClient_PendingResponse_method_WaitForResponse
    instance.StopObservingCancellation = __HttpClient_PendingResponse_method_StopObservingCancellation
    return instance
end function
function HttpClient_PendingResponse(startedFetch as object, messagePort as object, ownsPort as boolean, cancellation as dynamic, cancellationObserver as dynamic)
    instance = __HttpClient_PendingResponse_builder()
    instance.new(startedFetch, messagePort, ownsPort, cancellation, cancellationObserver)
    return instance
end function
function __HttpClient_Response_method_new(properties as object)
    m._urlEvent = properties.urlEvent
    m._statusCode = properties.statusCode
    m._headers = properties.headers
    m._text = properties.text
    m._bodyFilePath = properties.bodyFilePath
    m._cached = properties.cached = true
    m._timedOut = properties.timedOut = true
    m._cancelled = properties.cancelled = true
    m._cancellation = properties.cancellation
    m._notSentReason = properties.notSentReason
end function
function __HttpClient_Response_method_StatusCode() as integer
    if m._statusCode = invalid
        if m._urlEvent <> invalid
            m._statusCode = m._urlEvent.GetResponseCode()
        else
            m._statusCode = 0
        end if
    end if
    return m._statusCode
end function
function __HttpClient_Response_method_IsSuccess() as boolean
    statusCode = m.StatusCode()
    return statusCode >= 200 and statusCode < 400
end function
function __HttpClient_Response_method_IsTimedOut() as boolean
    return m._timedOut
end function
function __HttpClient_Response_method_IsCancelled() as boolean
    if not m._cancelled and CancellationUtils_IsCancelled(m._cancellation)
        m._cancelled = true
    end if
    return m._cancelled
end function
function __HttpClient_Response_method_IsCached() as boolean
    return m._cached
end function
function __HttpClient_Response_method_Headers() as object
    if m._headers = invalid
        if m._urlEvent <> invalid
            m._headers = m._urlEvent.GetResponseHeaders()
        else
            m._headers = {}
        end if
    end if
    return m._headers
end function
function __HttpClient_Response_method_RetryAfterSeconds() as dynamic
    retryAfter = m.Headers()["retry-after"]
    if not IsString(retryAfter)
        return invalid
    end if
    retryAfter = retryAfter.Trim()
    seconds = retryAfter.ToInt()
    if seconds < 0 or seconds.ToStr() <> retryAfter
        return invalid
    end if
    return seconds
end function
function __HttpClient_Response_method_Text() as string
    if m._text = invalid
        if m._urlEvent <> invalid
            m._text = m._urlEvent.GetString()
        else
            m._text = ""
        end if
    end if
    return m._text
end function
function __HttpClient_Response_method_Json() as dynamic
    if m._json = invalid
        m._json = StringUtils_ParseJsonSafe(m.Text())
    end if
    return m._json
end function
function __HttpClient_Response_method_ErrorMessage() as string
    if m.IsSuccess()
        return ""
    end if
    if m._notSentReason <> invalid
        return (bslib_toString(Tr("Request not sent.")) + " " + bslib_toString(m._notSentReason))
    end if
    if m.IsCancelled()
        return Tr("Request cancelled.")
    end if
    if m._timedOut
        return Tr("Request timed out.")
    end if
    
    if m._urlEvent = invalid
        message = ("StatusCode: " + bslib_toString(m.StatusCode()))
    else
        message = (bslib_toString(Tr("Reason")) + ":" + bslib_toString(m._urlEvent.GetFailureReason()) + chr(10) + "StatusCode: " + bslib_toString(m.StatusCode()) + chr(10) + "RequestId: " + bslib_toString(m._urlEvent.GetSourceIdentity()))
    end if
    if m._bodyFilePath = invalid
        message += (chr(10) + "Body: " + bslib_toString(m.Text()))
    end if
    return message
end function
function __HttpClient_Response_builder()
    instance = {}
    instance.new = __HttpClient_Response_method_new
    ' The HTTP status; 0 when no response came, a negative curl code when the transfer failed.
    instance.StatusCode = __HttpClient_Response_method_StatusCode
    ' A 2xx or 3xx status. Redirects are followed, so a 3xx is one that couldn't be.
    instance.IsSuccess = __HttpClient_Response_method_IsSuccess
    instance.IsTimedOut = __HttpClient_Response_method_IsTimedOut
    ' Cancelled by its fetch, or since: the request's cancellation is read at each call, so an answer taken before
    ' a later cancel reads as cancelled too. Once it reads as cancelled it stays so, the cancellation reset or not.
    instance.IsCancelled = __HttpClient_Response_method_IsCancelled
    instance.IsCached = __HttpClient_Response_method_IsCached
    ' Case-insensitive keys.
    instance.Headers = __HttpClient_Response_method_Headers
    ' The Retry-After header in seconds; invalid when it is absent or an HTTP date.
    instance.RetryAfterSeconds = __HttpClient_Response_method_RetryAfterSeconds
    instance.Text = __HttpClient_Response_method_Text
    ' The parsed body; invalid when it isn't JSON.
    instance.Json = __HttpClient_Response_method_Json
    ' Empty on success.
    instance.ErrorMessage = __HttpClient_Response_method_ErrorMessage
    return instance
end function
function HttpClient_Response(properties as object)
    instance = __HttpClient_Response_builder()
    instance.new(properties)
    return instance
end function

function HttpClient_CreateUrlTransfer(url as string, headers as object, messagePort as object) as object
    urlTransfer = CreateObject("roUrlTransfer")
    if urlTransfer = invalid
        return invalid
    end if
    if true
        urlTransfer.EnableEncodings(true)
    end if
    urlTransfer.RetainBodyOnError(true)
    if LCase(Left(url, 6)) = "https:"
        urlTransfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    end if
    urlTransfer.SetUrl(url)
    urlTransfer.SetHeaders(headers)
    urlTransfer.SetMessagePort(messagePort)
    return urlTransfer
end function