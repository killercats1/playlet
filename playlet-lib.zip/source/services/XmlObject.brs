'import "pkg:/source/utils/Types.bs"
sub __XmlObject_method_new()
    m.stack = []
    m.root = invalid
    m.prolog = []
    m.INDENT_SIZE = 2
end sub
function __XmlObject_method_Node(name as string, attributes = invalid as object) as boolean
    newNode = {
        type: "node"
        name: name
        attributes: attributes
        children: []
    }
    if m.root = invalid
        m.root = newNode
    end if
    if m.stack.count() > 0
        m.stack[m.stack.count() - 1].children.push(newNode)
    end if
    m.stack.push(newNode)
    return true
end function
function __XmlObject_method_Text(text as string)
    if m.stack.count() > 0
        m.stack[m.stack.count() - 1].children.push({
            type: "text"
            text: text
        })
    end if
end function
function __XmlObject_method_TextNode(name as string, text as string, attributes = invalid as object)
    m.Node(name, attributes)
    m.Text(text)
    m.End()
end function
function __XmlObject_method_EmptyNode(name as string, attributes = invalid as object)
    m.Node(name, attributes)
    m.End()
end function
function __XmlObject_method_End()
    m.stack.pop()
end function
function __XmlObject_method_Comment(comment as string)
    if m.stack.count() > 0
        m.stack[m.stack.count() - 1].children.push({
            type: "comment"
            comment: comment
        })
    else
        m.prolog.push({
            type: "comment"
            comment: comment
        })
    end if
end function
function __XmlObject_method_ToXmlString(header = true as boolean) as string
    xml = ""
    if header
        xml = ("<?xml version=" + chr(34) + "1.0" + chr(34) + " encoding=" + chr(34) + "UTF-8" + chr(34) + "?>" + chr(10))
    end if
    for each item in m.prolog
        if item.type = "comment"
            xml += ("<!-- " + bslib_toString(item.comment) + " -->" + chr(10))
        end if
    end for
    xml += m.NodeToXmlString(m.root, 0)
    return xml
end function
function __XmlObject_method_NodeToXmlString(node as object, indentLevel as integer) as string
    indentString = string(indentLevel * m.INDENT_SIZE, " ")
    xmlString = indentString + "<" + node.name
    if node.attributes <> invalid
        for each key in node.attributes.keys()
            value = m.XmlEscape((bslib_toString(node.attributes[key])))
            xmlString += (" " + bslib_toString(key) + "=" + chr(34) + bslib_toString(value) + chr(34))
        end for
    end if
    if node.children.count() = 0
        xmlString += (" />" + chr(10))
    else
        xmlString += ">"
        for i = 0 to node.children.count() - 1
            child = node.children[i]
            if i = 0
                if child.type <> "text"
                    xmlString += (chr(10))
                end if
            end if
            if child.type = "text"
                xmlString += m.XmlEscape(child.text)
            else if child.type = "comment"
                commentIndentString = string((indentLevel + 1) * m.INDENT_SIZE, " ")
                xmlString += (bslib_toString(commentIndentString) + "<!-- " + bslib_toString(child.comment) + " -->" + chr(10))
            else
                xmlString += m.NodeToXmlString(child, indentLevel + 1)
            end if
            if i = node.children.count() - 1
                if child.type <> "text"
                    xmlString += (bslib_toString(indentString))
                end if
            end if
        end for
        xmlString += ("</" + bslib_toString(node.name) + ">" + chr(10))
    end if
    return xmlString
end function
function __XmlObject_method_XmlEscape(input as string) as string
    input = input.replace("&", "&amp;")
    input = input.replace("<", "&lt;")
    input = input.replace(">", "&gt;")
    input = input.replace((chr(34)), "&quot;")
    input = input.replace("'", "&apos;")
    return input
end function
function __XmlObject_builder()
    instance = {}
    instance.new = __XmlObject_method_new
    instance.Node = __XmlObject_method_Node
    instance.Text = __XmlObject_method_Text
    instance.TextNode = __XmlObject_method_TextNode
    instance.EmptyNode = __XmlObject_method_EmptyNode
    instance.End = __XmlObject_method_End
    instance.Comment = __XmlObject_method_Comment
    instance.ToXmlString = __XmlObject_method_ToXmlString
    instance.NodeToXmlString = __XmlObject_method_NodeToXmlString
    instance.XmlEscape = __XmlObject_method_XmlEscape
    return instance
end function
function XmlObject()
    instance = __XmlObject_builder()
    instance.new()
    return instance
end function