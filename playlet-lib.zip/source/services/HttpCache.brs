'import "pkg:/source/utils/CryptoUtils.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
' Responses to GET requests, kept on disk until they expire. An entry is one file: a JSON line
' { expiresAt, statusCode, headers }, then the body as is.
' An entry per url, headers and file the body is saved to.
function HttpCache_GetFilePath(url as string, headers as object, bodyFilePath as dynamic) as string
    key = url + FormatJson(headers)
    if bodyFilePath <> invalid
        key += bodyFilePath
    end if
    return ("cachefs:/request_v3_" + bslib_toString(CryptoUtils_GetMd5(key)) + ".json")
end function

' The entry as { statusCode, headers, text }; invalid when there is none, it expired, or the file its body was
' saved to is gone. Such an entry, or a corrupt one, is deleted; a corrupt one warns, whether its body file exists
' or not.
function HttpCache_Read(filePath as string, bodyFilePath as dynamic) as dynamic
    
    fileSystem = CreateObject("roFileSystem")
    if fileSystem = invalid or not fileSystem.Exists(filePath)
        return invalid
    end if
    text = ReadAsciiFile(filePath)
    metadataEnd = text.InStr((chr(10)))
    if metadataEnd = -1
        LogWarn2("[HttpCache.bs:30]", "Failed to parse cache.")
        DeleteFile(filePath)
        return invalid
    end if
    metadata = StringUtils_ParseJsonSafe(text.Left(metadataEnd))
    if not IsAssociativeArray(metadata) or not IsInt(metadata.expiresAt) or not IsInt(metadata.statusCode)
        LogWarn2("[HttpCache.bs:36]", "Failed to parse metadata from cache.")
        DeleteFile(filePath)
        return invalid
    end if
    if not IsAssociativeArray(metadata.headers)
        LogWarn2("[HttpCache.bs:41]", "Failed to parse headers from cache.")
        DeleteFile(filePath)
        return invalid
    end if
    if metadata.expiresAt < CreateObject("roDateTime").AsSeconds()
        DeleteFile(filePath)
        return invalid
    end if
    if bodyFilePath <> invalid and not fileSystem.Exists(bodyFilePath)
        DeleteFile(filePath)
        return invalid
    end if
    
    headers = {}
    headers.Append(metadata.headers)
    return {
        statusCode: metadata.statusCode
        headers: headers
        text: text.Mid(metadataEnd + 1)
    }
end function

' cacheSeconds: invalid for the headers' Cache-Control max-age; without one, nothing is written.
function HttpCache_Write(filePath as string, cacheSeconds as dynamic, statusCode as integer, headers as object, body as string) as void
    if cacheSeconds = invalid
        cacheSeconds = HttpCache_ParseMaxAgeSeconds(headers)
        if cacheSeconds = invalid
            return
        end if
    end if
    metadata = FormatJson({
        expiresAt: CreateObject("roDateTime").AsSeconds() + cacheSeconds
        statusCode: statusCode
        headers: headers
    })
    WriteAsciiFile(filePath, metadata + (chr(10)) + body)
end function

' Cache-Control's max-age, invalid when absent or when no-store/no-cache forbid caching.
function HttpCache_ParseMaxAgeSeconds(headers as object) as dynamic
    cacheControl = headers["cache-control"]
    if not IsString(cacheControl)
        return invalid
    end if
    maxAgeSeconds = invalid
    for each directive in cacheControl.Split(",")
        parts = directive.Trim().Split("=")
        name = LCase(parts[0].Trim())
        if name = "no-store" or name = "no-cache"
            return invalid
        else if name = "max-age" and parts.Count() > 1
            maxAgeSeconds = parts[1].Trim().ToInt()
        end if
    end for
    if maxAgeSeconds = invalid or maxAgeSeconds <= 0
        return invalid
    end if
    return maxAgeSeconds
end function