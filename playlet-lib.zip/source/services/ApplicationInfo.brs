'import "pkg:/components/Services/ApplicationInfo/LibManifestUtils.bs"
'import "pkg:/source/utils/CodecCapabilities.bs"
'import "pkg:/source/utils/StringUtils.bs"
function __ApplicationInfo_method_new(node as object)
    m.node = invalid
    m.roDeviceInfo = invalid
    m.roAppInfo = invalid
    m.node = node
    m.roDeviceInfo = CreateObject("roDeviceInfo")
    m.roAppInfo = CreateObject("roAppInfo")
end function
function __ApplicationInfo_method_GetLocalIpAddress() as dynamic
    if StringUtils_IsNullOrEmpty(m.ipAddress)
        ips = m.roDeviceInfo.GetIPAddrs()
        for each ip in ips
            m.ipAddress = ips[ip]
            return m.ipAddress
        end for
    end if
    return m.ipAddress
end function
function __ApplicationInfo_method_GetUserCountryCode() as string
    if StringUtils_IsNullOrEmpty(m.countryCode)
        m.countryCode = m.roDeviceInfo.GetUserCountryCode()
    end if
    return m.countryCode
end function
function __ApplicationInfo_method_GetAppInfo() as object
    if m.appInfo = invalid
        m.appInfo = {
            id: m.roAppInfo.GetID()
            app_version: m.roAppInfo.GetVersion()
            app_git_commit_hash: m.roAppInfo.GetValue("git_commit_sha")
            lib_version: LibManifestUtils_GetLibVersion()
            lib_git_commit_hash: LibManifestUtils_GetLibGitCommitHash()
        }
        m.appInfo["lib_url"] = "N/A"
        m.appInfo["lib_url_type"] = "N/A"
        scene = m.node.getScene()
        if scene.playletLibLoadedUrl <> invalid
            m.appInfo["lib_url"] = scene.playletLibLoadedUrl.link
            m.appInfo["lib_url_type"] = scene.playletLibLoadedUrl.type
        end if
    end if
    return m.appInfo
end function
function __ApplicationInfo_method_GetDeviceInfo() as object
    if m.deviceInfo = invalid
        m.deviceInfo = {
            model: m.roDeviceInfo.GetModel()
            model_display_name: m.roDeviceInfo.GetModelDisplayName()
            model_type: m.roDeviceInfo.GetModelType()
            model_details: m.roDeviceInfo.GetModelDetails()
            os_version: m.roDeviceInfo.GetOSVersion()
            display_type: m.roDeviceInfo.GetDisplayType()
            display_mode: m.roDeviceInfo.GetDisplayMode()
            display_aspect_ratio: m.roDeviceInfo.GetDisplayAspectRatio()
            display_size: m.roDeviceInfo.GetDisplaySize()
            video_mode: m.roDeviceInfo.GetVideoMode()
            ui_resolution: m.roDeviceInfo.GetUIResolution()
            graphics_platform: m.roDeviceInfo.GetGraphicsPlatform()
            internet_status: m.roDeviceInfo.GetInternetStatus()
            user_country_code: m.roDeviceInfo.GetUserCountryCode()
            friendly_name: m.roDeviceInfo.GetFriendlyName()
            current_locale: m.roDeviceInfo.GetCurrentLocale()
            can_decode_av1: CodecCapabilities_CanDecodeAv1()
        }
    end if
    return m.deviceInfo
end function
function __ApplicationInfo_builder()
    instance = {}
    instance.new = __ApplicationInfo_method_new
    instance.GetLocalIpAddress = __ApplicationInfo_method_GetLocalIpAddress
    instance.GetUserCountryCode = __ApplicationInfo_method_GetUserCountryCode
    instance.GetAppInfo = __ApplicationInfo_method_GetAppInfo
    instance.GetDeviceInfo = __ApplicationInfo_method_GetDeviceInfo
    return instance
end function
function ApplicationInfo(node as object)
    instance = __ApplicationInfo_builder()
    instance.new(node)
    return instance
end function