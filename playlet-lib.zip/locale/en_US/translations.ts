<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US" sourcelanguage="en_US">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>default</name>
    <message>
        <source>Profile</source>
        <translation>Profile</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Search</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <source>Library</source>
        <translation>Library</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Music</translation>
    </message>
    <message>
        <source>Trending - Music</source>
        <translation>Trending - Music</translation>
    </message>
    <message>
        <source>Music playlists</source>
        <translation>Music playlists</translation>
    </message>
    <message>
        <source>Recommended music</source>
        <translation>Recommended music</translation>
    </message>
    <message>
        <source>Liked videos</source>
        <translation>Liked videos</translation>
    </message>
    <message>
        <source>Watch later</source>
        <translation>Watch later</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Bookmarks</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Settings</translation>
    </message>
    <message>
        <source>Remote</source>
        <translation>Remote</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Do not show again</source>
        <translation>Do not show again</translation>
    </message>
    <message>
        <source>Activate</source>
        <translation>Activate</translation>
    </message>
    <message>
        <source>In Use</source>
        <translation>In Use</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <source>Logout</source>
        <translation>Logout</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Exit</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>Filters</source>
        <translation>Filters</translation>
    </message>
    <message>
        <source>Subscriptions</source>
        <translation>Subscriptions</translation>
    </message>
    <message>
        <source>Recommended</source>
        <translation>Recommended</translation>
    </message>
    <message>
        <source>Playlists</source>
        <translation>Playlists</translation>
    </message>
    <message>
        <source>Watch history</source>
        <translation>Watch history</translation>
    </message>
    <message>
        <source>Trending - Live</source>
        <translation>Trending - Live</translation>
    </message>
    <message>
        <source>Trending - Gaming</source>
        <translation>Trending - Gaming</translation>
    </message>
    <message>
        <source>Popular</source>
        <translation>Popular</translation>
    </message>
    <message>
        <source>Videos</source>
        <translation>Videos</translation>
    </message>
    <message>
        <source>Shorts</source>
        <translation>Shorts</translation>
    </message>
    <message>
        <source>Live</source>
        <translation>Live</translation>
    </message>
    <message>
        <source>Releases</source>
        <translation>Releases</translation>
    </message>
    <message>
        <source>Podcasts</source>
        <translation>Podcasts</translation>
    </message>
    <message>
        <source>Courses</source>
        <translation>Courses</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Edit</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Save</translation>
    </message>
    <message>
        <source>Test instance</source>
        <translation>Test instance</translation>
    </message>
    <message>
        <source>Subscribe</source>
        <translation>Subscribe</translation>
    </message>
    <message>
        <source>Unsubscribe</source>
        <translation>Unsubscribe</translation>
    </message>
    <message>
        <source>Login to Invidious</source>
        <translation>Login to Invidious</translation>
    </message>
    <message>
        <source>IP address not available</source>
        <translation>IP address not available</translation>
    </message>
    <message>
        <source>Scan the QR code</source>
        <translation>Scan the QR code</translation>
    </message>
    <message>
        <source>Login to Invidious in order to view Subscriptions, Playlists, and use the Watch history.</source>
        <translation>Login to Invidious in order to view Subscriptions, Playlists, and use the Watch history.</translation>
    </message>
    <message>
        <source>Please note that an Invidious account is different from a YouTube account.</source>
        <translation>Please note that an Invidious account is different from a YouTube account.</translation>
    </message>
    <message>
        <source>Do you want to exit Playlet?</source>
        <translation>Do you want to exit Playlet?</translation>
    </message>
    <message>
        <source>Sort %1 by</source>
        <translation>Sort %1 by</translation>
    </message>
    <message>
        <source>Latest</source>
        <translation>Latest</translation>
    </message>
    <message>
        <source>Oldest</source>
        <translation>Oldest</translation>
    </message>
    <message>
        <source>Date added (newest)</source>
        <translation>Date added (newest)</translation>
    </message>
    <message>
        <source>Last video added</source>
        <translation>Last video added</translation>
    </message>
    <message>
        <source>Channel load error</source>
        <translation>Channel load error</translation>
    </message>
    <message>
        <source>Failed to load channel %1</source>
        <translation>Failed to load channel %1</translation>
    </message>
    <message>
        <source>Playlist load error</source>
        <translation>Playlist load error</translation>
    </message>
    <message>
        <source>Failed to load playlist %1</source>
        <translation>Failed to load playlist %1</translation>
    </message>
    <message>
        <source>No results found</source>
        <translation>No results found</translation>
    </message>
    <message>
        <source>We didn&apos;t find any results for your search. Please try again with a different query or different filters.</source>
        <translation>We didn&apos;t find any results for your search. Please try again with a different query or different filters.</translation>
    </message>
    <message>
        <source>Invidious public instances load error</source>
        <translation>Invidious public instances load error</translation>
    </message>
    <message>
        <source>Failed to load Invidious public instances</source>
        <translation>Failed to load Invidious public instances</translation>
    </message>
    <message>
        <source>Failed to load feed</source>
        <translation>Failed to load feed</translation>
    </message>
    <message>
        <source>Session expired</source>
        <translation>Session expired</translation>
    </message>
    <message>
        <source>The session has expired. Please sign in again with this profile, or switch to another profile.</source>
        <translation>The session has expired. Please sign in again with this profile, or switch to another profile.</translation>
    </message>
    <message>
        <source>The session has expired.</source>
        <translation>The session has expired.</translation>
    </message>
    <message>
        <source>Please sign in again with this profile, or switch to another profile.</source>
        <translation>Please sign in again with this profile, or switch to another profile.</translation>
    </message>
    <message>
        <source>Backend changed</source>
        <translation>Backend changed</translation>
    </message>
    <message>
        <source>Backend changed to Playlet, because no Invidious instance is set.</source>
        <translation>Backend changed to Playlet, because no Invidious instance is set.</translation>
    </message>
    <message>
        <source>Select a service to login</source>
        <translation>Select a service to login</translation>
    </message>
    <message>
        <source>Login to YouTube</source>
        <translation>Login to YouTube</translation>
    </message>
    <message>
        <source>Open the link %1 and enter the following code:</source>
        <translation>Open the link %1 and enter the following code:</translation>
    </message>
    <message>
        <source>Disclaimer</source>
        <translation>Disclaimer</translation>
    </message>
    <message>
        <source>Playlet is a third-party app and is not affiliated with, endorsed by, or sponsored by YouTube or Google. All trademarks and registered trademarks mentioned are the property of their respective owners and are used only for identification purposes.</source>
        <translation>Playlet is a third-party app and is not affiliated with, endorsed by, or sponsored by YouTube or Google. All trademarks and registered trademarks mentioned are the property of their respective owners and are used only for identification purposes.</translation>
    </message>
    <message>
        <source>By using Playlet and signing in with your YouTube account, you acknowledge that you do so at your own risk. The developers of Playlet are not liable for any harm, including but not limited to data loss, account suspension or ban, hacking, or loss of content.</source>
        <translation>By using Playlet and signing in with your YouTube account, you acknowledge that you do so at your own risk. The developers of Playlet are not liable for any harm, including but not limited to data loss, account suspension or ban, hacking, or loss of content.</translation>
    </message>
    <message>
        <source>Use responsibly, especially if your YouTube account is tied to business or monetization.</source>
        <translation>Use responsibly, especially if your YouTube account is tied to business or monetization.</translation>
    </message>
    <message>
        <source>Who&#39;s watching?</source>
        <translation>Who&#39;s watching?</translation>
    </message>
    <message>
        <source>No valid accounts found for YouTube login.</source>
        <translation>No valid accounts found for YouTube login.</translation>
    </message>
    <message>
        <source>Invidious custom instance</source>
        <translation>Invidious custom instance</translation>
    </message>
    <message>
        <source>Or</source>
        <translation>Or</translation>
    </message>
    <message>
        <source>Invidious public instances</source>
        <translation>Invidious public instances</translation>
    </message>
    <message>
        <source>Move up</source>
        <translation>Move up</translation>
    </message>
    <message>
        <source>Move down</source>
        <translation>Move down</translation>
    </message>
    <message>
        <source>name</source>
        <translation>name</translation>
    </message>
    <message>
        <source>version</source>
        <translation>version</translation>
    </message>
    <message>
        <source>users</source>
        <translation>users</translation>
    </message>
    <message>
        <source>signup</source>
        <translation>signup</translation>
    </message>
    <message>
        <source>location</source>
        <translation>location</translation>
    </message>
    <message>
        <source>health</source>
        <translation>health</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Yes</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Success</source>
        <translation>Success</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation>Refresh</translation>
    </message>
    <message>
        <source>Play next video</source>
        <translation>Play next video</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Clear</translation>
    </message>
    <message>
        <source>Test</source>
        <translation>Test</translation>
    </message>
    <message>
        <source>Testing %1</source>
        <translation>Testing %1</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>Test duration</source>
        <translation>Test duration</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Details</translation>
    </message>
    <message>
        <source>Valid URL</source>
        <translation>Valid URL</translation>
    </message>
    <message>
        <source>Instance reachable</source>
        <translation>Instance reachable</translation>
    </message>
    <message>
        <source>Fetch video details</source>
        <translation>Fetch video details</translation>
    </message>
    <message>
        <source>Fetch video comments</source>
        <translation>Fetch video comments</translation>
    </message>
    <message>
        <source>Fetch video captions</source>
        <translation>Fetch video captions</translation>
    </message>
    <message>
        <source>Fetch video thumbnails</source>
        <translation>Fetch video thumbnails</translation>
    </message>
    <message>
        <source>Fetch with CORS</source>
        <translation>Fetch with CORS</translation>
    </message>
    <message>
        <source>Press &apos;OK&apos; for details</source>
        <translation>Press &apos;OK&apos; for details</translation>
    </message>
    <message>
        <source>Url must start with http:// or https://</source>
        <translation>Url must start with http:// or https://</translation>
    </message>
    <message>
        <source>Url must not end with /</source>
        <translation>Url must not end with /</translation>
    </message>
    <message>
        <source>The url seems to be of a valid format</source>
        <translation>The url seems to be of a valid format</translation>
    </message>
    <message>
        <source>Invalid JSON from %1</source>
        <translation>Invalid JSON from %1</translation>
    </message>
    <message>
        <source>Invalid JSON from %1 (couldn&apos;t read %2)</source>
        <translation>Invalid JSON from %1 (couldn&apos;t read %2)</translation>
    </message>
    <message>
        <source>The instance is reachable and running %1 version %2</source>
        <translation>The instance is reachable and running %1 version %2</translation>
    </message>
    <message>
        <source>The instance can fetch video details for ID %1 (%2)</source>
        <translation>The instance can fetch video details for ID %1 (%2)</translation>
    </message>
    <message>
        <source>The instance can fetch video comments for ID %1 (%2 comments)</source>
        <translation>The instance can fetch video comments for ID %1 (%2 comments)</translation>
    </message>
    <message>
        <source>Invalid caption data from %1 (Content-Type is not text/vtt)</source>
        <translation>Invalid caption data from %1 (Content-Type is not text/vtt)</translation>
    </message>
    <message>
        <source>Invalid caption data from %1 (response is not a valid vtt file)</source>
        <translation>Invalid caption data from %1 (response is not a valid vtt file)</translation>
    </message>
    <message>
        <source>Did not find expected text in caption data from %1</source>
        <translation>Did not find expected text in caption data from %1</translation>
    </message>
    <message>
        <source>The instance can fetch video %1 captions for ID %2</source>
        <translation>The instance can fetch video %1 captions for ID %2</translation>
    </message>
    <message>
        <source>No thumbnails found in JSON from %1</source>
        <translation>No thumbnails found in JSON from %1</translation>
    </message>
    <message>
        <source>%1 is not reachable</source>
        <translation>%1 is not reachable</translation>
    </message>
    <message>
        <source>Invalid thumbnail data %1 (Content-Type is not image/*)</source>
        <translation>Invalid thumbnail data %1 (Content-Type is not image/*)</translation>
    </message>
    <message>
        <source>The instance can fetch video thumbnail for ID %1 (%2)</source>
        <translation>The instance can fetch video thumbnail for ID %1 (%2)</translation>
    </message>
    <message>
        <source>CORS header not set correctly from %1</source>
        <translation>CORS header not set correctly from %1</translation>
    </message>
    <message>
        <source>The instance can fetch with CORS from %1</source>
        <translation>The instance can fetch with CORS from %1</translation>
    </message>
    <message>
        <source>Passed</source>
        <translation>Passed</translation>
    </message>
    <message>
        <source>Failed</source>
        <translation>Failed</translation>
    </message>
    <message>
        <source>0 subscribers</source>
        <translation>0 subscribers</translation>
    </message>
    <message>
        <source>1 subscriber</source>
        <translation>1 subscriber</translation>
    </message>
    <message>
        <source>^n subscribers</source>
        <translation>^n subscribers</translation>
    </message>
    <message>
        <source>0 videos</source>
        <translation>0 videos</translation>
    </message>
    <message>
        <source>1 video</source>
        <translation>1 video</translation>
    </message>
    <message>
        <source>^n videos</source>
        <translation>^n videos</translation>
    </message>
    <message>
        <source>0 views</source>
        <translation>0 views</translation>
    </message>
    <message>
        <source>1 view</source>
        <translation>1 view</translation>
    </message>
    <message>
        <source>^n views</source>
        <translation>^n views</translation>
    </message>
    <message>
        <source>Updated 1 minute ago</source>
        <translation>Updated 1 minute ago</translation>
    </message>
    <message>
        <source>Updated ^n minutes ago</source>
        <translation>Updated ^n minutes ago</translation>
    </message>
    <message>
        <source>Updated 1 hour ago</source>
        <translation>Updated 1 hour ago</translation>
    </message>
    <message>
        <source>Updated ^n hours ago</source>
        <translation>Updated ^n hours ago</translation>
    </message>
    <message>
        <source>Updated 1 day ago</source>
        <translation>Updated 1 day ago</translation>
    </message>
    <message>
        <source>Updated ^n days ago</source>
        <translation>Updated ^n days ago</translation>
    </message>
    <message>
        <source>Updated 1 week ago</source>
        <translation>Updated 1 week ago</translation>
    </message>
    <message>
        <source>Updated ^n weeks ago</source>
        <translation>Updated ^n weeks ago</translation>
    </message>
    <message>
        <source>Updated 1 month ago</source>
        <translation>Updated 1 month ago</translation>
    </message>
    <message>
        <source>Updated ^n months ago</source>
        <translation>Updated ^n months ago</translation>
    </message>
    <message>
        <source>Updated 1 year ago</source>
        <translation>Updated 1 year ago</translation>
    </message>
    <message>
        <source>Updated ^n years ago</source>
        <translation>Updated ^n years ago</translation>
    </message>
    <message>
        <source>1 year ago</source>
        <translation>1 year ago</translation>
    </message>
    <message>
        <source>^n years ago</source>
        <translation>^n years ago</translation>
    </message>
    <message>
        <source>1 month ago</source>
        <translation>1 month ago</translation>
    </message>
    <message>
        <source>^n months ago</source>
        <translation>^n months ago</translation>
    </message>
    <message>
        <source>1 week ago</source>
        <translation>1 week ago</translation>
    </message>
    <message>
        <source>^n weeks ago</source>
        <translation>^n weeks ago</translation>
    </message>
    <message>
        <source>1 day ago</source>
        <translation>1 day ago</translation>
    </message>
    <message>
        <source>^n days ago</source>
        <translation>^n days ago</translation>
    </message>
    <message>
        <source>1 hour ago</source>
        <translation>1 hour ago</translation>
    </message>
    <message>
        <source>^n hours ago</source>
        <translation>^n hours ago</translation>
    </message>
    <message>
        <source>1 minute ago</source>
        <translation>1 minute ago</translation>
    </message>
    <message>
        <source>^n minutes ago</source>
        <translation>^n minutes ago</translation>
    </message>
    <message>
        <source>Premiering now</source>
        <translation>Premiering now</translation>
    </message>
    <message>
        <source>Premieres in 1 second</source>
        <translation>Premieres in 1 second</translation>
    </message>
    <message>
        <source>Premieres in ^n seconds</source>
        <translation>Premieres in ^n seconds</translation>
    </message>
    <message>
        <source>Premieres in 1 minute</source>
        <translation>Premieres in 1 minute</translation>
    </message>
    <message>
        <source>Premieres in ^n minutes</source>
        <translation>Premieres in ^n minutes</translation>
    </message>
    <message>
        <source>Premieres in 1 hour</source>
        <translation>Premieres in 1 hour</translation>
    </message>
    <message>
        <source>Premieres in ^n hours</source>
        <translation>Premieres in ^n hours</translation>
    </message>
    <message>
        <source>Premieres in 1 day</source>
        <translation>Premieres in 1 day</translation>
    </message>
    <message>
        <source>Premieres in ^n days</source>
        <translation>Premieres in ^n days</translation>
    </message>
    <message>
        <source>LIVE</source>
        <translation>LIVE</translation>
    </message>
    <message>
        <source>UPCOMING</source>
        <translation>UPCOMING</translation>
    </message>
    <message>
        <source>You currently have no bookmarks.</source>
        <translation>You currently have no bookmarks.</translation>
    </message>
    <message>
        <source>To add bookmarks, long-press &apos;OK&apos; on a video, playlist or channel.</source>
        <translation>To add bookmarks, long-press &apos;OK&apos; on a video, playlist or channel.</translation>
    </message>
    <message>
        <source>Please note that Bookmarks is an experimental feature.</source>
        <translation>Please note that Bookmarks is an experimental feature.</translation>
    </message>
    <message>
        <source>Channels</source>
        <translation>Channels</translation>
    </message>
    <message>
        <source>Could not get IP address: are we connected to the internet?</source>
        <translation>Could not get IP address: are we connected to the internet?</translation>
    </message>
    <message>
        <source>Playlet Web App</source>
        <translation>Playlet Web App</translation>
    </message>
    <message>
        <source>Use Playlet Remote in the browser</source>
        <translation>Use Playlet Remote in the browser</translation>
    </message>
    <message>
        <source>Link with Wi-Fi</source>
        <translation>Link with Wi-Fi</translation>
    </message>
    <message>
        <source>Link with TV code</source>
        <translation>Link with TV code</translation>
    </message>
    <message>
        <source>Cast from the YouTube app to Playlet</source>
        <translation>Cast from the YouTube app to Playlet</translation>
    </message>
    <message>
        <source>On your phone, connect to the same Wi-Fi network as this device.</source>
        <translation>On your phone, connect to the same Wi-Fi network as this device.</translation>
    </message>
    <message>
        <source>Open the YouTube app on your phone.</source>
        <translation>Open the YouTube app on your phone.</translation>
    </message>
    <message>
        <source>Tap the cast icon and select %1</source>
        <translation>Tap the cast icon and select %1</translation>
    </message>
    <message>
        <source>Roku connected to:</source>
        <translation>Roku connected to:</translation>
    </message>
    <message>
        <source>Wired connection</source>
        <translation>Wired connection</translation>
    </message>
    <message>
        <source>On your phone, open the YouTube app.</source>
        <translation>On your phone, open the YouTube app.</translation>
    </message>
    <message>
        <source>Tap the cast icon.</source>
        <translation>Tap the cast icon.</translation>
    </message>
    <message>
        <source>Tap &apos;Link with TV code&apos; and enter the code below.</source>
        <translation>Tap &apos;Link with TV code&apos; and enter the code below.</translation>
    </message>
    <message>
        <source>Loading...</source>
        <translation>Loading...</translation>
    </message>
    <message>
        <source>TV code error</source>
        <translation>TV code error</translation>
    </message>
    <message>
        <source>Failed to generate manual pairing code</source>
        <translation>Failed to generate manual pairing code</translation>
    </message>
    <message>
        <source>Playback</source>
        <translation>Playback</translation>
    </message>
    <message>
        <source>Playback preferences</source>
        <translation>Playback preferences</translation>
    </message>
    <message>
        <source>Autoplay</source>
        <translation>Autoplay</translation>
    </message>
    <message>
        <source>When you finish a video, another plays automatically</source>
        <translation>When you finish a video, another plays automatically</translation>
    </message>
    <message>
        <source>Preferred quality</source>
        <translation>Preferred quality</translation>
    </message>
    <message>
        <source>Preferred video quality</source>
        <translation>Preferred video quality</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <source>Backend</source>
        <translation>Backend</translation>
    </message>
    <message>
        <source>Backend preferences</source>
        <translation>Backend preferences</translation>
    </message>
    <message>
        <source>Selected backend</source>
        <translation>Selected backend</translation>
    </message>
    <message>
        <source>The backend used for browsing and playing videos.</source>
        <translation>The backend used for browsing and playing videos.</translation>
    </message>
    <message>
        <source>Content Feed</source>
        <translation>Content Feed</translation>
    </message>
    <message>
        <source>Feed preferences</source>
        <translation>Feed preferences</translation>
    </message>
    <message>
        <source>Disable auto-dubbed audio</source>
        <translation>Disable auto-dubbed audio</translation>
    </message>
    <message>
        <source>Remove AI-generated dubbed audio tracks.</source>
        <translation>Remove AI-generated dubbed audio tracks.</translation>
    </message>
    <message>
        <source>Disable Shorts</source>
        <translation>Disable Shorts</translation>
    </message>
    <message>
        <source>Disable short videos.</source>
        <translation>Disable short videos.</translation>
    </message>
    <message>
        <source>Invidious preferences</source>
        <translation>Invidious preferences</translation>
    </message>
    <message>
        <source>Instance</source>
        <translation>Instance</translation>
    </message>
    <message>
        <source>Playlet built-in backend</source>
        <translation>Playlet built-in backend</translation>
    </message>
    <message>
        <source>Invidious instance to use. Example: https://example.com</source>
        <translation>Invidious instance to use. Example: https://example.com</translation>
    </message>
    <message>
        <source>Proxy videos</source>
        <translation>Proxy videos</translation>
    </message>
    <message>
        <source>Proxy videos through the Invidious server. This is useful if videos are geoblocked.</source>
        <translation>Proxy videos through the Invidious server. This is useful if videos are geoblocked.</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Always</translation>
    </message>
    <message>
        <source>Only if needed</source>
        <translation>Only if needed</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Never</translation>
    </message>
    <message>
        <source>SponsorBlock</source>
        <translation>SponsorBlock</translation>
    </message>
    <message>
        <source>SponsorBlock preferences</source>
        <translation>SponsorBlock preferences</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Enabled</translation>
    </message>
    <message>
        <source>Enable SponsorBlock</source>
        <translation>Enable SponsorBlock</translation>
    </message>
    <message>
        <source>Show notifications</source>
        <translation>Show notifications</translation>
    </message>
    <message>
        <source>Show notifications when a segment is skipped</source>
        <translation>Show notifications when a segment is skipped</translation>
    </message>
    <message>
        <source>Categories</source>
        <translation>Categories</translation>
    </message>
    <message>
        <source>Configure which segments to skip</source>
        <translation>Configure which segments to skip</translation>
    </message>
    <message>
        <source>Select option for %1</source>
        <translation>Select option for %1</translation>
    </message>
    <message>
        <source>Search History</source>
        <translation>Search History</translation>
    </message>
    <message>
        <source>Search history preferences</source>
        <translation>Search history preferences</translation>
    </message>
    <message>
        <source>Enable search history</source>
        <translation>Enable search history</translation>
    </message>
    <message>
        <source>Clear search history</source>
        <translation>Clear search history</translation>
    </message>
    <message>
        <source>Clear search history from Playlet. This affects the search suggestions. This does not affect the watch history on Invidious.</source>
        <translation>Clear search history from Playlet. This affects the search suggestions. This does not affect the watch history on Invidious.</translation>
    </message>
    <message>
        <source>Search history cleared.</source>
        <translation>Search history cleared.</translation>
    </message>
    <message>
        <source>Miscellaneous</source>
        <translation>Miscellaneous</translation>
    </message>
    <message>
        <source>Misc. preferences</source>
        <translation>Misc. preferences</translation>
    </message>
    <message>
        <source>Edit home screen</source>
        <translation>Edit home screen</translation>
    </message>
    <message>
        <source>Enable/disable and reorder sections on the home screen</source>
        <translation>Enable/disable and reorder sections on the home screen</translation>
    </message>
    <message>
        <source>Queue notifications</source>
        <translation>Queue notifications</translation>
    </message>
    <message>
        <source>Show a notification when a video is added to the queue</source>
        <translation>Show a notification when a video is added to the queue</translation>
    </message>
    <message>
        <source>Developer</source>
        <translation>Developer</translation>
    </message>
    <message>
        <source>Developer preferences</source>
        <translation>Developer preferences</translation>
    </message>
    <message>
        <source>Playlet Library version</source>
        <translation>Playlet Library version</translation>
    </message>
    <message>
        <source>The version of Playlet Lib to use. These correspond to tagged releases on Github. Releases that do not have a playlet-lib.zip file are disabled.</source>
        <translation>The version of Playlet Lib to use. These correspond to tagged releases on Github. Releases that do not have a playlet-lib.zip file are disabled.</translation>
    </message>
    <message>
        <source>Loading</source>
        <translation>Loading</translation>
    </message>
    <message>
        <source>Buffering</source>
        <translation>Buffering</translation>
    </message>
    <message>
        <source>Press Options (*) for full screen</source>
        <translation>Press Options (*) for full screen</translation>
    </message>
    <message>
        <source>Rewind live TV</source>
        <translation>Rewind live TV</translation>
    </message>
    <message>
        <source>Video load error</source>
        <translation>Video load error</translation>
    </message>
    <message>
        <source>Failed to load video information for %1</source>
        <translation>Failed to load video information for %1</translation>
    </message>
    <message>
        <source>Error playing video %1</source>
        <translation>Error playing video %1</translation>
    </message>
    <message>
        <source>Error closing video</source>
        <translation>Error closing video</translation>
    </message>
    <message>
        <source>Request not sent.</source>
        <translation>Request not sent.</translation>
    </message>
    <message>
        <source>Request timed out.</source>
        <translation>Request timed out.</translation>
    </message>
    <message>
        <source>Request cancelled.</source>
        <translation>Request cancelled.</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Reason</translation>
    </message>
    <message>
        <source>Skipped</source>
        <translation>Skipped</translation>
    </message>
    <message>
        <source>Press OK to skip</source>
        <translation>Press OK to skip</translation>
    </message>
    <message>
        <source>Disable</source>
        <translation>Disable</translation>
    </message>
    <message>
        <source>Auto Skip</source>
        <translation>Auto Skip</translation>
    </message>
    <message>
        <source>Manual Skip</source>
        <translation>Manual Skip</translation>
    </message>
    <message>
        <source>Show in Seekbar</source>
        <translation>Show in Seekbar</translation>
    </message>
    <message>
        <source>Sponsor</source>
        <translation>Sponsor</translation>
    </message>
    <message>
        <source>Unpaid/Self Promotion</source>
        <translation>Unpaid/Self Promotion</translation>
    </message>
    <message>
        <source>Exclusive Access</source>
        <translation>Exclusive Access</translation>
    </message>
    <message>
        <source>Interaction Reminder (Subscribe)</source>
        <translation>Interaction Reminder (Subscribe)</translation>
    </message>
    <message>
        <source>Interaction Reminder</source>
        <translation>Interaction Reminder</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation>Highlight</translation>
    </message>
    <message>
        <source>Intermission/Intro Animation</source>
        <translation>Intermission/Intro Animation</translation>
    </message>
    <message>
        <source>Intermission</source>
        <translation>Intermission</translation>
    </message>
    <message>
        <source>Endcards/Credits</source>
        <translation>Endcards/Credits</translation>
    </message>
    <message>
        <source>Preview/Recap</source>
        <translation>Preview/Recap</translation>
    </message>
    <message>
        <source>Hook/Greetings</source>
        <translation>Hook/Greetings</translation>
    </message>
    <message>
        <source>Filler Tangent/Jokes</source>
        <translation>Filler Tangent/Jokes</translation>
    </message>
    <message>
        <source>Filler</source>
        <translation>Filler</translation>
    </message>
    <message>
        <source>Chapter</source>
        <translation>Chapter</translation>
    </message>
    <message>
        <source>Music: Non-Music Section</source>
        <translation>Music: Non-Music Section</translation>
    </message>
    <message>
        <source>Non-Music</source>
        <translation>Non-Music</translation>
    </message>
    <message>
        <source>Added to queue</source>
        <translation>Added to queue</translation>
    </message>
    <message>
        <source>Press and hold Options (*) to open the queue</source>
        <translation>Press and hold Options (*) to open the queue</translation>
    </message>
    <message>
        <source>Device</source>
        <translation>Device</translation>
    </message>
    <message>
        <source>Device connected</source>
        <translation>Device connected</translation>
    </message>
    <message>
        <source>Queue</source>
        <translation>Queue</translation>
    </message>
    <message>
        <source>Load more</source>
        <translation>Load more</translation>
    </message>
    <message>
        <source>No Bookmarks</source>
        <translation>No Bookmarks</translation>
    </message>
    <message>
        <source>To add bookmarks, select a video, playlist or channel, and add a bookmark.</source>
        <translation>To add bookmarks, select a video, playlist or channel, and add a bookmark.</translation>
    </message>
    <message>
        <source>Invidious instance to use. Example: https://example.com. Find more instances at %INVIDIOUS_PUBLIC_INSTANCES%</source>
        <translation>Invidious instance to use. Example: https://example.com. Find more instances at %INVIDIOUS_PUBLIC_INSTANCES%</translation>
    </message>
    <message>
        <source>Thank you for using Playlet.</source>
        <translation>Thank you for using Playlet.</translation>
    </message>
    <message>
        <source>You have feedback? Let us know by %IssueStart%creating an issue on Github%IssueEnd% or by %EmailStart%sending an email%EmailEnd%.</source>
        <translation>You have feedback? Let us know by %IssueStart%creating an issue on Github%IssueEnd% or by %EmailStart%sending an email%EmailEnd%.</translation>
    </message>
    <message>
        <source>Latest (default)</source>
        <translation>Latest (default)</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Are you sure you want to change the Playlet Library version to %1?</source>
        <translation>Are you sure you want to change the Playlet Library version to %1?</translation>
    </message>
    <message>
        <source>This will restart Playlet.</source>
        <translation>This will restart Playlet.</translation>
    </message>
    <message>
        <source>Playlet Library version changed. Playlet will now restart.</source>
        <translation>Playlet Library version changed. Playlet will now restart.</translation>
    </message>
    <message>
        <source>Error with login, please refresh the page.</source>
        <translation>Error with login, please refresh the page.</translation>
    </message>
    <message>
        <source>Profiles</source>
        <translation>Profiles</translation>
    </message>
    <message>
        <source>Drop a YouTube link here</source>
        <translation>Drop a YouTube link here</translation>
    </message>
    <message>
        <source>Play on %1</source>
        <translation>Play on %1</translation>
    </message>
    <message>
        <source>Queue on %1</source>
        <translation>Queue on %1</translation>
    </message>
    <message>
        <source>Open on %1</source>
        <translation>Open on %1</translation>
    </message>
    <message>
        <source>Open in Invidious</source>
        <translation>Open in Invidious</translation>
    </message>
    <message>
        <source>Open in YouTube</source>
        <translation>Open in YouTube</translation>
    </message>
    <message>
        <source>Start at</source>
        <translation>Start at</translation>
    </message>
    <message>
        <source>Play Video</source>
        <translation>Play Video</translation>
    </message>
    <message>
        <source>Queue Video</source>
        <translation>Queue Video</translation>
    </message>
    <message>
        <source>Play Playlist</source>
        <translation>Play Playlist</translation>
    </message>
    <message>
        <source>Queue Playlist</source>
        <translation>Queue Playlist</translation>
    </message>
    <message>
        <source>Open Channel</source>
        <translation>Open Channel</translation>
    </message>
    <message>
        <source>Open Playlist</source>
        <translation>Open Playlist</translation>
    </message>
    <message>
        <source>Open Playlist Channel</source>
        <translation>Open Playlist Channel</translation>
    </message>
    <message>
        <source>Open Video Channel</source>
        <translation>Open Video Channel</translation>
    </message>
    <message>
        <source>Refresh Home</source>
        <translation>Refresh Home</translation>
    </message>
    <message>
        <source>Video details</source>
        <translation>Video details</translation>
    </message>
    <message>
        <source>Not interested</source>
        <translation>Not interested</translation>
    </message>
    <message>
        <source>Don&apos;t recommend channel</source>
        <translation>Don&apos;t recommend channel</translation>
    </message>
    <message>
        <source>%1 likes</source>
        <translation>%1 likes</translation>
    </message>
    <message>
        <source>Up next</source>
        <translation>Up next</translation>
    </message>
    <message>
        <source>All</source>
        <translation>All</translation>
    </message>
    <message>
        <source>News</source>
        <translation>News</translation>
    </message>
    <message>
        <source>Gaming</source>
        <translation>Gaming</translation>
    </message>
    <message>
        <source>Sleep timer</source>
        <translation>Sleep timer</translation>
    </message>
    <message>
        <source>Stop playback after:</source>
        <translation>Stop playback after:</translation>
    </message>
    <message>
        <source>Playback stops in %1 minutes.</source>
        <translation>Playback stops in %1 minutes.</translation>
    </message>
    <message>
        <source>Off</source>
        <translation>Off</translation>
    </message>
    <message>
        <source>15 minutes</source>
        <translation>15 minutes</translation>
    </message>
    <message>
        <source>30 minutes</source>
        <translation>30 minutes</translation>
    </message>
    <message>
        <source>1 hour</source>
        <translation>1 hour</translation>
    </message>
    <message>
        <source>2 hours</source>
        <translation>2 hours</translation>
    </message>
    <message>
        <source>Loading Shorts...</source>
        <translation>Loading Shorts...</translation>
    </message>
    <message>
        <source>Sign in with your YouTube account (Profile tab) to see your Shorts.</source>
        <translation>Sign in with your YouTube account (Profile tab) to see your Shorts.</translation>
    </message>
    <message>
        <source>No Shorts to show right now.</source>
        <translation>No Shorts to show right now.</translation>
    </message>
    <message>
        <source>Thumbnail previews</source>
        <translation>Thumbnail previews</translation>
    </message>
    <message>
        <source>The selected video's thumbnail cycles through moments from the video.</source>
        <translation>The selected video&apos;s thumbnail cycles through moments from the video.</translation>
    </message>
    <message>
        <source>Refresh Bookmarks</source>
        <translation>Refresh Bookmarks</translation>
    </message>
    <message>
        <source>Remove from %1 bookmarks</source>
        <translation>Remove from %1 bookmarks</translation>
    </message>
    <message>
        <source>Add to %1 bookmark</source>
        <translation>Add to %1 bookmark</translation>
    </message>
    <message>
        <source>Upload date</source>
        <translation>Upload date</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Duration</source>
        <translation>Duration</translation>
    </message>
    <message>
        <source>Features</source>
        <translation>Features</translation>
    </message>
    <message>
        <source>Sort by</source>
        <translation>Sort by</translation>
    </message>
    <message>
        <source>Any date</source>
        <translation>Any date</translation>
    </message>
    <message>
        <source>Last hour</source>
        <translation>Last hour</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Today</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>This week</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>This month</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>This year</translation>
    </message>
    <message>
        <source>Any type</source>
        <translation>Any type</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation>Playlist</translation>
    </message>
    <message>
        <source>Channel</source>
        <translation>Channel</translation>
    </message>
    <message>
        <source>Movie</source>
        <translation>Movie</translation>
    </message>
    <message>
        <source>Any duration</source>
        <translation>Any duration</translation>
    </message>
    <message>
        <source>Under 4 minutes</source>
        <translation>Under 4 minutes</translation>
    </message>
    <message>
        <source>4 - 20 minutes</source>
        <translation>4 - 20 minutes</translation>
    </message>
    <message>
        <source>Over 20 minutes</source>
        <translation>Over 20 minutes</translation>
    </message>
    <message>
        <source>4K</source>
        <translation>4K</translation>
    </message>
    <message>
        <source>HD</source>
        <translation>HD</translation>
    </message>
    <message>
        <source>Subtitles/CC</source>
        <translation>Subtitles/CC</translation>
    </message>
    <message>
        <source>Creative Commons</source>
        <translation>Creative Commons</translation>
    </message>
    <message>
        <source>360°</source>
        <translation>360°</translation>
    </message>
    <message>
        <source>VR180</source>
        <translation>VR180</translation>
    </message>
    <message>
        <source>3D</source>
        <translation>3D</translation>
    </message>
    <message>
        <source>HDR</source>
        <translation>HDR</translation>
    </message>
    <message>
        <source>Purchased</source>
        <translation>Purchased</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Location</translation>
    </message>
    <message>
        <source>Relevance</source>
        <translation>Relevance</translation>
    </message>
    <message>
        <source>View count</source>
        <translation>View count</translation>
    </message>
    <message>
        <source>Rating</source>
        <translation>Rating</translation>
    </message>
    <message>
        <source>Clear cache</source>
        <translation>Clear cache</translation>
    </message>
    <message>
        <source>Clear cache from cachefs: and tmp:</source>
        <translation>Clear cache from cachefs: and tmp:</translation>
    </message>
    <message>
        <source>Cache cleared.</source>
        <translation>Cache cleared.</translation>
    </message>
    <message>
        <source>Clear PoTokens</source>
        <translation>Clear PoTokens</translation>
    </message>
    <message>
        <source>Clear all stored PoTokens.</source>
        <translation>Clear all stored PoTokens.</translation>
    </message>
    <message>
        <source>PoTokens cleared.</source>
        <translation>PoTokens cleared.</translation>
    </message>
    <message>
        <source>Enable Diagnostics</source>
        <translation>Enable Diagnostics</translation>
    </message>
    <message>
        <source>Save diagnostics (errors and crash reports) to a log file on this TV. Nothing is sent anywhere.</source>
        <translation>Save diagnostics (errors and crash reports) to a log file on this TV. Nothing is sent anywhere.</translation>
    </message>
    <message>
        <source>Select keyboard language</source>
        <translation>Select keyboard language</translation>
    </message>
    <message>
        <source>Continue watching</source>
        <translation>Continue watching</translation>
    </message>
    <message>
        <source>More for you</source>
        <translation>More for you</translation>
    </message>
    <message>
        <source>Save to Watch later</source>
        <translation>Save to Watch later</translation>
    </message>
    <message>
        <source>Saved to Watch later</source>
        <translation>Saved to Watch later</translation>
    </message>
    <message>
        <source>Couldn't save to Watch later</source>
        <translation>Couldn&apos;t save to Watch later</translation>
    </message>
    <message>
        <source>This TV can't change the playback speed</source>
        <translation>This TV can&apos;t change the playback speed</translation>
    </message>
    <message>
        <source>Speed: %1</source>
        <translation>Speed: %1</translation>
    </message>
    <message>
        <source>Speed: Normal</source>
        <translation>Speed: Normal</translation>
    </message>
    <message>
        <source>Hide members-only videos</source>
        <translation>Hide members-only videos</translation>
    </message>
    <message>
        <source>Don't show videos only channel members can watch on Home and in topic feeds.</source>
        <translation>Don&apos;t show videos only channel members can watch on Home and in topic feeds.</translation>
    </message>
    <message>
        <source>Hide watched videos</source>
        <translation>Hide watched videos</translation>
    </message>
    <message>
        <source>Don't show videos you've already watched to the end on Home and in topic feeds.</source>
        <translation>Don&apos;t show videos you&apos;ve already watched to the end on Home and in topic feeds.</translation>
    </message>
    <message>
        <source>Playback stops at the end of this video.</source>
        <translation>Playback stops at the end of this video.</translation>
    </message>
    <message>
        <source>Your channels</source>
        <translation>Your channels</translation>
    </message>
    <message>
        <source>Removed from your feeds</source>
        <translation>Removed from your feeds</translation>
    </message>
    <message>
        <source>Channel hidden from your feeds</source>
        <translation>Channel hidden from your feeds</translation>
    </message>
    <message>
        <source>Reset Not interested</source>
        <translation>Reset Not interested</translation>
    </message>
    <message>
        <source>Let videos and channels you marked Not interested or Don't recommend show up in Playlet's feeds again. This doesn't change what YouTube remembers.</source>
        <translation>Let videos and channels you marked Not interested or Don&apos;t recommend show up in Playlet&apos;s feeds again. This doesn&apos;t change what YouTube remembers.</translation>
    </message>
    <message>
        <source>Not interested list cleared.</source>
        <translation>Not interested list cleared.</translation>
    </message>
    <message>
        <source>Play next</source>
        <translation>Play next</translation>
    </message>
    <message>
        <source>Remove from Watch later</source>
        <translation>Remove from Watch later</translation>
    </message>
    <message>
        <source>Remove from Liked videos</source>
        <translation>Remove from Liked videos</translation>
    </message>
    <message>
        <source>Remove from watch history</source>
        <translation>Remove from watch history</translation>
    </message>
    <message>
        <source>Removed from Watch later</source>
        <translation>Removed from Watch later</translation>
    </message>
    <message>
        <source>Removed from Liked videos</source>
        <translation>Removed from Liked videos</translation>
    </message>
    <message>
        <source>Removed from watch history</source>
        <translation>Removed from watch history</translation>
    </message>
    <message>
        <source>Shuffle play</source>
        <translation>Shuffle play</translation>
    </message>
    <message>
        <source>Caption size</source>
        <translation>Caption size</translation>
    </message>
    <message>
        <source>Text size of the captions shown with the player's CC button.</source>
        <translation>Text size of the captions shown with the player&apos;s CC button.</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Small</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Medium</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Large</translation>
    </message>
    <message>
        <source>Extra large</source>
        <translation>Extra large</translation>
    </message>
    <message>
        <source>Play now</source>
        <translation>Play now</translation>
    </message>
    <message>
        <source>Autoplay countdown</source>
        <translation>Autoplay countdown</translation>
    </message>
    <message>
        <source>Before autoplay starts a related video, show what's up next for a few seconds so you can cancel.</source>
        <translation>Before autoplay starts a related video, show what&apos;s up next for a few seconds so you can cancel.</translation>
    </message>
    <message>
        <source>Remember playback speed</source>
        <translation>Remember playback speed</translation>
    </message>
    <message>
        <source>Start at the speed you last picked with the player's Speed button, also after Playlet restarts.</source>
        <translation>Start at the speed you last picked with the player&apos;s Speed button, also after Playlet restarts.</translation>
    </message>
    <message>
        <source>Music for you</source>
        <translation>Music for you</translation>
    </message>
    <message>
        <source>Start mix</source>
        <translation>Start mix</translation>
    </message>
    <message>
        <source>Mix - %1</source>
        <translation>Mix - %1</translation>
    </message>
    <message>
        <source>Plays next</source>
        <translation>Plays next</translation>
    </message>
    <message>
        <source>(built-in)</source>
        <translation>(built-in)</translation>
    </message>
    <message>
        <source>That didn't work, try again</source>
        <translation>That didn&apos;t work, try again</translation>
    </message>
    <message>
        <source>(saved copy)</source>
        <translation>(saved copy)</translation>
    </message>
    <message>
        <source>Updated to v%1</source>
        <translation>Updated to v%1</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Comments</translation>
    </message>
</context>
</TS>
