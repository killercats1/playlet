'import "pkg:/components/Telemetry/LastExitCrash.bs"
'import "pkg:/components/Telemetry/LocalDiagnostics.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/Types.bs"

function Init() as void
    InitializeBindings() ' auto-generated!
    if m.global.telemetry <> invalid
        return
    end if
    m.global.addFields({
        telemetry: m.top
    })
    m.top.functionName = "TelemetryLoop"
end function

function OnNodeReady() as void
    m.top.ObserveField("enabled", FuncName(OnEnabledChanged))
    m.preferences.ObserveFieldScoped("dev.diagnostics.enabled", FuncName(OnPreferencesChanged))
    enabled = ValidBool(m.preferences["dev.diagnostics.enabled"])
    OnPreferencesChanged({
        enabled: enabled
        getData: function() as boolean
            return m.enabled
        end function
    })
end function

function OnPreferencesChanged(event as object) as void
    m.top.enabled = event.getData()
end function

function OnEnabledChanged(event as object) as void
    enabled = event.getData()
    LogInfo3("[Telemetry.bs:31]", "Telemetry enabled:", enabled)
    if enabled
        m.top.control = "run"
    else
        m.top.control = "stop"
    end if
end function

function TelemetryLoop() as void
    msgPort = CreateObject("roMessagePort")
    m.deviceInfo = CreateObject("roDeviceInfo")
    m.tags = GetTags()
    m.release = GetRelease(m.tags)
    m.dist = GetDist(m.tags)
    m.top.observeField("LogInfo", msgPort)
    m.top.observeField("LogWarn", msgPort)
    m.top.observeField("LogError", msgPort)
    m.top.observeField("LogEvent", msgPort)
    writer = LocalDiagnostics_Writer()
    writer.WriteHeader(m.tags)
    lastExitCrashEvent = CreateLastExitCrashEvent()
    if lastExitCrashEvent <> invalid
        writer.WriteEvent(lastExitCrashEvent)
    end if
    levelMap = {
        "LogInfo": "info"
        "LogWarn": "warning"
        "LogError": "error"
    }
    receivedAt = CreateObject("roDateTime")
    while true
        msg = wait(0, msgPort)
        if type(msg) <> "roSGNodeEvent"
            continue while
        end if
        receivedAt.Mark()
        field = msg.getField()
        if levelMap.DoesExist(field)
            writer.WriteEvent({
                level: levelMap[field]
                message: msg.getData()
                timestamp: receivedAt.ToISOString()
            })
        else if field = "LogEvent"
            data = msg.getData()
            writer.WriteEvent({
                level: data.level
                message: data.message
                timestamp: receivedAt.ToISOString()
                attachments: data.attachments
            })
        end if
    end while
end function

function GetTags() as object
    appInfo = m.applicationInfo
    tags = appInfo.callfunc("GetAppInfo", invalid)
    tags.Append(appInfo.callfunc("GetDeviceInfo", invalid))
    tags.Delete("friendly_name")
    for each key in tags
        if not IsString(tags[key])
            tags[key] = ToString(tags[key])
        end if
    end for
    
    tags["session_id"] = m.deviceInfo.GetRandomUUID()
    return tags
end function

function GetRelease(tags as object) as string
    return (bslib_toString(tags["lib_version"]) + "-" + bslib_toString(tags["lib_git_commit_hash"]))
end function

function GetDist(tags as object) as string
    dist = (bslib_toString(tags["app_version"]) + "-" + bslib_toString(tags["app_git_commit_hash"]) + "-" + bslib_toString(tags["lib_version"]) + "-" + bslib_toString(tags["lib_git_commit_hash"]))
    if tags["id"] = "dev"
        dist = dist + "-dev"
    end if
    return dist
end function