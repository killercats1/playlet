'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
' Diagnostics are only ever written to a local file on the device; nothing is sent over the network.
' The files can be read from the web app's Info page (served under /logs/).



' cachefs is shared and limited, so a single session's file is capped.

function __LocalDiagnostics_Writer_method_new()
    m.buffer = invalid
    m.bytesWritten = 0
    m.full = false
    m.buffer = CreateObject("roByteArray")
    CreateDirectory("cachefs:/logs")
    DeleteFile("cachefs:/logs/diagnostics_previous.txt")
    MoveFile("cachefs:/logs/diagnostics.txt", "cachefs:/logs/diagnostics_previous.txt")
end function
function __LocalDiagnostics_Writer_method_WriteHeader(tags as object) as void
    m.Append(("************* Session " + bslib_toString(ValidString(tags["session_id"])) + " *************" + chr(10) + bslib_toString(FormatJson(tags)) + chr(10)))
end function
function __LocalDiagnostics_Writer_method_WriteEvent(event as object) as void
    m.Append(LocalDiagnostics_FormatEvent(event))
end function
function __LocalDiagnostics_Writer_method_Append(text as string) as void
    if m.full
        return
    end if
    m.buffer.FromAsciiString(text)
    if m.bytesWritten + m.buffer.Count() > 2097152
        m.full = true
        m.buffer.FromAsciiString(("[diagnostics log full: " + bslib_toString(2097152) + " bytes, further events dropped]" + chr(10)))
    end if
    m.buffer.AppendFile("cachefs:/logs/diagnostics.txt")
    m.bytesWritten += m.buffer.Count()
end function
function __LocalDiagnostics_Writer_builder()
    instance = {}
    instance.new = __LocalDiagnostics_Writer_method_new
    instance.WriteHeader = __LocalDiagnostics_Writer_method_WriteHeader
    instance.WriteEvent = __LocalDiagnostics_Writer_method_WriteEvent
    instance.Append = __LocalDiagnostics_Writer_method_Append
    return instance
end function
function LocalDiagnostics_Writer()
    instance = __LocalDiagnostics_Writer_builder()
    instance.new()
    return instance
end function

function LocalDiagnostics_FormatEvent(event as object) as string
    timestamp = ValidString(event.timestamp)
    if timestamp = ""
        timestamp = CreateObject("roDateTime").ToISOString()
    end if
    text = ("[" + bslib_toString(timestamp) + "] [" + bslib_toString(UCase(ValidString(event.level))) + "] " + bslib_toString(LocalDiagnostics_Redact(ToString(event.message))) + chr(10))
    if IsArray(event.attachments)
        for each attachment in event.attachments
            if IsAssociativeArray(attachment)
                text += ("----- " + bslib_toString(ValidString(attachment.filename)) + " -----" + chr(10) + bslib_toString(LocalDiagnostics_Redact(ValidString(attachment.data))) + chr(10) + "----- end " + bslib_toString(ValidString(attachment.filename)) + " -----" + chr(10))
            end if
        end for
    end if
    return text
end function

' Masks credentials that can show up in logged requests.
function LocalDiagnostics_Redact(text as dynamic) as dynamic
    if StringUtils_IsNullOrEmpty(text)
        return text
    end if
    authHeader = CreateObject("roRegex", "Authorization: (?!<REDACTED>)[^\r\n]*", "i")
    for each match in authHeader.MatchAll(text)
        text = text.Replace(match[0], "Authorization: <REDACTED>")
    end for
    refreshToken = CreateObject("roRegex", "(" + chr(34) + "refresh_token" + chr(34) + "\s*:\s*)" + chr(34) + "[^" + chr(34) + "]*" + chr(34) + "", "i")
    for each match in refreshToken.MatchAll(text)
        text = text.Replace(match[0], (bslib_toString(match[1]) + chr(34) + "<REDACTED>" + chr(34)))
    end for
    return text
end function