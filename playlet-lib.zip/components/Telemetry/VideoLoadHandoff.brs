'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
function VideoLoadHandoff_Read(path as string, videoLoadId as string) as dynamic
    handoff = StringUtils_ParseJsonSafe(ReadAsciiFile(path))
    if not IsAssociativeArray(handoff) or handoff["video_load_id"] <> videoLoadId
        return invalid
    end if
    return handoff["value"]
end function

function VideoLoadHandoff_Write(path as string, videoLoadId as string, value as dynamic) as void
    WriteAsciiFile(path, FormatJson({
        "video_load_id": videoLoadId
        "value": value
    }))
end function

function VideoLoadHandoff_ReadAndDelete(path as string, videoLoadId as string) as dynamic
    value = VideoLoadHandoff_Read(path, videoLoadId)
    if value <> invalid
        DeleteFile(path)
    end if
    return value
end function