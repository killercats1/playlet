'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"


function Init()
    m.chipsGroup = m.top.findNode("chipsGroup")
    m.focusedIndex = 0
    m.top.visible = false
    m.top.focusable = false
end function

function OnChipsChange() as void
    chips = m.top.chips
    hadFocus = m.top.isInFocusChain()
    while m.chipsGroup.getChildCount() > 0
        m.chipsGroup.removeChildIndex(0)
    end while
    if not IsArray(chips) or chips.Count() = 0
        m.top.hasChips = false
        m.top.visible = false
        m.top.focusable = false
        return
    end if
    x = 0
    m.focusedIndex = 0
    for i = 0 to chips.Count() - 1
        chip = chips[i]
        button = CreateObject("roSGNode", "ButtonEx")
        button.iconVisible = false
        button.height = 44
        button.padding = [
            22
            22
        ]
        button.normalFontSize = 20
        button.boldFontSize = 20
        if chip.isSelected = true
            
            button.backgroundColor = "#EBEBEBFF"
            button.textColor = "#161616FF"
            m.focusedIndex = i
        end if
        button.text = ValidString(chip.title)
        
        button.disabled = true
        button.disabled = false
        button.translation = [
            x
            0
        ]
        button.addFields({
            chipIndex: i
        })
        button.observeField("buttonSelected", FuncName(OnChipSelected))
        m.chipsGroup.appendChild(button)
        x += button.width + 14
    end for
    m.top.hasChips = true
    m.top.visible = true
    m.top.focusable = true
    if hadFocus
        FocusChip(m.focusedIndex)
    end if
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    FocusChip(m.focusedIndex)
end function

function FocusChip(index as integer) as void
    count = m.chipsGroup.getChildCount()
    if count = 0
        return
    end if
    if index < 0
        index = 0
    else if index >= count
        index = count - 1
    end if
    m.focusedIndex = index
    NodeSetFocus(m.chipsGroup.getChild(index), true)
end function

function OnChipSelected(event as object) as void
    index = event.getRoSGNode().chipIndex
    chips = m.top.chips
    if not IsArray(chips) or index < 0 or index >= chips.Count()
        return
    end if
    m.top.selected = chips[index]
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if not press
        return false
    end if
    if key = "left" and m.focusedIndex > 0
        FocusChip(m.focusedIndex - 1)
        return true
    end if
    if key = "right" and m.focusedIndex < m.chipsGroup.getChildCount() - 1
        FocusChip(m.focusedIndex + 1)
        return true
    end if
    return false
end function