'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/VideoFeed/FeedLoadState.bs"
'import "pkg:/source/utils/ErrorUtils.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"

function LoadPlaylistPage(invidiousNode as object, jobQueue as object) as void
    LoadPlaylist(invidiousNode, jobQueue, true)
end function

function LoadPlaylistAll(invidiousNode as object, jobQueue as object) as void
    LoadPlaylist(invidiousNode, jobQueue, false)
end function

function LoadPlaylist(invidiousNode as object, jobQueue as object, singlePage as boolean) as void
    loadState = m.top.loadState
    if loadState = "Loading" or loadState = "Loaded"
        return
    end if
    if m.playlistContentJob <> invalid
        m.playlistContentJob.cancel = true
        m.top.isLoading = false
    end if
    m.top.loadState = "Loading"
    input = {
        content: m.top
        invidious: invidiousNode
        singlePage: singlePage
    }
    m.top.isLoading = true
    m.playlistContentJob = JobSystem_CreateCallback(OnPlaylistContentJobDone)
    JobSystem_QueueJob(jobQueue, "PlaylistContentJob", input, m.playlistContentJob)
end function

function OnPlaylistContentJobDone(event as object) as void
    callback = event.getRoSGNode()
    JobSystem_UnobserveCallback(callback)
    m.playlistContentJob = invalid
    m.top.isLoading = false
    if callback.cancel or callback.success
        return
    end if
    message = Tr("Failed to load playlist %1").Replace("%1", m.top.playlistId) + (chr(10) + bslib_toString(callback.error))
    DialogUtils_ShowDialogEx({
        message: message
        title: Tr("Playlist load error")
        large: true
    })
end function