'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/VideoFeed/FeedLoadState.bs"
'import "pkg:/source/utils/ErrorUtils.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"

function LoadChannel(invidiousNode as object, jobQueue as object) as void
    loadState = m.top.loadState
    if loadState = "Loading" or loadState = "Loaded" or loadState = "Error"
        return
    end if
    if m.channelContentJob <> invalid
        m.channelContentJob.cancel = true
    end if
    m.top.loadState = "Loading"
    input = {
        content: m.top
        invidious: invidiousNode
    }
    m.channelContentJob = JobSystem_CreateCallback(OnChannelContentJobDone)
    JobSystem_QueueJob(jobQueue, "ChannelContentJob", input, m.channelContentJob)
end function

function OnChannelContentJobDone(event as object) as void
    callback = event.getRoSGNode()
    JobSystem_UnobserveCallback(callback)
    m.channelContentJob = invalid
    if callback.cancel or callback.success
        return
    end if
    message = Tr("Failed to load channel %1").Replace("%1", m.top.authorId) + (chr(10) + bslib_toString(callback.error))
    DialogUtils_ShowDialogEx({
        message: message
        title: Tr("Channel load error")
        large: true
    })
end function