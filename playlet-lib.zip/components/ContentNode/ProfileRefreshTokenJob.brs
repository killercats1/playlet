'import "pkg:/components/Services/Innertube/InnertubeService.bs"
'import "pkg:/source/utils/ErrorUtils.bs"

function ExecuteJob() as void
    input = JobGetInput()
    profileNode = input.profile
    accessTokenObject = input.accessTokenObject
    profilesService = input.profilesService
    try
        cancellation = JobGetCancellation()
        if InnertubeService_AuthRefreshAccessToken(accessTokenObject, cancellation)
            profileNode.update({
                expiresIn: accessTokenObject.expiresIn
                expiresTimestamp: accessTokenObject.expiresTimestamp
                accessToken: accessTokenObject.accessToken
            })
            profilesService.callfunc("SaveUserProfilesToRegistry", invalid)
        else
            JobError("Refresh response contained no access token")
        end if
    catch error
        
        if ValidBool(accessTokenObject.terminalRefreshError)
            profileNode.callfunc("MarkNeedsReauth", invalid)
        end if
        JobError("Failed to refresh access token: " + ErrorUtils_Format(error))
    end try
    
    profileNode.refreshCompleted = true
end function