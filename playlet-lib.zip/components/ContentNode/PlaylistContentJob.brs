'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/components/VideoFeed/FeedLoadState.bs"

function ExecuteJob() as void
    input = JobGetInput()
    contentNode = input.content
    invidiousNode = input.invidious
    singlePage = input.singlePage
    if JobIsCancelled()
        contentNode.loadState = "None"
        JobCancel()
        return
    end if
    service = Invidious_InvidiousService(invidiousNode)
    instance = service.GetInstance()
    cancellation = JobGetCancellation()
    while true
        playlistId = contentNode.playlistId
        index = contentNode.getChildCount()
        continuation = contentNode.continuation
        hadContinuation = not StringUtils_IsNullOrEmpty(continuation)
        if playlistId.StartsWith("RD") and not hadContinuation
            videoId = contentNode.videoId
            if not StringUtils_IsNullOrEmpty(videoId)
                continuation = videoId
            end if
        end if
        response = service.GetPlaylist(playlistId, index, continuation, cancellation)
        if JobIsCancelled()
            contentNode.loadState = "None"
            JobCancel()
            return
        end if
        metadata = response.Json()
        if not response.IsSuccess() or metadata = invalid
            contentNode.loadState = "Error"
            JobError(response.ErrorMessage())
            return
        end if
        if metadata.DoesExist("error")
            contentNode.loadState = "Error"
            JobError(metadata.error)
            return
        end if
        beforeChildCount = contentNode.getChildCount()
        InvidiousContent_ToPlaylistContentNode(contentNode, metadata, instance)
        afterChildCount = contentNode.getChildCount()
        videoCount = ValidInt(metadata.videoCount)
        hasContinuation = not StringUtils_IsNullOrEmpty(metadata.continuation)
        noMoreContinuation = hadContinuation and not hasContinuation
        noVideosAdded = afterChildCount = beforeChildCount
        reachedVideoCount = videoCount <> -1 and afterChildCount >= videoCount
        if noMoreContinuation or noVideosAdded or reachedVideoCount
            contentNode.loadState = "Loaded"
            return
        else
            contentNode.loadState = "LoadedPage"
            if singlePage
                return
            end if
        end if
    end while
end function