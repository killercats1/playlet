'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"

function ExecuteJob() as void
    input = JobGetInput()
    contentNode = input.content
    invidiousNode = input.invidious
    if JobIsCancelled()
        contentNode.loadState = "None"
        JobCancel()
        return
    end if
    service = Invidious_InvidiousService(invidiousNode)
    cancellation = JobGetCancellation()
    response = service.GetChannel(contentNode.authorId, cancellation)
    if JobIsCancelled()
        contentNode.loadState = "None"
        JobCancel()
        return
    end if
    metadata = response.Json()
    if not response.IsSuccess() or metadata = invalid
        contentNode.loadState = "Error"
        JobError(response.ErrorMessage())
        return
    end if
    InvidiousContent_ToChannelContentNode(contentNode, metadata)
    contentNode.loadState = "Loaded"
end function