'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.types.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/MessagePortUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/TimeUtils.bs"
function ProfileContentAuthTokenUtils_DeriveAuthState(profileType as string, accessToken as dynamic, refreshToken as dynamic) as string
    if profileType = "youtube"
        if StringUtils_IsNullOrEmpty(refreshToken)
            return "NeedsReauth"
        end if
        return "Authenticated"
    end if
    if profileType = "invidious"
        if StringUtils_IsNullOrEmpty(accessToken)
            return "NeedsReauth"
        end if
        
        token = StringUtils_ParseJsonSafe(accessToken)
        if IsAssociativeArray(token) and IsNumber(token.expire) and token.expire <= TimeUtils_Now().AsSeconds()
            return "NeedsReauth"
        end if
        return "Authenticated"
    end if
    LogError3("[ProfileContentAuthTokenUtils.bs:26]", "Unknown profile type when deriving auth state:", profileType)
    return "Authenticated"
end function

' The unobserve at the end is field-level: it removes every scoped observer the
' calling component holds on refreshCompleted. Hold long-lived observers on authState.
function ProfileContentAuthTokenUtils_EnsureFreshAccessToken(profileNode as object) as object
    messagePort = CreateObject("roMessagePort")
    MessagePortUtils_ObserveFieldScopedExSafe(profileNode, "refreshCompleted", messagePort)
    result = profileNode.callfunc("ResolveAccessToken", invalid)
    if result.state = "Refreshing"
        wait(30000, messagePort)
        result = profileNode.callfunc("ResolveAccessToken", invalid)
    end if
    result.profile = profileNode
    profileNode.unobserveFieldScoped("refreshCompleted")
    return result
end function