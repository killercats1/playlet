'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.types.bs"
'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/TimeUtils.bs"
' Refresh well before expiry; stop serving a few minutes before expiry so a request
' never carries a token that dies in flight.



' A Refreshing state means a refresh job is in flight; its completion pulses refreshCompleted.
function ResolveAccessToken(_unused as dynamic) as object
    result = {
        state: "Refreshing"
        token: ""
        serverUrl: m.top.serverUrl
        activeIdentifyToken: m.top.activeIdentifyToken
        freshUntilSeconds: 0
    }
    if m.top.authState = "NeedsReauth"
        result.state = "NeedsReauth"
        return result
    end if
    if m.top.type = "invidious"
        
        result.state = "Ok"
        result.token = m.top.accessToken
        return result
    end if
    nowSeconds = TimeUtils_Now().AsSeconds()
    expiresTimestamp = m.top.expiresTimestamp
    result.freshUntilSeconds = expiresTimestamp - (60 * 60)
    accessToken = m.top.accessToken
    
    if expiresTimestamp < nowSeconds + (60 * 60) or StringUtils_IsNullOrEmpty(accessToken)
        StartRefreshJob()
        if m.top.authState = "NeedsReauth"
            result.state = "NeedsReauth"
            return result
        end if
    end if
    if not StringUtils_IsNullOrEmpty(accessToken) and expiresTimestamp > nowSeconds + (60 * 5)
        result.state = "Ok"
        result.token = accessToken
    end if
    return result
end function

function StartRefreshJob() as void
    if m.profileRefreshTokenJob <> invalid and not m.profileRefreshTokenJob.done
        return
    end if
    
    if StringUtils_IsNullOrEmpty(m.top.refreshToken)
        LogError2("[ProfileContentNode.bs:66]", "Refresh requested for profile without a refresh token")
        MarkNeedsReauth(invalid)
        return
    end if
    EnsureSceneRefs()
    LogInfo3("[ProfileContentNode.bs:73]", "Refreshing access token for profile:", m.top.username)
    input = {
        profile: m.top
        profilesService: m.profilesService
        accessTokenObject: {
            clientId: m.top.clientId
            clientSecret: m.top.clientSecret
            refreshToken: m.top.refreshToken
        }
    }
    m.profileRefreshTokenJob = JobSystem_CreateCallback(OnProfileRefreshTokenJobDone)
    JobSystem_QueueJob(m.jobQueue, "ProfileRefreshTokenJob", input, m.profileRefreshTokenJob)
end function

function OnProfileRefreshTokenJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.profileRefreshTokenJob = invalid
end function

function MarkNeedsReauth(_unused as dynamic) as void
    if m.top.authState = "NeedsReauth"
        return
    end if
    m.top.update({
        accessToken: ""
        refreshToken: ""
        expiresTimestamp: 0
        authState: "NeedsReauth"
    })
    
    m.top.refreshCompleted = true
    LogError2("[ProfileContentNode.bs:108]", "Profile credential is dead; sign-in required")
    EnsureSceneRefs()
    if m.profilesService <> invalid
        m.profilesService.callfunc("SaveUserProfilesToRegistry", invalid)
        currentProfile = m.profilesService.currentProfile
        if currentProfile <> invalid and currentProfile.isSameNode(m.top)
            m.profilesService.currentProfileChanged = true
        end if
    end if
    DialogUtils_ShowDialogEx({
        title: Tr("Session expired")
        message: Tr("The session has expired. Please sign in again with this profile, or switch to another profile.")
    })
end function

function EnsureSceneRefs() as void
    if m.scene = invalid
        m.scene = m.top.getScene()
    end if
    if m.profilesService = invalid
        m.profilesService = m.scene.findNode("ProfilesService")
    end if
    if m.jobQueue = invalid
        m.jobQueue = m.scene.findNode("JobQueue")
    end if
end function