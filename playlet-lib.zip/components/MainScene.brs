'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/EcpArgs.bs"
'import "pkg:/components/parts/AutoBind/AutoBind.part.bs"
'import "pkg:/components/parts/AutoBind/OnNodeReadyNoOp.bs"
'import "pkg:/source/utils/LoadingScreen.bs"
'import "pkg:/source/utils/Locale.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.scene = m.top.getScene()
    SetScenePalette(m.scene)
    
    m.MainSceneContainer = m.scene.findNode("MainSceneContainer")
    m.MainSceneContainer.ObserveField("change", FuncName(MainSceneContainerChanged))
end function

function SetScenePalette(scene as object) as void
    palette = scene.palette
    if palette <> invalid
        return
    end if
    palette = CreateObject("roSGNode", "RSGPalette")
    palette.colors = {
        DialogBackgroundColor: "#212121FF"
        DialogFocusColor: "#CECECEFF"
        DialogFocusItemColor: "#202020FF"
        DialogSecondaryTextColor: "#EBEBEBFF"
        DialogSecondaryItemColor: "#FF1C30FF"
        DialogTextColor: "#EBEBEBFF"
    }
    scene.palette = palette
end function


function MainSceneContainerChanged()
    AutoBindSceneGraph()
    StartWebServer()
    HideLoadingScreen()
    InitEcpArgs()
    if false
        if not ShowAnnouncement()
            m.scene.signalBeacon("AppLaunchComplete")
        end if
    else
        m.scene.signalBeacon("AppLaunchComplete")
    end if
    CopyLoadingMessagesToCache()
end function

function StartWebServer()
    m.loungeService = m.top.findNode("LoungeService")
    m.loungeService.callfunc("StartService", invalid)
    m.webServer = m.top.findNode("WebServer")
    m.webServer.callfunc("StartServer", invalid)
    m.dialServer = m.top.findNode("DialServer")
    m.dialServer.callfunc("StartServer", invalid)
end function

function ShowAnnouncement() as boolean
    dialog = DialogUtils_ShowDialogOnce({
        messageId: "1755469284"
        title: "Playback fixes - Canary build"
        message: [
            "Thank you for helping test the latest changes by using the Canary build of Playlet!"
            "If you encounter any issues with playback, please report them on the GitHub issue tracker."
            "https://github.com/iBicha/playlet/issues"
        ]
        alwaysOnTop: true
        large: true
    })
    if dialog = invalid
        return false
    end if
    m.scene.signalBeacon("AppDialogInitiate")
    dialog.observeField("wasClosed", FuncName(OnAnnouncementDialogClosed))
    return true
end function

function OnAnnouncementDialogClosed()
    m.scene.signalBeacon("AppDialogComplete")
    m.scene.signalBeacon("AppLaunchComplete")
end function