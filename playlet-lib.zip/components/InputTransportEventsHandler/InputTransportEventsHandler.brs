'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
'import "TransportEvents.types.bs"

function Init()
    m.appManager = CreateObject("roAppManager")
    m.videoQueue = m.top.getScene().findNode("VideoQueue")
    
    m.commandHandlers = {}
    m.commandHandlers["play"] = PlayCommand
    m.commandHandlers["pause"] = PauseCommand
    m.commandHandlers["stop"] = PauseCommand
    m.commandHandlers["seek"] = SeekCommand
    m.commandHandlers["startover"] = StartOverCommand
    m.commandHandlers["nowplaying"] = NowPlayingCommand
    m.commandHandlers["like"] = NotSupportedCommand
    m.commandHandlers["dislike"] = NotSupportedCommand
    m.commandHandlers["shuffle"] = NotSupportedCommand
    m.commandHandlers["loop"] = NotSupportedCommand
end function

function HandleTransportEvent(event as object) as string
    status = RouteTransportEvent(event)
    LogInfo5("[InputTransportEventsHandler.bs:26]", "transport event", event, "->", status)
    return status
end function

function RouteTransportEvent(event as object) as string
    commandHandler = m.commandHandlers[ValidString(event.command)]
    if commandHandler = invalid
        return "unhandled"
    end if
    return commandHandler(event)
end function

function PlayCommand(_event as object) as string
    player = m.videoQueue.player
    if player = invalid
        return "unhandled"
    end if
    if player.state = "paused"
        m.videoQueue.play = true
    end if
    return "success"
end function

function PauseCommand(_event as object) as string
    player = m.videoQueue.player
    if player = invalid
        return "unhandled"
    end if
    if player.state = "paused"
        return "error.redundant"
    end if
    m.videoQueue.pause = true
    return "success"
end function

function SeekCommand(event as object) as string
    player = m.videoQueue.player
    if player = invalid
        return "unhandled"
    end if
    deltaSeconds = ValidString(event.duration).ToInt()
    if deltaSeconds <= 0
        return "error"
    end if
    if event.direction = "backward"
        deltaSeconds = -deltaSeconds
    end if
    targetSeconds = player.position + deltaSeconds
    status = "success"
    if targetSeconds < 0
        targetSeconds = 0
        status = "success.seek-start"
    else if player.duration > 0 and targetSeconds > player.duration
        targetSeconds = player.duration
        status = "success.seek-end"
    end if
    player.setSeek = targetSeconds
    return status
end function

function StartOverCommand(_event as object) as string
    player = m.videoQueue.player
    if player = invalid
        return "unhandled"
    end if
    player.setSeek = 0
    return "success"
end function

function NowPlayingCommand(_event as object) as string
    player = m.videoQueue.player
    if player = invalid
        m.appManager.SetNowPlayingContentMetaData(invalid)
        return "success"
    end if
    content = player.content
    if content = invalid or StringUtils_IsNullOrEmpty(content.title)
        m.appManager.SetNowPlayingContentMetaData(invalid)
        return "error.generic"
    end if
    m.appManager.SetNowPlayingContentMetaData({
        title: content.title
        contentType: "movie"
    })
    return "success"
end function

function NotSupportedCommand(_event as object) as string
    return "error.channel"
end function