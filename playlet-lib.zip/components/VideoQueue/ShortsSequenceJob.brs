'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.bs"
'import "pkg:/components/Services/Innertube/ShortsSequence.bs"

' Loads the next batch of Shorts for the queue (endless Shorts). input: { more, videoId, invidious }
function ExecuteJob() as void
    input = JobGetInput()
    more = ValidString(input.more)
    accessToken = invalid
    onBehalfOfUser = invalid
    invidiousNode = input.invidious
    profile = invalid
    if invidiousNode <> invalid and invidiousNode.profilesService <> invalid
        profile = invidiousNode.profilesService.currentProfile
    end if
    if profile <> invalid and profile.type = "youtube"
        auth = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(profile)
        if auth.state = "Ok"
            accessToken = auth.token
            onBehalfOfUser = auth.activeIdentifyToken
        end if
    end if
    result = InnertubeShorts_GetMore(more, ValidString(input.videoId), accessToken, onBehalfOfUser, JobGetCancellation())
    if JobIsCancelled()
        JobCancel()
        return
    end if
    if result.error <> invalid
        JobError(result.error)
        return
    end if
    JobSuccessData({
        items: result.items
        continuation: result.continuation
    })
end function