'import "pkg:/source/utils/Locale.bs"


function VideoQueue_ShowNotifcation(notifications as object, contentNode as object, hintVisible as boolean) as void
    notification = notifications.findNode("VideoQueueNotification")
    if notification = invalid
        notification = notifications.createChild("VideoQueueNotification")
        notification.id = "VideoQueueNotification"
    end if
    notification.content = contentNode
    notification.heading = Tr("Added to queue")
    notification.hintVisible = hintVisible
    notification.show = true
end function

function VideoQueue_RemoveNotifcation(notifications as object) as void
    notification = notifications.findNode("VideoQueueNotification")
    if notification <> invalid
        notifications.RemoveChild(notification)
    end if
end function

function VideoQueue_SetVisible(notifications as object, visible as boolean)
    notification = notifications.findNode("VideoQueueNotification")
    if notification <> invalid
        notification.visible = visible
    end if
end function