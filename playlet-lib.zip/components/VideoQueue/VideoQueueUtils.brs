'import "pkg:/components/Services/FeedFilters/FeedFilters.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Logging.bs"
function VideoQueueUtils_GetQueueDto(videoQueue as object) as object
    items = []
    nowPlaying = invalid
    queueNodes = videoQueue.content.getChildren(-1, 0)
    for each node in queueNodes
        items.push({
            type: node.type
            videoId: node.videoId
            title: node.title
            author: node._author
            thumbnail: node.thumbnail
        })
    end for
    nowPlayingNode = videoQueue.nowPlaying
    if nowPlayingNode <> invalid
        nowPlaying = {
            type: nowPlayingNode.type
            videoId: nowPlayingNode.videoId
            title: nowPlayingNode.title
            author: nowPlayingNode._author
            thumbnail: nowPlayingNode.thumbnail
        }
    end if
    return {
        items: items
        nowPlaying: nowPlaying
        index: videoQueue.index
    }
end function

function VideoQueueUtils_IsVideoPlayerFullScreen(videoQueue as object) as boolean
    return videoQueue.videoContainer.fullscreen
end function

function VideoQueueUtils_ToggleVideoPictureInPicture(videoQueue as object) as boolean
    player = videoQueue.player
    if player = invalid
        return false
    end if
    videoContainer = videoQueue.videoContainer
    videoContainer.fullscreen = not videoContainer.fullscreen
    if videoContainer.fullscreen
        NodeSetFocus(player, true)
    else
        videoQueue.appController.callfunc("FocusTopScreen", invalid)
    end if
    return true
end function

function VideoQueueUtils_IsVideoPlayerOpen(videoQueue as object) as boolean
    return videoQueue.player <> invalid
end function

function VideoQueueUtils_Play(videoQueue as object) as boolean
    player = videoQueue.player
    if player = invalid
        return false
    end if
    videoQueue.play = true
    return true
end function

function VideoQueueUtils_Pause(videoQueue as object) as boolean
    player = videoQueue.player
    if player = invalid
        return false
    end if
    videoQueue.pause = true
    return true
end function

function VideoQueueUtils_Resume(videoQueue as object) as boolean
    player = videoQueue.player
    if player = invalid
        return false
    end if
    videoQueue.play = true
    return true
end function

function VideoQueueUtils_TogglePause(videoQueue as object) as boolean
    player = videoQueue.player
    if player = invalid
        return false
    end if
    if player.state = "playing"
        player.control = "pause"
        return true
    else if player.state = "paused"
        player.control = "resume"
        return true
    end if
    return false
end function

' force: the viewer asked for the next video (the player's Next button), so a recommended video plays even
' with autoplay off.
function VideoQueueUtils_PlayNext(videoQueue as object, invidiousNode as object, preferences as object, force = false as boolean) as boolean
    if videoQueue.hasNext
        videoQueue.next = true
        return true
    end if
    if not force and preferences["playback.autoplay"] <> true
        return false
    end if
    player = videoQueue.player
    if player = invalid
        return false
    end if
    content = player.content
    if content = invalid
        return false
    end if
    metadata = content.metadata
    if metadata = invalid
        return false
    end if
    recommendedVideos = metadata.recommendedVideos
    if not IsArray(recommendedVideos) or recommendedVideos.Count() = 0
        return false
    end if
    recommendedVideo = VideoQueueUtils_PickRecommended(recommendedVideos, videoQueue.content)
    if recommendedVideo = invalid
        return false
    end if
    LogInfo2("[VideoQueueUtils.bs:142]", ("Playing next recommended video (" + bslib_toString(recommendedVideo.videoId) + ")"))
    instance = invidiousNode.callfunc("GetInstance", invalid)
    node = InvidiousContent_ToVideoContentNode(invalid, recommendedVideo, instance)
    videoQueue.playVideo = node
    return true
end function

' The related video autoplay plays: the first one not already in the queue that can be watched (not
' members-only, not marked Not interested / Don't recommend), preferring one not already watched to the end.
function VideoQueueUtils_PickRecommended(recommendedVideos as object, queueContent as dynamic) as dynamic
    if not IsArray(recommendedVideos)
        return invalid
    end if
    hidden = FeedFilters_LoadLookup()
    for each skipWatched in [
        true
        false
    ]
        for each video in recommendedVideos
            if not IsAssociativeArray(video) or not IsString(video.videoId) or video.videoId = ""
                continue for
            end if
            if queueContent <> invalid and queueContent.findNode(video.videoId) <> invalid
                continue for
            end if
            if VideoQueueUtils_IsWatchableRecommendation(video, hidden, skipWatched)
                return video
            end if
        end for
    end for
    return invalid
end function

' hidden: FeedFilters.LoadLookup()
function VideoQueueUtils_IsWatchableRecommendation(video as object, hidden as object, skipWatched as boolean) as boolean
    if video.membersOnly = true
        return false
    end if
    if hidden.videos.DoesExist(video.videoId)
        return false
    end if
    if IsString(video.authorId) and hidden.channels.DoesExist(video.authorId)
        return false
    end if
    if skipWatched and IsNumber(video.percentDurationWatched) and video.percentDurationWatched >= 90
        return false
    end if
    return true
end function