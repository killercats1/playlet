' Convenience functions to use from context menu
function FuncPlayVideo(videoNode as object)
    m.top.playVideo = videoNode
end function

function FuncPlayPlaylist(playlistNode as object, playlistIndex as integer)
    m.top.playPlaylist = {
        playlistNode: playlistNode
        playlistIndex: playlistIndex
    }
end function

function FuncAddToQueueVideo(videoNode as object)
    m.top.addToQueue = [
        videoNode
    ]
end function

function FuncShufflePlaylist(playlistNode as object)
    m.top.playPlaylist = {
        playlistNode: playlistNode
        playlistIndex: 0
        shuffle: true
    }
end function

function FuncPlayNextVideo(videoNode as object)
    InsertNextInQueue(videoNode)
end function

function FuncAddToQueuePlaylist(playlistNode as object)
    m.top.addToQueuePlaylist = playlistNode
end function