'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/source/utils/DisposableObserve.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    m.queueList = m.top.findNode("queueList")
    m.queueLabel = m.top.findNode("queueLabel")
    m.clearButton = m.top.findNode("clearButton")
    m.showAnimation = m.top.findNode("showAnimation")
    DisposableObserveField(m.clearButton, "buttonSelected", FuncName(OnClearButtonSelected))
    DisposableObserveField(m.queueList, "itemSelected", FuncName(OnItemSelected))
    SetNavigation(m.queueList, "up", m.clearButton)
    SetNavigation(m.clearButton, "down", m.queueList)
    m.videosDetailsToLoad = []
end function

function Show(_unused as dynamic)
    m.showAnimation.control = "start"
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.queueList, true)
end function

function OnContentSet() as void
    content = m.top.content
    if content = invalid
        if m.videoQueueViewContentJob <> invalid
            m.videoQueueViewContentJob.cancel = true
            m.videoQueueViewContentJob = invalid
        end if
        return
    end if
    if not content.isSameNode(m.queueList.content)
        m.queueList.content = content
    end if
    index = content.index
    videoCount = content.getChildCount()
    if IsInt(index) and index <> -1
        m.queueLabel.text = Tr("Queue") + (" (" + bslib_toString(index + 1) + "/" + bslib_toString(videoCount) + ")")
    else
        m.queueLabel.text = Tr("Queue") + (" (" + bslib_toString(videoCount) + ")")
    end if
    AdjustFocus(videoCount)
    
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if NavigationKeyHandler(key, press).handled
        return true
    end if
    if press = false
        return false
    end if
    if key = "back"
        Close()
        return true
    end if
    return false
end function

function Close()
    m.top.appController.callfunc("PopScreen", invalid)
    m.top.dispose = true
end function

function OnClearButtonSelected()
    m.top.videoQueue.clearQueue = true
end function

function OnItemSelected() as void
    content = m.queueList.content
    if content = invalid
        return
    end if
    index = m.queueList.itemSelected
    if index < 0 or index >= content.getChildCount()
        return
    end if
    videoQueue = m.top.videoQueue
    videoQueue.index = index
    videoQueue.play = true
end function

function LoadVideoDetailsIfNeeded() as void
    content = m.queueList.content
    if content = invalid
        return
    end if
    videoNodes = content.getChildren(-1, 0)
    index = m.top.videoQueue.index
    indexInLoadingArray = -1
    m.videosDetailsToLoad.Clear()
    for i = 0 to videoNodes.Count() - 1
        videoNode = videoNodes[i]
        
        if videoNode.title = ""
            m.videosDetailsToLoad.Push(videoNode)
        end if
        if index = i
            indexInLoadingArray = m.videosDetailsToLoad.Count() - 1
        end if
    end for
    for each videoNode in videoNodes
        if videoNode.title = ""
            m.videosDetailsToLoad.Push(videoNode)
        end if
    end for
    if m.videosDetailsToLoad.Count() = 0
        return
    end if
    LogInfo4("[VideoQueueView.bs:141]", "Loading video details for", m.videosDetailsToLoad.Count(), "videos")
    if m.videoQueueViewContentJob <> invalid
        m.videoQueueViewContentJob.cancel = true
    end if
    input = {
        videoNodes: m.videosDetailsToLoad
        innertube: m.top.innertube
        invidious: m.top.invidious
        preferences: m.top.preferences
        index: indexInLoadingArray
    }
    m.videoQueueViewContentJob = JobSystem_CreateCallback()
    JobSystem_QueueJob(m.jobQueue, "VideoQueueViewContentJob", input, m.videoQueueViewContentJob)
end function

function AdjustFocus(videoCount as integer)
    hasVideos = videoCount > 0
    if not hasVideos and m.queueList.hasFocus()
        NodeSetFocus(m.clearButton, true)
    end if
    m.queueList.focusable = hasVideos
end function

function OnDispose()
    m.queueList.content = invalid
    DisposeObservers()
    if m.loadDetailsTask <> invalid
        m.loadDetailsTask.cancel = true
        m.loadDetailsTask = invalid
    end if
end function