'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
function VideoQueueViewUtils_Open(videoQueue as object, appController as object) as object
    videoQueueView = CreateObject("roSGNode", "VideoQueueView")
    videoQueueView.videoQueue = videoQueue
    videoQueueView.appController = appController
    videoQueueView.jobQueue = videoQueue.jobQueue
    videoQueueView.innertube = videoQueue.innertube
    videoQueueView.invidious = videoQueue.invidious
    videoQueueView.preferences = videoQueue.preferences
    appController.callfunc("PushScreen", videoQueueView)
    content = videoQueue.content
    index = videoQueue.index
    videoQueueView.content = content
    if index > -1 and index < content.GetChildCount()
        videoQueueView.jumpToItem = index
    end if
    videoQueueView.callfunc("Show", invalid)
    return videoQueueView
end function