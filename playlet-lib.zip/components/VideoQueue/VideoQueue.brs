'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/components/Services/LoungeService/LoungeMessages.bs"
'import "pkg:/components/VideoFeed/FeedLoadState.bs"
'import "pkg:/components/VideoQueue/Notifications/VideoQueueNotificationUtils.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/MathUtils.bs"
'import "VideoQueueFunctions.bs"

function Init()
    m.content = m.top.findNode("Content")
    m.top.content = m.content
    m.content.addField("index", "integer", false)
    m.content.index = m.top.index
    m.shortsJob = invalid
    m.shortsAttempts = 0
    m.sleepTimer = m.top.findNode("SleepTimer")
    m.sleepTimer.ObserveField("fire", FuncName(OnSleepTimerFire))
end function

' Sleep timer (the player's moon button): it lives here, not in the player, so it keeps counting across videos.
function OnSleepTimerChange() as void
    m.sleepTimer.control = "stop"
    minutes = m.top.sleepTimerMinutes
    if minutes > 0
        m.top.sleepAfterVideo = false
    end if
    if minutes <= 0
        m.top.sleepTimerEndsAt = 0
        return
    end if
    m.sleepTimer.duration = minutes * 60
    m.sleepTimer.control = "start"
    m.top.sleepTimerEndsAt = CreateObject("roDateTime").AsSeconds() + minutes * 60
end function

function OnSleepTimerFire() as void
    LogInfo2("[VideoQueue.bs:41]", "Sleep timer: stopping playback")
    m.top.sleepTimerMinutes = 0
    m.top.closePlayer = true
end function

function OnIndexChange()
    index = m.top.index
    m.content.index = index
    nodes = m.content.getChildren(-1, 0)
    for each node in nodes
        node.queueIndex = index
    end for
    UpdateHasPreviousNext()
    MaybeLoadMoreShorts()
end function

' Endless Shorts: while a Short from the Shorts tab plays within 6 of the end of the queue (or when the player
' asks, at the very end), load the next batch. The last Short holds where to continue from ("shortsMore":
' "v:<videoId>" or "c:<token>"). A batch that brings nothing new is retried from a different Short in the queue,
' up to 3 times; shortsLoading is true while a batch loads, so the player can wait for it.
function MaybeLoadMoreShorts(force = false as boolean) as void
    if m.shortsJob <> invalid
        return
    end if
    count = m.content.getChildCount()
    current = m.content.getChild(m.top.index)
    if current = invalid or not current.hasField("isShort") or current.isShort <> true
        return
    end if
    if not force and count - 1 - m.top.index > 6
        return
    end if
    last = m.content.getChild(count - 1)
    if last = invalid
        return
    end if
    more = ""
    if last.hasField("shortsMore") and IsString(last.shortsMore)
        more = last.shortsMore
        last.shortsMore = ""
    end if
    if more = ""
        if not force and m.shortsAttempts = 0
            return
        end if
        more = "v:" + RandomShortId()
    end if
    StartShortsJob(more, last.videoId)
end function

function StartShortsJob(more as string, fallbackVideoId as string) as void
    m.top.shortsLoading = true
    m.shortsJob = JobSystem_CreateCallback(OnShortsJobDone)
    JobSystem_QueueJob(m.top.jobQueue, "ShortsSequenceJob", {
        more: more
        videoId: fallbackVideoId
        invidious: m.top.invidious
    }, m.shortsJob)
end function

' A Short in the queue to start the next batch from (another one each retry, so the results differ).
function RandomShortId() as string
    count = m.content.getChildCount()
    for tries = 1 to 5
        node = m.content.getChild(Rnd(count) - 1)
        if node <> invalid and node.hasField("isShort") and node.isShort = true and not StringUtils_IsNullOrEmpty(node.videoId)
            return node.videoId
        end if
    end for
    return ValidString(m.content.getChild(count - 1).videoId)
end function

function OnLoadMoreShorts() as void
    MaybeLoadMoreShorts(true)
    if m.shortsJob = invalid
        
        m.top.shortsLoading = false
    end if
end function

function OnShortsJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.shortsJob = invalid
    info = event.getInfo()
    nodes = []
    continuation = ""
    if info.success
        instance = m.top.invidious.callfunc("GetInstance", invalid)
        for each item in ValidArray(info.data.items)
            if IsAssociativeArray(item) and IsString(item.videoId) and m.content.findNode(item.videoId) = invalid
                node = InvidiousContent_ToVideoContentNode(invalid, item, instance)
                node.addFields({
                    isShort: true
                })
                nodes.Push(node)
            end if
        end for
        continuation = ValidString(info.data.continuation)
    else
        LogWarnNoTelemetry3("[VideoQueue.bs:135]", "No more Shorts:", info.error)
    end if
    if nodes.Count() = 0
        m.shortsAttempts += 1
        if m.shortsAttempts < 3
            count = m.content.getChildCount()
            StartShortsJob("v:" + RandomShortId(), ValidString(m.content.getChild(count - 1).videoId))
            return
        end if
        LogWarnNoTelemetry2("[VideoQueue.bs:145]", "No more Shorts after 3 tries")
        m.shortsAttempts = 0
        m.top.shortsLoading = false
        return
    end if
    m.shortsAttempts = 0
    lastNode = nodes[nodes.Count() - 1]
    if continuation <> ""
        lastNode.addFields({
            shortsMore: "c:" + continuation
        })
    else
        
        lastNode.addFields({
            shortsMore: "v:" + lastNode.videoId
        })
    end if
    m.content.appendChildren(nodes)
    UpdateHasPreviousNext()
    m.top.shortsLoading = false
end function

function OnPlay() as void
    videoNode = m.content.getChild(m.top.index)
    if videoNode = invalid
        m.top.nowPlaying = invalid
        return
    end if
    player = m.top.player
    if player <> invalid
        content = player.content
        if content <> invalid and content.videoId = videoNode.videoId
            if player.state = "paused"
                player.control = "resume"
            else
                player.control = "play"
            end if
            return
        end if
        RemovePlayer()
    end if
    player = CreateVideoPlayer()
    if player = invalid
        m.top.nowPlaying = invalid
        return
    end if
    player.callfunc("PlayWithContent", videoNode)
    m.top.player = player
    m.top.nowPlaying = videoNode
end function

function OnPause() as void
    player = m.top.player
    if player = invalid
        return
    end if
    player.control = "pause"
end function

function OnPrevious() as void
    if not m.top.hasPrevious
        return
    end if
    RemovePlayer()
    m.top.index -= 1
    m.top.play = true
end function

function OnNext() as void
    if not m.top.hasNext
        return
    end if
    RemovePlayer()
    m.top.index += 1
    m.top.play = true
end function

function OnClosePlayer() as void
    if RemovePlayer()
        m.top.loungeService.outgoingMessages = [
            LoungeMessages_NowPlaying(invalid)
            LoungeMessages_OnStateChange(invalid)
        ]
    end if
end function

' Returns whether a player was open. A replacement calls this, not the closePlayer field: the field tells a
' lounge sender that nothing plays, which between two videos shows an empty nowPlaying.
function RemovePlayer() as boolean
    m.top.nowPlaying = invalid
    player = m.top.player
    if player = invalid
        return false
    end if
    player.close = true
    m.top.player = invalid
    m.previousPlayer = player
    m.top.appController.callfunc("FocusTopScreen", invalid)
    return true
end function

function OnPlayVideo() as void
    videoNode = m.top.playVideo
    if videoNode = invalid
        return
    end if
    m.top.playVideo = invalid
    nodeParent = videoNode.getParent()
    if not m.content.isSameNode(nodeParent)
        videoNode = videoNode.clone(false)
    end if
    queueCount = m.content.getChildCount()
    index = m.top.index
    index += 1
    if index >= queueCount
        m.content.appendChild(videoNode)
        index = m.content.getChildCount() - 1
    else
        m.content.insertChild(videoNode, index)
    end if
    m.top.index = index
    RemovePlayer()
    m.top.play = true
end function

function OnPlayPlaylist() as void
    playPlaylist = m.top.playPlaylist
    if playPlaylist = invalid
        return
    end if
    m.top.playPlaylist = invalid
    if m.loadingPlaylist <> invalid
        m.loadingPlaylist.UnobserveFieldScoped("loadState")
        m.loadingPlaylist = invalid
    end if
    playlistNode = playPlaylist.playlistNode
    playlistIndex = playPlaylist.playlistIndex
    if playlistNode = invalid or playlistIndex < 0
        return
    end if
    m.loadingPlaylist = playlistNode
    m.loadingPlaylistIndex = playlistIndex
    m.loadingPlaylistOp = "play"
    m.loadingPlaylistShuffle = playPlaylist.shuffle = true
    
    m.loadingPlaylistIsMix = ValidString(playlistNode.playlistId).StartsWith("RD")
    if playlistNode.loadState = "Loaded" or (m.loadingPlaylistIsMix and playlistNode.loadState = "LoadedPage")
        OnPlaylistLoadStateChange()
        return
    end if
    playlistNode.ObserveFieldScoped("loadState", FuncName(OnPlaylistLoadStateChange))
    if m.loadingPlaylistIsMix
        playlistNode.callfunc("LoadPlaylistPage", m.top.invidious, m.top.jobQueue)
    else
        playlistNode.callfunc("LoadPlaylistAll", m.top.invidious, m.top.jobQueue)
    end if
end function

function OnPlaylistLoadStateChange() as void
    if m.loadingPlaylist = invalid
        return
    end if
    loadState = m.loadingPlaylist.loadState
    if loadState = "None" or loadState = "Error"
        m.loadingPlaylist.UnobserveFieldScoped("loadState")
        m.loadingPlaylist = invalid
        return
    end if
    if loadState <> "Loaded" and not (m.loadingPlaylistIsMix = true and loadState = "LoadedPage")
        return
    end if
    m.loadingPlaylistIsMix = false
    playlistNode = m.loadingPlaylist
    playlistIndex = m.loadingPlaylistIndex
    playlistOp = m.loadingPlaylistOp
    m.loadingPlaylist.UnobserveFieldScoped("loadState")
    m.loadingPlaylist = invalid
    videoNodes = playlistNode.getChildren(-1, 0)
    if videoNodes.Count() = 0
        return
    end if
    LogInfo4("[VideoQueue.bs:344]", "Adding", videoNodes.Count(), "videos to the queue")
    for i = 0 to videoNodes.Count() - 1
        videoNodes[i] = videoNodes[i].clone(false)
    end for
    
    if playlistOp = "play" and m.loadingPlaylistShuffle = true
        m.loadingPlaylistShuffle = false
        for i = videoNodes.Count() - 1 to 1 step -1
            j = Rnd(i + 1) - 1
            swap = videoNodes[i]
            videoNodes[i] = videoNodes[j]
            videoNodes[j] = swap
        end for
        playlistIndex = 0
        queueCount = m.content.getChildCount()
        index = m.top.index + 1
        if index >= queueCount
            m.content.appendChildren(videoNodes)
        else
            m.content.insertChildren(videoNodes, index)
        end if
        m.top.index = index
        RemovePlayer()
        m.top.play = true
        return
    end if
    if playlistOp = "play"
        playlistIndex = MathUtils_Clamp(playlistIndex, 0, videoNodes.Count() - 1)
        
        existingIndex = FindPlaylistVideosInQueue(videoNodes)
        if existingIndex >= 0
            m.top.index = existingIndex + playlistIndex
            RemovePlayer()
            m.top.play = true
            return
        end if
        queueCount = m.content.getChildCount()
        index = m.top.index
        index += 1
        if index >= queueCount
            m.content.appendChildren(videoNodes)
        else
            m.content.insertChildren(videoNodes, index)
        end if
        m.top.index = index + playlistIndex
        RemovePlayer()
        m.top.play = true
    else if playlistOp = "queue"
        m.content.appendChildren(videoNodes)
        UpdateHasPreviousNext()
        queueNotifications = m.top.preferences["misc.queue_notifications"]
        if queueNotifications
            hintVisible = m.top.player = invalid or not m.top.videoContainer.fullscreen
            VideoQueue_ShowNotifcation(m.top.notifications, playlistNode, hintVisible)
        end if
    end if
end function

function FindPlaylistVideosInQueue(videoNodes as object) as integer
    queueCount = m.content.getChildCount()
    playlistCount = videoNodes.Count()
    if queueCount < playlistCount
        return -1
    end if
    queueVideos = m.content.getChildren(-1, 0)
    
    for i = queueCount - playlistCount to 0 step -1
        found = true
        for j = 0 to playlistCount - 1
            if queueVideos[i + j].videoId <> videoNodes[j].videoId
                found = false
                exit for
            end if
        end for
        if found
            return i
        end if
    end for
    return -1
end function

function OnClearQueue()
    queueCount = m.content.getChildCount()
    if queueCount > 0
        m.content.removeChildrenIndex(queueCount, 0)
    end if
    m.top.closePlayer = true
    m.top.index = -1
end function

function OnAddToQueue() as void
    videoNodes = m.top.addToQueue
    if videoNodes = invalid
        return
    end if
    m.top.addToQueue = invalid
    if videoNodes.Count() = 0
        return
    end if
    for i = 0 to videoNodes.Count() - 1
        videoNodes[i] = videoNodes[i].clone(false)
    end for
    m.content.appendChildren(videoNodes)
    UpdateHasPreviousNext()
    queueNotifications = m.top.preferences["misc.queue_notifications"]
    if queueNotifications
        node = videoNodes[0]
        hintVisible = m.top.player = invalid or not m.top.videoContainer.fullscreen
        VideoQueue_ShowNotifcation(m.top.notifications, node, hintVisible)
    end if
end function

'  "Play next": right after the playing video (or at the end of the queue when nothing plays).
function InsertNextInQueue(videoNode as object) as void
    if videoNode = invalid
        return
    end if
    index = m.top.index
    if index < 0 or index >= m.content.getChildCount()
        m.top.addToQueue = [
            videoNode
        ]
        return
    end if
    node = videoNode.clone(false)
    m.content.insertChild(node, index + 1)
    UpdateHasPreviousNext()
    if m.top.preferences["misc.queue_notifications"]
        hintVisible = m.top.player = invalid or not m.top.videoContainer.fullscreen
        VideoQueue_ShowNotifcation(m.top.notifications, node, hintVisible)
        notification = m.top.notifications.findNode("VideoQueueNotification")
        if notification <> invalid
            notification.heading = Tr("Plays next")
        end if
    end if
end function

function OnAddToQueuePlaylist() as void
    playlistNode = m.top.addToQueuePlaylist
    if playlistNode = invalid
        return
    end if
    m.top.addToQueuePlaylist = invalid
    if m.loadingPlaylist <> invalid
        m.loadingPlaylist.UnobserveFieldScoped("loadState")
        m.loadingPlaylist = invalid
    end if
    m.loadingPlaylist = playlistNode
    m.loadingPlaylistOp = "queue"
    m.loadingPlaylistIsMix = false
    if playlistNode.loadState = "Loaded"
        OnPlaylistLoadStateChange()
        return
    end if
    playlistNode.ObserveFieldScoped("loadState", FuncName(OnPlaylistLoadStateChange))
    playlistNode.callfunc("LoadPlaylistAll", m.top.invidious, m.top.jobQueue)
end function

function OnSetQueueAndIndex() as void
    setQueueAndIndex = m.top.setQueueAndIndex
    if setQueueAndIndex = invalid
        return
    end if
    m.top.setQueueAndIndex = invalid
    videoNodes = setQueueAndIndex.videoNodes
    index = setQueueAndIndex.index
    queueCount = m.content.getChildCount()
    if queueCount > 0
        m.content.removeChildrenIndex(queueCount, 0)
    end if
    if videoNodes.Count() > 0
        m.content.appendChildren(videoNodes)
    end if
    m.top.index = index
end function

function UpdateHasPreviousNext()
    queueCount = m.content.getChildCount()
    index = MathUtils_Clamp(m.top.index, 0, queueCount - 1)
    m.top.hasPrevious = index > 0
    m.top.hasNext = index < queueCount - 1
end function

function OnHasPrevious()
    message = LoungeMessages_OnHasPreviousNextChanged(m.top.hasPrevious, m.top.hasNext)
    m.top.loungeService.outgoingMessages = [
        message
    ]
end function

function OnHasNext()
    
    message = LoungeMessages_OnHasPreviousNextChanged(m.top.hasPrevious, m.top.hasNext)
    m.top.loungeService.outgoingMessages = [
        message
    ]
end function

function CreateVideoPlayer() as object
    playerComponent = "VideoPlayerDev"
    container = m.top.videoContainer
    videoPlayer = container.createChild(playerComponent)
    if videoPlayer = invalid
        LogError4("[VideoQueue.bs:572]", "createChild returned invalid for", playerComponent, "- cannot start playback")
        return invalid
    end if
    videoPlayer.id = "VideoPlayer"
    videoPlayer.previousPlayer = m.previousPlayer
    
    m.previousPlayer = invalid
    videoPlayer.callfunc("BindNode", invalid)
    if container.fullscreen
        NodeSetFocus(videoPlayer, true)
        dialog = m.top.getScene().dialog
        if dialog <> invalid and not ValidBool(dialog.alwaysOnTop)
            dialog.close = true
        end if
    end if
    return videoPlayer
end function