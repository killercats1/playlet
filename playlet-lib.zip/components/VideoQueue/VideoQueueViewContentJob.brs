'import "pkg:/components/Services/Innertube/InnertubeService.bs"
'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/source/utils/CancellationUtils.bs"
'import "pkg:/source/utils/MathUtils.bs"

function ExecuteJob() as void
    input = JobGetInput()
    videoNodes = input.videoNodes
    innertubeNode = input.innertube
    invidiousNode = input.invidious
    preferencesNode = input.preferences
    service = Invidious_InvidiousService(invidiousNode)
    instance = service.GetInstance()
    cancellation = JobGetCancellation()
    index = MathUtils_Clamp(input.index - 2, 0, videoNodes.Count() - 1)
    backend = preferencesNode["backend.selected"]
    visitorData = ""
    sessionData = innertubeNode.sessionData
    if IsAssociativeArray(sessionData)
        visitorData = ValidString(sessionData.visitorData)
    end if
    requestOptions = {
        cancellation: cancellation
        retryCount: 0
        fetchNext: false
        visitorData: visitorData
    }
    
    for i = index to videoNodes.Count() - 1
        videoNode = videoNodes[i]
        if not LoadVideoDetail(videoNode, service, instance, requestOptions, backend)
            
            sleep(500)
        end if
        if JobIsCancelled()
            JobCancel()
            return
        end if
    end for
    for i = index - 1 to 0 step -1
        videoNode = videoNodes[i]
        if not LoadVideoDetail(videoNode, service, instance, requestOptions, backend)
            
            sleep(1000)
        end if
        if JobIsCancelled()
            JobCancel()
            return
        end if
    end for
    return
end function

function LoadVideoDetail(videoNode as object, service as object, instance as string, requestOptions as object, backend as string) as boolean
    videoId = videoNode.videoId
    if backend = "playlet" or instance = "http://127.0.0.1:8888/playlet-invidious-backend"
        requestOptions["retry"] = false
        metadata = InnertubeService_GetVideoInfoBatched([
            videoId
        ], requestOptions)
        if IsArray(metadata.videos) and metadata.videos.Count() > 0
            metadata = metadata.videos[0]
        else
            metadata = {
                "error": "Failed to get video info with video_info_batched=true"
            }
        end if
    else
        metadata = service.GetVideoMetadata(videoId, requestOptions)
    end if
    if metadata.error <> invalid
        LogError3("[VideoQueueViewContentJob.bs:87]", "Failed to load video metadata", metadata.error)
        videoNode.title = "Video not available"
        return false
    end if
    InvidiousContent_ToVideoContentNode(videoNode, metadata, instance)
    return false
end function