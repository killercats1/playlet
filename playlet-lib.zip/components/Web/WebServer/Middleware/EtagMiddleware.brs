'import "EtagUtils.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/utils/CryptoUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
function __Http_EtagMiddleware_method_new(etags as object)
    m.super0_new()
    m.etags = etags
    m.routes.push({ method: "GET", path: "*", router: m, func: "HandleEtag" })
end function
function __Http_EtagMiddleware_method_HandleEtag(context as object) as boolean
    request = context.request
    response = context.response
    if response.http_code <> 200
        return false
    end if
    m.etags.AddEtagFromBody(request, response)
    m.etags.ClearContentIfNoneMatch(request, response)
    return false
end function
function __Http_EtagMiddleware_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_EtagMiddleware_method_new
    instance.HandleEtag = __Http_EtagMiddleware_method_HandleEtag
    return instance
end function
function Http_EtagMiddleware(etags as object)
    instance = __Http_EtagMiddleware_builder()
    instance.new(etags)
    return instance
end function