'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
function __Http_EtagUtils_method_new()
    m.pathToEtags = {}
end function
function __Http_EtagUtils_method_AddEtagFromBody(request as object, response as object, path = "" as string) as boolean
    cacheControl = request.headers["Cache-Control"]
    if IsString(cacheControl) and cacheControl.instr("no-cache") <> -1
        return false
    end if
    cacheControl = response.headers["Cache-Control"]
    if IsString(cacheControl) and cacheControl.instr("no-cache") <> -1
        return false
    end if
    etag = response.headers["ETag"]
    if not StringUtils_IsNullOrEmpty(etag)
        return false
    end if
    body = response.body_buffer
    if not IsByteArray(body)
        return false
    end if
    response.headers["ETag"] = (chr(34) + bslib_toString(m.HashContent(body)) + chr(34))
    if not StringUtils_IsNullOrEmpty(path)
        m.pathToEtags[path] = {
            etag: response.headers["ETag"]
            size: body.count()
        }
    end if
    return true
end function
function __Http_EtagUtils_method_AddFileEtagFromCache(request as object, response as object, path as string) as boolean
    if not m.pathToEtags.DoesExist(path)
        return false
    end if
    cacheControl = request.headers["Cache-Control"]
    if IsString(cacheControl) and cacheControl.instr("no-cache") <> -1
        return false
    end if
    cacheControl = response.headers["Cache-Control"]
    if IsString(cacheControl) and cacheControl.instr("no-cache") <> -1
        return false
    end if
    etag = response.headers["ETag"]
    if not StringUtils_IsNullOrEmpty(etag)
        return false
    end if
    etagObject = m.pathToEtags[path]
    response.headers["ETag"] = etagObject.etag
    response.ContentLength(etagObject.size)
    return true
end function
function __Http_EtagUtils_method_ClearContentIfNoneMatch(request as object, response as object) as boolean
    ifNoneMatch = request.headers["If-None-Match"]
    if StringUtils_IsNullOrEmpty(ifNoneMatch)
        return false
    end if
    etag = response.headers["ETag"]
    if StringUtils_IsNullOrEmpty(etag)
        return false
    end if
    if etag <> ifNoneMatch
        return false
    end if
    LogInfo3("[EtagUtils.bs:84]", "ETag cache hit:", etag)
    response.http_code = 304
    
    response.ClearBody(false)
    return true
end function
function __Http_EtagUtils_method_HashContent(content as object) as string
    digest = CreateObject("roEVPDigest")
    digest.Setup("md5")
    return digest.Process(content)
end function
function __Http_EtagUtils_builder()
    instance = {}
    instance.new = __Http_EtagUtils_method_new
    instance.AddEtagFromBody = __Http_EtagUtils_method_AddEtagFromBody
    instance.AddFileEtagFromCache = __Http_EtagUtils_method_AddFileEtagFromCache
    instance.ClearContentIfNoneMatch = __Http_EtagUtils_method_ClearContentIfNoneMatch
    instance.HashContent = __Http_EtagUtils_method_HashContent
    return instance
end function
function Http_EtagUtils()
    instance = __Http_EtagUtils_builder()
    instance.new()
    return instance
end function