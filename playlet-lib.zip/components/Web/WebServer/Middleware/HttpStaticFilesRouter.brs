'import "pkg:/components/Web/WebServer/Http/HttpRequest.bs"
'import "pkg:/components/Web/WebServer/Http/HttpResponse.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
function __Http_HttpStaticFilesRouter_method_new(route as string, root as string, etags as object, options = {} as object)
    m.super0_new()
    m.root = invalid
    m.route = invalid
    m.etags = invalid
    m.showDirectories = invalid
    m.showHidden = invalid
    m.fsCheck = invalid
    m.staticFiles = invalid
    m.staticCompressed = invalid
    m.root = root
    m.route = route
    m.etags = etags
    
    m.showDirectories = ValidBool(options.showDirectories)
    
    m.showHidden = ValidBool(options.showHidden)
    
    m.fsCheck = ValidBool(options.fsCheck)
    
    m.staticFiles = ValidBool(options.staticFiles)
    
    m.staticCompressed = m.staticFiles and ValidBool(options.staticCompressed)
    m.routes.push({ method: "GET", path: "*", router: m, func: "GetFileOrFolder" })
end function
function __Http_HttpStaticFilesRouter_method_GetFileOrFolder(context as object) as boolean
    request = context.request
    response = context.response
    server = context.server
    if not request.route.StartsWith(m.route)
        return false
    end if
    path_in_route = request.route.Mid(m.route.Len())
    decoded_path = path_in_route.DecodeUri()
    full_path = StringUtils_PathJoin(m.root, decoded_path)
    if m.staticCompressed
        full_path += ".gz"
    end if
    if m.staticFiles
        
        if m.etags.AddFileEtagFromCache(request, response, full_path)
            if m.etags.ClearContentIfNoneMatch(request, response)
                return true
            end if
        end if
    end if
    if not m.fsCheck
        
        buffer = createObject("roByteArray")
        if buffer.ReadFile(full_path) and buffer.count() > 0
            mimetype = server.utils.MimeType(decoded_path)
            response.SetBodyDataBuffer(buffer)
            response.ContentType(mimetype)
            response.http_code = 200
            if m.staticFiles
                m.etags.AddEtagFromBody(request, response, full_path)
            end if
            if m.staticCompressed
                response.headers["Content-Encoding"] = "gzip"
            end if
            return true
        end if
    end if
    path = CreateObject("roPath", full_path)
    fs = CreateObject("roFilesystem")
    if not path.isValid()
        
        return false
    else if not fs.exists(path)
        
        return false
    end if
    stat = fs.stat(path)
    if stat = invalid
        response.Default(500, "fstat() failed.")
        return true
    end if
    if stat.type = "directory"
        if not m.showDirectories
            response.Default(403, "Forbidden")
            return true
        end if
        response.ContentType("text/html")
        m.GenerateDirectoryListing(path, request, response)
        if m.staticFiles
            m.etags.AddEtagFromBody(request, response, full_path)
        end if
        return true
    else if stat.type = "file"
        mimetype = server.utils.MimeType(decoded_path)
        response.ContentType(mimetype)
        response.SetBodyDataFile(path)
        response.http_code = 200
        LogInfo9("[HttpStaticFilesRouter.bs:124]", "uri:", request.uri, "target:", path, "content-type:", mimetype, "content-length", stat.size)
        if m.staticFiles
            m.etags.AddEtagFromBody(request, response, full_path)
        end if
        if m.staticCompressed
            response.headers["Content-Encoding"] = "gzip"
        end if
        return true
    else
        response.Default(403, "Not a regular file.")
        return true
    end if
end function
function __Http_HttpStaticFilesRouter_method_GenerateDirectoryListing(path as object, request as object, response as object) as boolean
    fs = CreateObject("roFilesystem")
    dirList = fs.GetDirectoryListing(path)
    if dirList = invalid
        response.Default(500, "Couldn't list directory")
        return false
    end if
    
    maxlen = 0
    for each item in dirList
        il = item.len()
        if maxlen < il
            maxlen = il
        end if
    end for
    listing = ("<html>" + chr(10) + "<head>" + chr(10) + "<title>" + bslib_toString(response.settings.ServerName) + "</title>" + chr(10) + "</head>" + chr(10) + "<body>" + chr(10) + "    <h1>" + bslib_toString(request.uri.DecodeUri()) + "</h1>" + chr(10) + "    <tt><pre>" + chr(10))
    dir = path.getString()
    if dir.len() > 0 and dir.right(1) <> "/"
        dir = dir + "/"
    end if
    uriDir = request.uri
    if uriDir.len() > 0 and uriDir.right(1) <> "/"
        uriDir = uriDir + "/"
    end if
    routeDir = m.route
    if routeDir.len() > 0 and routeDir.right(1) <> "/"
        routeDir = routeDir + "/"
    end if
    if not uriDir = routeDir
        uri = uriDir + ".."
        listing += ("<a href=" + chr(34) + bslib_toString(uri) + chr(34) + ">..</a>" + chr(10))
    end if
    for each item in dirList
        if m.showHidden or item.left(1) <> "."
            indicator = invalid
            stat = fs.stat(dir + item)
            if stat <> invalid
                if stat.doesexist("type") and stat.type = "directory"
                    indicator = "/"
                else if stat.doesexist("size")
                    indicator = string(maxlen - item.len(), " ") + Stri(stat.size)
                end if
            end if
            if indicator <> invalid
                uri = uriDir + item
                safe_url = uri 
                listing += ("<a href=" + chr(34) + bslib_toString(safe_url) + chr(34) + ">" + bslib_toString(item) + bslib_toString(indicator) + "</a>" + chr(10))
            else
                LogWarn2("[HttpStaticFilesRouter.bs:198]", "insufficient stat info to include '" + dir + item + "'")
            end if
        end if
    end for
    listing += ("</pre></tt><hr>" + bslib_toString(response.GeneratedBy()) + "</body></html>")
    response.SetBodyDataString(listing)
    response.http_code = 200
    response.KeepAlive(true)
    return true
end function
function __Http_HttpStaticFilesRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_HttpStaticFilesRouter_method_new
    instance.GetFileOrFolder = __Http_HttpStaticFilesRouter_method_GetFileOrFolder
    instance.GenerateDirectoryListing = __Http_HttpStaticFilesRouter_method_GenerateDirectoryListing
    return instance
end function
function Http_HttpStaticFilesRouter(route as string, root as string, etags as object, options = {} as object)
    instance = __Http_HttpStaticFilesRouter_builder()
    instance.new(route, root, etags, options)
    return instance
end function