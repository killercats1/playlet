'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
function __Http_CsrfMiddleware_method_new(headerName as string, exemptRoutePrefixes as object)
    m.super0_new()
    m.headerName = invalid
    m.exemptRoutePrefixes = invalid
    m.headerName = headerName
    m.exemptRoutePrefixes = exemptRoutePrefixes
    m.routes.push({ method: "*", path: "*", router: m, func: "RequireHeader" })
end function
function __Http_CsrfMiddleware_method_RequireHeader(context as object) as boolean
    request = context.request
    method = request.method
    if method = "GET" or method = "HEAD" or method = "OPTIONS"
        return false
    end if
    if request.headers[m.headerName] <> invalid
        return false
    end if
    for each prefix in m.exemptRoutePrefixes
        if request.route.StartsWith(prefix)
            return false
        end if
    end for
    context.response.Default(403, ("Missing " + bslib_toString(m.headerName) + " header"))
    return true
end function
function __Http_CsrfMiddleware_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_CsrfMiddleware_method_new
    instance.RequireHeader = __Http_CsrfMiddleware_method_RequireHeader
    return instance
end function
function Http_CsrfMiddleware(headerName as string, exemptRoutePrefixes as object)
    instance = __Http_CsrfMiddleware_builder()
    instance.new(headerName, exemptRoutePrefixes)
    return instance
end function