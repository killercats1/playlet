'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
function __Http_CorsMiddleware_method_new(origin = "*" as string, methods = "POST, PUT, GET, DELETE, OPTIONS" as string)
    m.super0_new()
    m.origin = invalid
    m.methods = invalid
    m.origin = origin
    m.methods = methods
    m.routes.push({ method: "*", path: "*", router: m, func: "AddAccessControlHeaders" })
end function
function __Http_CorsMiddleware_method_AddAccessControlHeaders(context as object) as boolean
    request = context.request
    response = context.response
    if not StringUtils_IsNullOrEmpty(m.origin)
        response.headers["Access-Control-Allow-Origin"] = m.origin
    end if
    if not StringUtils_IsNullOrEmpty(m.methods)
        response.headers["Access-Control-Allow-Methods"] = m.methods
    end if
    allowHeaders = request.headers["Access-Control-Request-Headers"]
    if not StringUtils_IsNullOrEmpty(allowHeaders)
        response.headers["Access-Control-Allow-Headers"] = allowHeaders
    end if
    if request.method = "OPTIONS"
        response.ClearBody()
        response.http_code = 200
        return true
    end if
    return false
end function
function __Http_CorsMiddleware_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_CorsMiddleware_method_new
    instance.AddAccessControlHeaders = __Http_CorsMiddleware_method_AddAccessControlHeaders
    return instance
end function
function Http_CorsMiddleware(origin = "*" as string, methods = "POST, PUT, GET, DELETE, OPTIONS" as string)
    instance = __Http_CorsMiddleware_builder()
    instance.new(origin, methods)
    return instance
end function