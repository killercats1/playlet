function __Http_HttpDefaultRouter_method_new()
    m.super0_new()
    m.routes.push({ method: "*", path: "*", router: m, func: "HandleDefault" })
end function
function __Http_HttpDefaultRouter_method_HandleDefault(context as object) as boolean
    request = context.request
    response = context.response
    method = request.method
    uri = request.uri
    if method = ""
        response.Default(400, "You sent a request that the server couldn't understand.")
    else
        response.Default(404, ("Cannot " + bslib_toString(method) + " " + bslib_toString(uri)))
    end if
    return true
end function
function __Http_HttpDefaultRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_HttpDefaultRouter_method_new
    instance.HandleDefault = __Http_HttpDefaultRouter_method_HandleDefault
    return instance
end function
function Http_HttpDefaultRouter()
    instance = __Http_HttpDefaultRouter_builder()
    instance.new()
    return instance
end function