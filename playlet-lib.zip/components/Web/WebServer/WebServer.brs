'import "pkg:/components/Web/WebServer/Http/HttpServer.bs"
'import "pkg:/components/Web/WebServer/Middleware/HttpDefaultRouter.bs"
'import "pkg:/source/utils/Logging.bs"

function Init()
    m.top.functionName = "WebServerLoop"
end function

function StartServer(_unused as dynamic) as boolean
    if m.top.isRunning = true
        return true
    end if
    m.top.control = "run"
    return true
end function

function StopServer(_unused as dynamic) as void
    if m.top.isRunning = false
        return
    end if
    m.top.shouldQuit = true
end function

function CreateSettings(messagePort as object) as object
    settings = Http_HttpSettings(messagePort)
    settings.MaxConnections = 10
    settings.MaxRequestLength = 2097152
    settings.PackageName = "Playlet"
    settings.Port = 8888
    settings.ServerName = "Playlet Web Server"
    settings.TimeoutInMs = 30000
    settings.WebSocketsEnabled = false
    return settings
end function

function WebServerLoop() as void
    msgPort = CreateObject("roMessagePort")
    settings = CreateSettings(msgPort)
    server = Http_HttpServer(settings, m.top)
    if not server.success
        m.top.isRunning = false
        LogError2("[WebServer.bs:44]", "Failed to start server")
        return
    end if
    SetupRoutes(server)
    server.UseRouter(Http_HttpDefaultRouter())
    m.top.shouldQuit = false
    m.top.observeField("shouldQuit", msgPort, [
        "shouldQuit"
    ])
    m.top.isRunning = true
    
    timeoutInMs = 1000
    msgPort = settings.MessagePort
    while true
        server.PreWait()
        msg = wait(timeoutInMs, msgPort)
        msgType = type(msg)
        if msgType = "roSocketEvent" or msg = invalid
            server.PostWait()
        else if msgType = "roSGNodeEvent"
            info = msg.getInfo()
            if info.shouldQuit = true
                exit while
            end if
        end if
    end while
    LogInfo2("[WebServer.bs:77]", "closing server")
    server.Close()
    m.top.isRunning = false
    m.top.unobserveField("shouldQuit")
end function

function SetupRoutes(_server as object)
    LogWarn2("[WebServer.bs:84]", "No routes configured")
end function