'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/utils/CryptoUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function __Http_WebSocketMiddleware_method_new()
    m.super0_new()
    m.routes.push({ method: "GET", path: "*", router: m, func: "HandleWebSocketHeaders" })
end function
function __Http_WebSocketMiddleware_method_HandleWebSocketHeaders(context as object) as boolean
    request = context.request
    response = context.response
    connection = context.connection
    if LCase(ValidString(request.headers["Connection"])) <> "upgrade"
        return false
    end if
    if LCase(ValidString(request.headers["Upgrade"])) <> "websocket"
        return false
    end if
    webSocketKey = request.headers["Sec-WebSocket-Key"]
    if webSocketKey = invalid
        return false
    end if
    sha1Hash = CryptoUtils_GetSha1(webSocketKey + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")
    buffer = CreateObject("roByteArray")
    buffer.FromHexString(sha1Hash)
    webSocketAccept = buffer.ToBase64String()
    response.http_code = 101
    response.headers["Connection"] = "Upgrade"
    response.headers["Upgrade"] = "websocket"
    response.headers["Sec-WebSocket-Accept"] = webSocketAccept
    response.ClearBody()
    
    connection.ws_upgrade = true
    return true
end function
function __Http_WebSocketMiddleware_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_WebSocketMiddleware_method_new
    instance.HandleWebSocketHeaders = __Http_WebSocketMiddleware_method_HandleWebSocketHeaders
    return instance
end function
function Http_WebSocketMiddleware()
    instance = __Http_WebSocketMiddleware_builder()
    instance.new()
    return instance
end function