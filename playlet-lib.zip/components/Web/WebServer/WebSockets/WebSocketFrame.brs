'import "pkg:/components/Web/WebServer/WebSockets/WebSocketOpCode.bs"
function __Web_WebSocketFrame_method_new()
    m.fin = invalid
    m.opcode = invalid
    m.is_masked = invalid
    m.payload_size = invalid
    m.payload_size_buffer = invalid
    m.mask = invalid
    m.payload = invalid
    m.index = invalid
    m.length = invalid
    m.payload = CreateObject("roByteArray")
    m.payload_size_buffer = CreateObject("roByteArray")
end function
function __Web_WebSocketFrame_method_ReadFromBuffer(buffer as object, index as integer, length as integer) as boolean
    m.buffer = buffer
    m.index = index
    m.length = length
    firstByte = m.ReadByte()
    m.fin = (firstByte and &h80) <> 0
    m.opcode = firstByte and &hf
    if not m.fin
        return false
    end if
    if m.opcode <> 1
        return false
    end if
    secondByte = m.ReadByte()
    m.is_masked = (secondByte and &h80) <> 0
    if not m.is_masked
        return false
    end if
    if not m.ReadPayloadSize(secondByte)
        return false
    end if
    m.mask = [
        m.ReadByte()
        m.ReadByte()
        m.ReadByte()
        m.ReadByte()
    ]
    m.payload.Clear()
    for i = 0 to m.payload_size - 1
        m.payload[i] = m.Xor(m.ReadByte(), m.mask[i mod 4])
    end for
    return true
end function
function __Web_WebSocketFrame_method_ReadPayloadSize(secondByte as integer) as boolean
    payloadSize = secondByte and &h7F
    if payloadSize < 126
        m.payload_size = payloadSize
        return true
    else if payloadSize = 126
        payloadSize = (m.ReadByte() << 8) or m.ReadByte()
        m.payload_size = payloadSize
        return true
    else
        
        return false
    end if
end function
function __Web_WebSocketFrame_method_WritePayloadSize(payloadSize as integer)
    if payloadSize < 126
        m.WriteByte(payloadSize)
    else if payloadSize < 65536
        m.WriteByte(126)
        m.WriteByte(payloadSize >> 8)
        m.WriteByte(payloadSize and &hFF)
    else
        m.WriteByte(127)
        for i = 7 to 0 step -1
            m.payload_size_buffer[i] = payloadSize and &hFF
            payloadSize = payloadSize >> 8
        end for
        for i = 0 to 7
            m.WriteByte(m.payload_size_buffer[i])
        end for
    end if
end function
function __Web_WebSocketFrame_method_WriteToBuffer(buffer as object, index as integer, length as integer) as integer
    m.buffer = buffer
    m.index = index
    m.length = length
    m.WriteByte(m.fin or m.opcode)
    m.WritePayloadSize(m.payload_size)
    for i = 0 to m.payload_size - 1
        m.buffer[m.index] = m.payload[i]
        m.index++
    end for
    return m.index - index
end function
function __Web_WebSocketFrame_method_GetPayloadText() as string
    return m.payload.ToAsciiString()
end function
function __Web_WebSocketFrame_method_SetPayloadText(text as string)
    m.fin = &h80
    m.opcode = 1
    m.is_masked = false
    m.mask = invalid
    m.payload.FromAsciiString(text)
    m.payload_size = m.payload.Count()
end function
function __Web_WebSocketFrame_method_ReadByte() as integer
    byte = m.buffer[m.index]
    m.index++
    return byte
end function
function __Web_WebSocketFrame_method_WriteByte(byte as integer) as integer
    m.buffer[m.index] = byte
    m.index++
    return byte
end function
function __Web_WebSocketFrame_method_Xor(a as integer, b as integer) as integer
    return (a or b) and not (a and b)
end function
function __Web_WebSocketFrame_builder()
    instance = {}
    instance.new = __Web_WebSocketFrame_method_new
    instance.ReadFromBuffer = __Web_WebSocketFrame_method_ReadFromBuffer
    instance.ReadPayloadSize = __Web_WebSocketFrame_method_ReadPayloadSize
    instance.WritePayloadSize = __Web_WebSocketFrame_method_WritePayloadSize
    instance.WriteToBuffer = __Web_WebSocketFrame_method_WriteToBuffer
    instance.GetPayloadText = __Web_WebSocketFrame_method_GetPayloadText
    instance.SetPayloadText = __Web_WebSocketFrame_method_SetPayloadText
    instance.ReadByte = __Web_WebSocketFrame_method_ReadByte
    instance.WriteByte = __Web_WebSocketFrame_method_WriteByte
    instance.Xor = __Web_WebSocketFrame_method_Xor
    return instance
end function
function Web_WebSocketFrame()
    instance = __Web_WebSocketFrame_builder()
    instance.new()
    return instance
end function