'import "pkg:/source/utils/Logging.bs"
'import "WebSocketConnection.bs"
function __Web_WebSocketServer_method_new(webServer as object)
    m.webServer = invalid
    m.connections = invalid
    m.buffer = invalid
    m.onConnectListeners = invalid
    m.onDisconnectListeners = invalid
    m.onMessageListeners = invalid
    m.connections = CreateObject("roAssociativeArray")
    m.onConnectListeners = []
    m.onDisconnectListeners = []
    m.onMessageListeners = []
    m.webServer = webServer
end function
function __Web_WebSocketServer_method_OnConnect(callback as Function)
    m.onConnectListeners.push(callback)
end function
function __Web_WebSocketServer_method_OnDisconnect(callback as Function)
    m.onDisconnectListeners.push(callback)
end function
function __Web_WebSocketServer_method_OnMessage(callback as Function)
    m.onMessageListeners.push(callback)
end function
function __Web_WebSocketServer_method_AddConnection(socket as object)
    client = Web_WebSocketConnection(m, socket)
    m.connections[client.id] = client
    m.TriggerOnConnect(client)
end function
function __Web_WebSocketServer_method_TriggerOnConnect(connection as object)
    LogInfo2("[WebSocketServer.bs:40]", "on connect")
    for each listener in m.onConnectListeners
        listener({
            server: m
            connection: connection
        })
    end for
end function
function __Web_WebSocketServer_method_TriggerOnDisconnect(connection as object)
    LogInfo2("[WebSocketServer.bs:50]", "on disconnect")
    for each listener in m.onDisconnectListeners
        listener({
            server: m
            connection: connection
        })
    end for
end function
function __Web_WebSocketServer_method_TriggerOnMessage(connection as object, message as string)
    for each listener in m.onMessageListeners
        listener({
            server: m
            connection: connection
            message: message
        })
    end for
end function
function __Web_WebSocketServer_method_Poll()
    connections = m.connections
    for each id in connections
        connection = connections[id]
        if connection.IsClosed()
            connections.delete(id)
        else
            connection.Poll()
        end if
    end for
end function
function __Web_WebSocketServer_method_Close()
    connections = m.connections
    for each id in connections
        conn = connections[id]
        conn.Close()
    end for
end function
function __Web_WebSocketServer_method_Send(text as string) as void
    connections = m.connections
    for each id in connections
        conn = connections[id]
        conn.Send(text)
    end for
end function
function __Web_WebSocketServer_builder()
    instance = {}
    instance.new = __Web_WebSocketServer_method_new
    instance.OnConnect = __Web_WebSocketServer_method_OnConnect
    instance.OnDisconnect = __Web_WebSocketServer_method_OnDisconnect
    instance.OnMessage = __Web_WebSocketServer_method_OnMessage
    instance.AddConnection = __Web_WebSocketServer_method_AddConnection
    instance.TriggerOnConnect = __Web_WebSocketServer_method_TriggerOnConnect
    instance.TriggerOnDisconnect = __Web_WebSocketServer_method_TriggerOnDisconnect
    instance.TriggerOnMessage = __Web_WebSocketServer_method_TriggerOnMessage
    instance.Poll = __Web_WebSocketServer_method_Poll
    instance.Close = __Web_WebSocketServer_method_Close
    instance.Send = __Web_WebSocketServer_method_Send
    return instance
end function
function Web_WebSocketServer(webServer as object)
    instance = __Web_WebSocketServer_builder()
    instance.new(webServer)
    return instance
end function