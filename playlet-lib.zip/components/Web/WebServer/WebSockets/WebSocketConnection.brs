'import "pkg:/source/utils/Logging.bs"
'import "WebSocketConnectionState.bs"
'import "WebSocketFrame.bs"
'import "WebSocketServer.bs"

function __Web_WebSocketConnection_method_new(server as object, socket as object)
    m.server = invalid
    m.socket = invalid
    m.frame = invalid
    m.id = invalid
    m.state = invalid
    m.server = server
    m.socket = socket
    m.socket.SetKeepAlive(true)
    m.socket.SetNoDelay(true)
    m.id = Stri(m.socket.getID()).trim()
    m.buffer = CreateObject("roByteArray")
    m.buffer[524288] = 0
    m.frame = Web_WebSocketFrame()
    m.state = 1
end function
function __Web_WebSocketConnection_method_Poll() as void
    if not m.socket.eOK()
        m.Close()
        return
    end if
    received = m.socket.receive(m.buffer, 0, 524288)
    if received = 0
        m.Close()
        return
    else if received > 0
        if m.frame.ReadFromBuffer(m.buffer, 0, received)
            message = m.frame.GetPayloadText()
            LogInfo3("[WebSocketConnection.bs:43]", "received message:", message)
            m.server.TriggerOnMessage(m, message)
        end if
    end if
end function
function __Web_WebSocketConnection_method_IsClosed() as boolean
    return m.state = 3
end function
function __Web_WebSocketConnection_method_Close() as void
    if m.IsClosed()
        return
    end if
    m.socket.Close()
    m.state = 3
    m.server.TriggerOnDisconnect(m)
end function
function __Web_WebSocketConnection_method_Send(text as string) as void
    if m.IsClosed()
        return
    end if
    m.frame.SetPayloadText(text)
    written_bytes = m.frame.WriteToBuffer(m.buffer, 0, 524288)
    if written_bytes > 0
        total_sent = 0
        
        while total_sent < written_bytes
            sent = m.socket.Send(m.buffer, total_sent, written_bytes - total_sent)
            if sent > 0
                total_sent += sent
                LogInfo5("[WebSocketConnection.bs:76]", "Sent bytes:", total_sent, "out of:", written_bytes)
            end if
        end while
    end if
end function
function __Web_WebSocketConnection_builder()
    instance = {}
    instance.new = __Web_WebSocketConnection_method_new
    instance.Poll = __Web_WebSocketConnection_method_Poll
    instance.IsClosed = __Web_WebSocketConnection_method_IsClosed
    instance.Close = __Web_WebSocketConnection_method_Close
    instance.Send = __Web_WebSocketConnection_method_Send
    return instance
end function
function Web_WebSocketConnection(server as object, socket as object)
    instance = __Web_WebSocketConnection_builder()
    instance.new(server, socket)
    return instance
end function