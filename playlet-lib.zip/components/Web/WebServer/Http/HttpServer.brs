'import "../WebSockets/WebSocketServer.bs"
'import "HttpConnection.bs"
'import "HttpConnectionState.bs"
'import "HttpRouter.bs"
'import "HttpSettings.bs"
'import "HttpUtils.bs"
'import "pkg:/components/Services/Invidious/InvidiousService.bs"
function __Http_HttpServer_method_new(settings as object, task as object)
    m.connections = invalid
    m.sockin = invalid
    m.uptime = invalid
    m.num_requests = 0
    m.total_in = 0
    m.total_out = 0
    m.routers = invalid
    m.postRouters = invalid
    m.success = invalid
    m.settings = invalid
    m.task = invalid
    m.websocket = invalid
    m.settings = settings
    m.task = task
    m.routers = []
    m.postRouters = []
    m.utils = Http_Utils()
    m.success = m.Init()
end function
function __Http_HttpServer_method_Init() as boolean
    m.uptime = CreateObject("roTimespan")
    m.connections = CreateObject("roAssociativeArray")
    success = true
    
    sockin = CreateObject("roStreamSocket")
    if sockin = invalid
        success = false
        LogError2("[HttpServer.bs:48]", "socket()")
    end if
    
    if not sockin.setReuseAddr(true)
        success = false
        LogError3("[HttpServer.bs:54]", "setsockopt(SO_REUSEADDR)", sockin.status())
    end if
    
    addrin = CreateObject("roSocketAddress")
    addrin.setPort(m.settings.Port)
    if not sockin.setAddress(addrin)
        success = false
        LogError3("[HttpServer.bs:62]", "bind(port" + Stri(m.settings.Port) + ")", sockin.status())
    end if
    
    if not sockin.listen(m.settings.MaxConnections)
        success = false
        LogError3("[HttpServer.bs:67]", "listen()", sockin.status())
    end if
    
    sockin.setMessagePort(m.settings.MessagePort)
    sockin.notifyReadable(true)
    m.sockin = sockin
    LogInfo2("[HttpServer.bs:75]", "listening on " + addrin.getAddress())
    if m.settings.WebSocketsEnabled
        m.websocket = Web_WebSocketServer(m)
        LogInfo2("[HttpServer.bs:79]", "WebSocketServer created")
    end if
    return success
end function
function __Http_HttpServer_method_UseRouter(router as object)
    m.routers.Push(router)
end function
function __Http_HttpServer_method_UsePostRouter(router as object)
    m.postRouters.Push(router)
end function
function __Http_HttpServer_method_PreWait()
    connections = m.connections
    for each id in connections
        conn = connections[id]
        conn.CheckTimeout(m.settings.TimeoutInMs)
        cs = conn.state
        if cs = 4
            conn.socket.notifyReadable(false)
            conn.socket.notifyWritable(false)
        else if cs = 1
            conn.socket.notifyReadable(true)
            conn.socket.notifyWritable(false)
        else if cs = 2 or cs = 3
            conn.socket.notifyWritable(true)
            conn.socket.notifyReadable(false)
        else
            LogError2("[HttpServer.bs:108]", "invalid state")
        end if
    end for
    if m.settings.WebSocketsEnabled
        m.websocket.Poll()
    end if
end function
function __Http_HttpServer_method_PostWait()
    connections = m.connections
    if m.sockin.isReadable()
        conn = m.AcceptHttpConnection()
        if conn <> invalid
            connections[conn.id] = conn
        end if
    end if
    for each id in connections
        conn = connections[id]
        cs = conn.state
        if cs = 1
            if conn.socket.isReadable()
                conn.PollRequest(m)
            end if
        else if cs = 2
            if conn.socket.isWritable()
                conn.PollHeader(m)
            end if
        else if cs = 3
            if conn.socket.isWritable()
                conn.PollResponse(m)
            end if
        else if cs = 4
            
        else
            LogError2("[HttpServer.bs:143]", "invalid state")
        end if
        cs = conn.state
        if cs = 4
            if conn.close
                conn.socket.close()
                connections.delete(id)
            else if conn.ws_upgrade and m.settings.WebSocketsEnabled
                LogInfo2("[HttpServer.bs:151]", "upgrading connection to web socket")
                m.websocket.AddConnection(conn.socket)
                connections.delete(id)
            else
                conn.Recycle()
                conn.PollRequest(m)
            end if
        end if
    end for
end function
function __Http_HttpServer_method_AcceptHttpConnection() as object
    sockin = m.sockin
    socket = sockin.accept()
    if not sockin.eOK()
        LogError3("[HttpServer.bs:166]", "accept()", sockin.status())
    end if
    if socket = invalid
        return invalid
    end if
    conn = Http_HttpConnection(m, m.settings)
    conn.Accepted(m, socket)
    return conn
end function
function __Http_HttpServer_method_Close()
    
    m.sockin.close()
    connections = m.connections
    for each id in connections
        conn = connections[id]
        conn.socket.close()
    end for
    if m.settings.WebSocketsEnabled
        m.websocket.Close()
    end if
    
    LogInfo2("[HttpServer.bs:188]", (chr(10)) + m.stats())
end function
function __Http_HttpServer_method_Stats() as string
    stats = "  Uptime" + Stri(m.uptime.totalSeconds()) + " secs" + (chr(10))
    stats = stats + "  Requests" + Stri(m.num_requests) + (chr(10))
    stats = stats + "  Bytes" + Stri(m.total_in) + " in," + Stri(m.total_out) + " out"
    return stats
end function
function __Http_HttpServer_method_ProcessRequestLocal(method as string, uri as string, headers as object, body as string) as object
    LogInfo2("[HttpServer.bs:199]", ("Processing request locally " + bslib_toString(method) + " " + bslib_toString(uri)))
    request = Http_HttpRequest()
    request.FromParsedData(method, uri, headers, body)
    response = Http_HttpResponse(request, m, m.settings)
    response.Process({})
    return {
        http_code: response.http_code
        headers: response.headers
        body: response.body_buffer
    }
end function
function __Http_HttpServer_builder()
    instance = {}
    ' members
    ' initializable (copied) members
    instance.new = __Http_HttpServer_method_new
    instance.Init = __Http_HttpServer_method_Init
    instance.UseRouter = __Http_HttpServer_method_UseRouter
    instance.UsePostRouter = __Http_HttpServer_method_UsePostRouter
    instance.PreWait = __Http_HttpServer_method_PreWait
    instance.PostWait = __Http_HttpServer_method_PostWait
    instance.AcceptHttpConnection = __Http_HttpServer_method_AcceptHttpConnection
    instance.Close = __Http_HttpServer_method_Close
    instance.Stats = __Http_HttpServer_method_Stats
    instance.ProcessRequestLocal = __Http_HttpServer_method_ProcessRequestLocal
    return instance
end function
function Http_HttpServer(settings as object, task as object)
    instance = __Http_HttpServer_builder()
    instance.new(settings, task)
    return instance
end function