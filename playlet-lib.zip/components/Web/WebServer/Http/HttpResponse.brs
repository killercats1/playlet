'import "pkg:/components/Web/WebServer/Http/HttpConnection.bs"
'import "pkg:/components/Web/WebServer/Http/HttpServer.bs"
'import "pkg:/components/Web/WebServer/Http/HttpSettings.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/TimeUtils.bs"
function Http_GetHttpResponseId() as integer
    m.http_response_id = ValidInt(m.http_response_id) + 1
    return m.http_response_id
end function
function __Http_HttpResponse_method_new(request as object, server as object, settings as object)
    m.body_buffer = invalid
    m.header_buffer = invalid
    m.path = invalid
    m.request = invalid
    m.id = 0
    m.start = 0
    m.body_buffer_length = 0
    m.sent = 0
    m.header_sent = 0
    m.buf_start = 0
    m.http_code = 0
    m.server = invalid
    m.settings = invalid
    m.id = Http_GetHttpResponseId()
    m.request = request
    m.server = server
    m.settings = settings
    m.body_buffer = CreateObject("roByteArray")
    m.headers = {}
end function
function __Http_HttpResponse_method_Process(connection as object) as boolean
    routers = m.server.routers
    for each router in routers
        if router.OnRequest(m.request, m, connection)
            exit for
        end if
    end for
    postRouters = m.server.postRouters
    for each router in postRouters
        if router.OnRequest(m.request, m, connection)
            exit for
        end if
    end for
    return true
end function
function __Http_HttpResponse_method_Default(errcode as integer, reason as string) as void
    m.http_code = errcode
    if errcode = 204
        
        m.SetBodyDataString("")
        return
    end if
    errname = m.server.utils.HttpTitle(errcode)
    buffer = ("<html><head><title>" + bslib_toString(errcode) + " " + bslib_toString(errname) + "</title></head><body>" + chr(10) + "<h1>" + bslib_toString(errname) + "</h1>" + chr(10) + bslib_toString(reason) + chr(10) + "<hr>" + chr(10) + bslib_toString(m.GeneratedBy()) + chr(10) + "</body></html>")
    m.SetBodyDataString(buffer)
    m.ContentType("text/html")
end function
function __Http_HttpResponse_method_Redirect(where as string, code = 302 as integer)
    m.headers["Location"] = where
    message = ("Moved to: <a href=" + chr(34) + bslib_toString(where) + chr(34) + ">" + bslib_toString(where) + "</a>")
    m.Default(code, message)
end function
function __Http_HttpResponse_method_Json(data as object)
    m.http_code = 200
    buffer = FormatJson(data)
    m.SetBodyDataString(buffer)
    m.ContentType("application/json")
end function
function __Http_HttpResponse_method_SetBodyDataBuffer(buffer as object)
    m.body_buffer = buffer
    m.body_buffer_length = m.body_buffer.count()
    m.ContentLength(m.body_buffer_length)
end function
function __Http_HttpResponse_method_SetBodyDataString(data as string)
    m.body_buffer.fromasciistring(data)
    m.body_buffer_length = m.body_buffer.count()
    m.ContentLength(m.body_buffer_length)
end function
function __Http_HttpResponse_method_SetBodyDataFile(path as string)
    m.body_buffer.ReadFile(path)
    m.body_buffer_length = m.body_buffer.count()
    m.ContentLength(m.body_buffer_length)
end function
function __Http_HttpResponse_method_ClearBody(clearContentLength = true as boolean)
    m.body_buffer.clear()
    m.body_buffer_length = 0
    if clearContentLength
        m.ContentLength(0)
    end if
end function
function __Http_HttpResponse_method_ContentLength(length as integer)
    m.headers["Content-Length"] = Stri(length).trim()
end function
function __Http_HttpResponse_method_ContentType(mimeType as string)
    m.headers["Content-Type"] = mimeType
end function
function __Http_HttpResponse_method_Send(sock as object) as integer
    sent = -1
    buf_pos = m.start + m.sent - m.buf_start
    buf_remaining = m.body_buffer.count() - buf_pos
    if buf_remaining = 0
        
        
    end if
    req_remaining = m.body_buffer_length - m.sent
    if buf_remaining > req_remaining
        buf_remaining = req_remaining
    end if
    sent = sock.send(m.body_buffer, buf_pos, buf_remaining)
    m.LogSentRange(sent, m.buf_start + buf_pos, m.body_buffer_length)
    if sent > 0
        m.sent = m.sent + sent
    end if
    return sent
end function
function __Http_HttpResponse_method_SendHeader(sock as object) as integer
    if m.header = invalid
        m.GenerateHeader()
    end if
    if m.header_sent = 0
        sent = sock.sendStr(m.header)
    else
        sent = sock.sendStr(m.header.mid(m.header_sent))
    end if
    m.LogSentRange(sent, m.header_sent, m.header_length)
    if sent > 0
        m.header_sent = m.header_sent + sent
    end if
    return sent
end function
function __Http_HttpResponse_method_GenerateHeader()
    code = m.http_code
    title = m.server.utils.HttpTitle(code)
    if not m.headers.DoesExist("Date")
        m.headers["Date"] = m.Now()
    end if
    if not m.headers.DoesExist("Server")
        m.headers["Server"] = m.settings.serverName
    end if
    if not m.headers.DoesExist("Connection")
        m.KeepAlive(false)
    end if
    m.header = ("HTTP/1.1 " + bslib_toString(code) + " " + bslib_toString(title) + chr(13) + chr(10))
    for each header in m.headers
        m.header += (bslib_toString(header) + ": " + bslib_toString(m.headers[header]) + chr(13) + chr(10))
    end for
    m.header += (chr(13) + chr(10))
    m.header_length = m.header.len()
end function
function __Http_HttpResponse_method_Done() as boolean
    return m.sent = m.body_buffer_length
end function
function __Http_HttpResponse_method_DoneHeader() as boolean
    return m.header_sent = m.header_length
end function
function __Http_HttpResponse_method_LogSentRange(recent as integer, from as integer, total as integer)
    
end function
function __Http_HttpResponse_method_KeepAlive(keepAlive as boolean)
    if keepAlive
        m.headers["Connection"] = "keep-alive"
        timeout = Int(m.settings.TimeoutInMs / 1000)
        m.headers["Keep-Alive"] = ("timeout=" + bslib_toString(timeout))
    else
        m.headers["Connection"] = "close"
        m.headers.Delete("Keep-Alive")
    end if
end function
function __Http_HttpResponse_method_Now() as string
    if m._now = invalid
        m._now = TimeUtils_RFC1123_Date(TimeUtils_Now())
    end if
    return m._now
end function
function __Http_HttpResponse_method_GeneratedBy() as string
    return ("generated by " + bslib_toString(m.settings.PackageName) + " on " + bslib_toString(m.Now()))
end function
function __Http_HttpResponse_method_MakeRange(start as integer, length as integer, total as integer) as string
    return (bslib_toString(start) + "-" + bslib_toString(start + length - 1) + "/" + bslib_toString(total))
end function
function __Http_HttpResponse_builder()
    instance = {}
    ' members
    ' copy-initializable members
    instance.new = __Http_HttpResponse_method_new
    instance.Process = __Http_HttpResponse_method_Process
    instance.Default = __Http_HttpResponse_method_Default
    instance.Redirect = __Http_HttpResponse_method_Redirect
    instance.Json = __Http_HttpResponse_method_Json
    instance.SetBodyDataBuffer = __Http_HttpResponse_method_SetBodyDataBuffer
    instance.SetBodyDataString = __Http_HttpResponse_method_SetBodyDataString
    instance.SetBodyDataFile = __Http_HttpResponse_method_SetBodyDataFile
    instance.ClearBody = __Http_HttpResponse_method_ClearBody
    instance.ContentLength = __Http_HttpResponse_method_ContentLength
    instance.ContentType = __Http_HttpResponse_method_ContentType
    instance.Send = __Http_HttpResponse_method_Send
    instance.SendHeader = __Http_HttpResponse_method_SendHeader
    instance.GenerateHeader = __Http_HttpResponse_method_GenerateHeader
    instance.Done = __Http_HttpResponse_method_Done
    instance.DoneHeader = __Http_HttpResponse_method_DoneHeader
    instance.LogSentRange = __Http_HttpResponse_method_LogSentRange
    instance.KeepAlive = __Http_HttpResponse_method_KeepAlive
    instance.Now = __Http_HttpResponse_method_Now
    instance.GeneratedBy = __Http_HttpResponse_method_GeneratedBy
    instance.MakeRange = __Http_HttpResponse_method_MakeRange
    return instance
end function
function Http_HttpResponse(request as object, server as object, settings as object)
    instance = __Http_HttpResponse_builder()
    instance.new(request, server, settings)
    return instance
end function