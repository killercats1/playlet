'import "pkg:/components/Web/WebServer/Http/HttpConnection.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRequest.bs"
'import "pkg:/components/Web/WebServer/Http/HttpResponse.bs"
'import "pkg:/source/utils/ErrorUtils.bs"
'import "pkg:/source/utils/Logging.bs"
function __Http_HttpRouter_method_new()
    m.routes = invalid
    m.routes = []
end function
function __Http_HttpRouter_method_OnRequest(request as object, response as object, connection as object) as boolean
    for each route in m.routes
        if m.RouteMatchesRequest(route, request)
            try
                if route.router[route.func]({
                    request: request
                    response: response
                    connection: connection
                    server: response.server
                }) = true
                    return true
                end if
            catch error
                formattedError = ErrorUtils_Format(error)
                LogError2("[HttpRouter.bs:36]", formattedError)
                response.Default(500, formattedError)
                return true
            end try
        end if
    end for
    return false
end function
function __Http_HttpRouter_method_RouteMatchesRequest(route as object, request as object) as boolean
    if route.method <> "*" and route.method <> request.method
        return false
    end if
    if route.path <> "*" and route.path <> request.route
        return false
    end if
    return true
end function
function __Http_HttpRouter_builder()
    instance = {}
    ' [{
    '     method: "GET"
    '     path: "/example"
    '     router: router as HttpRouter
    '     func: func as string
    ' }]
    instance.new = __Http_HttpRouter_method_new
    instance.OnRequest = __Http_HttpRouter_method_OnRequest
    instance.RouteMatchesRequest = __Http_HttpRouter_method_RouteMatchesRequest
    return instance
end function
function Http_HttpRouter()
    instance = __Http_HttpRouter_builder()
    instance.new()
    return instance
end function