'import "HttpRequest.bs"
'import "HttpResponse.bs"
'import "HttpSettings.bs"
'import "pkg:/components/Web/WebServer/Http/HttpConnectionState.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function __Http_HttpConnection_method_new(server as object, settings as object)
    m.total_received = 0
    m.total_sent = 0
    m.id = "<uninit>"
    m.close = true
    m.ws_upgrade = false
    m.state = 0
    m.server = invalid
    m.settings = invalid
    m.server = server
    m.settings = settings
    m.Reset()
end function
function __Http_HttpConnection_method_Reset()
    
    m.socket = invalid
    m.addr = invalid
    m.Restart()
end function
function __Http_HttpConnection_method_Restart()
    
    m.last_active = CreateObject("roTimespan")
    m.request = Http_HttpRequest()
    m.header = invalid
    m.response = invalid
    m.close = true
    m.ws_upgrade = false
    m.SetState(0)
end function
function __Http_HttpConnection_method_Recycle()
    
    m.Restart()
    m.SetState(1) 
end function
function __Http_HttpConnection_method_Accepted(server as object, socket as object)
    m.socket = socket
    m.id = socket.getID().ToStr()
    m.SetState(1)
    m.client = m.socket.getReceivedFromAddress().getAddress()
    
    
    m.PollRequest(server)
end function
function __Http_HttpConnection_method_PollRequest(server as object)
    if m.state <> 1
        LogError2("[HttpConnection.bs:72]", "illegal request state @" + m.client)
    end if
    received = m.request.Receive(m.socket)
    if m.CheckResult(received, "RECV_REQUEST")
        m.total_received = m.total_received + received
        server.total_in = server.total_in + received
    end if
    if m.request.ProcessNext(m)
        if m.request.state = 4
            server.num_requests = validint(server.num_requests) + 1
            m.response = Http_HttpResponse(m.request, m.server, m.settings)
            m.response.Process(m)
            m.SetState(2)
        else
            m.setState(4)
            m.close = true
            LogErrorNoTelemetry2("[HttpConnection.bs:91]", "couldn't process request or response, closing @" + m.client)
        end if
    else if m.request.buffer.Count() > m.settings.MaxRequestLength 
        m.response = Http_HttpResponse(m.request, m.server, m.settings)
        m.response.Default(413, "Your request was dropped because it was too long.")
        m.SetState(2)
    end if
    
    if m.state = 2
        m.PollHeader(server)
    end if
end function
function __Http_HttpConnection_method_PollHeader(server as object) as void
    if m.state <> 2
        LogError2("[HttpConnection.bs:109]", "illegal header state @" + m.client)
    end if
    sent = m.response.SendHeader(m.socket)
    if m.CheckResult(sent, "SEND_HEADER")
        m.total_sent = m.total_sent + sent
        server.total_out = server.total_out + sent
    end if
    if m.response.DoneHeader()
        m.SetState(3)
        m.PollResponse(server)
    end if
end function
function __Http_HttpConnection_method_PollResponse(server as object)
    if m.state <> 3
        LogError2("[HttpConnection.bs:127]", "illegal response state @" + m.client)
    end if
    sent = m.response.Send(m.socket)
    if m.CheckResult(sent, "SEND_RESPONSE")
        m.total_sent = m.total_sent + sent
        server.total_out = server.total_out + sent
    end if
    if m.response.Done()
        m.SetState(4)
    end if
end function
function __Http_HttpConnection_method_CheckTimeout(timeoutInMs as integer)
    if m.last_active.TotalMilliseconds() > timeoutInMs
        m.close = true
        m.SetState(4)
    end if
end function
function __Http_HttpConnection_method_CheckResult(byteCount as integer, op as object) as boolean
    gotSome = false
    if byteCount > 0
        m.last_active.mark()
        gotSome = true
    else if byteCount = 0 and op = "RECV_REQUEST"
        
    else if m.socket.eOK() and not m.socket.eSuccess()
        
    else
        if m.socket.eSuccess()
            
        else
            LogErrorNoTelemetry5("[HttpConnection.bs:161]", op, " transfer error", m.client, m.socket.status())
        end if
        m.close = true
        m.SetState(4)
    end if
    return gotSome
end function
function __Http_HttpConnection_method_SetState(newState as object)
    if m.state <> newState
        
        m.state = newState
    end if
end function
function __Http_HttpConnection_builder()
    instance = {}
    instance.new = __Http_HttpConnection_method_new
    instance.Reset = __Http_HttpConnection_method_Reset
    instance.Restart = __Http_HttpConnection_method_Restart
    instance.Recycle = __Http_HttpConnection_method_Recycle
    instance.Accepted = __Http_HttpConnection_method_Accepted
    instance.PollRequest = __Http_HttpConnection_method_PollRequest
    instance.PollHeader = __Http_HttpConnection_method_PollHeader
    instance.PollResponse = __Http_HttpConnection_method_PollResponse
    instance.CheckTimeout = __Http_HttpConnection_method_CheckTimeout
    instance.CheckResult = __Http_HttpConnection_method_CheckResult
    instance.SetState = __Http_HttpConnection_method_SetState
    return instance
end function
function Http_HttpConnection(server as object, settings as object)
    instance = __Http_HttpConnection_builder()
    instance.new(server, settings)
    return instance
end function