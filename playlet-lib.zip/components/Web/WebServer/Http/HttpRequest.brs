'import "HttpRequestState.bs"
'import "pkg:/components/Web/WebServer/Http/HttpConnection.bs"
'import "pkg:/components/Web/WebServer/Http/HttpUtils.bs"
'import "pkg:/source/utils/ByteArrayUtils.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/MathUtils.bs"
'import "pkg:/source/utils/Types.bs"
'import "pkg:/source/utils/UrlUtils.bs"


function Http_GetHttpRequestId() as integer
    m.http_request_id = ValidInt(m.http_request_id) + 1
    return m.http_request_id
end function
function __Http_HttpRequest_method_new()
    m.method = invalid
    m.uri = invalid
    m.route = invalid
    m.query = invalid
    m.protocol = invalid
    m.encoder = invalid
    m.buffer = invalid
    m.buffer_index = 0
    m.headers = invalid
    m.body_bytes = invalid
    m.body_string = invalid
    m.state = 0
    m.id = 0
    m.ready_for_response = false
    m.id = Http_GetHttpRequestId()
    m.headers = CreateObject("roAssociativeArray")
end function
function __Http_HttpRequest_method_FromParsedData(method as string, uri as string, headers as object, body as dynamic)
    m.method = method
    m.uri = uri
    m.ParseUri()
    m.headers = headers
    if IsString(body)
        m.body_string = body
    else if IsByteArray(body)
        m.body_bytes = body
    end if
    m.state = 4
end function
function __Http_HttpRequest_method_Receive(socket as object) as integer
    if not IsByteArray(m.buffer)
        m.buffer = CreateObject("roByteArray")
        m.buffer_index = 0
    end if
    lengthToRead = MathUtils_Min(socket.GetCountRcvBuf(), 65536)
    if lengthToRead <= 0
        return 0
    end if
    newSize = m.buffer_index + lengthToRead
    if m.buffer.Count() < newSize
        m.buffer[newSize - 1] = 0
    end if
    received = socket.Receive(m.buffer, m.buffer_index, lengthToRead)
    if received > 0
        m.buffer_index += received
    end if
    return received
end function
function __Http_HttpRequest_method_ProcessNext(connection as object) as boolean
    if m.state = 4
        return m.ready_for_response
    end if
    if m.state = 0
        m.state = 1
    end if
    if m.state = 1
        if m.ParseStartAndHeaders()
            m.ParseUri()
            m.ProcessHeaders(connection)
            m.state = 3
        end if
    end if
    if m.state = 3
        if m.ParseBody()
            m.buffer = invalid
            m.state = 4
        end if
    end if
    return m.ready_for_response
end function
function __Http_HttpRequest_method_ParseStartAndHeaders() as boolean
    if m.buffer.Count() = 0
        return false
    end if
    if m.buffer.Count() = m.buffer_size_at_last_delimiter_check
        return false
    end if
    bufferStr = m.buffer.ToAsciiString()
    bodyDelimiterIndex = bufferStr.InStr((chr(13) + chr(10) + chr(13) + chr(10)))
    if bodyDelimiterIndex = -1
        m.buffer_size_at_last_delimiter_check = m.buffer.Count()
        return false
    end if
    m.content_index = bodyDelimiterIndex + 4
    if m.buffer[m.content_index - 4] <> 13 or m.buffer[m.content_index - 3] <> 10 or m.buffer[m.content_index - 2] <> 13 or m.buffer[m.content_index - 1] <> 10
        LogError2("[HttpRequest.bs:120]", "invalid request: malformed headers")
        m.ready_for_response = true
        return false
    end if
    startAndHeaders = bufferStr.Left(bodyDelimiterIndex)
    lines = startAndHeaders.Split((chr(13) + chr(10)))
    if lines.count() < 2
        LogError2("[HttpRequest.bs:128]", "invalid request: expected at least start line and one header")
        m.ready_for_response = true
        return false
    end if
    startLine = lines[0]
    if not m.ParseStartLine(startLine)
        m.ready_for_response = true
        return false
    end if
    for i = 1 to lines.count() - 1
        if not m.ParseHeader(lines[i])
            m.ready_for_response = true
            return false
        end if
    end for
    return true
end function
function __Http_HttpRequest_method_ParseStartLine(startLine as string) as boolean
    if startLine = ""
        LogError2("[HttpRequest.bs:151]", "empty request")
        return false
    end if
    firstChar = startLine.Mid(0, 1)
    if Asc(firstChar) = &h16
        LogErrorNoTelemetry2("[HttpRequest.bs:157]", "TLS handshake detected. HTTPS is not supported.")
        return false
    end if
    parts = startLine.tokenize(" ")
    if parts.count() <> 3
        LogError2("[HttpRequest.bs:163]", "invalid start line: " + startLine)
        return false
    end if
    m.method = Ucase(parts[0])
    m.uri = parts[1]
    m.protocol = Ucase(parts[2])
    LogInfo2("[HttpRequest.bs:170]", (bslib_toString(m.method) + " '" + bslib_toString(m.uri) + "'"))
    return true
end function
function __Http_HttpRequest_method_ParseHeader(line as string) as boolean
    splitIndex = line.InStr(":")
    if splitIndex <= 0
        LogError3("[HttpRequest.bs:178]", "invalid header line:", line)
        return false
    end if
    key = line.Left(splitIndex).Trim()
    value = line.Mid(splitIndex + 1).Trim()
    m.headers[key] = value
    return true
end function
function __Http_HttpRequest_method_ParseBody() as boolean
    if m.headers["Content-Length"] = invalid
        m.ready_for_response = true
        if m.buffer.Count() = m.content_index
            return true
        else
            LogError2("[HttpRequest.bs:193]", "invalid request: request body found, but no Content-Length header")
            return false
        end if
    end if
    contentLength = m.headers["Content-Length"].toInt()
    bodyLength = m.buffer.Count() - m.content_index
    if bodyLength > contentLength
        LogError2("[HttpRequest.bs:201]", "invalid request: request body is larger than Content-Length")
        m.ready_for_response = true
        return false
    end if
    if bodyLength < contentLength
        return false
    end if
    m.body_bytes = ByteArrayUtils_Slice(m.buffer, m.content_index)
    m.ready_for_response = true
    return true
end function
function __Http_HttpRequest_method_ProcessHeaders(connection as object)
    m.ParseConnection(connection)
end function
function __Http_HttpRequest_method_ParseUri()
    m.route = m.uri
    split = m.route.Instr("?")
    if split <> -1
        m.route = m.route.Left(split)
        m.query = UrlUtils_ParseQueryComponents(m.uri)
    else
        m.query = {}
    end if
end function
function __Http_HttpRequest_method_ParseConnection(connection as object)
    connectionStr = m.headers.connection
    if connectionStr <> invalid
        connection.close = (lcase(connectionStr.trim()) = "close")
    end if
end function
function __Http_HttpRequest_method_BodyBytes() as object
    if IsByteArray(m.body_bytes)
        return m.body_bytes
    end if
    if IsString(m.body_string)
        m.body_bytes = CreateObject("roByteArray")
        m.body_bytes.FromAsciiString(m.body_string)
    end if
    return m.body_bytes
end function
function __Http_HttpRequest_method_BodyText() as string
    if IsString(m.body_string)
        return m.body_string
    end if
    if IsByteArray(m.body_bytes)
        m.body_string = ValidString(m.body_bytes.ToAsciiString())
    else
        m.body_string = ""
    end if
    return m.body_string
end function
function __Http_HttpRequest_method_BodyJson() as dynamic
    if m.body_json <> invalid
        return m.body_json
    end if
    text = m.BodyText()
    if text = ""
        return invalid
    end if
    m.body_json = StringUtils_ParseJsonSafe(text)
    return m.body_json
end function
function __Http_HttpRequest_builder()
    instance = {}
    ' members
    ' copied members
    instance.new = __Http_HttpRequest_method_new
    instance.FromParsedData = __Http_HttpRequest_method_FromParsedData
    instance.Receive = __Http_HttpRequest_method_Receive
    instance.ProcessNext = __Http_HttpRequest_method_ProcessNext
    instance.ParseStartAndHeaders = __Http_HttpRequest_method_ParseStartAndHeaders
    instance.ParseStartLine = __Http_HttpRequest_method_ParseStartLine
    instance.ParseHeader = __Http_HttpRequest_method_ParseHeader
    instance.ParseBody = __Http_HttpRequest_method_ParseBody
    instance.ProcessHeaders = __Http_HttpRequest_method_ProcessHeaders
    instance.ParseUri = __Http_HttpRequest_method_ParseUri
    instance.ParseConnection = __Http_HttpRequest_method_ParseConnection
    instance.BodyBytes = __Http_HttpRequest_method_BodyBytes
    instance.BodyText = __Http_HttpRequest_method_BodyText
    instance.BodyJson = __Http_HttpRequest_method_BodyJson
    return instance
end function
function Http_HttpRequest()
    instance = __Http_HttpRequest_builder()
    instance.new()
    return instance
end function