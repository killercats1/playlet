'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
sub __Http_Utils_method_new()
end sub
function __Http_Utils_method_MimeType(uri = "" as string) as string
    map = m.MimeTypes
    if map = invalid
        json = ReadAsciiFile("libpkg:/config/mime-types.json5")
        if StringUtils_IsNullOrEmpty(json)
            return "application/octet-stream"
        end if
        map = StringUtils_ParseJsonSafe(json)
        if not IsAssociativeArray(map)
            return "application/octet-stream"
        end if
        m.MimeTypes = map
    end if
    ext = m.GetExtension(uri)
    if map.doesexist(ext)
        return map[ext]
    else
        return map.default
    end if
end function
function __Http_Utils_method_GetExtension(filename as string) as string
    parts = filename.tokenize(".")
    if parts.count() > 0
        return parts.GetTail()
    else
        return ""
    end if
end function
function __Http_Utils_method_HttpTitle(code = 0 as integer) as string
    map = m.httpCodesMap
    if map = invalid
        json = ReadAsciiFile("libpkg:/config/http-codes.json5")
        if StringUtils_IsNullOrEmpty(json)
            return ""
        end if
        map = StringUtils_ParseJsonSafe(json)
        if not IsAssociativeArray(map)
            return ""
        end if
        m.httpCodesMap = map
    end if
    return ValidString(map[(bslib_toString(code))])
end function
function __Http_Utils_builder()
    instance = {}
    instance.new = __Http_Utils_method_new
    instance.MimeType = __Http_Utils_method_MimeType
    instance.GetExtension = __Http_Utils_method_GetExtension
    instance.HttpTitle = __Http_Utils_method_HttpTitle
    return instance
end function
function Http_Utils()
    instance = __Http_Utils_builder()
    instance.new()
    return instance
end function