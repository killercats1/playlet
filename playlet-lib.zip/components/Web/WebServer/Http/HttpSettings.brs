function __Http_HttpSettings_method_new(messagePort as object)
    m.MaxConnections = 10
    m.MaxRequestLength = 2097152
    m.PackageName = "Roku app"
    m.Port = 8888
    m.ServerName = "Roku Server"
    m.TimeoutInMs = 60 * 1000
    m.WebSocketsEnabled = true
    m.MessagePort = invalid
    m.MessagePort = messagePort
end function
function __Http_HttpSettings_builder()
    instance = {}
    instance.new = __Http_HttpSettings_method_new
    return instance
end function
function Http_HttpSettings(messagePort as object)
    instance = __Http_HttpSettings_builder()
    instance.new(messagePort)
    return instance
end function