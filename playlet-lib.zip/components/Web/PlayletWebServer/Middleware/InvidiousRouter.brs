'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.types.bs"
'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/utils/CryptoUtils.bs"
function __Http_InvidiousRouter_method_new(server as object)
    m.super0_new()
    m.server = server
    m.profilesNode = server.sceneNodes.profilesService
    m.invidiousNode = server.sceneNodes.invidious
    m.invidiousService = Invidious_InvidiousService(m.invidiousNode)
    m.routes.push({ method: "GET", path: "/invidious/login", router: m, func: "Login" })
    m.routes.push({ method: "GET", path: "/invidious/token_callback", router: m, func: "OnTokenReceived" })
    m.routes.push({ method: "GET", path: "/invidious/authenticated-request", router: m, func: "AuthRequestProxy" })
end function
function __Http_InvidiousRouter_method_Login(context as object) as boolean
    request = context.request
    response = context.response
    
    server = ""
    profileId = request.query["profile"]
    if profileId <> invalid
        server = m.GetProfileServer(ValidString(profileId))
        if server = invalid
            response.Default(400, "Unknown profile")
            return true
        end if
    end if
    if m.loginNonce = invalid
        m.loginNonce = CreateObject("roDeviceInfo").GetRandomUUID()
    end if
    authLink = m.invidiousService.GetAuthorizeTokenLink(server, m.loginNonce)
    if authLink = invalid
        response.Default(503, "Invidious server not configured")
        return true
    end if
    response.Redirect(authLink)
    return true
end function
function __Http_InvidiousRouter_method_OnTokenReceived(context as object) as boolean
    request = context.request
    response = context.response
    if request.query["token"] <> invalid and request.query["ref"] <> invalid and request.query["username"] <> invalid
        
        nonce = request.query["nonce"]
        if m.loginNonce = invalid or not IsString(nonce) or nonce <> m.loginNonce
            response.Default(403, "Invalid login link. Please start the login again.")
            return true
        end if
        m.loginNonce = invalid
        
        token = request.query["token"].DecodeUriComponent().DecodeUriComponent()
        username = request.query["username"].DecodeUriComponent().DecodeUriComponent()
        referer = request.query["ref"].DecodeUriComponent()
        profile = CreateObject("roSGNode", "ProfileContentNode")
        profile.username = username
        profile.accessToken = token
        profile.serverUrl = referer
        m.profilesNode.callfunc("LoginWithProfile", profile)
    end if
    response.Redirect("/")
    return true
end function
function __Http_InvidiousRouter_method_GetProfileServer(profileId as string) as dynamic
    profilesDto = m.profilesNode.callfunc("GetProfilesDto", false)
    profiles = profilesDto.profiles
    for each profile in profiles
        if profile.id = profileId and profile.type = "invidious"
            return profile.serverUrl
        end if
    end for
    return invalid
end function
function __Http_InvidiousRouter_method_AuthRequestProxy(context as object) as boolean
    request = context.request
    response = context.response
    profile = m.invidiousService.GetCurrentProfile()
    if profile = invalid
        response.Default(403, "Not logged in")
        return true
    end if
    if profile.authState = "NeedsReauth"
        response.Default(403, "Session expired. Please sign in again.")
        return true
    end if
    feedSource = request.query["feed-source"]
    if feedSource = invalid
        response.Default(400, "Expected feed-source")
        return true
    end if
    feedSource = StringUtils_ParseJsonSafe(feedSource)
    if feedSource = invalid
        response.Default(400, "Expected valid JSON for feed-source")
        return true
    end if
    options = {
        httpServer: m.server
    }
    if feedSource.state <> invalid and feedSource.state.queryParams <> invalid
        options.additionalQueryParams = feedSource.state.queryParams
    end if
    invResponse = m.invidiousService.MakeRequest(feedSource, options)
    if not invResponse.success
        response.Default(500, ("Failed to make request: " + bslib_toString(invResponse.error)))
        return true
    end if
    response.Json(invResponse.result)
    return true
end function
function __Http_InvidiousRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_InvidiousRouter_method_new
    instance.Login = __Http_InvidiousRouter_method_Login
    instance.OnTokenReceived = __Http_InvidiousRouter_method_OnTokenReceived
    instance.GetProfileServer = __Http_InvidiousRouter_method_GetProfileServer
    ' This is an endpoint allowing the web app to make an authenticated request
    ' without needing the Invidious token
    ' This is a GET not a POST for better caching
    instance.AuthRequestProxy = __Http_InvidiousRouter_method_AuthRequestProxy
    return instance
end function
function Http_InvidiousRouter(server as object)
    instance = __Http_InvidiousRouter_builder()
    instance.new(server)
    return instance
end function