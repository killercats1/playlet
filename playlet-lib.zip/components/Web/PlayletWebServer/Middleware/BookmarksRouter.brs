'import "pkg:/components/Services/BookmarksService/BookmarksServiceUtils.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/utils/RegistryUtils.bs"
function __Http_BookmarksRouter_method_new(server as object)
    m.super0_new()
    m.bookmarksService = server.sceneNodes.bookmarksService
    m.routes.push({ method: "GET", path: "/api/bookmarks", router: m, func: "GetBookmarks" })
    m.routes.push({ method: "GET", path: "/api/bookmarks/feeds", router: m, func: "GetBookmarksFeeds" })
end function
function __Http_BookmarksRouter_method_GetBookmarks(context as object) as boolean
    response = context.response
    bookmarksString = RegistryUtils_Read("bookmarks")
    if bookmarksString = invalid
        response.Json({
            groups: []
        })
        return true
    end if
    response.SetBodyDataString(bookmarksString)
    response.ContentType("application/json")
    response.http_code = 200
    return true
end function
function __Http_BookmarksRouter_method_GetBookmarksFeeds(context as object) as boolean
    response = context.response
    feeds = BookmarksServiceUtils_BookmarksContentToFeed(m.bookmarksService.content)
    response.Json(feeds)
    return true
end function
function __Http_BookmarksRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_BookmarksRouter_method_new
    instance.GetBookmarks = __Http_BookmarksRouter_method_GetBookmarks
    instance.GetBookmarksFeeds = __Http_BookmarksRouter_method_GetBookmarksFeeds
    return instance
end function
function Http_BookmarksRouter(server as object)
    instance = __Http_BookmarksRouter_builder()
    instance.new(server)
    return instance
end function