'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.bs"
'import "pkg:/components/Services/Innertube/Constants.bs"
'import "pkg:/components/Services/Innertube/DrmLicenseRequests.bs"
'import "pkg:/components/Services/Innertube/InnertubeService.bs"
'import "pkg:/components/Services/Innertube/PoTokens.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/Types.bs"
function __Http_InnertubeRouter_method_new(server as object)
    m.super0_new()
    m.innertube = server.sceneNodes.innertube
    m.profilesService = server.sceneNodes.profilesService
    m.proxyRequestAllowedKeys = {
        "Method": true
        "Url": true
        "Headers": true
        "Body": true
        "CacheSeconds": true
    }
    m.routes.push({ method: "GET", path: "/api/innertube/potoken", router: m, func: "GetPoToken" })
    m.routes.push({ method: "POST", path: "/api/innertube/potoken", router: m, func: "SetPoToken" })
    m.routes.push({ method: "DELETE", path: "/api/innertube/potoken/all", router: m, func: "ClearPoTokens" })
    m.routes.push({ method: "POST", path: "/api/innertube/proxy", router: m, func: "ProxyRequest" })
    m.routes.push({ method: "POST", path: "/api/innertube/get_drm_license", router: m, func: "GetDrmLicense" })
end function
function __Http_InnertubeRouter_method_GetPoToken(context as object) as object
    response = context.response
    identity = ""
    sessionData = m.innertube.sessionData
    if IsAssociativeArray(sessionData)
        identity = ValidString(sessionData.livingRoomPoTokenId)
    end if
    if StringUtils_IsNullOrEmpty(identity)
        response.Default(503, "No current identity")
        return true
    end if
    result = {
        "identity": identity
    }
    entry = Innertube_PoTokens_GetPoTokenEntryForIdentity(identity)
    if IsAssociativeArray(entry)
        result["poToken"] = entry.token
        result["mintedAt"] = entry.mintedAt
        result["expiresAt"] = entry.expiresAt
    end if
    response.Json(result)
    return true
end function
function __Http_InnertubeRouter_method_SetPoToken(context as object) as object
    request = context.request
    response = context.response
    payload = request.BodyJson()
    if payload = invalid or not IsAssociativeArray(payload)
        response.Default(400, "Invalid payload")
        return true
    end if
    if StringUtils_IsNullOrEmpty(payload.poToken)
        response.Default(400, "Invalid poToken")
        return true
    end if
    if StringUtils_IsNullOrEmpty(payload.identity)
        response.Default(400, "Invalid identity")
        return true
    end if
    if not IsInt(payload.mintedAt) or not IsInt(payload.expiresAt)
        response.Default(400, "Invalid mintedAt/expiresAt")
        return true
    end if
    identity = ""
    sessionData = m.innertube.sessionData
    if IsAssociativeArray(sessionData)
        identity = ValidString(sessionData.livingRoomPoTokenId)
    end if
    if StringUtils_IsNullOrEmpty(identity)
        response.Default(503, "No current identity")
        return true
    end if
    
    if payload.identity <> identity
        response.Default(409, "identity is not the device's current identity")
        return true
    end if
    Innertube_PoTokens_StorePoToken(payload.identity, payload.poToken, payload.expiresAt, payload.mintedAt)
    response.Default(204, "PoToken updated successfully")
    return true
end function
function __Http_InnertubeRouter_method_ClearPoTokens(context as object) as object
    response = context.response
    Innertube_PoTokens_ClearAllPoTokens()
    response.Default(204, "PoTokens cleared")
    return true
end function
function __Http_InnertubeRouter_method_ProxyRequest(context as object) as boolean
    request = context.request
    response = context.response
    requestArgs = request.BodyJson()
    if not IsAssociativeArray(requestArgs)
        response.Default(400, "Invalid request body")
        return true
    end if
    for each key in requestArgs
        if not m.proxyRequestAllowedKeys.DoesExist(key)
            response.Default(400, ("Unsupported key: " + chr(34) + bslib_toString(key) + chr(34)))
            return true
        end if
    end for
    requestHeaders = requestArgs.Headers
    
    if StringUtils_IsNullOrEmpty(requestHeaders["User-Agent"])
        requestHeaders["User-Agent"] = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:150.0) Gecko/20100101 Firefox/150.0"
    end if
    method = "GET"
    if requestArgs.Method <> invalid
        method = requestArgs.Method
    end if
    proxyRequest = HttpClient_Request(method, requestArgs.Url)
    proxyRequest.Headers(requestHeaders)
    if requestArgs.Body <> invalid
        proxyRequest.TextBody(requestArgs.Body)
    end if
    if requestArgs.CacheSeconds <> invalid
        if requestArgs.CacheSeconds > 0
            proxyRequest.CacheForSeconds(requestArgs.CacheSeconds)
        else
            proxyRequest.NoCache()
        end if
    end if
    httpRes = proxyRequest.Await()
    result = {
        "status": httpRes.StatusCode()
        "headers": httpRes.Headers()
        "body": httpRes.Text()
    }
    response.Json(result)
    return true
end function
function __Http_InnertubeRouter_method_GetDrmLicense(context as object) as object
    request = context.request
    response = context.response
    drmStringQueryParams = [
        "videoId"
        "videoLoadId"
        "drmParams"
        "drmSessionId"
        "cpn"
    ]
    for each paramName in drmStringQueryParams
        if StringUtils_IsNullOrEmpty(request.query[paramName])
            response.Default(400, "Missing " + paramName)
            return true
        end if
    end for
    licenseRequest = request.BodyBytes()
    if not IsByteArray(licenseRequest) or licenseRequest.count() = 0
        response.Default(400, "Missing licenseRequest")
        return true
    end if
    options = {
        "videoId": request.query.videoId
        "drmParams": request.query.drmParams
        "drmSessionId": request.query.drmSessionId
        "cpn": request.query.cpn
        "licenseRequest": licenseRequest.ToBase64String()
    }
    currentProfile = m.profilesService.currentProfile
    tokenResult = invalid
    if currentProfile <> invalid and currentProfile.type = "youtube"
        tokenResult = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(currentProfile)
    end if
    if tokenResult <> invalid and tokenResult.state = "Ok"
        options["accessToken"] = tokenResult.token
    else
        options["visitorData"] = m.innertube.sessionData.visitorData
    end if
    DrmLicenseRequests_RecordSent(request.query.videoLoadId)
    licenseResponse = InnertubeService_GetDrmLicense(options)
    DrmLicenseRequests_RecordResponse(request.query.videoLoadId, licenseResponse)
    license = licenseResponse.license
    if not IsByteArray(license) or license.Count() = 0
        LogTelemetryEvent({
            level: "error"
            message: ("DRM license request failed: " + bslib_toString(ValidString(licenseResponse.error)) + chr(10) + "videoId: " + bslib_toString(request.query.videoId) + chr(10) + "video_load_id: " + bslib_toString(request.query.videoLoadId))
            fingerprint: [
                "DRM license request failed"
            ]
        })
        response.Default(500, FormatJson(licenseResponse))
        return true
    end if
    response.http_code = 200
    response.SetBodyDataBuffer(license)
    response.ContentType("text/html; charset=utf-8")
    response.headers["Cache-Control"] = "no-cache"
    return true
end function
function __Http_InnertubeRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_InnertubeRouter_method_new
    instance.GetPoToken = __Http_InnertubeRouter_method_GetPoToken
    instance.SetPoToken = __Http_InnertubeRouter_method_SetPoToken
    instance.ClearPoTokens = __Http_InnertubeRouter_method_ClearPoTokens
    instance.ProxyRequest = __Http_InnertubeRouter_method_ProxyRequest
    instance.GetDrmLicense = __Http_InnertubeRouter_method_GetDrmLicense
    return instance
end function
function Http_InnertubeRouter(server as object)
    instance = __Http_InnertubeRouter_builder()
    instance.new(server)
    return instance
end function