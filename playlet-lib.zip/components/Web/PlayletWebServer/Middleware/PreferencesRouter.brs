'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
function __Http_PreferencesRouter_method_new(server as object)
    m.super0_new()
    m.preferencesNode = server.sceneNodes.preferences
    m.routes.push({ method: "GET", path: "/api/preferences", router: m, func: "GetPreferences" })
    m.routes.push({ method: "PUT", path: "/api/preferences", router: m, func: "UpdatePreferences" })
    m.routes.push({ method: "DELETE", path: "/api/preferences", router: m, func: "ResetPreferences" })
end function
function __Http_PreferencesRouter_method_GetPreferences(context as object) as boolean
    response = context.response
    userPrefs = m.preferencesNode.callfunc("GetUserPreferences", invalid)
    response.Json(userPrefs)
    return true
end function
function __Http_PreferencesRouter_method_UpdatePreferences(context as object) as boolean
    request = context.request
    response = context.response
    payload = request.BodyJson()
    if payload = invalid
        response.Default(400, "Invalid JSON payload")
        return true
    end if
    m.preferencesNode.callfunc("ApplyUserPreferences", payload)
    response.Default(204, "OK")
    return true
end function
function __Http_PreferencesRouter_method_ResetPreferences(context as object) as boolean
    response = context.response
    m.preferencesNode.callfunc("ClearUserPreferences", invalid)
    response.Default(204, "OK")
    return true
end function
function __Http_PreferencesRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_PreferencesRouter_method_new
    instance.GetPreferences = __Http_PreferencesRouter_method_GetPreferences
    instance.UpdatePreferences = __Http_PreferencesRouter_method_UpdatePreferences
    instance.ResetPreferences = __Http_PreferencesRouter_method_ResetPreferences
    return instance
end function
function Http_PreferencesRouter(server as object)
    instance = __Http_PreferencesRouter_builder()
    instance.new(server)
    return instance
end function