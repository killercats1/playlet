'import "pkg:/components/ChannelView/ChannelUtils.bs"
'import "pkg:/components/PlaylistView/PlaylistUtils.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/components/VideoQueue/VideoQueueUtils.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
function __Http_ViewRouter_method_new(server as object)
    m.super0_new()
    m.appController = server.sceneNodes.appController
    m.videoQueue = server.sceneNodes.videoQueue
    m.routes.push({ method: "GET", path: "/api/view/open", router: m, func: "OpenView" })
end function
function __Http_ViewRouter_method_OpenView(context as object) as boolean
    request = context.request
    response = context.response
    playlistId = request.query.playlistId
    
    videoId = request.query.videoId
    authorId = request.query.authorId
    if not StringUtils_IsNullOrEmpty(playlistId)
        content = {
            playlistId: playlistId
        }
        if playlistId.startsWith("RD") and not StringUtils_IsNullOrEmpty(videoId)
            content.videoId = videoId
        end if
        contentNode = InvidiousContent_ToPlaylistContentNode(invalid, content, invalid)
        PlaylistUtils_Open(contentNode, m.appController)
        if VideoQueueUtils_IsVideoPlayerOpen(m.videoQueue) and VideoQueueUtils_IsVideoPlayerFullScreen(m.videoQueue)
            VideoQueueUtils_ToggleVideoPictureInPicture(m.videoQueue)
        end if
        response.Default(204, "OK")
    else if not StringUtils_IsNullOrEmpty(authorId)
        contentNode = InvidiousContent_ToChannelContentNode(invalid, {
            authorId: authorId
        })
        ChannelUtils_Open(contentNode, m.appController)
        if VideoQueueUtils_IsVideoPlayerOpen(m.videoQueue) and VideoQueueUtils_IsVideoPlayerFullScreen(m.videoQueue)
            VideoQueueUtils_ToggleVideoPictureInPicture(m.videoQueue)
        end if
        response.Default(204, "OK")
    else
        response.Default(400, "Invalid request")
    end if
    return true
end function
function __Http_ViewRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_ViewRouter_method_new
    instance.OpenView = __Http_ViewRouter_method_OpenView
    return instance
end function
function Http_ViewRouter(server as object)
    instance = __Http_ViewRouter_builder()
    instance.new(server)
    return instance
end function