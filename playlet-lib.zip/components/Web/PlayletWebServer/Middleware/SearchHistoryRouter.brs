'import "pkg:/components/Services/SearchHistory/SearchHistoryUtils.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
function __Http_SearchHistoryRouter_method_new(server as object)
    m.super0_new()
    m.preferencesNode = server.sceneNodes.preferences
    m.routes.push({ method: "GET", path: "/api/search-history", router: m, func: "GetSearchHistory" })
    m.routes.push({ method: "POST", path: "/api/search-history", router: m, func: "AddSearchHistory" })
    m.routes.push({ method: "DELETE", path: "/api/search-history", router: m, func: "ClearSearchHistory" })
end function
function __Http_SearchHistoryRouter_method_GetSearchHistory(context as object) as boolean
    response = context.response
    response.Json(SearchHistoryUtils_GetAllSaved(m.preferencesNode))
    return true
end function
function __Http_SearchHistoryRouter_method_AddSearchHistory(context as object) as boolean
    request = context.request
    response = context.response
    payload = request.BodyJson()
    if payload = invalid
        response.Default(400, "Invalid JSON payload")
        return true
    end if
    query = payload.query
    if query = invalid
        response.Default(400, ("missing " + chr(34) + "query" + chr(34) + " property in JSON payload"))
        return true
    end if
    SearchHistoryUtils_Save(m.preferencesNode, query)
    response.Json(SearchHistoryUtils_GetAllSaved(m.preferencesNode))
    return true
end function
function __Http_SearchHistoryRouter_method_ClearSearchHistory(context as object) as boolean
    response = context.response
    SearchHistoryUtils_Clear()
    response.Default(204, "OK")
    return true
end function
function __Http_SearchHistoryRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_SearchHistoryRouter_method_new
    instance.GetSearchHistory = __Http_SearchHistoryRouter_method_GetSearchHistory
    instance.AddSearchHistory = __Http_SearchHistoryRouter_method_AddSearchHistory
    instance.ClearSearchHistory = __Http_SearchHistoryRouter_method_ClearSearchHistory
    return instance
end function
function Http_SearchHistoryRouter(server as object)
    instance = __Http_SearchHistoryRouter_builder()
    instance.new(server)
    return instance
end function