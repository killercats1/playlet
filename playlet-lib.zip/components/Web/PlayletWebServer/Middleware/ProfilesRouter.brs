'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/utils/StringUtils.bs"
function __Http_ProfilesRouter_method_new(server as object)
    m.super0_new()
    m.profilesNode = server.sceneNodes.profilesService
    m.profilesContent = m.profilesNode.content.getChild(0)
    m.routes.push({ method: "GET", path: "/api/profiles", router: m, func: "GetProfiles" })
    m.routes.push({ method: "POST", path: "/api/profiles/activate", router: m, func: "ActivateProfile" })
    m.routes.push({ method: "DELETE", path: "/api/profiles", router: m, func: "Logout" })
end function
function __Http_ProfilesRouter_method_GetProfiles(context as object) as boolean
    response = context.response
    profiles = m.profilesNode.callfunc("GetProfilesDto", false)
    response.Json(profiles)
    return true
end function
function __Http_ProfilesRouter_method_ActivateProfile(context as object) as boolean
    request = context.request
    response = context.response
    payload = request.BodyJson()
    if payload = invalid
        response.Default(400, "Invalid JSON payload")
        return true
    end if
    id = payload.id
    if StringUtils_IsNullOrEmpty(id)
        response.Default(400, "Missing profile id")
        return true
    end if
    profile = m.profilesContent.findNode(id)
    if profile = invalid
        response.Default(404, ("Profile id " + chr(34) + bslib_toString(id) + chr(34) + " not found"))
        return true
    end if
    m.profilesNode.callfunc("SetCurrentProfile", profile)
    response.Default(200, "Profile updated")
    return true
end function
function __Http_ProfilesRouter_method_Logout(context as object) as boolean
    request = context.request
    response = context.response
    id = request.query.id
    if StringUtils_IsNullOrEmpty(id)
        response.Default(400, "Missing profile id")
        return true
    end if
    profile = m.profilesContent.findNode(id)
    if profile = invalid
        response.Default(404, ("Profile id " + chr(34) + bslib_toString(id) + chr(34) + " not found"))
        return true
    end if
    m.profilesNode.callfunc("LogoutWithProfile", profile)
    response.Default(200, "Profile logged out")
    return true
end function
function __Http_ProfilesRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_ProfilesRouter_method_new
    instance.GetProfiles = __Http_ProfilesRouter_method_GetProfiles
    instance.ActivateProfile = __Http_ProfilesRouter_method_ActivateProfile
    instance.Logout = __Http_ProfilesRouter_method_Logout
    return instance
end function
function Http_ProfilesRouter(server as object)
    instance = __Http_ProfilesRouter_builder()
    instance.new(server)
    return instance
end function