'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/components/VideoQueue/VideoQueueUtils.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/utils/MathUtils.bs"
function __Http_VideoQueueRouter_method_new(server as object)
    m.super0_new()
    m.videoQueueNode = server.sceneNodes.videoQueue
    m.invidiousNode = server.sceneNodes.invidious
    m.invidiousService = Invidious_InvidiousService(m.invidiousNode)
    m.routes.push({ method: "GET", path: "/api/queue", router: m, func: "GetQueue" })
    m.routes.push({ method: "POST", path: "/api/queue", router: m, func: "AddToQueue" })
    m.routes.push({ method: "POST", path: "/api/queue/play", router: m, func: "Play" })
    m.routes.push({ method: "GET", path: "/watch", router: m, func: "PlayWatch" })
    m.routes.push({ method: "DELETE", path: "/api/queue", router: m, func: "ClearQueue" })
end function
function __Http_VideoQueueRouter_method_GetQueue(context as object) as boolean
    response = context.response
    queue = VideoQueueUtils_GetQueueDto(m.videoQueueNode)
    response.Json(queue)
    return true
end function
function __Http_VideoQueueRouter_method_AddToQueue(context as object) as boolean
    request = context.request
    response = context.response
    payload = request.BodyJson()
    if payload = invalid
        response.Default(400, "Invalid JSON payload")
        return true
    end if
    videoId = payload.videoId
    playlistId = payload.playlistId
    if StringUtils_IsNullOrEmpty(videoId) and StringUtils_IsNullOrEmpty(playlistId)
        response.Default(400, ("Missing " + chr(34) + "videoId" + chr(34) + " or " + chr(34) + "playlistId" + chr(34) + " in payload"))
        return true
    end if
    if IsString(payload.timestamp)
        payload.timestamp = payload.timestamp.toInt()
    else if IsString(payload.percentDurationWatched)
        payload.percentDurationWatched = payload.percentDurationWatched.toFloat()
    end if
    instance = m.invidiousService.GetInstance()
    contentNode = InvidiousContent_ToRowCellContentNode(payload, instance)
    nodeType = contentNode.type
    if nodeType = "playlist"
        m.videoQueueNode.addToQueuePlaylist = contentNode
    else if nodeType = "video"
        m.videoQueueNode.addToQueue = [
            contentNode
        ]
    end if
    response.Default(204, "OK")
    return true
end function
function __Http_VideoQueueRouter_method_Play(context as object) as boolean
    request = context.request
    response = context.response
    payload = request.BodyJson()
    if payload = invalid
        response.Default(400, "Invalid JSON payload")
        return true
    end if
    videoId = payload.videoId
    playlistId = payload.playlistId
    if StringUtils_IsNullOrEmpty(videoId) and StringUtils_IsNullOrEmpty(playlistId)
        response.Default(400, ("Missing " + chr(34) + "videoId" + chr(34) + " or " + chr(34) + "playlistId" + chr(34) + " in payload"))
        return true
    end if
    if IsString(payload.timestamp)
        payload.timestamp = payload.timestamp.toInt()
    else if IsString(payload.percentDurationWatched)
        payload.percentDurationWatched = payload.percentDurationWatched.toFloat()
    end if
    instance = m.invidiousService.GetInstance()
    contentNode = InvidiousContent_ToRowCellContentNode(payload, instance)
    nodeType = contentNode.type
    if nodeType = "playlist"
        playlistIndex = MathUtils_Max(0, ValidInt(payload.playlistIndex))
        m.videoQueueNode.playPlaylist = {
            playlistNode: contentNode
            playlistIndex: playlistIndex
        }
    else if nodeType = "video"
        m.videoQueueNode.playVideo = contentNode
    end if
    response.Default(204, "OK")
    return true
end function
function __Http_VideoQueueRouter_method_PlayWatch(context as object) as boolean
    request = context.request
    response = context.response
    videoId = request.query.v
    playlistId = request.query.list
    playlistIndex = request.query.index
    hasValidVideo = not StringUtils_IsNullOrEmpty(videoId)
    hasValidPlaylist = not StringUtils_IsNullOrEmpty(playlistId) and not StringUtils_IsNullOrEmpty(playlistIndex)
    if not hasValidVideo and not hasValidPlaylist
        response.Default(400, ("Missing video id (" + chr(34) + "v" + chr(34) + ") or playlist id and index (" + chr(34) + "list" + chr(34) + " and " + chr(34) + "index" + chr(34) + ") in query"))
        return true
    end if
    instance = m.invidiousService.GetInstance()
    if hasValidPlaylist
        payload = {
            "type": "playlist"
            "playlistId": playlistId
        }
        contentNode = InvidiousContent_ToRowCellContentNode(payload, instance)
        playlistIndex = MathUtils_Max(0, ValidInt(playlistIndex.toInt()) - 1)
        
        m.videoQueueNode.playPlaylist = {
            playlistNode: contentNode
            playlistIndex: playlistIndex
        }
        response.Default(200, "Now playing playlist - " + playlistId)
        return true
    else if hasValidVideo
        timestamp = request.query.t
        if IsString(timestamp)
            if timestamp.endsWith("s")
                timestamp = timestamp.left(timestamp.Len() - 1)
            end if
            timestamp = timestamp.toInt()
        end if
        timestamp = ValidInt(timestamp)
        payload = {
            "type": "video"
            "videoId": videoId
            "timestamp": timestamp
        }
        contentNode = InvidiousContent_ToRowCellContentNode(payload, instance)
        m.videoQueueNode.playVideo = contentNode
        response.Default(200, "Now playing video - " + videoId)
        return true
    end if
    return false
end function
function __Http_VideoQueueRouter_method_ClearQueue(context as object) as boolean
    response = context.response
    m.videoQueueNode.clearQueue = true
    response.Default(204, "OK")
    return true
end function
function __Http_VideoQueueRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_VideoQueueRouter_method_new
    instance.GetQueue = __Http_VideoQueueRouter_method_GetQueue
    instance.AddToQueue = __Http_VideoQueueRouter_method_AddToQueue
    instance.Play = __Http_VideoQueueRouter_method_Play
    ' A shortcut to play a video using a /watch endpoint
    instance.PlayWatch = __Http_VideoQueueRouter_method_PlayWatch
    instance.ClearQueue = __Http_VideoQueueRouter_method_ClearQueue
    return instance
end function
function Http_VideoQueueRouter(server as object)
    instance = __Http_VideoQueueRouter_builder()
    instance.new(server)
    return instance
end function