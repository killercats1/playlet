'import "pkg:/components/Services/FeedFilters/FeedFilters.bs"
'import "pkg:/components/Services/Innertube/InnertubeService.bs"
'import "pkg:/components/Services/Innertube/MusicHome.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
' Recommended and the Home shelf rows share one home page load for this long

' a video watched this far counts as watched (hidden from feeds, not in Continue watching)

function __Http_PlayletInvidiousBackendRouter_method_new(server as object)
    m.super0_new()
    m.innertube = server.sceneNodes.innertube
    m.loungeService = server.sceneNodes.loungeService
    m.preferences = server.sceneNodes.preferences
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/authorize_token", router: m, func: "AuthorizeToken" })
    m.routes.push({ method: "POST", path: "/playlet-invidious-backend/api/v1/auth/tokens/unregister", router: m, func: "UnregisterToken" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/feed", router: m, func: "GetAuthFeed" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/subscriptions", router: m, func: "GetAuthSubscriptions" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/playlists", router: m, func: "GetAuthPlaylists" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/history", router: m, func: "GetAuthHistory" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/stats", router: m, func: "GetStats" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/trending", router: m, func: "GetTrending" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/popular", router: m, func: "GetPopular" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/home_shelf", router: m, func: "GetAuthHomeShelf" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/topic_shelf", router: m, func: "GetAuthTopicShelf" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/channels", router: m, func: "GetAuthChannels" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/continue_watching", router: m, func: "GetAuthContinueWatching" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/shorts", router: m, func: "GetAuthShorts" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/music_recommended", router: m, func: "GetAuthMusicRecommended" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/search/suggestions", router: m, func: "GetSearchSuggestions" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/search", router: m, func: "GetSearch" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/resolveurl", router: m, func: "ResolveUrl" })
    m.routes.push({ method: "GET", path: "*", router: m, func: "GetAll" })
    m.routes.push({ method: "POST", path: "*", router: m, func: "PostAll" })
    m.routes.push({ method: "DELETE", path: "*", router: m, func: "DeleteAll" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/watch", router: m, func: "RedirectWatch" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/playlist", router: m, func: "RedirectPlaylist" })
end function
function __Http_PlayletInvidiousBackendRouter_method_AuthorizeToken(context as object) as boolean
    response = context.response
    response.Json({
        "error": "Playlet built-in Invidious backend is not a real Invidious instance, and does not support accounts. Please use the login with YouTube option instead."
    })
    response.http_code = 400
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_UnregisterToken(context as object) as boolean
    request = context.request
    response = context.response
    token = request.BodyText()
    if StringUtils_IsNullOrEmpty(token)
        response.Json({
            "error": "Missing 'token' body parameter"
        })
        response.http_code = 400
        return true
    end if
    if not InnertubeService_AuthRevokeToken(token)
        response.Json({
            "error": "Failed to revoke token"
        })
        response.http_code = 500
        return true
    end if
    response.Default(204, "OK")
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthFeed(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    options = {
        "accessToken": accessToken
        "disableShorts": m.preferences["content_feed.disable_shorts"]
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    continuation = request.query.continuation
    if not StringUtils_IsNullOrEmpty(continuation)
        options.continuation = continuation
    end if
    result = InnertubeService_GetSubscriptions(options)
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    if not IsArray(result.feeds) or result.feeds.Count() = 0
        
        response.Json({
            "videos": []
        })
        return true
    end if
    
    merged = m.MergeFeeds(result.feeds)
    responseBody = {
        "videos": ValidArray(merged.items)
    }
    if merged.DoesExist("continuation")
        responseBody.continuation = merged.continuation
    end if
    response.Json(responseBody)
    if result.DoesExist("cache-control")
        response.headers["cache-control"] = result["cache-control"]
    end if
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthSubscriptions(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    response.Json([])
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthPlaylists(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    options = {
        "accessToken": accessToken
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    continuation = request.query.continuation
    if not StringUtils_IsNullOrEmpty(continuation)
        options.continuation = continuation
    end if
    result = InnertubeService_GetPlaylists(options)
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    if not IsArray(result.feeds) or result.feeds.Count() = 0
        response.Json({
            "error": "Failed to get auth playlists"
        })
        response.http_code = 500
        return true
    end if
    response.Json(result.feeds[0])
    if result.DoesExist("cache-control")
        response.headers["cache-control"] = result["cache-control"]
    end if
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthHistory(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    options = {
        "accessToken": accessToken
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    continuation = request.query.continuation
    hasContinuation = not StringUtils_IsNullOrEmpty(continuation)
    if hasContinuation
        options.continuation = continuation
    end if
    if not hasContinuation
        page = ValidString(request.query.page).ToInt()
        if page > 1
            LogErrorNoTelemetry2("[PlayletInvidiousBackendRouter.bs:209]", "Playlet backend does not use history pagination (use continuation instead)")
            response.Json({
                "items": []
            })
            return true
        end if
    end if
    result = InnertubeService_GetWatchHistory(options)
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    if not IsArray(result.feeds) or result.feeds.Count() = 0
        
        response.Json({
            "items": []
        })
        return true
    end if
    response.Json(result.feeds[0])
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetStats(context as object) as boolean
    response = context.response
    response.Json({
        "error": "Playlet built-in Invidious backend is not a real Invidious instance, and does not support stats."
    })
    response.http_code = 400
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetTrending(context as object) as boolean
    request = context.request
    response = context.response
    raw = request.query.raw <> invalid
    options = {
        "disableShorts": m.preferences["content_feed.disable_shorts"]
        raw: raw
        type: request.query.type
    }
    result = InnertubeService_GetTrending(options)
    if raw
        response.Json(result)
        return true
    end if
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    if not IsArray(result.feeds) or result.feeds.Count() = 0
        response.Json({
            "error": "Failed to get trending feed"
        })
        response.http_code = 500
        return true
    end if
    response.Json(ValidArray(result.feeds[0].items))
    if result.DoesExist("cache-control")
        response.headers["cache-control"] = result["cache-control"]
    end if
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetPopular(context as object) as boolean
    request = context.request
    response = context.response
    isRecommended = request.query.recommended = "true"
    if isRecommended
        return m.GetAuthRecommended(context)
    end if
    response.Json({
        "error": "Playlet built-in Invidious backend does not support popular videos."
    })
    response.http_code = 400
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthRecommended(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    options = {
        "accessToken": accessToken
        "disableShorts": m.preferences["content_feed.disable_shorts"]
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    
    topic = request.query.topic
    if IsString(topic) and (topic = "music" or topic = "news" or topic = "gaming" or topic = "live")
        return m.RespondTopic(response, topic, options, ValidString(request.query.continuation))
    end if
    continuation = request.query.continuation
    if not StringUtils_IsNullOrEmpty(continuation)
        options.continuation = continuation
    else
        
        chip = request.query.chip
        if IsString(chip) and chip <> ""
            options.continuation = chip
        end if
    end if
    
    if options.DoesExist("continuation")
        result = InnertubeService_GetHome(options)
    else
        result = m.HomeFeeds(options, true)
    end if
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    if not IsArray(result.feeds) or result.feeds.Count() = 0
        
        response.Json({
            "items": []
        })
        return true
    end if
    
    recommended = m.CleanFeed(result.feeds[0], true)
    
    if not recommended.DoesExist("sortOptions")
        for each feed in result.feeds
            if IsAssociativeArray(feed) and IsArray(feed.sortOptions)
                recommended["sortOptions"] = feed.sortOptions
                exit for
            end if
        end for
    end if
    response.Json(recommended)
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_RespondTopic(response as object, topic as string, options as object, continuation as string) as boolean
    feeds = invalid
    fromTopicPage = false
    if continuation <> ""
        options.continuation = continuation
    end if
    result = InnertubeService_GetBrowseAuthenticatedPage("FEtopics_" + topic, options)
    if result.error = invalid and m.HasItems(result.feeds)
        feeds = result.feeds
        fromTopicPage = true
    end if
    if feeds = invalid and continuation = "" and (topic = "gaming" or topic = "live")
        trendingType = ""
        if topic = "gaming"
            trendingType = "gaming"
        end if
        result = InnertubeService_GetTrending({
            "type": trendingType
            "disableShorts": options.disableShorts
        })
        if result.error = invalid
            feeds = result.feeds
        end if
    end if
    merged = invalid
    if m.HasItems(feeds)
        merged = m.CleanFeed(m.MergeFeeds(feeds), true)
        if not fromTopicPage
            merged.Delete("continuation")
        end if
    end if
    if merged = invalid
        if continuation <> ""
            response.Json({
                "items": []
            })
            return true
        end if
        response.Json({
            "error": "Nothing for this topic right now"
        })
        response.http_code = 500
        return true
    end if
    response.Json(merged)
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_HasItems(feeds as dynamic) as boolean
    if not IsArray(feeds)
        return false
    end if
    for each feed in feeds
        if IsAssociativeArray(feed) and IsArray(feed.items) and feed.items.Count() > 0
            return true
        end if
    end for
    return false
end function
function __Http_PlayletInvidiousBackendRouter_method_HomeFeeds(options as object, fresh = false as boolean) as object
    cacheKey = (bslib_toString(ValidString(options.accessToken)) + "|" + bslib_toString(ValidString(options.onBehalfOfUser)) + "|" + bslib_toString(ValidBool(options.disableShorts)))
    now = CreateObject("roDateTime").AsSeconds()
    cache = m.homeCache
    if not fresh and IsAssociativeArray(cache) and cache.key = cacheKey and now - cache.savedAt <= 120
        return {
            feeds: cache.feeds
        }
    end if
    
    result = m.AllShelfFeeds("FEwhat_to_watch", options, 1)
    if result.error = invalid and IsArray(result.feeds) and result.feeds.Count() > 0
        m.homeCache = {
            key: cacheKey
            savedAt: now
            feeds: result.feeds
        }
    end if
    return result
end function
function __Http_PlayletInvidiousBackendRouter_method_AllShelfFeeds(browseId as string, options as object, maxMorePages = 2 as integer) as object
    result = InnertubeService_GetBrowseAuthenticatedPage(browseId, options)
    if result.error <> invalid or not IsArray(result.feeds) or result.feeds.Count() = 0
        return result
    end if
    feeds = []
    feeds.Append(result.feeds)
    more = ValidString(result.feeds[0].sectionContinuation)
    pages = 0
    while more <> "" and pages < maxMorePages and feeds.Count() < 12
        pages += 1
        pageOptions = {}
        pageOptions.Append(options)
        pageOptions.continuation = more
        page = InnertubeService_GetBrowseAuthenticatedPage(browseId, pageOptions)
        if page.error <> invalid or not IsArray(page.feeds) or page.feeds.Count() = 0
            exit while
        end if
        feeds.Append(page.feeds)
        nextMore = ValidString(page.feeds[0].sectionContinuation)
        if nextMore = more
            exit while
        end if
        more = nextMore
    end while
    return {
        feeds: feeds
    }
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthHomeShelf(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    options = {
        "accessToken": accessToken
        "disableShorts": m.preferences["content_feed.disable_shorts"]
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    
    continuation = ValidString(request.query.continuation)
    if continuation <> ""
        options.continuation = continuation
        result = InnertubeService_GetHome(options)
        if result.error <> invalid or not m.HasItems(result.feeds)
            response.Json({
                "items": []
            })
            return true
        end if
        page = m.CleanFeed(result.feeds[0], true)
        page.Delete("title")
        response.Json(page)
        return true
    end if
    result = m.HomeFeeds(options)
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    shelfIndex = ValidString(request.query.index).ToInt()
    shelves = m.Shelves(result.feeds, true, "")
    if shelfIndex < 1 or shelfIndex > shelves.Count()
        
        response.Json({
            "error": "No such home shelf"
        })
        response.http_code = 404
        return true
    end if
    response.Json(shelves[shelfIndex - 1])
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthTopicShelf(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    topic = ValidString(request.query.topic)
    if topic <> "music" and topic <> "news" and topic <> "gaming" and topic <> "live"
        response.Json({
            "error": "Unknown topic"
        })
        response.http_code = 400
        return true
    end if
    options = {
        "accessToken": accessToken
        "disableShorts": m.preferences["content_feed.disable_shorts"]
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    
    continuation = ValidString(request.query.continuation)
    if continuation <> ""
        options.continuation = continuation
        result = InnertubeService_GetBrowseAuthenticatedPage("FEtopics_" + topic, options)
        if result.error <> invalid or not m.HasItems(result.feeds)
            response.Json({
                "items": []
            })
            return true
        end if
        page = m.CleanFeed(result.feeds[0], true)
        page.Delete("title")
        response.Json(page)
        return true
    end if
    
    cacheKey = (bslib_toString(topic) + "|" + bslib_toString(accessToken) + "|" + bslib_toString(ValidString(options.onBehalfOfUser)) + "|" + bslib_toString(ValidBool(options.disableShorts)))
    now = CreateObject("roDateTime").AsSeconds()
    if not IsAssociativeArray(m.topicCache)
        m.topicCache = {}
    end if
    cache = m.topicCache[topic]
    feeds = invalid
    if IsAssociativeArray(cache) and cache.key = cacheKey and now - cache.savedAt <= 120
        feeds = cache.feeds
    else
        result = m.AllShelfFeeds("FEtopics_" + topic, options)
        if result.error <> invalid
            response.Json(result)
            response.http_code = 500
            return true
        end if
        feeds = result.feeds
        if IsArray(feeds) and feeds.Count() > 0
            m.topicCache[topic] = {
                key: cacheKey
                savedAt: now
                feeds: feeds
            }
        end if
    end if
    shelfIndex = ValidString(request.query.index).ToInt()
    shelves = m.Shelves(feeds, false, topic)
    if shelfIndex < 1 or shelfIndex > shelves.Count()
        response.Json({
            "error": "No such topic shelf"
        })
        response.http_code = 404
        return true
    end if
    response.Json(shelves[shelfIndex - 1])
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_Shelves(feeds as object, skipFirst as boolean, topic as string) as object
    shelves = []
    if not IsArray(feeds) or feeds.Count() = 0
        return shelves
    end if
    seen = {}
    firstIndex = 0
    if skipFirst
        firstIndex = 1
        if IsAssociativeArray(feeds[0]) and IsArray(feeds[0].items)
            for each item in feeds[0].items
                seen[m.FeedItemKey(item)] = true
            end for
        end if
    end if
    for i = firstIndex to feeds.Count() - 1
        feed = feeds[i]
        if not IsAssociativeArray(feed) or not IsArray(feed.items)
            continue for
        end if
        items = []
        onlyShorts = true
        for each item in feed.items
            if not IsAssociativeArray(item)
                continue for
            end if
            key = m.FeedItemKey(item)
            if key <> ""
                if seen.DoesExist(key)
                    continue for
                end if
                seen[key] = true
            end if
            if item.isShort <> true
                onlyShorts = false
            end if
            items.Push(item)
        end for
        if onlyShorts or m.IsGeneralShelf(ValidString(feed.title), topic)
            continue for
        end if
        shelf = m.CleanFeed({
            "title": ValidString(feed.title)
            "items": items
        }, true)
        if shelf.items.Count() < 3
            continue for
        end if
        if IsString(feed.continuation) and feed.continuation <> ""
            shelf["continuation"] = feed.continuation
        end if
        shelves.Push(shelf)
    end for
    return shelves
end function
function __Http_PlayletInvidiousBackendRouter_method_IsGeneralShelf(title as string, topic as string) as boolean
    lower = LCase(title)
    if lower = ""
        return false
    end if
    words = [
        "trending"
        "live"
        "popular"
        "news"
        "gaming"
        "sports"
        "movies"
        "learning"
        "fashion"
        "podcast"
        "premium"
    ]
    if topic = "music"
        
        words = [
            "live"
            "news"
            "gaming"
            "sports"
            "movies"
            "learning"
            "fashion"
            "podcast"
            "premium"
        ]
    else if topic <> ""
        words = [
            "news"
            "gaming"
            "sports"
            "movies"
            "learning"
            "fashion"
            "podcast"
            "premium"
            "music"
        ]
        for i = words.Count() - 1 to 0 step -1
            if words[i] = topic
                words.Delete(i)
            end if
        end for
    end if
    for each word in words
        if lower.InStr(word) <> -1
            return true
        end if
    end for
    return false
end function
function __Http_PlayletInvidiousBackendRouter_method_CleanFeed(feed as object, hideWatched as boolean) as object
    cleaned = {}
    cleaned.Append(feed)
    if not IsArray(feed.items)
        return cleaned
    end if
    hidden = FeedFilters_LoadLookup()
    
    hideMembersOnlyPref = m.preferences["content_feed.hide_members_only"]
    hideMembersOnly = not IsBool(hideMembersOnlyPref) or hideMembersOnlyPref
    hideWatchedPref = m.preferences["content_feed.hide_watched"]
    hideWatched = hideWatched and (not IsBool(hideWatchedPref) or hideWatchedPref)
    items = []
    for each item in feed.items
        if IsAssociativeArray(item)
            if IsString(item.videoId) and hidden.videos.DoesExist(item.videoId)
                continue for
            end if
            if IsString(item.authorId) and hidden.channels.DoesExist(item.authorId)
                continue for
            end if
            if hideMembersOnly and item.membersOnly = true
                continue for
            end if
            if hideWatched and IsNumber(item.percentDurationWatched) and item.percentDurationWatched >= 90
                continue for
            end if
        end if
        items.Push(item)
    end for
    cleaned["items"] = items
    return cleaned
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthChannels(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    options = {
        "accessToken": accessToken
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    channels = []
    seen = {}
    for each browseId in [
        "FEchannels"
        "FEsubscriptions"
    ]
        result = InnertubeService_GetBrowseAuthenticatedPage(browseId, options)
        if result.error = invalid and IsArray(result.feeds)
            for each feed in result.feeds
                if not IsAssociativeArray(feed) or not IsArray(feed.items)
                    continue for
                end if
                for each item in feed.items
                    if channels.Count() >= 100
                        exit for
                    end if
                    if IsAssociativeArray(item) and item.type = "channel" and IsString(item.authorId) and not seen.DoesExist(item.authorId)
                        seen[item.authorId] = true
                        
                        if ValidInt(item.videoCount) <= 0
                            item["videoCount"] = -1
                            item.Delete("videoCountText")
                        end if
                        
                        if ValidInt(item.subCount) <= 0 and StringUtils_IsNullOrEmpty(item.authorSubTitle)
                            item.Delete("subCount")
                            item["authorSubTitle"] = ValidString(item.channelHandle)
                            if item["authorSubTitle"] = ""
                                item["authorSubTitle"] = " "
                            end if
                        end if
                        channels.Push(item)
                    end if
                end for
            end for
        end if
        if channels.Count() > 0
            exit for
        end if
    end for
    if channels.Count() = 0
        response.Json({
            "error": "No channel list"
        })
        response.http_code = 404
        return true
    end if
    response.Json({
        "items": channels
    })
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthContinueWatching(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    options = {
        "accessToken": accessToken
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    result = InnertubeService_GetWatchHistory(options)
    items = []
    seen = {}
    if result.error = invalid and IsArray(result.feeds)
        for each feed in result.feeds
            if not IsAssociativeArray(feed) or not IsArray(feed.items)
                continue for
            end if
            for each item in feed.items
                if items.Count() >= 30
                    exit for
                end if
                if not IsAssociativeArray(item) or item.type <> "video" or item.isShort = true or not IsString(item.videoId)
                    continue for
                end if
                if seen.DoesExist(item.videoId) or not IsNumber(item.percentDurationWatched)
                    continue for
                end if
                if item.percentDurationWatched < 3 or item.percentDurationWatched >= 90
                    continue for
                end if
                seen[item.videoId] = true
                items.Push(item)
            end for
        end for
    end if
    if items.Count() = 0
        response.Json({
            "error": "Nothing to continue watching"
        })
        response.http_code = 404
        return true
    end if
    response.Json({
        "items": items
    })
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_MergeFeeds(feeds as object) as object
    maxItems = 150
    merged = {}
    merged.Append(feeds[0])
    items = []
    seen = {}
    continuation = ""
    for each feed in feeds
        if not IsAssociativeArray(feed)
            continue for
        end if
        if continuation = "" and IsString(feed.continuation)
            continuation = feed.continuation
        end if
        if not merged.DoesExist("sortOptions") and IsArray(feed.sortOptions)
            merged["sortOptions"] = feed.sortOptions
        end if
        if not IsArray(feed.items)
            continue for
        end if
        for each item in feed.items
            if items.Count() >= maxItems
                exit for
            end if
            key = m.FeedItemKey(item)
            if key <> ""
                if seen.DoesExist(key)
                    continue for
                end if
                seen[key] = true
            end if
            items.Push(item)
        end for
    end for
    merged["items"] = items
    if continuation <> ""
        merged["continuation"] = continuation
    end if
    return merged
end function
function __Http_PlayletInvidiousBackendRouter_method_FeedItemKey(item as object) as string
    if not IsAssociativeArray(item)
        return ""
    end if
    itemType = ValidString(item["type"])
    id = ""
    if itemType = "video"
        id = ValidString(item["videoId"])
    else if itemType = "playlist"
        id = ValidString(item["playlistId"])
    else if itemType = "channel"
        id = ValidString(item["authorId"])
    end if
    if id = ""
        return ""
    end if
    return itemType + ":" + id
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthShorts(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    
    if request.query.respectDisableShorts <> invalid and m.preferences["content_feed.disable_shorts"] = true
        response.Json({
            "error": "Shorts are disabled"
        })
        response.http_code = 500
        return true
    end if
    onBehalfOfUser = request.query.activeIdentifyToken
    items = []
    seen = {}
    for each source in [
        "home"
        "subscriptions"
    ]
        options = {
            "accessToken": accessToken
            "disableShorts": false
        }
        if not StringUtils_IsNullOrEmpty(onBehalfOfUser)
            options.onBehalfOfUser = onBehalfOfUser
        end if
        if source = "home"
            
            result = m.HomeFeeds(options)
        else
            result = InnertubeService_GetSubscriptions(options)
        end if
        if IsArray(result.feeds)
            for each feed in result.feeds
                if IsAssociativeArray(feed) and IsArray(feed.items)
                    for each item in feed.items
                        if IsAssociativeArray(item) and item.isShort = true and IsString(item.videoId) and not seen.DoesExist(item.videoId)
                            seen[item.videoId] = true
                            items.Push(item)
                        end if
                    end for
                end if
            end for
        end if
    end for
    if items.Count() = 0
        response.Json({
            "error": "No Shorts found"
        })
        response.http_code = 500
        return true
    end if
    response.Json(m.CleanFeed({
        "items": items
    }, false))
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthMusicRecommended(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    
    result = InnertubeMusic_GetHome(accessToken, request.query.activeIdentifyToken, invalid)
    if result.error <> invalid
        musicOptions = {
            "accessToken": accessToken
            "disableShorts": true
        }
        if not StringUtils_IsNullOrEmpty(request.query.activeIdentifyToken)
            musicOptions.onBehalfOfUser = request.query.activeIdentifyToken
        end if
        tvMusic = m.AllShelfFeeds("FEtopics_music", musicOptions)
        if tvMusic.error = invalid and m.HasItems(tvMusic.feeds) and m.Shelves(tvMusic.feeds, false, "music").Count() = 0
            merged = m.CleanFeed(m.MergeFeeds(tvMusic.feeds), true)
            if merged.items.Count() > 0
                response.Json({
                    "items": merged.items
                })
                return true
            end if
        end if
        response.Json({
            "error": ("YouTube Music recommendations unavailable: " + bslib_toString(result.error))
        })
        response.http_code = 500
        return true
    end if
    response.Json({
        "items": result.items
    })
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetSearchSuggestions(context as object) as boolean
    request = context.request
    response = context.response
    query = request.query.q
    result = InnertubeService_SearchSuggestions(query)
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    result.query = query
    if result.DoesExist("cache-control")
        response.headers["cache-control"] = result["cache-control"]
    end if
    response.Json(result)
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetSearch(context as object) as boolean
    request = context.request
    response = context.response
    query = request.query.q
    continuation = request.query.continuation
    raw = request.query.raw <> invalid
    options = {
        "disableShorts": m.preferences["content_feed.disable_shorts"]
        raw: raw
    }
    searchFilters = {}
    sort = request.query.sort
    if not StringUtils_IsNullOrEmpty(sort)
        searchFilters.sort = sort
    end if
    date = request.query.date
    if not StringUtils_IsNullOrEmpty(date)
        searchFilters.date = date
    end if
    _type = request.query.type
    if not StringUtils_IsNullOrEmpty(_type)
        searchFilters.type = _type
    end if
    duration = request.query.duration
    if not StringUtils_IsNullOrEmpty(duration)
        searchFilters.duration = duration
    end if
    features = request.query.features
    if not StringUtils_IsNullOrEmpty(features)
        searchFilters.features = features.Split(",")
    end if
    if searchFilters.Count() > 0
        options.searchFilters = searchFilters
    end if
    if not StringUtils_IsNullOrEmpty(continuation)
        options.continuation = continuation
    end if
    fetchedPages = 0
    while true
        
        if fetchedPages > 3
            response.Json({
                "error": "Failed to search: no results found"
            })
            response.http_code = 500
            return true
        end if
        result = InnertubeService_Search(query, options)
        fetchedPages += 1
        if raw
            response.Json(result)
            return true
        end if
        if result.error <> invalid
            response.Json(result)
            response.http_code = 500
            return true
        end if
        if not IsArray(result.feeds) or result.feeds.Count() = 0
            response.Json({
                "error": "Failed to search: no results found"
            })
            response.http_code = 500
            return true
        end if
        feed = result.feeds[0]
        if feed.items.Count() > 0
            response.Json(feed)
            if fetchedPages = 1 and result.DoesExist("cache-control")
                response.headers["cache-control"] = result["cache-control"]
            end if
            return true
        end if
        if StringUtils_IsNullOrEmpty(feed.continuation)
            response.Json({
                "error": "Failed to search: no results found"
            })
            response.http_code = 500
            return true
        end if
        
        options.continuation = feed.continuation
    end while
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_ResolveUrl(context as object) as boolean
    request = context.request
    response = context.response
    url = request.query.url
    raw = request.query.raw <> invalid
    if StringUtils_IsNullOrEmpty(url)
        response.Json({
            "error": "Missing 'url' query parameter"
        })
        response.http_code = 400
        return true
    end if
    json = InnertubeService_ResolveUrl(url)
    if json = invalid
        response.Json({
            "error": "Failed to resolve URL"
        })
        response.http_code = 500
        return true
    end if
    if raw
        response.Json(json)
        return true
    end if
    endpoint = json["endpoint"]
    pageType = ValidString(ObjectUtils_Dig(endpoint, [
        "commandMetadata"
        "webCommandMetadata"
        "webPageType"
    ]))
    if pageType = "WEB_PAGE_TYPE_UNKNOWN" or pageType = ""
        response.Json({
            "error": "Unknown page type"
        })
        response.http_code = 400
        return true
    end if
    subEndpoint = endpoint["watchEndpoint"]
    if subEndpoint = invalid
        subEndpoint = endpoint["browseEndpoint"]
        if subEndpoint = invalid
            subEndpoint = endpoint
        end if
    end if
    params = ObjectUtils_Dig(subEndpoint, [
        "params"
    ])
    result = {
        "pageType": pageType
    }
    browseId = ObjectUtils_Dig(subEndpoint, [
        "browseId"
    ])
    if not StringUtils_IsNullOrEmpty(browseId)
        result["ucid"] = browseId
    end if
    videoId = ObjectUtils_Dig(subEndpoint, [
        "videoId"
    ])
    if not StringUtils_IsNullOrEmpty(videoId)
        result["videoId"] = videoId
    end if
    playlistId = ObjectUtils_Dig(subEndpoint, [
        "playlistId"
    ])
    if not StringUtils_IsNullOrEmpty(playlistId)
        result["playlistId"] = playlistId
    end if
    startTimeSeconds = ObjectUtils_Dig(subEndpoint, [
        "startTimeSeconds"
    ])
    if ValidInt(startTimeSeconds) > 0
        result["startTimeSeconds"] = startTimeSeconds
    end if
    if IsString(params)
        result["params"] = params
    end if
    response.Json(result)
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAll(context as object) as boolean
    request = context.request
    route = request.route
    if route.StartsWith("/playlet-invidious-backend/api/v1/videos/")
        return m.GetVideo(context)
    else if route.StartsWith("/playlet-invidious-backend/api/v1/playlists/")
        return m.GetPlaylist(context)
    else if route.StartsWith("/playlet-invidious-backend/api/v1/auth/playlists/")
        return m.GetAuthPlaylist(context)
    else if route.StartsWith("/playlet-invidious-backend/api/v1/channels/")
        return m.GetChannel(context)
    else if route.StartsWith("/playlet-invidious-backend/channel")
        return m.RedirectChannel(context)
    end if
    return false
end function
function __Http_PlayletInvidiousBackendRouter_method_PostAll(context as object) as boolean
    request = context.request
    route = request.route
    if route.StartsWith("/playlet-invidious-backend/api/v1/auth/subscriptions/")
        return m.SubscribeToChannel(context)
    end if
    return false
end function
function __Http_PlayletInvidiousBackendRouter_method_GetVideo(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    videoId = route.Mid("/playlet-invidious-backend/api/v1/videos/".Len())
    if videoId.InStr("?") > 0
        videoId = videoId.Left(videoId.InStr("?"))
    end if
    raw = request.query.raw <> invalid
    videoInfoBatched = request.query.video_info_batched <> invalid
    visitorData = ""
    sessionData = m.innertube.sessionData
    if IsAssociativeArray(sessionData)
        visitorData = ValidString(sessionData.visitorData)
    end if
    options = {
        "raw": raw
        "visitorData": visitorData
    }
    if videoInfoBatched
        options["retry"] = false
        metadata = InnertubeService_GetVideoInfoBatched([
            videoId
        ], options)
        if IsArray(metadata.videos) and metadata.videos.Count() > 0
            metadata = metadata.videos[0]
        else
            metadata = {
                "error": "Failed to get video info with video_info_batched=true"
            }
        end if
    else
        options["credentialTransferToken"] = m.loungeService.credentialTransferToken
        metadata = InnertubeService_GetVideoMetadata(videoId, options)
    end if
    response.Json(metadata)
    if metadata.error <> invalid
        response.http_code = 500
        return true
    end if
    
    if videoInfoBatched
        response.headers["cache-control"] = "public, max-age=259200" 
    end if
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetPlaylist(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    playlistId = context.playlistId
    if StringUtils_IsNullOrEmpty(playlistId)
        playlistId = route.Mid("/playlet-invidious-backend/api/v1/playlists/".Len())
        if playlistId.InStr("?") > 0
            playlistId = playlistId.Left(playlistId.InStr("?"))
        end if
    end if
    continuation = request.query.continuation
    raw = request.query.raw <> invalid
    infoOnly = request.query.info_only <> invalid
    options = {
        raw: raw
    }
    accessToken = m.GetAccessToken(request)
    if accessToken <> invalid
        options["accessToken"] = accessToken
        activeIdentifyToken = request.query.activeIdentifyToken
        if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
            options.onBehalfOfUser = activeIdentifyToken
        end if
    end if
    if playlistId.StartsWith("RD")
        if not StringUtils_IsNullOrEmpty(continuation)
            options.videoId = continuation
        else
            videoId = request.query.videoId
            if not StringUtils_IsNullOrEmpty(videoId)
                options.videoId = videoId
            end if
        end if
        playlist = InnertubeService_GetMix(playlistId, options)
    else
        if not StringUtils_IsNullOrEmpty(continuation)
            options.continuation = continuation
        end if
        playlist = InnertubeService_GetPlaylist(playlistId, options)
    end if
    if raw
        response.Json(playlist)
        return true
    end if
    if playlist.error <> invalid
        response.Json(playlist)
        response.http_code = 500
        return true
    end if
    index = request.query.index
    if not StringUtils_IsNullOrEmpty(index)
        index = index.ToInt()
        if index > 1
            LogErrorNoTelemetry2("[PlayletInvidiousBackendRouter.bs:1375]", "Playlet backend does not use playlist pagination (use continuation instead)")
            playlist.videos = []
        end if
    end if
    
    if infoOnly
        playlist.videos = []
        playlist.Delete("continuation")
    end if
    response.Json(playlist)
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthPlaylist(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    playlistId = route.Mid("/playlet-invidious-backend/api/v1/auth/playlists/".Len())
    if playlistId.InStr("?") > 0
        playlistId = playlistId.Left(playlistId.InStr("?"))
    end if
    context.playlistId = playlistId
    return m.GetPlaylist(context)
end function
function __Http_PlayletInvidiousBackendRouter_method_GetChannel(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    channelAndTab = route.Mid("/playlet-invidious-backend/api/v1/channels/".Len())
    if channelAndTab.InStr("?") > 0
        channelAndTab = channelAndTab.Left(channelAndTab.InStr("?"))
    end if
    channelAndTab = channelAndTab.Split("/")
    continuation = request.query.continuation
    raw = request.query.raw <> invalid
    options = {
        raw: raw
    }
    if not StringUtils_IsNullOrEmpty(continuation)
        options.continuation = continuation
    end if
    if channelAndTab.Count() = 1
        channelId = channelAndTab[0]
        channel = InnertubeService_GetChannel(channelId, options)
        if raw
            response.Json(channel)
            return true
        end if
        if channel.error <> invalid
            response.Json(channel)
            response.http_code = 500
            return true
        end if
        response.Json(channel)
        if channel.DoesExist("cache-control")
            response.headers["cache-control"] = channel["cache-control"]
        end if
        return true
    else if channelAndTab.Count() = 2
        channelId = channelAndTab[0]
        _tab = channelAndTab[1]
        params = request.query.params
        if not StringUtils_IsNullOrEmpty(params)
            options.params = params
        end if
        
        sortBy = request.query.sort_by
        if not StringUtils_IsNullOrEmpty(sortBy) and sortBy.StartsWith("{")
            sortBy = StringUtils_ParseJsonSafe(sortBy)
            if IsAssociativeArray(sortBy)
                if sortBy.DoesExist("params")
                    options.params = sortBy.params
                end if
                if sortBy.DoesExist("continuation")
                    options.continuation = sortBy.continuation
                end if
            end if
        end if
        channel = InnertubeService_GetChannel(channelId, options)
        if raw
            response.Json(channel)
            return true
        end if
        if channel.error <> invalid
            response.Json(channel)
            response.http_code = 500
            return true
        end if
        result = {}
        if _tab = "playlists" or _tab = "podcasts" or _tab = "releases" or _tab = "courses"
            result["playlists"] = channel.items
        else
            result["videos"] = channel.items
        end if
        if channel.DoesExist("continuation")
            result.continuation = channel.continuation
        end if
        if channel.DoesExist("sortOptions")
            
            sortOptions = channel.sortOptions
            if IsArray(sortOptions) and sortOptions.Count() > 0
                for i = 0 to sortOptions.Count() - 1
                    sortOption = sortOptions[i]
                    sortOptionId = {}
                    if sortOption.DoesExist("params")
                        sortOptionId["params"] = sortOption.params
                    end if
                    if sortOption.DoesExist("continuation")
                        sortOptionId["continuation"] = sortOption.continuation
                    end if
                    sortOption.id = FormatJson(sortOptionId)
                end for
            end if
            result["sortOptions"] = sortOptions
        end if
        response.Json(result)
        if channel.DoesExist("cache-control")
            response.headers["cache-control"] = channel["cache-control"]
        end if
        return true
    end if
    return false
end function
function __Http_PlayletInvidiousBackendRouter_method_SubscribeToChannel(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    channelId = route.Mid("/playlet-invidious-backend/api/v1/auth/subscriptions/".Len())
    if channelId.InStr("?") > 0
        channelId = channelId.Left(channelId.InStr("?"))
    end if
    if StringUtils_IsNullOrEmpty(channelId)
        response.Json({
            "error": "Missing 'channelId' path parameter"
        })
        response.http_code = 400
        return true
    end if
    options = {
        "accessToken": accessToken
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    result = InnertubeService_SubscribeToChannel(channelId, options)
    if result.success <> true
        response.Json(result)
        response.http_code = 500
        return true
    end if
    response.Default(204, "OK")
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_DeleteAll(context as object) as boolean
    request = context.request
    route = request.route
    if route.StartsWith("/playlet-invidious-backend/api/v1/auth/subscriptions/")
        return m.UnsubscribeFromChannel(context)
    end if
    return false
end function
function __Http_PlayletInvidiousBackendRouter_method_UnsubscribeFromChannel(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    channelId = route.Mid("/playlet-invidious-backend/api/v1/auth/subscriptions/".Len())
    if channelId.InStr("?") > 0
        channelId = channelId.Left(channelId.InStr("?"))
    end if
    if StringUtils_IsNullOrEmpty(channelId)
        response.Json({
            "error": "Missing 'channelId' path parameter"
        })
        response.http_code = 400
        return true
    end if
    options = {
        "accessToken": accessToken
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    result = InnertubeService_UnsubscribeFromChannel(channelId, options)
    if result.success <> true
        response.Json(result)
        response.http_code = 500
        return true
    end if
    response.Default(204, "OK")
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_RedirectWatch(context as object) as boolean
    request = context.request
    response = context.response
    videoId = request.query.v
    t = request.query.t
    if StringUtils_IsNullOrEmpty(videoId)
        response.Json({
            "error": "Missing 'v' query parameter"
        })
        response.http_code = 400
        return true
    end if
    url = ("https://redirect.invidious.io/watch?v=" + bslib_toString(videoId))
    if not StringUtils_IsNullOrEmpty(t)
        url = (bslib_toString(url) + "&t=" + bslib_toString(t))
    end if
    response.Redirect(url)
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_RedirectPlaylist(context as object) as boolean
    request = context.request
    response = context.response
    playlistId = request.query.list
    if StringUtils_IsNullOrEmpty(playlistId)
        response.Json({
            "error": "Missing 'list' query parameter"
        })
        response.http_code = 400
        return true
    end if
    response.Redirect(("https://redirect.invidious.io/playlist?list=" + bslib_toString(playlistId)))
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_RedirectChannel(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    channelId = route.Mid("/playlet-invidious-backend/channel/".Len())
    if StringUtils_IsNullOrEmpty(channelId)
        response.Json({
            "error": "Missing 'channelId' path parameter"
        })
        response.http_code = 400
        return true
    end if
    response.Redirect(("https://redirect.invidious.io/channel/" + bslib_toString(channelId)))
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAccessToken(request as object) as dynamic
    accessToken = request.headers["authorization"]
    if StringUtils_IsNullOrEmpty(accessToken) or not accessToken.StartsWith("Bearer ")
        return invalid
    end if
    return accessToken.Mid("Bearer ".Len())
end function
function __Http_PlayletInvidiousBackendRouter_method_RequireAccessToken(request as object, response as object) as dynamic
    accessToken = m.GetAccessToken(request)
    if accessToken = invalid
        response.Json({
            "error": "Missing or invalid 'Authorization' header. Please login again."
        })
        response.http_code = 403
        return invalid
    end if
    return accessToken
end function
function __Http_PlayletInvidiousBackendRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_PlayletInvidiousBackendRouter_method_new
    instance.AuthorizeToken = __Http_PlayletInvidiousBackendRouter_method_AuthorizeToken
    instance.UnregisterToken = __Http_PlayletInvidiousBackendRouter_method_UnregisterToken
    instance.GetAuthFeed = __Http_PlayletInvidiousBackendRouter_method_GetAuthFeed
    instance.GetAuthSubscriptions = __Http_PlayletInvidiousBackendRouter_method_GetAuthSubscriptions
    instance.GetAuthPlaylists = __Http_PlayletInvidiousBackendRouter_method_GetAuthPlaylists
    instance.GetAuthHistory = __Http_PlayletInvidiousBackendRouter_method_GetAuthHistory
    instance.GetStats = __Http_PlayletInvidiousBackendRouter_method_GetStats
    instance.GetTrending = __Http_PlayletInvidiousBackendRouter_method_GetTrending
    instance.GetPopular = __Http_PlayletInvidiousBackendRouter_method_GetPopular
    instance.GetAuthRecommended = __Http_PlayletInvidiousBackendRouter_method_GetAuthRecommended
    ' Topic chips use the signed-in YouTube TV topic page (FEtopics_<topic>, personalized like the TV app's own
    ' Music/News/Gaming/Live pages). Gaming and Live fall back to YouTube's trending lists only when the account
    ' has no such page. Continuations only ever come from a topic page (the trending fallback drops its token).
    instance.RespondTopic = __Http_PlayletInvidiousBackendRouter_method_RespondTopic
    instance.HasItems = __Http_PlayletInvidiousBackendRouter_method_HasItems
    ' Subscriptions come back as several shelves (feeds), all of them the account's own subscriptions. Instead of
    ' only the first shelf, put all of them in the one row, in order and without duplicates. Paging continues
    ' the first shelf that has more to load.
    ' The account's home page (all its shelves), kept for a short while: Recommended and the Home shelf rows
    ' load at the same time and must come from the same page (the home page changes on every load).
    instance.HomeFeeds = __Http_PlayletInvidiousBackendRouter_method_HomeFeeds
    ' A TV page with all its shelves: the first load only has the top few, the rest come with the page's
    ' "more shelves" continuation (followed up to twice).
    instance.AllShelfFeeds = __Http_PlayletInvidiousBackendRouter_method_AllShelfFeeds
    ' One of YouTube's own home shelves after the first ("Because you watched...", a channel's new videos,
    ' Mixes...), as its own row with YouTube's title. index: 1 for the first shelf after Recommended.
    instance.GetAuthHomeShelf = __Http_PlayletInvidiousBackendRouter_method_GetAuthHomeShelf
    ' One shelf of a YouTube TV topic page (Music: "Mixed for you", "New releases", "Trending"...), as its own
    ' row with YouTube's title, like the TV app's Music page. topic: music, news, gaming or live; index: 1 for
    ' the first shelf.
    instance.GetAuthTopicShelf = __Http_PlayletInvidiousBackendRouter_method_GetAuthTopicShelf
    ' A page's shelves, cleaned up: no video twice (with skipFirst, also not one in the first shelf, which is
    ' Recommended on Home), no Shorts-only shelves (Shorts have their own row), and none with too little left
    ' to fill a row.
    instance.Shelves = __Http_PlayletInvidiousBackendRouter_method_Shelves
    ' Shelves for everyone rather than for this account (Trending, Live, News, Gaming...) on Home, or shelves of
    ' another topic further down a topic page (the Music page's later parts bring Gaming and Live).
    instance.IsGeneralShelf = __Http_PlayletInvidiousBackendRouter_method_IsGeneralShelf
    ' Drops what the user doesn't want to see: videos and channels marked Not interested / Don't recommend
    ' (remembered on the TV), members-only videos and, with hideWatched, videos already watched to the end
    ' (both settings, on by default).
    instance.CleanFeed = __Http_PlayletInvidiousBackendRouter_method_CleanFeed
    ' The channels the account is subscribed to: YouTube's channel list page, or the channels on the
    ' subscriptions page when that has none.
    instance.GetAuthChannels = __Http_PlayletInvidiousBackendRouter_method_GetAuthChannels
    ' Videos started but not finished, from the account's watch history (like YouTube's "Continue watching").
    instance.GetAuthContinueWatching = __Http_PlayletInvidiousBackendRouter_method_GetAuthContinueWatching
    instance.MergeFeeds = __Http_PlayletInvidiousBackendRouter_method_MergeFeeds
    instance.FeedItemKey = __Http_PlayletInvidiousBackendRouter_method_FeedItemKey
    ' The account's Shorts (the Shorts tab): the Shorts YouTube puts in its home page and subscriptions feed.
    ' The Shorts tab is opt-in, so this ignores the "Disable Shorts" setting.
    instance.GetAuthShorts = __Http_PlayletInvidiousBackendRouter_method_GetAuthShorts
    ' The account's YouTube Music recommendations (the Music tab's first row).
    instance.GetAuthMusicRecommended = __Http_PlayletInvidiousBackendRouter_method_GetAuthMusicRecommended
    instance.GetSearchSuggestions = __Http_PlayletInvidiousBackendRouter_method_GetSearchSuggestions
    instance.GetSearch = __Http_PlayletInvidiousBackendRouter_method_GetSearch
    instance.ResolveUrl = __Http_PlayletInvidiousBackendRouter_method_ResolveUrl
    instance.GetAll = __Http_PlayletInvidiousBackendRouter_method_GetAll
    instance.PostAll = __Http_PlayletInvidiousBackendRouter_method_PostAll
    instance.GetVideo = __Http_PlayletInvidiousBackendRouter_method_GetVideo
    instance.GetPlaylist = __Http_PlayletInvidiousBackendRouter_method_GetPlaylist
    instance.GetAuthPlaylist = __Http_PlayletInvidiousBackendRouter_method_GetAuthPlaylist
    instance.GetChannel = __Http_PlayletInvidiousBackendRouter_method_GetChannel
    instance.SubscribeToChannel = __Http_PlayletInvidiousBackendRouter_method_SubscribeToChannel
    instance.DeleteAll = __Http_PlayletInvidiousBackendRouter_method_DeleteAll
    instance.UnsubscribeFromChannel = __Http_PlayletInvidiousBackendRouter_method_UnsubscribeFromChannel
    instance.RedirectWatch = __Http_PlayletInvidiousBackendRouter_method_RedirectWatch
    instance.RedirectPlaylist = __Http_PlayletInvidiousBackendRouter_method_RedirectPlaylist
    instance.RedirectChannel = __Http_PlayletInvidiousBackendRouter_method_RedirectChannel
    instance.GetAccessToken = __Http_PlayletInvidiousBackendRouter_method_GetAccessToken
    instance.RequireAccessToken = __Http_PlayletInvidiousBackendRouter_method_RequireAccessToken
    return instance
end function
function Http_PlayletInvidiousBackendRouter(server as object)
    instance = __Http_PlayletInvidiousBackendRouter_builder()
    instance.new(server)
    return instance
end function