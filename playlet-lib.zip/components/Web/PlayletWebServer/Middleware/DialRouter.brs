'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/services/XmlObject.bs"
'import "pkg:/source/utils/MessagePortUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
function __Http_DialRouter_method_new(server as object)
    m.super0_new()
    task = server.task
    m.serverAddress = task.callfunc("GetServerAddress", invalid)
    m.scene = task.getScene()
    m.loungeService = server.sceneNodes.loungeService
    m.deviceId = m.loungeService.deviceId
    m.deviceName = m.loungeService.deviceName
    m.routes.push({
        method: "GET"
        path: ("/dial/" + bslib_toString(m.deviceId) + "/device-description.xml")
        router: m
        func: "GetDialManifest"
    })
    m.routes.push({
        method: "GET"
        path: ("/dial/" + bslib_toString(m.deviceId) + "/YouTube")
        router: m
        func: "GetDialYouTube"
    })
    m.routes.push({
        method: "POST"
        path: ("/dial/" + bslib_toString(m.deviceId) + "/YouTube")
        router: m
        func: "PostDialYouTube"
    })
    m.routes.push({
        method: "DELETE"
        path: ("/dial/" + bslib_toString(m.deviceId) + "/YouTube/run")
        router: m
        func: "CloseChannel"
    })
end function
function __Http_DialRouter_method_GetDialManifest(context as object) as boolean
    response = context.response
    xmlContent = m.GenerateDialManifest()
    response.http_code = 200
    response.SetBodyDataString(xmlContent)
    response.ContentType(("text/xml; charset=" + chr(34) + "utf-8" + chr(34)))
    response.headers["Application-URL"] = (bslib_toString(m.serverAddress) + "/dial/" + bslib_toString(m.deviceId))
    response.headers["Cache-Control"] = "no-cache, no-store, max-age=0, must-revalidate"
    return true
end function
function __Http_DialRouter_method_GetDialYouTube(context as object) as boolean
    response = context.response
    xmlContent = m.GenerateDialYouTube()
    response.http_code = 200
    response.SetBodyDataString(xmlContent)
    response.ContentType(("text/xml; charset=" + chr(34) + "utf-8" + chr(34)))
    response.headers["Cache-Control"] = "no-cache, no-store, max-age=0, must-revalidate"
    return true
end function
function __Http_DialRouter_method_PostDialYouTube(context as object) as boolean
    request = context.request
    response = context.response
    fields = UrlUtils_GetUrlDecodedForm(request.BodyText())
    pairingCode = fields["pairingCode"]
    if StringUtils_IsNullOrEmpty(pairingCode)
        response.Default(400, "Bad Request")
        return true
    end if
    theme = fields["theme"]
    if not IsString(theme) or theme <> "cl"
        response.Default(400, "Bad Request")
        return true
    end if
    loungeToken = m.loungeService.loungeToken
    if StringUtils_IsNullOrEmpty(loungeToken)
        messagePort = CreateObject("roMessagePort")
        MessagePortUtils_ObserveFieldScopedExSafe(m.loungeService, "loungeToken", messagePort)
        m.loungeService.join = true
        message = wait(30000, messagePort)
        m.loungeService.unobserveFieldScoped("loungeToken")
        if message = invalid or StringUtils_IsNullOrEmpty(message.GetData())
            response.Default(500, "Couldn't join lounge")
            return true
        end if
    end if
    req = HttpClient_Post("https://www.youtube.com/api/lounge/pairing/register_pairing_code")
    req.FormBody({
        "pairing_code": pairingCode
        "screen_id": m.loungeService.screenId
        "screen_name": m.deviceName
        "device_id": m.deviceId
    })
    res = req.Await()
    if not res.IsSuccess()
        response.Default(500, "Internal Server Error")
        return true
    end if
    response.Default(200, "OK")
    return true
end function
function __Http_DialRouter_method_CloseChannel(context as object) as boolean
    response = context.response
    response.Default(200, "Shutting down app...")
    m.scene.exitChannel = true
    return true
end function
function __Http_DialRouter_method_GenerateDialManifest() as string
    if m._dialXml <> invalid
        return m._dialXml
    end if
    xml = XmlObject()
    if xml.Node("root", {
        "xmlns": "urn:schemas-upnp-org:device-1-0"
    })
        if xml.Node("specVersion")
            xml.TextNode("major", "1")
            xml.TextNode("minor", "0")
            xml.End()
        end if
        if xml.Node("device")
            xml.TextNode("deviceType", "urn:dial-multiscreen-org:device:dial:1")
            xml.TextNode("friendlyName", m.deviceName)
            xml.TextNode("manufacturer", "Generic")
            xml.TextNode("modelName", "Generic")
            xml.TextNode("UDN", "uuid:" + m.deviceId)
            if xml.Node("serviceList")
                if xml.Node("service")
                    xml.TextNode("serviceType", "urn:dial-multiscreen-org:service:dial:1")
                    xml.TextNode("serviceId", "urn:dial-multiscreen-org:serviceId:dial")
                    xml.EmptyNode("controlURL")
                    xml.EmptyNode("eventSubURL")
                    xml.EmptyNode("SCPDURL")
                    xml.End()
                end if
                xml.End()
            end if
            xml.End()
        end if
        xml.End()
    end if
    m._dialXml = xml.ToXmlString()
    return m._dialXml
end function
function __Http_DialRouter_method_GenerateDialYouTube() as string
    screenId = m.loungeService.screenId
    loungeToken = m.loungeService.loungeToken
    if m._dialYouTubeXml <> invalid
        if m._dialYoutubeScreenId = screenId and m._dialYoutubeLoungeToken = loungeToken
            return m._dialYouTubeXml
        end if
    end if
    xml = XmlObject()
    if xml.Node("service", {
        "dialVer": "1.7"
        "xmlns": "urn:dial-multiscreen-org:schemas:dial"
    })
        xml.TextNode("name", "YouTube")
        xml.EmptyNode("options", {
            "allowStop": "true"
        })
        xml.TextNode("state", "running")
        xml.EmptyNode("link", {
            "rel": "run"
            "href": "run"
        })
        if not StringUtils_IsNullOrEmpty(screenId) and not StringUtils_IsNullOrEmpty(loungeToken)
            if xml.Node("additionalData")
                xml.TextNode("theme", "cl")
                xml.TextNode("deviceId", m.deviceId)
                xml.TextNode("screenId", screenId)
                xml.TextNode("loungeToken", loungeToken)
                xml.End()
            end if
        end if
        xml.End()
    end if
    m._dialYouTubeXml = xml.ToXmlString()
    m._dialYoutubeScreenId = screenId
    m._dialYoutubeLoungeToken = loungeToken
    return m._dialYouTubeXml
end function
function __Http_DialRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_DialRouter_method_new
    ' @get("/dial/:device-id/device-description.xml")
    instance.GetDialManifest = __Http_DialRouter_method_GetDialManifest
    ' @get("/dial/:device-id/YouTube")
    instance.GetDialYouTube = __Http_DialRouter_method_GetDialYouTube
    ' @post("/dial/:device-id/YouTube")
    instance.PostDialYouTube = __Http_DialRouter_method_PostDialYouTube
    ' @delete("/dial/:device-id/YouTube/run")
    instance.CloseChannel = __Http_DialRouter_method_CloseChannel
    instance.GenerateDialManifest = __Http_DialRouter_method_GenerateDialManifest
    instance.GenerateDialYouTube = __Http_DialRouter_method_GenerateDialYouTube
    return instance
end function
function Http_DialRouter(server as object)
    instance = __Http_DialRouter_builder()
    instance.new(server)
    return instance
end function