'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/utils/RegistryUtils.bs"

function __Http_RegistryRouter_method_new()
    m.super0_new()
    m.routes.push({ method: "POST", path: "/api/registry/export/code", router: m, func: "ShowExportRegistryCode" })
    m.routes.push({ method: "POST", path: "/api/registry/export", router: m, func: "ExportRegistry" })
end function
function __Http_RegistryRouter_method_ShowExportRegistryCode(context as object) as boolean
    response = context.response
    
    dialog = DialogUtils_ShowOnScreenCodeDialog("ExportRegistry", "Export registry")
    if dialog = invalid
        response.Default(429, "Too Many Requests")
        return true
    end if
    response.Default(204, "OK")
    return true
end function
function __Http_RegistryRouter_method_ExportRegistry(context as object) as boolean
    request = context.request
    response = context.response
    if not DialogUtils_ConsumeOnScreenCode("ExportRegistry", request.query.code)
        response.Default(400, "Invalid code")
        return true
    end if
    registryValues = RegistryUtils_ReadAll()
    registryValues["__version"] = 1
    response.Json(registryValues)
    response.headers["Content-Disposition"] = "attachment; filename=playlet-registry.json"
    return true
end function
function __Http_RegistryRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_RegistryRouter_method_new
    instance.ShowExportRegistryCode = __Http_RegistryRouter_method_ShowExportRegistryCode
    instance.ExportRegistry = __Http_RegistryRouter_method_ExportRegistry
    return instance
end function
function Http_RegistryRouter()
    instance = __Http_RegistryRouter_builder()
    instance.new()
    return instance
end function