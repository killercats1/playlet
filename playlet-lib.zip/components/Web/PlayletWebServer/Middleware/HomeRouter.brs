'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
function __Http_HomeRouter_method_new()
    m.super0_new()
    m.routes.push({ method: "GET", path: "/", router: m, func: "GoHome" })
end function
function __Http_HomeRouter_method_GoHome(context as object) as boolean
    response = context.response
    response.Redirect("/index.html")
    return true
end function
function __Http_HomeRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_HomeRouter_method_new
    instance.GoHome = __Http_HomeRouter_method_GoHome
    return instance
end function
function Http_HomeRouter()
    instance = __Http_HomeRouter_builder()
    instance.new()
    return instance
end function