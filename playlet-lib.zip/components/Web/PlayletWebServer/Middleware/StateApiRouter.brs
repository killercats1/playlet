'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/utils/Types.bs"
function __Http_StateApiRouter_method_new(server as object)
    m.super0_new()
    m.applicationInfoNode = server.sceneNodes.applicationInfo
    m.invidiousNode = server.sceneNodes.invidious
    m.preferencesNode = server.sceneNodes.preferences
    m.profilesNode = server.sceneNodes.profilesService
    m.routes.push({ method: "GET", path: "/api/state", router: m, func: "GetState" })
end function
function __Http_StateApiRouter_method_GetState(context as object) as boolean
    request = context.request
    response = context.response
    keys = [
        "app"
        "device"
        "invidious"
        "preferences"
        "profiles"
    ]
    if request.query.DoesExist("key")
        keys = request.query["key"]
        if not IsArray(keys)
            keys = [
                keys
            ]
        end if
    end if
    keysDict = {}
    for each key in keys
        keysDict[key] = true
    end for
    state = {}
    if keysDict["app"] = true
        appInfo = m.applicationInfoNode.callfunc("GetAppInfo", invalid)
        state["app"] = appInfo
    end if
    if keysDict["device"] = true
        state["device"] = m.applicationInfoNode.callfunc("GetDeviceInfo", invalid)
    end if
    if keysDict["invidious"] = true
        state["invidious"] = {
            instance: m.invidiousNode.callfunc("GetInstance", invalid)
            invidious_instance: m.invidiousNode.callfunc("GetInvidiousInstance", invalid)
        }
    end if
    if keysDict["preferences"] = true
        state["preferences"] = m.preferencesNode.callfunc("GetUserPreferences", invalid)
    end if
    if keysDict["profiles"] = true
        state["profiles"] = m.profilesNode.callfunc("GetProfilesDto", false)
    end if
    response.Json(state)
    return true
end function
function __Http_StateApiRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_StateApiRouter_method_new
    instance.GetState = __Http_StateApiRouter_method_GetState
    return instance
end function
function Http_StateApiRouter(server as object)
    instance = __Http_StateApiRouter_builder()
    instance.new(server)
    return instance
end function