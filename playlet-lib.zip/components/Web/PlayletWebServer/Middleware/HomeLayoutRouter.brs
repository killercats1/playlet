'import "pkg:/components/Screens/HomeScreen/HomeScreenUtils.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
function __Http_HomeLayoutRouter_method_new(server as object)
    m.super0_new()
    m.preferencesNode = server.sceneNodes.preferences
    m.routes.push({ method: "GET", path: "/api/home-layout", router: m, func: "GetHomeLayout" })
end function
function __Http_HomeLayoutRouter_method_GetHomeLayout(context as object) as boolean
    response = context.response
    feed = HomeScreenUtils_GetFeed("libpkg:/config/default_home_layout.yaml", m.preferencesNode)
    response.Json(feed)
    return true
end function
function __Http_HomeLayoutRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_HomeLayoutRouter_method_new
    instance.GetHomeLayout = __Http_HomeLayoutRouter_method_GetHomeLayout
    return instance
end function
function Http_HomeLayoutRouter(server as object)
    instance = __Http_HomeLayoutRouter_builder()
    instance.new(server)
    return instance
end function