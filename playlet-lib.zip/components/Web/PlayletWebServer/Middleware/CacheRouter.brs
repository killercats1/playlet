'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/utils/CacheUtils.bs"
function __Http_CacheRouter_method_new(server as object)
    m.super0_new()
    m.jobQueue = server.sceneNodes.jobQueue
    m.routes.push({ method: "DELETE", path: "/api/cache", router: m, func: "ClearCache" })
end function
function __Http_CacheRouter_method_ClearCache(context as object) as boolean
    response = context.response
    CacheUtils_Clear(m.jobQueue)
    response.Default(204, "OK")
    return true
end function
function __Http_CacheRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_CacheRouter_method_new
    instance.ClearCache = __Http_CacheRouter_method_ClearCache
    return instance
end function
function Http_CacheRouter(server as object)
    instance = __Http_CacheRouter_builder()
    instance.new(server)
    return instance
end function