'import "pkg:/components/Web/PlayletWebServer/Middleware/BookmarksRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/CacheRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/DashRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/DialRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/HlsRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/HomeLayoutRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/HomeRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/InnertubeRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/InvidiousRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/PlayletInvidiousBackendRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/PreferencesRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/ProfilesRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/RegistryRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/SearchHistoryRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/StateApiRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/VideoQueueRouter.bs"
'import "pkg:/components/Web/PlayletWebServer/Middleware/ViewRouter.bs"
'import "pkg:/components/Web/WebServer/Middleware/CorsMiddleware.bs"
'import "pkg:/components/Web/WebServer/Middleware/CsrfMiddleware.bs"
'import "pkg:/components/Web/WebServer/Middleware/EtagMiddleware.bs"
'import "pkg:/components/Web/WebServer/Middleware/HttpStaticFilesRouter.bs"
'import "pkg:/components/Web/WebServer/WebSockets/WebSocketMiddleware.bs"

function Init()
    InitializeBindings() ' auto-generated!
end function

function OnNodeReady()
    m.sceneNodes = {
        "appController": m.top.appController
        "preferences": m.top.preferences
        "innertube": m.top.innertube
        "invidious": m.top.invidious
        "profilesService": m.top.profilesService
        "applicationInfo": m.top.applicationInfo
        "videoQueue": m.top.videoQueue
        "bookmarksService": m.top.bookmarksService
        "loungeService": m.top.loungeService
        "jobQueue": m.top.jobQueue
    }
end function

function GetServerAddress(_unused as dynamic) as dynamic
    port = m.top.port
    ip = m.top.applicationInfo.callfunc("GetLocalIpAddress", invalid)
    if StringUtils_IsNullOrEmpty(ip)
        return invalid
    end if
    return ("http://" + bslib_toString(ip) + ":" + bslib_toString(port))
end function

function SetupRoutes(server as object)
    server.sceneNodes = m.sceneNodes
    
    server.UseRouter(Http_CorsMiddleware(""))
    server.UseRouter(Http_CsrfMiddleware("X-Playlet", [
        ' Phones and smart speakers can't send the header.
        "/dial/"
        ' The player's license requests change nothing on the device, and a page can't read the license.
        "/api/innertube/get_drm_license"
        ' Every write needs the caller's bearer token.
        "/playlet-invidious-backend/"
    ]))
    if server.settings.WebSocketsEnabled
        server.UseRouter(Http_WebSocketMiddleware())
    end if
    server.UseRouter(Http_HomeRouter())
    server.UseRouter(Http_StateApiRouter(server))
    server.UseRouter(Http_DashRouter(server))
    server.UseRouter(Http_HlsRouter(server))
    server.UseRouter(Http_PreferencesRouter(server))
    server.UseRouter(Http_InvidiousRouter(server))
    server.UseRouter(Http_ProfilesRouter(server))
    server.UseRouter(Http_VideoQueueRouter(server))
    server.UseRouter(Http_BookmarksRouter(server))
    server.UseRouter(Http_HomeLayoutRouter(server))
    server.UseRouter(Http_ViewRouter(server))
    server.UseRouter(Http_SearchHistoryRouter(server))
    server.UseRouter(Http_DialRouter(server))
    server.UseRouter(Http_CacheRouter(server))
    server.UseRouter(Http_RegistryRouter())
    server.UseRouter(Http_PlayletInvidiousBackendRouter(server))
    server.UseRouter(Http_InnertubeRouter(server))
    etags = Http_EtagUtils()
    server.UseRouter(Http_HttpStaticFilesRouter("/", "libpkg:/www", etags, {
        staticFiles: true
        staticCompressed: true
    }))
    server.UseRouter(Http_HttpStaticFilesRouter("/config", "libpkg:/config", etags, {
        staticFiles: true
    }))
    server.UseRouter(Http_HttpStaticFilesRouter("/locale", "libpkg:/locale", etags, {
        staticFiles: true
    }))
    server.UseRouter(Http_HttpStaticFilesRouter("/logs", "cachefs:/logs", etags, {
        fsCheck: true
    }))
    server.UsePostRouter(Http_EtagMiddleware(etags))
end function