'import "pkg:/components/JobSystem/JobRequest.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/StringUtils.bs"
' wait() sometimes isn't woken by a new message (seen on device); the next wait() returns it


function Init()
    m.top.functionName = "JobTaskLoop"
    m.port = CreateObject("roMessagePort")
    m.top.observeField("shutdown", m.port)
    m.top.observeField("request", m.port)
end function

function JobTaskLoop() as void
    port = m.port
    while true
        msg = wait(1000, port)
        msgType = type(msg)
        if msgType = "roSGNodeEvent"
            field = msg.GetField()
            if field = "shutdown" and msg.getData()
                m.top.request = invalid
                return
            end if
            if field = "request"
                request = msg.getData()
                JobRequest_Execute(request)
                m.top.ready = true
            end if
        end if
    end while
end function