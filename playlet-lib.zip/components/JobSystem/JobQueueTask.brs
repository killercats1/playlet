'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/MessagePortUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
' Maximum number of JobTasks that can be created
' https://developer.roku.com/en-ca/docs/developer-program/core-concepts/threads.md
' "Developers should take steps to ensure that their apps always remain well under the 50-thread "warning" limit."
' Accounting for other types of long running Tasks in the app, this limit should be way lower than 50.

' Minimum number of JobTasks that will be kept alive

' Time in milliseconds without a message before scaling down JobTasks

' wait() sometimes isn't woken by a new message (seen on device); the next wait() returns it

' Missed requests cluster right after start (measured): check the port more often then



function Init()
    m.top.functionName = "JobQueueTaskLoop"
    m.port = CreateObject("roMessagePort")
    m.top.observeField("shutdown", m.port)
    m.top.observeField("request", m.port)
end function

function JobQueueTaskLoop() as void
    port = m.port
    m.busyJobTasks = {}
    m.idleJobTasks = []
    requests = []
    startup = CreateObject("roTimespan")
    scaleDownTimer = CreateObject("roTimespan")
    while true
        while requests.Count() > 0 and m.idleJobTasks.Count() > 0
            ScheduleRequest(requests.Shift(), m.idleJobTasks.Pop())
        end while
        if requests.Count() > 0 and m.idleJobTasks.Count() + m.busyJobTasks.Count() < 30
            StartJobTask(requests.Shift(), port)
        end if
        waitMs = 1000
        if startup.TotalMilliseconds() < 2000
            waitMs = 100
        end if
        message = wait(waitMs, port)
        if message = invalid
            if m.idleJobTasks.Count() > 2 and scaleDownTimer.TotalMilliseconds() >= 10000
                jobTaskObject = m.idleJobTasks.Pop()
                jobTaskObject.node.UnobserveFieldScoped("ready")
                jobTaskObject.node.shutdown = true
                
                scaleDownTimer.Mark()
            end if
            continue while
        end if
        scaleDownTimer.Mark()
        messageType = Type(message)
        if messageType = "roSGNodeEvent"
            field = message.GetField()
            if field = "request"
                request = message.GetData()
                requests.Push(request)
            else if field = "ready" and message.GetData()
                jobTaskId = message.GetNode()
                jobTaskObject = m.busyJobTasks[jobTaskId]
                m.busyJobTasks.Delete(jobTaskId)
                m.idleJobTasks.Push(jobTaskObject)
            else if field = "shutdown" and message.GetData()
                Shutdown()
                return
            end if
        end if
    end while
end function

function StartJobTask(request as object, port as object) as void
    
    jobTask = CreateObject("roSGNode", "JobTask")
    jobTaskId = "JobTask-" + StringUtils_RandomId()
    jobTask.id = jobTaskId
    jobTaskObject = {
        id: jobTaskId
        node: jobTask
    }
    MessagePortUtils_ObserveFieldScopedExSafe(jobTask, "ready", port)
    
    ScheduleRequest(request, jobTaskObject)
    jobTask.control = "run"
end function

function ScheduleRequest(request as dynamic, jobTaskObject as dynamic)
    m.busyJobTasks[jobTaskObject.id] = jobTaskObject
    jobTaskObject.node.request = request
end function

function Shutdown()
    m.top.UnobserveField("request")
    m.top.UnobserveField("shutdown")
    m.top.request = invalid
    for each jobTaskId in m.busyJobTasks
        jobTask = m.busyJobTasks[jobTaskId]
        jobTask.node.UnobserveFieldScoped("ready")
        jobTask.node.shutdown = true
    end for
    for each jobTask in m.idleJobTasks
        jobTask.node.UnobserveFieldScoped("ready")
        jobTask.node.shutdown = true
    end for
    m.busyJobTasks = invalid
    m.idleJobTasks = invalid
end function