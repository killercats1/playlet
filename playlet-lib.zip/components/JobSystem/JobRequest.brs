'import "pkg:/source/utils/AssertUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
function JobRequest_Execute(request as object) as void
    job = CreateObject("roSGNode", request.jobName)
    if job = invalid
        error = "Failed to create job node: " + request.jobName
        LogError2("[JobRequest.bs:13]", error)
        
        if request.input <> invalid and request.input._callback <> invalid
            request.input._callback.error = error
            request.input._callback.success = false
            request.input._callback.done = true
        end if
        return
    end if
    job.id = request.jobName + "-" + StringUtils_RandomId()
    if request.input <> invalid
        job.input = request.input
    end if
    job.callfunc("Execute", invalid)
    job.input = invalid
end function