'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
function JobSystem_CreateCallback(func = invalid as dynamic) as object
    node = CreateObject("roSGNode", "JobCallback")
    node.id = "JobCallback-" + StringUtils_RandomId()
    if IsFunction(func)
        node.observeFieldScoped("done", FuncName(func), [
            "success"
            "cancel"
            "error"
            "data"
        ])
    end if
    return node
end function

function JobSystem_UnobserveCallback(callbackNode as object) as void
    if callbackNode <> invalid
        callbackNode.UnobserveFieldScoped("done")
    end if
end function

function JobSystem_QueueJob(jobQueue as object, jobName as string, input = invalid as dynamic, callbackNode = invalid as dynamic) as void
    if callbackNode <> invalid
        if input = invalid
            input = {}
        end if
        input._callback = callbackNode
    end if
    jobQueue.request = {
        "jobName": jobName
        "input": input
    }
end function