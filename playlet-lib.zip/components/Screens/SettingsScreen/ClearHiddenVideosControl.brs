'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/Services/FeedFilters/FeedFilters.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"

' Settings button: forget the videos and channels marked Not interested / Don't recommend on this TV.
function Init()
    m.top.focusable = true
    m.top.itemSpacings = [
        8
    ]
    m.button = m.top.findNode("Button")
    m.button.observeField("buttonSelected", FuncName(OnButtonSelected))
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.button, true)
end function

function BindPreference(_preferences as object, _key as string)
    
end function

function OnButtonSelected()
    FeedFilters_Clear()
    DialogUtils_ShowDialogEx({
        message: Tr("Not interested list cleared.")
        title: Tr("Success")
    })
end function