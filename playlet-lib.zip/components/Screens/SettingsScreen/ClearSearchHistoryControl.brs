'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/Services/SearchHistory/SearchHistoryUtils.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"

function Init()
    m.top.focusable = true
    m.top.itemSpacings = [
        8
    ]
    m.button = m.top.findNode("Button")
    m.button.observeField("buttonSelected", FuncName(OnButtonSelected))
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.button, true)
end function

function BindPreference(_preferences as object, _key as string)
    
end function

function OnButtonSelected()
    SearchHistoryUtils_Clear()
    DialogUtils_ShowDialogEx({
        message: Tr("Search history cleared.")
        title: Tr("Success")
    })
end function