'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/parts/AutoBind/OnNodeReadyNoOp.bs"
'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.textEditBox = m.top.findNode("textEditBox")
    m.editButton = m.top.findNode("editButton")
    m.testButton = m.top.findNode("testButton")
    m.saveButton = m.top.findNode("saveButton")
    m.publicInstances = m.top.findNode("instances")
    m.editButton.observeField("buttonSelected", FuncName(OnEditButtonSelected))
    m.saveButton.observeField("buttonSelected", FuncName(OnSaveButtonSelected))
    m.testButton.observeField("buttonSelected", FuncName(OnTestButtonSelected))
    m.publicInstances.observeField("instance", FuncName(OnPublicInstanceSelected))
    SetNavigation(m.editButton, "down", m.publicInstances)
    SetNavigation(m.editButton, "down", m.testButton)
    SetNavigation(m.publicInstances, "up", m.editButton)
    SetNavigation(m.publicInstances, "down", m.testButton)
    SetNavigation(m.testButton, "up", m.publicInstances)
    SetNavigation(m.testButton, "up", m.editButton)
    SetNavigation(m.saveButton, "up", m.publicInstances)
    SetNavigation(m.saveButton, "up", m.editButton)
    SetNavigation(m.saveButton, "left", m.testButton)
    SetNavigation(m.testButton, "right", m.saveButton)
    m.currentNavigtionNode = m.editButton
    m.textEditBox.hintText = ("e.g. " + bslib_toString("https://invidious.example.com"))
    SetButtonPositions()
    SetPublicInstancesPosition()
    m.publicInstances.observeField("width", FuncName(SetPublicInstancesPosition))
end function

function SetButtonPositions()
    testButtonWidth = m.testButton.width
    saveButtonWidth = m.saveButton.width
    buttonsWith = testButtonWidth + saveButtonWidth + 20
    m.testButton.translation = [
        960 / 2 - buttonsWith / 2
        m.testButton.translation[1]
    ]
    m.saveButton.translation = [
        960 / 2 + buttonsWith / 2 - saveButtonWidth
        m.saveButton.translation[1]
    ]
end function

function SetPublicInstancesPosition() as void
    width = m.publicInstances.width
    if width = 0
        return
    end if
    m.publicInstances.translation = [
        960 / 2 - width / 2
        m.publicInstances.translation[1]
    ]
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.currentNavigtionNode, true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    navigation = NavigationKeyHandler(key, press)
    if navigation.handled
        m.currentNavigtionNode = navigation.node
        return true
    end if
    if key = "options" or key = "play" or key = "pause" or key = "playonly"
        
        return false
    end if
    if key = "back" and press
        Close()
        return true
    end if
    return true
end function

function OnPublicInstanceSelected()
    m.top.text = m.publicInstances.instance
    m.currentNavigtionNode = m.testButton
    NodeSetFocus(m.testButton, true)
end function

function OnTestButtonSelected()
    testing = CreateObject("roSGNode", "InvidiousInstanceTesting")
    m.appController.callfunc("PushScreen", testing)
    testing.callfunc("BindNode", invalid)
    testing.instance = m.top.text
    testing.run = true
end function

function OnEditButtonSelected()
    keyboardDialog = createObject("roSGNode", "StandardKeyboardDialog")
    
    keyboardDialog.title = "Edit Instance"
    
    keyboardDialog.message = [
        ("Enter the instance url (e.g. " + bslib_toString("https://invidious.example.com") + ")")
    ]
    keyboardDialog.text = m.top.text
    keyboardDialog.buttons = [
        Tr("OK")
        Tr("Cancel")
    ]
    keyboardDialog.observeField("buttonSelected", FuncName(OnKeyboardButton))
    m.top.getScene().dialog = keyboardDialog
end function

function OnKeyboardButton(event as object)
    keyboard = event.getRoSGNode()
    buttonSelected = keyboard.buttonSelected
    if buttonSelected = 0
        m.top.text = keyboard.text
        m.currentNavigtionNode = m.testButton
        NodeSetFocus(m.testButton, true)
    end if
    keyboard.close = true
end function

function OnSaveButtonSelected()
    m.top.save = true
    Close()
end function

function Close()
    m.appController.callfunc("PopScreen", invalid)
end function