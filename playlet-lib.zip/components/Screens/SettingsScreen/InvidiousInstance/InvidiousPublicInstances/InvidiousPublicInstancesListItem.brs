function OnContentSet() as void
    content = m.top.itemContent
    if content = invalid
        return
    end if
    m.top.name = content.name
    m.top.version = content.version
    m.top.users = content.users
    m.top.signup = content.signup
    m.top.location = content.location
    m.top.flag = content.flag
    m.top.health = content.health
    fieldWidths = content.fieldWidths
    labels = {
        "name": "nameLabelWidth"
        "version": "versionLabelWidth"
        "users": "usersLabelWidth"
        "signup": "signupLabelWidth"
        "location": "locationLabelWidth"
        "health": "healthLabelWidth"
    }
    for each label in labels
        m.top[labels[label]] = fieldWidths[label]
    end for
end function