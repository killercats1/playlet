'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/parts/AutoBind/OnNodeReadyNoOp.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.titleLabel = m.top.findNode("titleLabel")
    m.closeButton = m.top.findNode("closeButton")
    m.testList = m.top.findNode("testList")
    m.closeButton.observeField("buttonSelected", FuncName(Close))
    m.testList.observeField("itemSelected", FuncName(ShowTestDetails))
    SetNavigation(m.closeButton, "up", m.testList)
    SetNavigation(m.testList, "down", m.closeButton)
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.closeButton, true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if NavigationKeyHandler(key, press).handled
        return true
    end if
    if key = "options" or key = "play" or key = "pause" or key = "playonly"
        
        return false
    end if
    if key = "back" and press
        Close()
        return true
    end if
    return true
end function

function Close()
    if m.invidiousInstanceTestingJob <> invalid
        m.invidiousInstanceTestingJob.cancel = true
        m.invidiousInstanceTestingJob = invalid
    end if
    m.appController.callfunc("PopScreen", invalid)
end function

function RunTestsJob()
    instance = m.top.instance
    m.titleLabel.text = Tr("Testing %1").Replace("%1", instance)
    if m.invidiousInstanceTestingJob <> invalid
        m.invidiousInstanceTestingJob.cancel = true
    end if
    input = {
        instance: instance
        listNode: m.testList
    }
    m.invidiousInstanceTestingJob = JobSystem_CreateCallback()
    JobSystem_QueueJob(m.jobQueue, "InvidiousInstanceTestingJob", input, m.invidiousInstanceTestingJob)
end function

function ShowTestDetails() as void
    selected = m.testList.itemSelected
    itemContent = m.testList.content.GetChild(selected)
    details = itemContent.details
    if StringUtils_IsNullOrEmpty(details)
        return
    end if
    state = itemContent.state
    displayStates = {
        "passed": Tr("Passed")
        "failed": Tr("Failed")
    }
    message = Tr("Status") + ": " + Tr(ValidString(displayStates[state])) + (chr(10))
    message += Tr("Test duration") + ": " + (bslib_toString(itemContent.duration) + "ms" + chr(10))
    message += Tr("Details") + ": " + details
    DialogUtils_ShowDialogEx({
        message: message
        title: Tr("Test") + ": " + itemContent.title
    })
end function