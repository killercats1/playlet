' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "appController": "/AppController", 
            "jobQueue": "/JobQueue"
        },
        childProps: {
    
        }
    }
end function