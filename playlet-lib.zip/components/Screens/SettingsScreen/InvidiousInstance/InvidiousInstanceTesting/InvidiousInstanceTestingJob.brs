'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/ErrorUtils.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/StringUtils.bs"

function ExecuteJob() as void
    input = JobGetInput()
    instance = input.instance
    listNode = input.listNode
    if JobIsCancelled()
        JobCancel()
        return
    end if
    content = PrepareTests()
    listNode.content = content
    cancellation = JobGetCancellation()
    RunTests(instance, content, cancellation)
end function

function PrepareTests() as object
    content = CreateObject("roSGNode", "ContentNode")
    content.AppendChild(CreateTestNode(Tr("Valid URL"), IsValidUrl))
    content.AppendChild(CreateTestNode(Tr("Instance reachable"), IsReachable))
    content.AppendChild(CreateTestNode(Tr("Fetch video details"), CanFetchVideoDetails))
    content.AppendChild(CreateTestNode(Tr("Fetch video comments"), CanFetchVideoComments))
    content.AppendChild(CreateTestNode(Tr("Fetch video captions"), CanFetchVideoCaptions))
    content.AppendChild(CreateTestNode(Tr("Fetch video thumbnails"), CanFetchVideoThumbails))
    content.AppendChild(CreateTestNode(Tr("Fetch with CORS"), CanFetchWithCors))
    return content
end function

function CreateTestNode(title as string, func as Function) as object
    testNode = CreateObject("roSGNode", "ContentNode")
    testNode.title = title
    testNode.AddFields({
        func: FuncName(func)
        state: "loading"
        details: ""
        duration: 0
    })
    m[testNode.func] = func
    return testNode
end function

function RunTests(instance as string, content as object, cancellation as object) as void
    testNodes = content.getChildren(-1, 0)
    timer = CreateObject("roTimespan")
    for each testNode in testNodes
        timer.Mark()
        m[testNode.func](instance, testNode, cancellation)
        testNode.duration = timer.TotalMilliseconds()
        testNode.title = (bslib_toString(testNode.title) + " (" + bslib_toString(testNode.duration) + "ms)")
        if testNode.state = "failed"
            LogErrorNoTelemetry2("[InvidiousInstanceTestingJob.bs:64]", testNode.details)
        end if
        if CancellationUtils_IsCancelled(cancellation)
            JobCancel()
            return
        end if
    end for
end function

function IsValidUrl(instance as string, testNode as object, _cancellation as object) as void
    try
        if not instance.StartsWith("http://") and not instance.StartsWith("https://")
            testNode.state = "failed"
            testNode.details = Tr("Url must start with http:// or https://")
            return
        end if
        if instance.EndsWith("/")
            testNode.state = "failed"
            testNode.details = Tr("Url must not end with /")
            return
        end if
        testNode.state = "passed"
        testNode.details = Tr("The url seems to be of a valid format")
    catch e
        testNode.state = "failed"
        testNode.details = ErrorUtils_Format(e)
    end try
end function

function IsReachable(instance as string, testNode as object, cancellation as object) as void
    try
        url = (bslib_toString(instance) + bslib_toString("/api/v1/stats"))
        response = HttpClient_Get(url).NoCache().Cancellation(cancellation).Await()
        if not response.IsSuccess()
            testNode.state = "failed"
            testNode.details = response.ErrorMessage()
            return
        end if
        json = response.Json()
        if json = invalid
            testNode.state = "failed"
            testNode.details = Tr("Invalid JSON from %1").Replace("%1", url)
            return
        end if
        software = json.software
        if software = invalid
            testNode.state = "failed"
            testNode.details = Tr("Invalid JSON from %1 (couldn't read %2)").Replace("%1", url).Replace("%2", "$.software")
            return
        end if
        name = software.name
        if not IsString(name)
            testNode.state = "failed"
            testNode.details = Tr("Invalid JSON from %1 (couldn't read %2)").Replace("%1", url).Replace("%2", "$.software.name")
            return
        end if
        version = software.version
        if not IsString(version)
            testNode.state = "failed"
            testNode.details = Tr("Invalid JSON from %1 (couldn't read %2)").Replace("%1", url).Replace("%2", "$.software.version")
            return
        end if
        testNode.state = "passed"
        testNode.details = Tr("The instance is reachable and running %1 version %2").Replace("%1", name).Replace("%2", version)
    catch e
        testNode.state = "failed"
        testNode.details = ErrorUtils_Format(e)
    end try
end function

function CanFetchVideoDetails(instance as string, testNode as object, cancellation as object) as void
    try
        
        videoId = "k85mRPqvMbE"
        url = (bslib_toString(instance) + bslib_toString("/api/v1/videos") + "/" + bslib_toString(videoId))
        response = HttpClient_Get(url).NoCache().Cancellation(cancellation).Await()
        if not response.IsSuccess()
            testNode.state = "failed"
            testNode.details = response.ErrorMessage()
            return
        end if
        json = response.Json()
        if json = invalid
            testNode.state = "failed"
            testNode.details = Tr("Invalid JSON from %1").Replace("%1", url)
            return
        end if
        title = json.title
        if not IsString(title)
            testNode.state = "failed"
            testNode.details = Tr("Invalid JSON from %1 (couldn't read %2)").Replace("%1", url).Replace("%2", "$.title")
            return
        end if
        testNode.state = "passed"
        testNode.details = Tr("The instance can fetch video details for ID %1 (%2)").Replace("%1", videoId).Replace("%2", title)
    catch e
        testNode.state = "failed"
        testNode.details = ErrorUtils_Format(e)
    end try
end function

function CanFetchVideoComments(instance as string, testNode as object, cancellation as object) as void
    try
        
        videoId = "k85mRPqvMbE"
        url = (bslib_toString(instance) + "/api/v1/comments/" + bslib_toString(videoId))
        response = HttpClient_Get(url).NoCache().Cancellation(cancellation).Await()
        if not response.IsSuccess()
            testNode.state = "failed"
            testNode.details = response.ErrorMessage()
            return
        end if
        json = response.Json()
        if json = invalid
            testNode.state = "failed"
            testNode.details = Tr("Invalid JSON from %1").Replace("%1", url)
            return
        end if
        commentCount = json.commentCount
        if not IsInt(commentCount)
            testNode.state = "failed"
            testNode.details = Tr("Invalid JSON from %1 (couldn't read %2)").Replace("%1", url).Replace("%2", "$.commentCount")
            return
        end if
        comments = json.comments
        if not IsArray(comments)
            testNode.state = "failed"
            testNode.details = Tr("Invalid JSON from %1 (couldn't read %2)").Replace("%1", url).Replace("%2", "$.comments")
            return
        end if
        testNode.state = "passed"
        testNode.details = Tr("The instance can fetch video comments for ID %1 (%2 comments)").Replace("%1", videoId).Replace("%2", (bslib_toString(commentCount)))
    catch e
        testNode.state = "failed"
        testNode.details = ErrorUtils_Format(e)
    end try
end function

function CanFetchVideoCaptions(instance as string, testNode as object, cancellation as object) as void
    try
        
        videoId = "k85mRPqvMbE"
        label = "English"
        
        expectedText = "Ding ding pch n daa, bam-ba-ba-re-bam"
        url = (bslib_toString(instance) + "/api/v1/captions/" + bslib_toString(videoId) + "?label=" + bslib_toString(label))
        response = HttpClient_Get(url).NoCache().Cancellation(cancellation).Await()
        if not response.IsSuccess()
            testNode.state = "failed"
            testNode.details = response.ErrorMessage()
            return
        end if
        headers = response.Headers()
        contentType = headers["Content-Type"]
        if StringUtils_IsNullOrEmpty(contentType) or not contentType.StartsWith("text/vtt")
            testNode.state = "failed"
            testNode.details = Tr("Invalid caption data from %1 (Content-Type is not text/vtt)").Replace("%1", url)
            return
        end if
        text = response.Text()
        if StringUtils_IsNullOrEmpty(text) or not text.StartsWith("WEBVTT")
            testNode.state = "failed"
            testNode.details = Tr("Invalid caption data from %1 (response is not a valid vtt file)").Replace("%1", url)
            return
        end if
        if text.InStr(expectedText) = -1
            testNode.state = "failed"
            testNode.details = Tr("Did not find expected text in caption data from %1").Replace("%1", url)
            return
        end if
        testNode.state = "passed"
        testNode.details = Tr("The instance can fetch video %1 captions for ID %2").Replace("%1", label).Replace("%2", videoId)
    catch e
        testNode.state = "failed"
        testNode.details = ErrorUtils_Format(e)
    end try
end function

function CanFetchVideoThumbails(instance as string, testNode as object, cancellation as object) as void
    try
        
        videoId = "k85mRPqvMbE"
        url = (bslib_toString(instance) + bslib_toString("/api/v1/videos") + "/" + bslib_toString(videoId))
        response = HttpClient_Get(url).NoCache().Cancellation(cancellation).Await()
        if not response.IsSuccess()
            testNode.state = "failed"
            testNode.details = response.ErrorMessage()
            return
        end if
        json = response.Json()
        if json = invalid
            testNode.state = "failed"
            testNode.details = Tr("Invalid JSON from %1").Replace("%1", url)
            return
        end if
        videoThumbnails = json.videoThumbnails
        if not IsArray(videoThumbnails) or videoThumbnails.Count() = 0
            testNode.state = "failed"
            testNode.details = Tr("No thumbnails found in JSON from %1").Replace("%1", url)
            return
        end if
        contentNode = InvidiousContent_ToVideoContentNode(invalid, json, instance)
        thumbnail = contentNode.thumbnail
        if StringUtils_IsNullOrEmpty(thumbnail)
            testNode.state = "failed"
            testNode.details = Tr("No thumbnails found in JSON from %1").Replace("%1", url)
            return
        end if
        
        response = HttpClient_Get(thumbnail).NoCache().Cancellation(cancellation).Await()
        if not response.IsSuccess()
            testNode.state = "failed"
            testNode.details = Tr("%1 is not reachable").Replace("%1", thumbnail) + (chr(10)) + response.ErrorMessage()
            return
        end if
        contentType = response.Headers()["Content-Type"]
        if StringUtils_IsNullOrEmpty(contentType) or not contentType.StartsWith("image/")
            testNode.state = "failed"
            testNode.details = Tr("Invalid thumbnail data %1 (Content-Type is not image/*)").Replace("%1", thumbnail)
            return
        end if
        testNode.state = "passed"
        testNode.details = Tr("The instance can fetch video thumbnail for ID %1 (%2)").Replace("%1", videoId).Replace("%2", thumbnail)
    catch e
        testNode.state = "failed"
        testNode.details = ErrorUtils_Format(e)
    end try
end function

function CanFetchWithCors(instance as string, testNode as object, cancellation as object) as void
    try
        url = (bslib_toString(instance) + "/api/v1/popular")
        response = HttpClient_Get(url).NoCache().Cancellation(cancellation).Await()
        if not response.IsSuccess()
            testNode.state = "failed"
            testNode.details = response.ErrorMessage()
            return
        end if
        json = response.Json()
        if json = invalid
            testNode.state = "failed"
            testNode.details = Tr("Invalid JSON from %1").Replace("%1", url)
            return
        end if
        headers = response.Headers()
        corsHeader = headers["Access-Control-Allow-Origin"]
        if not IsString(corsHeader) or corsHeader <> "*"
            testNode.state = "failed"
            testNode.details = Tr("CORS header not set correctly from %1").Replace("%1", url)
            return
        end if
        testNode.state = "passed"
        testNode.details = Tr("The instance can fetch with CORS from %1").Replace("%1", url)
    catch e
        testNode.state = "failed"
        testNode.details = ErrorUtils_Format(e)
    end try
end function