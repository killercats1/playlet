'import "pkg:/components/parts/AutoBind/OnNodeReadyNoOp.bs"
'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.top.focusable = true
    m.top.itemSpacings = [
        8
    ]
    m.button = m.top.findNode("button")
    m.button.text = Tr("Playlet built-in backend")
    AdjustButtonLabel(m.button)
    m.button.observeField("buttonSelected", FuncName(OpenInvidiousInstanceSettings))
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.button, true)
end function

function AdjustButtonLabel(button as object) as void
    children = button.getChildren(-1, 0)
    for each child in children
        if child.isSubtype("Label") and child.hasField("horizAlign")
            child.observeField("horizAlign", FuncName(OnButtonLabelHorizAlignChanged))
            child.horizAlign = "left"
            return
        end if
    end for
end function

function OnButtonLabelHorizAlignChanged(event as object)
    label = event.getRoSGNode()
    if label.horizAlign <> "left"
        label.horizAlign = "left"
    end if
end function

function BindPreference(preferences as object, key as string)
    if m.preferences <> invalid and m.key <> invalid
        m.preferences.unobserveFieldScoped(m.key)
    end if
    m.preferences = preferences
    m.key = key
    if preferences <> invalid and key <> invalid
        preferences.observeFieldScoped(key, FuncName(OnPreferenceChange))
        OnPreferenceChange()
    end if
end function

function OpenInvidiousInstanceSettings()
    settings = CreateObject("roSGNode", "InvidiousInstanceSettings")
    m.appController.callfunc("PushScreen", settings)
    settings.callfunc("BindNode", invalid)
    settings.text = m.top.value
    settings.observeField("save", FuncName(OnSaveInvidiousInstance))
end function

function OnSaveInvidiousInstance(event as object)
    settings = event.GetRoSGNode()
    m.top.value = settings.text
end function

function OnPreferenceChange()
    m.top.value = m.preferences[m.key]
end function

function OnValueChange() as void
    if m.preferences = invalid or m.key = invalid
        return
    end if
    value = m.top.value
    m.preferences[m.key] = value
    if StringUtils_IsNullOrEmpty(value)
        m.button.text = Tr("Playlet built-in backend")
    else
        m.button.text = value
    end if
end function