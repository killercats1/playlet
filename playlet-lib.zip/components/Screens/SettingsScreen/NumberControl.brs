'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/MathUtils.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    m.top.focusable = true
    m.top.itemSpacings = [
        10
    ]
    m.minusButton = m.top.findNode("MinusButton")
    m.numberButton = m.top.findNode("NumberButton")
    m.plusButton = m.top.findNode("PlusButton")
    m.minusButton.observeFieldScoped("buttonSelected", FuncName(OnMinusSelected))
    m.plusButton.observeFieldScoped("buttonSelected", FuncName(OnPlusSelected))
    SetNavigation(m.minusButton, "right", m.numberButton)
    SetNavigation(m.numberButton, "left", m.minusButton)
    SetNavigation(m.numberButton, "right", m.plusButton)
    SetNavigation(m.plusButton, "left", m.numberButton)
end function

function BindPreference(preferences as object, key as string)
    if m.preferences <> invalid and m.key <> invalid
        m.preferences.unobserveFieldScoped(m.key)
    end if
    m.preferences = preferences
    m.key = key
    if preferences <> invalid and key <> invalid
        preferences.observeFieldScoped(key, FuncName(OnPreferenceChange))
        OnPreferenceChange()
    end if
end function

function OnPreferenceChange()
    m.top.value = MathUtils_Clamp(m.preferences[m.key], m.top.min, m.top.max)
end function

function OnValueChange() as void
    m.numberButton.text = (bslib_toString(m.top.value))
    if m.preferences = invalid or m.key = invalid
        return
    end if
    m.preferences[m.key] = m.top.value
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.numberButton, true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if NavigationKeyHandler(key, press).handled
        return true
    end if
    return false
end function

function OnMinusSelected()
    m.top.value = MathUtils_Max(m.top.value - 1, m.top.min)
end function

function OnPlusSelected()
    m.top.value = MathUtils_Min(m.top.value + 1, m.top.max)
end function