'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/Navigation/ScrollTo.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.top.focusable = true
    m.container = m.top.findNode("Container")
    m.scrollAnimation = m.top.findNode("scrollAnimation")
    m.scrollAnimationInterpolator = m.scrollAnimation.findNode("scrollAnimationInterpolator")
    m.viewport = {
        x: 115
        y: 50
        width: 1920
        height: 620
    }
end function

function OnNodeReady()
    startX = 115
    startY = 100
    controlsX = 435
    categorySpacing = 50
    controlSpacing = 25
    model = m.preferences.prefsModel
    previousCategory = invalid
    previousControl = invalid
    for each item in model
        container = m.container.createChild("Group")
        category = CreateCategoryNode(item, container, startX, startY)
        if m.firstCategory = invalid
            m.firstCategory = category.node
            m.currentNavigtionNode = m.firstCategory
        end if
        if previousCategory <> invalid
            SetNavigation(previousCategory.node, "down", category.node)
            SetNavigation(category.node, "up", previousCategory.node)
        end if
        controls = CreateControls(item, container, startX + controlsX, startY, controlSpacing)
        if controls <> invalid
            if controls.nodes.Count() > 0
                SetNavigation(category.node, "right", controls.nodes[0])
            end if
            for each control in controls.nodes
                SetNavigation(control, "left", category.node)
                if previousControl <> invalid
                    SetNavigation(previousControl, "down", control)
                    SetNavigation(control, "up", previousControl)
                end if
                previousControl = control
            end for
        end if
        categoryRect = category.rect
        controlsRect = controls.rect
        if categoryRect.height > controlsRect.height then
            maxHeight = categoryRect.height
        else
            maxHeight = controlsRect.height
        end if
        startY += maxHeight + categorySpacing
        previousCategory = category
    end for
    SetNavigation(invalid, "back", m.navBar)
    SetNavigation(invalid, "left", m.navBar)
end function

function CreateCategoryNode(item as object, container as object, startX as integer, startY as integer) as object
    node = container.createChild("SettingCategory")
    node.maxWidth = 440
    node.translation = [
        startX
        startY
    ]
    node.displayText = Tr(item.displayText)
    node.description = Tr(item.description)
    return {
        node: node
        rect: node.boundingRect()
    }
end function

function CreateControls(item as object, container as object, startX as integer, startY as integer, controlSpacing as integer) as object
    if item.children = invalid
        return invalid
    end if
    x = startX
    y = startY
    width = 0
    height = 0
    nodes = []
    for each child in item.children
        if child.visibility = "web" or child.visibility = "off"
            continue for
        end if
        control = CreateControl(child, container, startX, startY)
        if control <> invalid
            nodes.push(control.node)
            controlRect = control.rect
            startY += controlRect.height + controlSpacing
            if controlRect.width > width
                width = controlRect.width
            end if
            height += controlRect.height + controlSpacing
        end if
    end for
    return {
        nodes: nodes
        rect: {
            x: x
            y: y
            width: width
            height: height
        }
    }
end function

function CreateControl(item as object, container as object, startX as integer, startY as integer) as object
    control = invalid
    if item.rokuComponent <> invalid
        control = CreateRokuComponent(item, container)
    else if item.type = "boolean"
        control = CreateBooleanControl(item, container)
    else if item.type = "radio"
        control = CreateRadioControl(item, container)
    else if item.type = "string"
        control = CreateStringControl(item, container)
    else if item.type = "number"
        control = CreateNumberComponent(item, container)
    end if
    if control = invalid
        return invalid
    end if
    control.id = ("preference." + bslib_toString(item.key))
    control.translation = [
        startX
        startY
    ]
    if control.hasField("binding_done")
        control.callfunc("BindNode", invalid)
    end if
    control.callfunc("BindPreference", m.preferences, item.key)
    return {
        node: control
        rect: control.boundingRect()
    }
end function

function CreateBooleanControl(item as object, container as object) as object
    node = container.createChild("BooleanControl")
    node.displayText = Tr(item.displayText)
    node.description = Tr(item.description)
    return node
end function

function CreateRadioControl(item as object, container as object) as object
    node = container.createChild("RadioControl")
    node.displayText = Tr(item.displayText)
    node.description = Tr(item.description)
    node.options = item.options
    return node
end function

function CreateStringControl(item as object, container as object) as object
    node = container.createChild("StringControl")
    node.displayText = Tr(item.displayText)
    node.description = Tr(item.description)
    return node
end function

function CreateNumberComponent(item as object, container as object) as object
    node = container.createChild("NumberControl")
    node.displayText = Tr(item.displayText)
    node.description = Tr(item.description)
    if IsInt(item.min)
        node.min = item.min
    end if
    if IsInt(item.max)
        node.max = item.max
    end if
    return node
end function

function CreateRokuComponent(item as object, container as object) as object
    node = container.createChild(item.rokuComponent)
    if node.hasField("displayText")
        node.displayText = Tr(item.displayText)
    end if
    if node.hasField("description")
        node.description = Tr(item.description)
    end if
    return node
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    navigation = NavigationKeyHandler(key, press)
    if navigation.handled
        m.currentNavigtionNode = navigation.node
        if m.currentNavigtionNode.isSameNode(m.navBar)
            m.currentNavigtionNode = m.firstCategory
        end if
        ScrollTo(m.viewport, m.container, m.currentNavigtionNode.getParent(), m.scrollAnimation, m.scrollAnimationInterpolator)
        return true
    end if
    return false
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.currentNavigtionNode, true)
    ScrollTo(m.viewport, m.container, m.currentNavigtionNode.getParent(), m.scrollAnimation, m.scrollAnimationInterpolator)
end function