'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/parts/AutoBind/OnNodeReadyNoOp.bs"
'import "pkg:/source/utils/CodecCapabilities.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/MathUtils.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.checkList = m.top.findNode("checkList")
    m.closeButton = m.top.findNode("closeButton")
    m.saveButton = m.top.findNode("saveButton")
    SetNavigation(m.checkList, "down", m.saveButton)
    SetNavigation(m.saveButton, "up", m.checkList)
    SetNavigation(m.closeButton, "up", m.checkList)
    SetNavigation(m.saveButton, "right", m.closeButton)
    SetNavigation(m.closeButton, "left", m.saveButton)
    m.saveButton.observeField("buttonSelected", FuncName(OnSaveButtonSelected))
    m.closeButton.observeField("buttonSelected", FuncName(Close))
    AddHighQualityOptions()
    m.lastCheckedState = NewCheckedState(false, false)
    m.checkList.observeField("checkedState", FuncName(OnCheckedStateChange))
    SetButtonPositions()
end function

' 1440p/2160p exist on YouTube only as AV1 (mp4) and VP9 (webm) streams, and the
' player only plays fragmented MP4 in DASH, so the options only work with an AV1 decoder.
function AddHighQualityOptions() as void
    if not CodecCapabilities_CanDecodeAv1()
        return
    end if
    content = m.checkList.content
    for each quality in [
        "1440p"
        "2160p"
    ]
        node = CreateObject("roSGNode", "ContentNode")
        node.id = quality
        node.title = quality
        content.insertChild(node, 1)
    end for
end function

function NewCheckedState(autoChecked as boolean, othersChecked as boolean) as object
    checkedState = [
        autoChecked
    ]
    count = m.checkList.content.getChildCount()
    for i = 1 to count - 1
        checkedState.push(othersChecked)
    end for
    return checkedState
end function

function AllQualitiesValue() as string
    values = []
    checkboxes = m.checkList.content.getChildren(-1, 0)
    for i = 1 to checkboxes.Count() - 1
        values.push(checkboxes[i].id)
    end for
    return values.Join(",")
end function

function SetButtonPositions()
    saveButtonWidth = m.saveButton.width
    closeButtonWidth = m.closeButton.width
    buttonsWith = closeButtonWidth + saveButtonWidth + 20
    m.saveButton.translation = [
        780 / 2 - buttonsWith / 2
        m.saveButton.translation[1]
    ]
    m.closeButton.translation = [
        780 / 2 + buttonsWith / 2 - closeButtonWidth
        m.closeButton.translation[1]
    ]
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.checkList, true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if NavigationKeyHandler(key, press).handled
        return true
    end if
    if key = "options" or key = "play" or key = "pause" or key = "playonly"
        
        return false
    end if
    if key = "back" and press
        Close()
        return true
    end if
    return true
end function

function OnValueChange() as void
    content = m.checkList.content
    value = m.top.value
    if content = invalid or content.getChildCount() = 0
        return
    end if
    values = value.Split(",")
    valuesDict = {}
    for each value in values
        valuesDict[value] = true
    end for
    checkboxes = content.getChildren(-1, 0)
    checkedState = []
    for i = 0 to checkboxes.Count() - 1
        checkedState.push(valuesDict.DoesExist(checkboxes[i].id))
    end for
    m.checkList.checkedState = checkedState
end function

function OnCheckedStateChange() as void
    content = m.checkList.content
    if content = invalid or content.getChildCount() = 0
        return
    end if
    checkedState = m.checkList.checkedState
    if checkedState = invalid or checkedState.Count() = 0
        return
    end if
    lastCheckedState = m.lastCheckedState
    m.lastCheckedState = checkedState
    autoChanged = lastCheckedState[0] <> checkedState[0]
    hasAuto = checkedState[0]
    if autoChanged
        if hasAuto
            checkedState = NewCheckedState(true, false)
            m.lastCheckedState = checkedState
            m.checkList.checkedState = checkedState
            m.top.value = "auto"
            return
        else
            checkedState = NewCheckedState(false, true)
            m.lastCheckedState = checkedState
            m.checkList.checkedState = checkedState
            m.top.value = AllQualitiesValue()
            return
        end if
    end if
    values = []
    checkboxes = content.getChildren(-1, 0)
    hasNonAuto = false
    for i = 0 to checkboxes.Count() - 1
        if not checkedState[i]
            continue for
        end if
        values.push(checkboxes[i].id)
        if i <> 0
            hasNonAuto = true
        end if
    end for
    if values.Count() = 0
        checkedState = NewCheckedState(true, false)
        m.lastCheckedState = checkedState
        m.checkList.checkedState = checkedState
        m.top.value = "auto"
        return
    end if
    if hasNonAuto and hasAuto
        checkedState[0] = false
        m.lastCheckedState = checkedState
        m.checkList.checkedState = checkedState
        values.shift()
    end if
    m.top.value = values.Join(",")
end function

function OnSaveButtonSelected()
    OnCheckedStateChange()
    m.top.save = true
    Close()
end function

function Close()
    m.appController.callfunc("PopScreen", invalid)
end function