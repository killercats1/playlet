'import "pkg:/components/parts/AutoBind/OnNodeReadyNoOp.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.top.focusable = true
    m.top.itemSpacings = [
        8
    ]
    m.button = m.top.findNode("button")
    m.button.observeField("buttonSelected", FuncName(OpenQualitySelector))
    AdjustButtonLabel(m.button)
    m.qualityToLabel = {
        "auto": Tr("Auto")
        "1080p": "1080p"
        "720p": "720p"
        "480p": "480p"
        "360p": "360p"
        "240p": "240p"
        "144p": "144p"
    }
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.button, true)
end function

function AdjustButtonLabel(button as object) as void
    children = button.getChildren(-1, 0)
    for each child in children
        if child.isSubtype("Label") and child.hasField("horizAlign")
            child.observeField("horizAlign", FuncName(OnButtonLabelHorizAlignChanged))
            child.horizAlign = "left"
            return
        end if
    end for
end function

function OnButtonLabelHorizAlignChanged(event as object)
    label = event.getRoSGNode()
    if label.horizAlign <> "left"
        label.horizAlign = "left"
    end if
end function

function BindPreference(preferences as object, key as string)
    if m.preferences <> invalid and m.key <> invalid
        m.preferences.unobserveFieldScoped(m.key)
    end if
    m.preferences = preferences
    m.key = key
    if preferences <> invalid and key <> invalid
        preferences.observeFieldScoped(key, FuncName(OnPreferenceChange))
        OnPreferenceChange()
    end if
end function

function OpenQualitySelector()
    selector = CreateObject("roSGNode", "QualitySelector")
    m.appController.callfunc("PushScreen", selector)
    selector.callfunc("BindNode", invalid)
    selector.value = m.top.value
    selector.observeField("save", FuncName(OnSaveQualitySelector))
end function

function OnSaveQualitySelector(event as object)
    editor = event.GetRoSGNode()
    m.top.value = editor.value
end function

function OnPreferenceChange()
    m.top.value = m.preferences[m.key]
end function

function OnValueChange() as void
    if m.preferences = invalid or m.key = invalid
        return
    end if
    value = m.top.value
    m.preferences[m.key] = value
    if StringUtils_IsNullOrEmpty(value)
        m.button.text = Tr("Auto")
    else
        qualities = value.split(",")
        labels = []
        for each quality in qualities
            label = m.qualityToLabel[quality]
            if StringUtils_IsNullOrEmpty(label)
                label = quality
            end if
            labels.push(label)
        end for
        m.button.text = labels.join(", ")
    end if
end function