'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    m.top.focusable = true
    m.radioButtonList = m.top.findNode("RadioButtonList")
    m.radioButtonListContent = m.top.findNode("RadioButtonListContent")
    m.top.itemSpacings = [
        8
    ]
    m.radioButtonList.observeField("checkedItem", FuncName(OnCheckedItemChange))
end function

function BindPreference(preferences as object, key as string)
    if m.preferences <> invalid and m.key <> invalid
        m.preferences.unobserveFieldScoped(m.key)
    end if
    m.preferences = preferences
    m.key = key
    if preferences <> invalid and key <> invalid
        preferences.observeFieldScoped(key, FuncName(OnPreferenceChange))
        OnPreferenceChange()
    end if
end function

function OnPreferenceChange()
    m.top.value = m.preferences[m.key]
end function

function OnValueChange() as void
    value = m.top.value
    options = m.top.options
    checkedItem = -1
    for i = 0 to options.Count() - 1
        option = options[i].value
        if value = option
            checkedItem = i
            exit for
        end if
    end for
    m.radioButtonList.checkedItem = checkedItem
    if m.preferences = invalid or m.key = invalid
        return
    end if
    m.preferences[m.key] = m.top.value
end function

function OnOptionsChange()
    options = m.top.options
    m.radioButtonListContent.removeChildrenIndex(m.radioButtonListContent.getChildCount(), 0)
    for i = 0 to options.Count() - 1
        option = options[i].displayText
        node = CreateObject("roSGNode", "ContentNode")
        node.title = Tr(option)
        m.radioButtonListContent.appendChild(node)
    end for
    OnValueChange()
end function

function OnCheckedItemChange()
    checkedItem = m.radioButtonList.checkedItem
    options = m.top.options
    if checkedItem >= 0 and checkedItem < options.Count()
        m.top.value = options[checkedItem].value
    end if
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.radioButtonList, true)
end function