'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    m.top.focusable = true
    m.checkbox = m.top.findNode("Checkbox")
    m.top.itemSpacings = [
        10
    ]
end function

function BindPreference(preferences as object, key as string)
    if m.preferences <> invalid and m.key <> invalid
        m.preferences.unobserveFieldScoped(m.key)
    end if
    m.preferences = preferences
    m.key = key
    if preferences <> invalid and key <> invalid
        preferences.observeFieldScoped(key, FuncName(OnPreferenceChange))
        OnPreferenceChange()
    end if
end function

function OnPreferenceChange()
    m.top.value = m.preferences[m.key]
end function

function OnValueChange() as void
    if m.preferences = invalid or m.key = invalid
        return
    end if
    m.preferences[m.key] = m.top.value
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.checkbox, true)
end function