'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/source/utils/CacheUtils.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"

function Init()
    m.top.focusable = true
    m.top.itemSpacings = [
        8
    ]
    m.button = m.top.findNode("Button")
    m.button.observeField("buttonSelected", FuncName(OnButtonSelected))
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.button, true)
end function

function BindPreference(_preferences as object, _key as string)
    
end function

function OnButtonSelected()
    jobQueue = m.top.getScene().findNode("JobQueue")
    CacheUtils_Clear(jobQueue)
    DialogUtils_ShowDialogEx({
        message: Tr("Cache cleared.")
        title: Tr("Success")
    })
end function