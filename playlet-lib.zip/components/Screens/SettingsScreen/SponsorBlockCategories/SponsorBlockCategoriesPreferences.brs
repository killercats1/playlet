'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/parts/AutoBind/OnNodeReadyNoOp.bs"
'import "pkg:/components/Services/SponsorBlock/SponsorBlockConfig.bs"
'import "pkg:/components/VideoPlayer/SponsorBlockSegmentAction.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.categoryList = m.top.findNode("categoryList")
    m.categoryList.ObserveField("itemSelected", FuncName(OnCategorySelected))
    m.config = SponsorBlock_SponsorBlockConfig()
    optionTitles = {}
    optionTitles["disable"] = Tr("Disable")
    optionTitles["auto_skip"] = Tr("Auto Skip")
    optionTitles["manual_skip"] = Tr("Manual Skip")
    optionTitles["show_in_seekbar"] = Tr("Show in Seekbar")
    m.optionTitles = optionTitles
    SetupCategoriesUi()
    m.closeButton = m.top.findNode("closeButton")
    m.saveButton = m.top.findNode("saveButton")
    SetButtonPositions()
    SetNavigation(m.saveButton, "right", m.closeButton)
    SetNavigation(m.closeButton, "left", m.saveButton)
    SetNavigation(m.saveButton, "up", m.categoryList)
    SetNavigation(m.closeButton, "up", m.categoryList)
    SetNavigation(m.categoryList, "down", m.saveButton)
    m.saveButton.observeField("buttonSelected", FuncName(OnSaveButtonSelected))
    m.closeButton.observeField("buttonSelected", FuncName(Close))
end function

function SetupCategoriesUi() as void
    categories = m.config.GetCategories()
    if categories.Count() = 0
        return
    end if
    content = CreateObject("roSGNode", "ContentNode")
    categoryContentNodes = []
    for each category in categories
        categoryNode = CreateObject("roSGNode", "SponsorBlockCategoryContent")
        categoryNode.category = category
        categoryNode.categoryTitle = Tr(m.config.SegmentTitle(category))
        categoryNode.selectedOption = "disable"
        categoryNode.options = m.config.GetOptionsForCategory(category)
        categoryNode.optionTitles = m.optionTitles
        categoryNode.color = m.config.SegmentColor(category)
        categoryContentNodes.push(categoryNode)
    end for
    content.appendChildren(categoryContentNodes)
    m.categoryList.content = content
end function

function SetButtonPositions()
    saveButtonWidth = m.saveButton.width
    closeButtonWidth = m.closeButton.width
    buttonsWith = closeButtonWidth + saveButtonWidth + 20
    m.saveButton.translation = [
        720 / 2 - buttonsWith / 2
        m.saveButton.translation[1]
    ]
    m.closeButton.translation = [
        720 / 2 + buttonsWith / 2 - closeButtonWidth
        m.closeButton.translation[1]
    ]
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.categoryList, true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if NavigationKeyHandler(key, press).handled
        return true
    end if
    if key = "options" or key = "play" or key = "pause" or key = "playonly"
        
        return false
    end if
    if key = "back" and press
        Close()
        return true
    end if
    return true
end function

function OnValueChange() as void
    content = m.categoryList.content
    if content = invalid
        return
    end if
    value = m.top.value
    if not IsAssociativeArray(value)
        return
    end if
    categoryContentNodes = content.getChildren(-1, 0)
    categoryNodeMap = {}
    for each categoryContentNode in categoryContentNodes
        categoryNodeMap[categoryContentNode.category] = categoryContentNode
    end for
    for each category in value
        if not categoryNodeMap.DoesExist(category)
            continue for
        end if
        categoryNode = categoryNodeMap[category]
        if categoryNode = invalid
            continue for
        end if
        categoryNode.selectedOption = value[category].option
    end for
end function

function OnSaveButtonSelected()
    m.top.save = true
    Close()
end function

function Close()
    m.appController.callfunc("PopScreen", invalid)
end function

function OnCategorySelected(event as object) as void
    itemSelected = event.GetData()
    itemNode = m.categoryList.content.GetChild(itemSelected)
    if itemNode = invalid
        LogError3("[SponsorBlockCategoriesPreferences.bs:137]", "Invalid item selected:", itemSelected)
        return
    end if
    options = itemNode.options
    optionTitles = itemNode.optionTitles
    optionTitlesArray = []
    for each option in options
        optionTitlesArray.push(optionTitles[option])
    end for
    dialog = DialogUtils_ShowDialogEx({
        title: itemNode.categoryTitle
        message: Tr("Select option for %1").Replace("%1", itemNode.categoryTitle)
        buttons: optionTitlesArray
    })
    if dialog = invalid
        return
    end if
    dialog.addFields({
        "categoryContentNode": itemNode
        "options": options
    })
    dialog.observeField("buttonSelected", FuncName(OnCategoryDialogResult), [
        "buttonSelected"
    ])
end function

function OnCategoryDialogResult(event as object) as void
    dialog = event.getRoSGNode()
    options = dialog.options
    buttonIndex = event.GetData()
    if not IsInt(buttonIndex) or buttonIndex < 0 or buttonIndex >= options.Count()
        return
    end if
    selectedOption = options[buttonIndex]
    category = dialog.categoryContentNode.category
    value = m.top.value
    value[category].option = selectedOption
    m.top.value = value
    LogInfo5("[SponsorBlockCategoriesPreferences.bs:179]", "SponsorBlock category", category, "set to", selectedOption)
end function