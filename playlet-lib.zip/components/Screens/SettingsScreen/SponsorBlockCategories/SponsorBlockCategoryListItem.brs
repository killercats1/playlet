function OnContentSet() as void
    content = m.top.itemContent
    if content = invalid
        return
    end if
    m.top.categoryTitle = content.categoryTitle
    optionTitles = content.optionTitles
    m.top.optionTitle = optionTitles[content.selectedOption]
    m.top.color = content.color
end function