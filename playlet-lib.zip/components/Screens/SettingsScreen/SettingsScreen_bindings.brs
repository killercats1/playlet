' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "navBar": "/NavBar", 
            "preferences": "/Preferences"
        },
        childProps: {
    
        }
    }
end function