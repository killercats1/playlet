'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/parts/AutoBind/OnNodeReadyNoOp.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/MathUtils.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.homeLayoutMap = {}
    homeLayoutMap = StringUtils_ParseJsonSafe(ReadAsciiFile("libpkg:/config/default_home_layout.yaml"))
    for each item in homeLayoutMap
        m.homeLayoutMap[item.id] = item
    end for
    m.checkList = m.top.findNode("checkList")
    m.moveUpButton = m.top.findNode("moveUpButton")
    m.moveDownButton = m.top.findNode("moveDownButton")
    m.closeButton = m.top.findNode("closeButton")
    m.saveButton = m.top.findNode("saveButton")
    SetNavigation(m.checkList, "down", m.saveButton)
    SetNavigation(m.saveButton, "up", m.checkList)
    SetNavigation(m.closeButton, "up", m.checkList)
    SetNavigation(m.saveButton, "right", m.closeButton)
    SetNavigation(m.closeButton, "left", m.saveButton)
    SetNavigation(m.moveUpButton, "left", m.checkList)
    SetNavigation(m.moveDownButton, "left", m.checkList)
    SetNavigation(m.checkList, "right", m.moveUpButton)
    SetNavigation(m.moveUpButton, "down", m.moveDownButton)
    SetNavigation(m.moveDownButton, "up", m.moveUpButton)
    SetNavigation(m.moveDownButton, "down", m.closeButton)
    m.moveUpButton.observeField("buttonSelected", FuncName(OnMoveUpButtonSelected))
    m.moveDownButton.observeField("buttonSelected", FuncName(OnMoveDownButtonSelected))
    m.saveButton.observeField("buttonSelected", FuncName(OnSaveButtonSelected))
    m.closeButton.observeField("buttonSelected", FuncName(Close))
    m.checkList.observeField("checkedState", FuncName(OnCheckedStateChange))
    SetButtonPositions()
end function

function SetButtonPositions()
    saveButtonWidth = m.saveButton.width
    closeButtonWidth = m.closeButton.width
    buttonsWith = closeButtonWidth + saveButtonWidth + 20
    m.saveButton.translation = [
        960 / 2 - buttonsWith / 2
        m.saveButton.translation[1]
    ]
    m.closeButton.translation = [
        960 / 2 + buttonsWith / 2 - closeButtonWidth
        m.closeButton.translation[1]
    ]
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.checkList, true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if NavigationKeyHandler(key, press).handled
        return true
    end if
    if key = "options" or key = "play" or key = "pause" or key = "playonly"
        
        return false
    end if
    if key = "back" and press
        Close()
        return true
    end if
    return true
end function

function OnValueChange()
    content = m.checkList.content
    value = m.top.value
    nodes = []
    checkedState = []
    homeLayoutMap = {}
    homeLayoutMap.Append(m.homeLayoutMap)
    for each item in value
        feed = homeLayoutMap[item.id]
        if feed = invalid
            LogWarn3("[HomeScreenEditor.bs:89]", "unknown feed id:", item.id)
            continue for
        end if
        homeLayoutMap.Delete(item.id)
        node = CreateObject("roSGNode", "ContentNode")
        node.id = feed.id
        node.title = Tr(feed.title)
        nodes.push(node)
        checkedState.push(item.enabled)
    end for
    for each id in homeLayoutMap
        feed = homeLayoutMap[id]
        if feed = invalid
            LogWarn3("[HomeScreenEditor.bs:103]", "unknown feed id:", id)
            continue for
        end if
        node = CreateObject("roSGNode", "ContentNode")
        node.id = feed.id
        node.title = Tr(feed.title)
        nodes.push(node)
        checkedState.push(false)
    end for
    labelCount = content.getChildCount()
    if labelCount > 0
        content.removeChildrenIndex(labelCount, 0)
    end if
    content.appendChildren(nodes)
    m.checkList.checkedState = checkedState
end function

function OnCheckedStateChange() as void
    content = m.checkList.content
    if content = invalid or content.getChildCount() = 0
        return
    end if
    checkedState = m.checkList.checkedState
    if checkedState = invalid or checkedState.Count() = 0
        return
    end if
    value = []
    checkboxes = content.getChildren(-1, 0)
    for i = 0 to checkboxes.Count() - 1
        checkbox = checkboxes[i]
        value.push({
            id: checkbox.id
            enabled: checkedState[i]
        })
    end for
    m.top.value = value
end function

function OnMoveUpButtonSelected() as void
    MoveItem(-1)
end function

function OnMoveDownButtonSelected() as void
    MoveItem(1)
end function

function MoveItem(offset as integer) as void
    content = m.checkList.content
    if content = invalid or content.getChildCount() = 0
        return
    end if
    itemCount = content.getChildCount()
    index = m.checkList.itemFocused
    newIndex = MathUtils_Clamp(index + offset, 0, itemCount - 1)
    if index = newIndex
        return
    end if
    checkedState = m.checkList.checkedState
    node = content.getChild(index)
    content.insertChild(node, newIndex)
    tmp = checkedState[index]
    checkedState[index] = checkedState[newIndex]
    checkedState[newIndex] = tmp
    m.checkList.itemFocused = newIndex
    m.checkList.jumpToItem = newIndex
    m.checkList.checkedState = checkedState
end function

function OnSaveButtonSelected()
    
    OnCheckedStateChange()
    m.top.save = true
    Close()
end function

function Close()
    m.appController.callfunc("PopScreen", invalid)
end function