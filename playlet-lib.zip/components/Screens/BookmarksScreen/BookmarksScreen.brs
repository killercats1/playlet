'import "pkg:/components/ContextMenu/ContextMenuUtils.bs"
'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/Services/BookmarksService/BookmarksServiceUtils.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.noBookmarks = m.top.findNode("noBookmarks")
    m.yesBookmarks = m.top.findNode("yesBookmarks")
    m.rowList = m.top.FindNode("rowList")
    m.rowList.screen = m.top
    m.isDirty = true
    m.top.ObserveField("visible", FuncName(OnVisibleChange))
end function

function OnNodeReady()
    SetNavigation(invalid, "back", m.navBar)
    SetNavigation(invalid, "left", m.navBar)
    m.rowList.callfunc("BindNode", invalid)
    OnBookmarksChange()
    m.bookmarksService.ObserveField("contentChange", FuncName(OnBookmarksChange))
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    if m.yesBookmarks.visible
        NodeSetFocus(m.rowList, true)
    else
        NodeSetFocus(m.navBar, true)
    end if
end function

function OnVisibleChange()
    if m.top.visible and m.isDirty
        OnBookmarksChange()
    end if
end function

function Refresh(_unused as dynamic)
    m.isDirty = true
    OnBookmarksChange()
end function

function OnBookmarksChange() as void
    if not m.top.visible
        m.isDirty = true
        return
    end if
    m.isDirty = false
    hasBookmarks = m.bookmarksService.content.getChildCount() > 0
    m.noBookmarks.visible = not hasBookmarks
    m.yesBookmarks.visible = hasBookmarks
    m.top.focusable = hasBookmarks
    if hasBookmarks
        SetRowListContent(m.bookmarksService.content)
    else
        if m.rowList.hasFocus()
            NodeSetFocus(m.navBar, true)
        end if
    end if
end function

function SetRowListContent(bookmarksContent as object)
    m.rowList.feeds = BookmarksServiceUtils_BookmarksContentToFeed(bookmarksContent)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if NavigationKeyHandler(key, press).handled
        return true
    end if
    return false
end function

function GetContextMenuOptionsForItem(_rowItem as object) as object
    refreshItem = ContextMenuUtils_CreateOption(Tr("Refresh Bookmarks"), m.top, "Refresh", [
        invalid
    ])
    return [
        refreshItem
    ]
end function