' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "navBar": "/NavBar", 
            "applicationInfo": "/ApplicationInfo", 
            "bookmarksService": "/BookmarksService"
        },
        childProps: {
    
        }
    }
end function