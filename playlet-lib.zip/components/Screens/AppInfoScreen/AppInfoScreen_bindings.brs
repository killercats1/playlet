' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "applicationInfo": "/ApplicationInfo"
        },
        childProps: {
    
        }
    }
end function