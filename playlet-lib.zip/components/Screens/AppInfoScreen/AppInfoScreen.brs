'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    
    m.displayNames = [
        {
            key: "app_version"
            displayText: "Playlet App Version"
        }
        {
            key: "lib_version"
            displayText: "Playlet Library Version"
        }
        {
            key: "lib_url"
            displayText: "Playlet Library URL"
        }
        {
            key: "lib_url_type"
            displayText: "Playlet Library URL Type"
        }
        {
            key: "app_git_commit_hash"
            displayText: "Playlet App Git Commit Hash"
        }
        {
            key: "lib_git_commit_hash"
            displayText: "Playlet Library Git Commit Hash"
        }
        {
            key: "id"
            displayText: "App ID"
        }
    ]
    m.keyValueList = m.top.findNode("KeyValueListContent")
end function

function OnNodeReady()
    m.appInfo = m.applicationInfo.callfunc("GetAppInfo", invalid)
    UpdateKeyValueList()
end function

function UpdateKeyValueList()
    while m.keyValueList.getChildCount() > 0
        m.keyValueList.removeChildIndex(0)
    end while
    for each item in m.displayNames
        value = (bslib_toString(item.displayText) + ": " + bslib_toString(m.appInfo[item.key]))
        contentNode = m.keyValueList.createChild("ContentNode")
        contentNode.title = value
    end for
end function