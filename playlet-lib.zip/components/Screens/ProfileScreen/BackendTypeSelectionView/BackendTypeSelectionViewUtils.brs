function BackendTypeSelectionViewUtils_Open(appController as object) as object
    backendTypeSelectionView = CreateObject("roSGNode", "BackendTypeSelectionView")
    appController.callfunc("PushScreen", backendTypeSelectionView)
    backendTypeSelectionView.callfunc("BindNode", invalid)
    return backendTypeSelectionView
end function