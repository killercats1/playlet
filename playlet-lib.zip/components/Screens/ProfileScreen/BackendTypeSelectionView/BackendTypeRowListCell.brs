function OnContentSet() as void
    content = m.top.itemContent
    if content = invalid
        return
    end if
    m.top.backendName = content.title
    m.top.backendLogoUri = content.backendLogoUri
end function