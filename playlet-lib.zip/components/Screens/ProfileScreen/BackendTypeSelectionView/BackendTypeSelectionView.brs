'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/parts/AutoBind/OnNodeReadyNoOp.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.rowList = m.top.FindNode("BackendRowList")
    m.rowList.ObserveField("rowItemSelected", FuncName(OnRowItemSelected))
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.rowList, true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if key = "options" or key = "play" or key = "pause" or key = "playonly"
        
        return false
    end if
    if key = "back" and press
        Close()
        return true
    end if
    return true
end function

function Close()
    m.top.appController.callfunc("PopScreen", invalid)
end function

function OnRowItemSelected(event as object) as void
    index = event.GetData()
    if index = invalid or index.count() <> 2
        LogWarn3("[BackendTypeSelectionView.bs:41]", "Invalid index:", index)
        return
    end if
    Close()
    content = m.rowList.content
    rowIndex = index[0]
    rowItemIndex = index[1]
    row = content.GetChild(rowIndex)
    rowItem = row.GetChild(rowItemIndex)
    m.top.selectedBackendType = rowItem.id
end function