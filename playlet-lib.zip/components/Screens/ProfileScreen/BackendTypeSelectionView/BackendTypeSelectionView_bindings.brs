' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "appController": "/AppController"
        },
        childProps: {
    
        }
    }
end function