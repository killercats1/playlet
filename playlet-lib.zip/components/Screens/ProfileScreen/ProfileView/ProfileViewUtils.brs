function ProfileViewUtils_Open(profile as object, appController as object)
    profileView = CreateObject("roSGNode", "ProfileView")
    appController.callfunc("PushScreen", profileView)
    profileView.callfunc("BindNode", invalid)
    profileView.content = profile
end function