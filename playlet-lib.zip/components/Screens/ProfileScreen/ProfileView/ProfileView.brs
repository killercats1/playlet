'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.types.bs"
'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/Screens/ProfileScreen/LoginUtils.bs"
'import "pkg:/source/utils/DisposableObserve.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.loginButton = m.top.findNode("loginButton")
    m.activateButton = m.top.findNode("activateButton")
    m.logoutButton = m.top.findNode("logoutButton")
    m.closeButton = m.top.findNode("closeButton")
    m.reauthLabel = m.top.findNode("ReauthLabel")
    m.loginButton.disabled = true
    m.needsReauth = false
    DisposableObserveField(m.loginButton, "buttonSelected", FuncName(Login))
    DisposableObserveField(m.activateButton, "buttonSelected", FuncName(Activate))
    DisposableObserveField(m.logoutButton, "buttonSelected", FuncName(Logout))
    DisposableObserveField(m.closeButton, "buttonSelected", FuncName(Close))
end function

function OnNodeReady()
    SetNavigation(m.loginButton, "down", m.activateButton)
    SetNavigation(m.activateButton, "up", m.loginButton)
    SetNavigation(m.activateButton, "down", m.logoutButton)
    SetNavigation(m.logoutButton, "down", m.closeButton)
    SetNavigation(m.closeButton, "up", m.logoutButton)
    SetNavigation(m.logoutButton, "up", m.activateButton)
    SetNavigation(m.loginButton, "down", m.logoutButton)
    SetNavigation(m.logoutButton, "up", m.loginButton)
    DisposableObserveFieldScoped(m.profilesService, "currentProfile", FuncName(OnCunrrentProfileChanged))
    DisposableObserveFieldScoped(m.profilesService, "onProfileLogout", FuncName(OnProfileLogout))
end function

function OnContentSet() as void
    content = m.top.content
    if content = invalid
        m.needsReauth = false
        m.reauthLabel.visible = false
        m.loginButton.visible = false
        m.loginButton.disabled = true
        return
    end if
    username = content.username
    m.top.username = username
    thumbnail = content.thumbnail
    if not StringUtils_IsNullOrEmpty(thumbnail)
        m.top.circlePosterInnerUri = thumbnail
        
        m.top.circlePosterInnerBlendColor = "#FFFFFFFF"
        m.top.letter = ""
    else
        m.top.circlePosterInnerUri = "pkg:/images/white-circle.png"
        m.top.circlePosterInnerBlendColor = content.color
        if not StringUtils_IsNullOrEmpty(username)
            letter = username.Left(1)
            if letter = "@" and Len(username) > 1
                letter = username.Mid(1, 1)
            end if
            m.top.letter = UCase(letter)
        else
            m.top.letter = ""
        end if
    end if
    m.top.crownVisible = content.isSelected
    backendType = content.type
    if backendType = "invidious"
        m.top.serverUrl = content.serverUrl
        m.top.backendTypePosterUri = "pkg:/images/invidious-logo.png"
    else if backendType = "youtube"
        m.top.serverUrl = "YouTube"
        m.top.backendTypePosterUri = "pkg:/images/youtube-logo.png"
    else
        m.top.serverUrl = ""
        m.top.backendTypePosterUri = ""
    end if
    UpdateReauthState(content.authState)
    UpdateActivateButton(content.isSelected)
end function

function OnFocusChange() as void
    if m.top.focus
        FocusTopButton()
    end if
end function

function FocusTopButton() as void
    if m.loginButton.focusable
        NodeSetFocus(m.loginButton, true)
    else if m.activateButton.focusable
        NodeSetFocus(m.activateButton, true)
    else
        NodeSetFocus(m.logoutButton, true)
    end if
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if NavigationKeyHandler(key, press).handled
        return true
    end if
    if key = "options" or key = "play" or key = "pause" or key = "playonly"
        
        return false
    end if
    if key = "back" and press
        Close()
        return true
    end if
    return true
end function

function Login() as void
    content = m.top.content
    if content = invalid
        return
    end if
    backendType = content.type
    if backendType = "invidious"
        LoginUtils_ShowInvidiousLoginDialog(content.id)
    else if backendType = "youtube"
        LoginUtils_ShowYouTubeLoginDialog()
    else
        LogError3("[ProfileView.bs:140]", "Unknown backend type:", backendType)
    end if
end function

function Activate() as void
    content = m.top.content
    if content = invalid
        return
    end if
    profile = m.profilesService.content.getChild(0).findNode(content.id)
    if profile = invalid
        return
    end if
    m.top.content = invalid
    m.profilesService.callfunc("SetCurrentProfile", profile)
    Close()
end function

function Logout() as void
    content = m.top.content
    if content = invalid
        return
    end if
    m.top.content = invalid
    m.profilesService.callfunc("LogoutWithProfile", content)
    Close()
end function

function Close()
    m.top.appController.callfunc("PopScreen", invalid)
    m.top.dispose = true
end function

function OnDispose()
    DisposeObservers()
    m.top.content = invalid
end function

function UpdateReauthState(authState as string) as void
    needsReauth = authState = "NeedsReauth"
    if needsReauth = m.needsReauth
        return
    end if
    m.needsReauth = needsReauth
    if needsReauth
        m.reauthLabel.text = [
            Tr("The session has expired.")
            Tr("Please sign in again with this profile, or switch to another profile.")
        ].Join(Chr(10))
        m.loginButton.text = Tr("Login")
    end if
    m.reauthLabel.visible = needsReauth
    m.loginButton.visible = needsReauth
    m.loginButton.disabled = not needsReauth
    if m.top.isInFocusChain()
        FocusTopButton()
    end if
end function

function OnCunrrentProfileChanged() as void
    content = m.top.content
    if content = invalid
        return
    end if
    m.top.crownVisible = content.isSelected
    UpdateActivateButton(content.isSelected)
end function

function OnProfileLogout() as void
    content = m.top.content
    if content = invalid
        return
    end if
    profile = m.profilesService.content.getChild(0).findNode(content.id)
    if profile = invalid
        Close()
    end if
end function

function UpdateActivateButton(isSelected as boolean) as void
    if isSelected
        if m.activateButton.hasFocus()
            NodeSetFocus(m.logoutButton, true)
        end if
        m.activateButton.text = Tr("In Use")
        m.activateButton.disabled = true
    else
        m.activateButton.text = Tr("Activate")
        m.activateButton.disabled = false
    end if
end function