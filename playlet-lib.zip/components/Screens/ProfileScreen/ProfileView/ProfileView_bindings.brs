' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "appController": "/AppController", 
            "profilesService": "/ProfilesService"
        },
        childProps: {
    
        }
    }
end function