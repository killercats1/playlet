' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "navBar": "/NavBar", 
            "profilesService": "/ProfilesService", 
            "appController": "/AppController", 
            "preferences": "/Preferences"
        },
        childProps: {
    
        }
    }
end function