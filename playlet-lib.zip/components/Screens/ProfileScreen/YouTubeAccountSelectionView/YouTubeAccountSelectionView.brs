'import "pkg:/components/Dialog/YouTubeLoginAccountItemUtils.bs"
'import "pkg:/components/parts/AutoBind/OnNodeReadyNoOp.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.accountList = m.top.FindNode("accountList")
    m.accountList.ObserveField("itemSelected", FuncName(OnAccountSelected))
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.accountList, true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if key = "options" or key = "play" or key = "pause" or key = "playonly"
        
        return false
    end if
    if key = "back" and press
        Close()
        return true
    end if
    return true
end function

function Close()
    m.top.appController.callfunc("PopScreen", invalid)
end function

function OnAccountsChanged() as void
    accounts = m.top.accounts
    if not IsArray(accounts) or accounts.Count() = 0
        m.accountList.content = invalid
        LogError2("[YouTubeAccountSelectionView.bs:43]", Tr("No valid accounts found for YouTube login."))
        Close()
        return
    end if
    content = CreateObject("roSGNode", "ContentNode")
    accountNodes = []
    for each accountItem in accounts
        if not IsAssociativeArray(accountItem)
            continue for
        end if
        accountNode = CreateObject("roSGNode", "ContentNode")
        accountNode.addField("accountItem", "assocarray", false)
        accountNode.accountItem = accountItem
        accountNodes.Push(accountNode)
    end for
    if accountNodes.Count() = 0
        m.accountList.content = invalid
        LogError2("[YouTubeAccountSelectionView.bs:63]", Tr("No valid accounts found for YouTube login."))
        Close()
        return
    end if
    content.appendChildren(accountNodes)
    m.accountList.content = content
end function

function OnAccountSelected() as void
    itemSelected = m.accountList.itemSelected
    itemNode = m.accountList.content.GetChild(itemSelected)
    if itemNode = invalid
        LogError3("[YouTubeAccountSelectionView.bs:76]", "Invalid item selected:", itemSelected)
        Close()
        return
    end if
    accountItem = itemNode.accountItem
    if not IsAssociativeArray(accountItem)
        LogError3("[YouTubeAccountSelectionView.bs:83]", "Invalid account item selected:", accountItem)
        Close()
        return
    end if
    accessToken = m.top.accessToken
    if accessToken = invalid or not IsAssociativeArray(accessToken)
        LogError2("[YouTubeAccountSelectionView.bs:90]", "No valid access token available for YouTube login.")
        Close()
        return
    end if
    profileNode = YouTubeLoginAccountItemUtils_CreateProfileContentNode(accountItem, accessToken)
    m.top.profilesService.callfunc("LoginWithProfile", profileNode)
    Close()
end function