'import "pkg:/source/utils/Types.bs"

function OnContentSet() as void
    content = m.top.itemContent
    if content = invalid
        return
    end if
    accountItem = content.accountItem
    if not IsAssociativeArray(accountItem)
        return
    end if
    m.top.accountPhoto = accountItem.accountPhoto
    m.top.text1 = accountItem.accountName
    m.top.text2 = accountItem.channelHandle
end function