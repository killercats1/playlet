function YouTubeAccountSelectionViewUtils_Open(appController as object) as object
    youTubeAccountSelectionView = CreateObject("roSGNode", "YouTubeAccountSelectionView")
    appController.callfunc("PushScreen", youTubeAccountSelectionView)
    youTubeAccountSelectionView.callfunc("BindNode", invalid)
    return youTubeAccountSelectionView
end function