'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Types.bs"
function LoginUtils_ShowInvidiousLoginDialog(profileId = "" as string) as void
    dialog = CreateObject("roSGNode", "InvidiousLoginDialog")
    dialog.profileId = profileId
    dialog.callfunc("BindNode", invalid)
    m.top.getScene().dialog = dialog
end function

function LoginUtils_ShowLoginWithYouTubeDisclaimerDialog() as void
    dialog = DialogUtils_ShowDialogEx({
        title: Tr("Disclaimer")
        message: [
            Tr("Playlet is a third-party app and is not affiliated with, endorsed by, or sponsored by YouTube or Google. All trademarks and registered trademarks mentioned are the property of their respective owners and are used only for identification purposes.")
            Tr("By using Playlet and signing in with your YouTube account, you acknowledge that you do so at your own risk. The developers of Playlet are not liable for any harm, including but not limited to data loss, account suspension or ban, hacking, or loss of content.")
            Tr("Use responsibly, especially if your YouTube account is tied to business or monetization.")
        ]
        large: true
        buttons: [
            Tr("OK")
            Tr("Cancel")
        ]
    })
    dialog.ObserveField("buttonSelected", FuncName(LoginUtils_OnLoginWithYouTubeDisclaimerDialogButtonSelected))
end function

function LoginUtils_OnLoginWithYouTubeDisclaimerDialogButtonSelected(event as object) as void
    buttonSelected = event.getData()
    if buttonSelected <> 0
        return
    end if
    LoginUtils_ShowYouTubeLoginDialog()
end function

function LoginUtils_ShowYouTubeLoginDialog() as void
    dialog = CreateObject("roSGNode", "YouTubeLoginDialog")
    dialog.callfunc("BindNode", invalid)
    m.top.getScene().dialog = dialog
end function