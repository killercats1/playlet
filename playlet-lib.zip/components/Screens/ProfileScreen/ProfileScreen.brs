'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/Screens/ProfileScreen/BackendTypeSelectionView/BackendTypeSelectionViewUtils.bs"
'import "pkg:/components/Screens/ProfileScreen/LoginUtils.bs"
'import "pkg:/components/Screens/ProfileScreen/ProfileView/ProfileViewUtils.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.top.focusable = true
    m.profileRowList = m.top.FindNode("ProfileRowList")
end function

function OnNodeReady()
    SetNavigation(invalid, "back", m.navBar)
    SetNavigation(invalid, "left", m.navBar)
    m.profileRowList.content = m.profilesService.content
    m.profileRowList.observeFieldScoped("rowItemSelected", FuncName(OnRowItemSelected))
    m.profilesService.observeFieldScoped("currentProfile", FuncName(OnCurrentProfileChanged))
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.profileRowList, true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if NavigationKeyHandler(key, press).handled
        return true
    end if
    return false
end function

function OnRowItemSelected() as void
    index = m.profileRowList.rowItemSelected[1]
    row = m.profileRowList.content.GetChild(0)
    selectedProfile = row.GetChild(index)
    if selectedProfile.type = "login"
        backendTypeSelectionView = BackendTypeSelectionViewUtils_Open(m.appController)
        backendTypeSelectionView.observeFieldScoped("selectedBackendType", FuncName(OnBackEndSelected))
        return
    end if
    ProfileViewUtils_Open(selectedProfile, m.appController)
end function

function OnBackEndSelected(event as object) as void
    backendTypeSelectionView = event.GetRoSGNode()
    backendTypeSelectionView.unobserveFieldScoped("selectedBackendType")
    selectedBackendType = event.getData()
    if selectedBackendType = "BackendTypeInvidious"
        OnLoginWithInvidiousSelected()
    else if selectedBackendType = "BackendTypeYouTube"
        LoginUtils_ShowLoginWithYouTubeDisclaimerDialog()
    else
        LogError3("[ProfileScreen.bs:61]", "Unknown backend type:", selectedBackendType)
    end if
end function

function OnLoginWithInvidiousSelected() as void
    invidiousInstance = m.preferences["invidious.instance"]
    if StringUtils_IsNullOrEmpty(invidiousInstance)
        DialogUtils_ShowDialogEx({
            title: "No Invidious Instance"
            message: [
                "Playlet built-in backend does not support Invidious login."
                "Can only login with Invidious if an Invidious instance is set in the settings."
            ]
        })
        return
    end if
    LoginUtils_ShowInvidiousLoginDialog()
end function

function OnCurrentProfileChanged() as void
    currentProfile = m.profilesService.currentProfile
    if currentProfile = invalid
        return
    end if
    row = m.profileRowList.content.GetChild(0)
    allProfiles = row.getChildren(-1, 0)
    for i = 0 to allProfiles.Count() - 1
        if currentProfile.id = allProfiles[i].id
            m.profileRowList.jumpToRowItem = [
                0
                i
            ]
            return
        end if
    end for
end function