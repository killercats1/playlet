' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "preferences": "/Preferences"
        },
        childProps: {
    
        }
    }
end function