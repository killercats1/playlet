' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "navBar": "/NavBar", 
            "invidious": "/Invidious", 
            "appController": "/AppController", 
            "preferences": "/Preferences", 
            "jobQueue": "/JobQueue"
        },
        childProps: {
    
        }
    }
end function