'import "pkg:/components/Services/Innertube/InnertubeService.bs"
'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/components/Services/SearchHistory/SearchHistoryUtils.bs"

function ExecuteJob() as void
    input = JobGetInput()
    q = input.q
    invidiousNode = input.invidious
    preferencesNode = input.preferences
    seachScreenNode = input.searchScreen
    if JobIsCancelled()
        JobCancel()
        return
    end if
    if StringUtils_IsNullOrEmpty(q)
        searchSuggestsions = {
            suggestions: []
        }
    else
        backend = preferencesNode["backend.selected"]
        if backend = "playlet"
            searchSuggestsions = InnertubeService_SearchSuggestions(q, m.top.cancellation)
        else
            service = Invidious_InvidiousService(invidiousNode)
            searchSuggestsions = service.SearchSuggestions(q, m.top.cancellation)
        end if
    end if
    if JobIsCancelled()
        JobCancel()
        return
    end if
    history = SearchHistoryUtils_GetSaved(preferencesNode, q)
    if searchSuggestsions <> invalid
        if searchSuggestsions.error <> invalid
            LogError2("[SearchSuggestionsJob.bs:40]", searchSuggestsions.error)
        else
            history = MergeSearchSuggestions(history, searchSuggestsions.suggestions)
        end if
    end if
    seachScreenNode.searchSuggestions = {
        q: q
        response: history
    }
end function

function MergeSearchSuggestions(history as object, queryResults as object, maxItems = 10 as integer) as object
    if queryResults = invalid
        return history
    end if
    while history.Count() < maxItems and queryResults.Count() > 0
        history.push(queryResults.shift())
    end while
    return history
end function