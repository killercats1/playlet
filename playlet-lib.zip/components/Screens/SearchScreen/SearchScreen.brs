'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/Services/SearchHistory/SearchHistoryUtils.bs"
'import "pkg:/source/utils/CryptoUtils.bs"
'import "pkg:/source/utils/ErrorUtils.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/LoadingScreen.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/UrlUtils.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.top.focusable = true
    m.container = m.top.FindNode("container")
    m.keyboard = m.top.FindNode("keyboard")
    m.rowList = m.top.FindNode("rowList")
    m.scrollAnimation = m.top.FindNode("scrollAnimation")
    m.scrollAnimationInterpolator = m.top.FindNode("scrollAnimationInterpolator")
    m.suggestions = m.top.FindNode("suggestions")
    m.filtersButton = m.top.FindNode("filtersButton")
    m.rowList.screen = m.top
    textEditBox = m.keyboard.textEditBox
    textEditBox.voiceEntryType = "generic"
    textEditBox.voiceEnabled = true
    m.top.filters = {
        date: ""
        type: ""
        duration: ""
        features: []
        sort: ""
    }
    m.top.ObserveField("filters", FuncName(OnFiltersChange))
end function

function OnNodeReady()
    m.rowlist.callfunc("BindNode", invalid)
    m.keyboard.callfunc("BindNode", invalid)
    m.keyboard.ObserveField("text", FuncName(OnTextChange))
    m.suggestions.ObserveField("buttonFocused", FuncName(OnSearchButtonFocused))
    m.suggestions.ObserveField("buttonSelected", FuncName(OnSearchButtonSelected))
    m.filtersButton.ObserveField("buttonSelected", FuncName(OnFiltersButtonSelected))
    m.top.ObserveField("visible", FuncName(OnVisibilityChange))
    m.rowlist.ObserveFieldScoped("onError", FuncName(OnSearchError))
    SetNavigation(invalid, "back", m.navBar, function()
        ScrollUp()
    end function)
    SetNavigation(m.suggestions, "right", m.keyboard)
    SetNavigation(m.filtersButton, "right", m.keyboard)
    SetNavigation(m.keyboard, "left", m.suggestions)
    SetNavigation(m.suggestions, "left", m.navBar)
    SetNavigation(m.filtersButton, "left", m.navBar)
    SetNavigation(m.keyboard, "left", m.navBar)
    SetNavigation(m.rowList, "left", m.navBar, function()
        ScrollUp()
    end function)
    SetNavigation(m.filtersButton, "down", m.suggestions)
    SetNavigation(m.filtersButton, "down", m.keyboard)
    SetNavigation(invalid, "down", m.rowList, function()
        ScrollDown()
    end function)
    SetNavigation(m.rowList, "up", m.suggestions, function()
        ScrollUp()
    end function)
    SetNavigation(m.suggestions, "up", m.filtersButton)
    SetNavigation(m.keyboard, "up", m.filtersButton)
    m.currentNavigtionNode = m.suggestions
    
    OnTextChange()
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    if m.currentNavigtionNode.isSameNode(m.suggestions) and not m.suggestions.focusable
        m.currentNavigtionNode = m.keyboard
    end if
    NodeSetFocus(m.currentNavigtionNode, true)
    if m.currentNavigtionNode.isSameNode(m.suggestions)
        OnSearchButtonFocused()
    end if
end function

function OnTextChange() as void
    if m.suggestions.isInFocusChain()
        return
    end if
    if m.searchSuggestionsJob <> invalid
        m.searchSuggestionsJob.cancel = true
    end if
    input = {
        "q": m.keyboard.text
        "invidious": m.invidious
        "preferences": m.preferences
        "searchScreen": m.top
    }
    m.searchSuggestionsJob = JobSystem_CreateCallback()
    JobSystem_QueueJob(m.jobQueue, "SearchSuggestionsJob", input, m.searchSuggestionsJob)
end function

function OnSearchSuggestions(event as object) as void
    m.searchSuggestionsJob = invalid
    result = event.GetData()
    if not IsAssociativeArray(result)
        return
    end if
    
    q = result.q
    if q <> m.keyboard.text
        return
    end if
    suggestions = result.response
    if suggestions = invalid
        return
    end if
    if q.len() > 0 and ArrayUtils_IndexOfString(suggestions, q) = -1
        suggestions.Unshift(q)
    end if
    
    buttonFocused = -1
    if m.suggestions.isInFocusChain()
        buttonFocused = m.suggestions.buttonFocused
    end if
    if buttonFocused >= m.suggestions.buttons.Count()
        buttonFocused = m.suggestions.buttons.Count() - 1
    end if
    m.suggestions.buttons = suggestions
    if buttonFocused <> -1
        m.suggestions.focusButton = buttonFocused
    end if
    m.suggestions.focusable = m.suggestions.buttons.Count() > 0
end function

function OnFiltersButtonSelected()
    searchFilters = CreateObject("roSGNode", "SearchFilters")
    m.appController.callfunc("PushScreen", searchFilters)
    searchFilters.searchScreen = m.top
    searchFilters.callfunc("BindNode", invalid)
end function

function OnSearchButtonSelected()
    selected = m.suggestions.buttonSelected
    text = m.suggestions.buttons[selected]
    SearchHistoryUtils_Save(m.preferences, text)
    Search(text)
end function

function OnSearchButtonFocused() as void
    if not m.suggestions.isInFocusChain()
        return
    end if
    buttonCount = m.suggestions.buttons.Count()
    selected = m.suggestions.buttonFocused
    if selected >= buttonCount
        m.suggestions.focusButton = 0
    end if
    selected = m.suggestions.buttonFocused
    if selected >= m.suggestions.buttons.Count() or selected < 0
        return
    end if
    text = m.suggestions.buttons[selected]
    m.keyboard.text = text
end function

function OnFiltersChange()
    filterCount = 0
    filters = m.top.filters
    for each filter in filters
        value = filters[filter]
        if IsString(value) and value.len() > 0
            filterCount++
        else if IsArray(value) and value.Count() > 0
            filterCount += value.Count()
        end if
    end for
    if filterCount > 0
        m.filtersButton.text = (bslib_toString(Tr("Filters")) + " (" + bslib_toString(filterCount) + ")")
    else
        m.filtersButton.text = Tr("Filters")
    end if
end function

function Search(text as string)
    m.rowlist.UnobserveFieldScoped("someContentReady")
    m.rowlist.ObserveFieldScoped("someContentReady", FuncName(OnSearchContentReady))
    ShowLoadingScreen()
    feedSource = {
        "id": ("inv_search_" + bslib_toString(CryptoUtils_GetMd5(text)))
        "title": (bslib_toString(Tr("Search")) + " - " + bslib_toString(text))
        "apiType": "Invidious"
        "endpoint": "search"
        "queryParams": {
            "q": text
        }
    }
    filters = m.top.filters
    for each filter in filters
        value = filters[filter]
        if IsString(value) and value.len() > 0
            feedSource.queryParams[filter] = value
        else if IsArray(value) and value.Count() > 0
            feedSource.queryParams[filter] = {
                value: value
                arrayType: "CommaSeparated"
            }
        end if
    end for
    m.rowList.feeds = [
        {
            "title": (bslib_toString(Tr("Search")) + " - " + bslib_toString(text))
            "feedSources": [
                feedSource
            ]
        }
    ]
end function

function OnSearchContentReady() as void
    m.rowlist.UnobserveFieldScoped("someContentReady")
    if not m.rowlist.someContentReady
        DialogUtils_ShowDialogEx({
            message: Tr("We didn't find any results for your search. Please try again with a different query or different filters.")
            title: Tr("No results found")
        })
        m.rowlist.feeds = invalid
        m.rowlist.focusable = false
        HideLoadingScreen()
        return
    end if
    m.rowlist.focusable = true
    m.currentNavigtionNode = m.rowList
    NodeSetFocus(m.rowlist, true)
    
    m.rowlist.content = m.rowlist.content
    ScrollDown()
    HideLoadingScreen()
end function

function OnSearchError()
    
    m.rowlist.feeds = invalid
    m.rowlist.focusable = false
    HideLoadingScreen()
end function

function OnVisibilityChange()
    if m.top.visible = false
        ClearSearch()
    else
        OnTextChange()
    end if
end function

function ClearSearch()
    m.keyboard.text = ""
    m.rowlist.feeds = invalid
    m.rowlist.focusable = false
    ScrollUp()
end function

function ScrollUp() as void
    destination = m.scrollAnimationInterpolator.keyValue[0][1]
    current = m.container.translation[1]
    if current = destination
        return
    end if
    if m.scrollAnimation.state = "running" and m.scrollAnimationInterpolator.reverse = true
        return
    end if
    m.scrollAnimationInterpolator.reverse = true
    m.scrollAnimation.control = "start"
end function

function ScrollDown() as void
    destination = m.scrollAnimationInterpolator.keyValue[2][1]
    current = m.container.translation[1]
    if current = destination
        return
    end if
    if m.scrollAnimation.state = "running" and m.scrollAnimationInterpolator.reverse = false
        return
    end if
    m.scrollAnimationInterpolator.reverse = false
    m.scrollAnimation.control = "start"
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    navigation = NavigationKeyHandler(key, press)
    if navigation.handled
        m.currentNavigtionNode = navigation.node
        if m.currentNavigtionNode.isSameNode(m.navBar)
            m.currentNavigtionNode = m.suggestions
        end if
        if m.currentNavigtionNode.isSameNode(m.suggestions)
            OnSearchButtonFocused()
        end if
        if m.currentNavigtionNode.isSameNode(m.keyboard)
            
            m.keyboard.keyGrid.jumpToKey = [
                0
                0
                0
                0
            ]
        end if
        return true
    end if
    return false
end function