'import "pkg:/components/Services/Invidious/InvidiousService.bs"

' Loads the account's Shorts for the Shorts tab (the built-in backend's auth_shorts).
function ExecuteJob() as void
    input = JobGetInput()
    service = Invidious_InvidiousService(input.invidious)
    response = service.MakeRequest({
        id: "shorts"
        title: "Shorts"
        apiType: "Invidious"
        endpoint: "auth_shorts"
    }, {
        cancellation: JobGetCancellation()
    })
    if JobIsCancelled()
        JobCancel()
        return
    end if
    if not response.success
        JobError(ValidString(response.error))
        return
    end if
    JobSuccessData({
        items: ValidArray(response.result.items)
    })
end function