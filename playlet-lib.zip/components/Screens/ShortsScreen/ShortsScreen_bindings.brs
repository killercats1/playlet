' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "navBar": "/NavBar", 
            "invidious": "/Invidious", 
            "jobQueue": "/JobQueue", 
            "videoQueue": "/VideoQueue"
        },
        childProps: {
    
        }
    }
end function