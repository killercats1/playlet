'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"







function Init()
    InitializeBindings() ' auto-generated!
    m.top.focusable = true
    m.titleLabel = m.top.findNode("titleLabel")
    m.messageLabel = m.top.findNode("messageLabel")
    m.strip = m.top.findNode("strip")
    m.titleLabel.text = Tr("Shorts")
    m.videos = []
    m.outlines = []
    m.focusedIndex = 0
    m.loadJob = invalid
    m.loaded = false
end function

function OnNodeReady()
    SetNavigation(invalid, "back", m.navBar)
    SetNavigation(invalid, "left", m.navBar)
    m.top.observeFieldScoped("visible", FuncName(OnVisibleChange))
    Load()
end function

' Reload each time the tab is shown again after a failed or empty load.
function OnVisibleChange() as void
    if m.top.visible and not m.loaded
        Load()
    end if
end function

function Load() as void
    if m.loadJob <> invalid
        return
    end if
    m.messageLabel.text = Tr("Loading Shorts...")
    m.loadJob = JobSystem_CreateCallback(OnLoadDone)
    JobSystem_QueueJob(m.top.jobQueue, "ShortsFeedJob", {
        invidious: m.top.invidious
    }, m.loadJob)
end function

function OnLoadDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.loadJob = invalid
    info = event.getInfo()
    if not info.success
        if ValidString(info.error).InStr("Not authenticated") <> -1
            m.messageLabel.text = Tr("Sign in with your YouTube account (Profile tab) to see your Shorts.")
        else
            LogWarnNoTelemetry3("[ShortsScreen.bs:62]", "Shorts not available:", info.error)
            m.messageLabel.text = Tr("No Shorts to show right now.")
        end if
        return
    end if
    instance = m.top.invidious.callfunc("GetInstance", invalid)
    videos = []
    for each item in ValidArray(info.data.items)
        if IsAssociativeArray(item) and IsString(item.videoId)
            node = InvidiousContent_ToVideoContentNode(invalid, item, instance)
            
            node.addFields({
                isShort: true
            })
            videos.Push(node)
        end if
    end for
    if videos.Count() = 0
        m.messageLabel.text = Tr("No Shorts to show right now.")
        return
    end if
    m.loaded = true
    m.messageLabel.text = ""
    BuildTiles(videos)
end function

function BuildTiles(videos as object) as void
    while m.strip.getChildCount() > 0
        m.strip.removeChildIndex(0)
    end while
    m.videos = videos
    m.outlines = []
    titleFont = CreateObject("roSGNode", "Font")
    titleFont.uri = "pkg:/fonts/Roboto-Medium.ttf"
    titleFont.size = 18
    for i = 0 to videos.Count() - 1
        video = videos[i]
        tile = m.strip.createChild("Group")
        tile.translation = [
            i * (200 + 24)
            0
        ]
        poster = tile.createChild("Poster")
        poster.width = 200
        poster.height = 356
        poster.loadWidth = 200
        poster.loadHeight = 356
        
        poster.loadDisplayMode = "scaleToZoom"
        poster.failedBitmapUri = "pkg:/images/thumbnail-missing.jpg"
        poster.uri = ("https://i.ytimg.com/vi/" + bslib_toString(video.videoId) + "/hqdefault.jpg")
        outline = tile.createChild("Poster")
        outline.uri = "pkg:/images/focus-outline.$$RES$$.9.png"
        outline.translation = [
            -8
            -8
        ]
        outline.width = 200 + 16
        outline.height = 356 + 16
        outline.visible = false
        m.outlines.Push(outline)
        title = tile.createChild("Label")
        title.translation = [
            0
            356 + 10
        ]
        title.width = 200
        title.maxLines = 2
        title.wrap = true
        title.color = "#EBEBEBFF"
        title.font = titleFont
        title.text = video.title
    end for
    m.focusedIndex = 0
    UpdateFocus()
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    
    m.top.setFocus(true)
    UpdateFocus()
end function

function UpdateFocus() as void
    hasFocus = m.top.isInFocusChain()
    for i = 0 to m.outlines.Count() - 1
        m.outlines[i].visible = hasFocus and i = m.focusedIndex
    end for
    tileStride = 200 + 24
    offset = m.focusedIndex * tileStride - (1160 - tileStride)
    if offset < 0
        offset = 0
    end if
    m.strip.translation = [
        90 - offset
        100
    ]
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if press and m.videos.Count() > 0
        if key = "right" and m.focusedIndex < m.videos.Count() - 1
            m.focusedIndex += 1
            UpdateFocus()
            return true
        else if key = "left" and m.focusedIndex > 0
            m.focusedIndex -= 1
            UpdateFocus()
            return true
        else if key = "OK"
            PlayFrom(m.focusedIndex)
            return true
        end if
    end if
    if press and (key = "left" or key = "back")
        
        for each outline in m.outlines
            outline.visible = false
        end for
    end if
    return NavigationKeyHandler(key, press).handled
end function

' Queue all the Shorts and play from the selected one, so the player can flip with Up/Down.
function PlayFrom(index as integer) as void
    nodes = []
    for each video in m.videos
        node = video.clone(false)
        if not node.hasField("isShort")
            node.addFields({
                isShort: true
            })
        end if
        nodes.Push(node)
    end for
    
    lastNode = nodes[nodes.Count() - 1]
    lastNode.addFields({
        shortsMore: "v:" + lastNode.videoId
    })
    m.top.videoQueue.setQueueAndIndex = {
        videoNodes: nodes
        index: index
    }
    m.top.videoQueue.play = true
end function