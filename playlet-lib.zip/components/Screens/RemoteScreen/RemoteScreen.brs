'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/source/utils/ErrorUtils.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/MathUtils.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/StringUtils.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.webAppButton = m.top.findNode("WebAppButton")
    m.linkWithWifiButton = m.top.findNode("LinkWithWiFiButton")
    m.linkWithTvButton = m.top.findNode("LinkWithTvButton")
    m.webAppPanel = m.top.findNode("WebAppPanel")
    m.linkWithWifiPanel = m.top.findNode("LinkWithWiFiPanel")
    m.linkWithTvPanel = m.top.findNode("LinkWithTvPanel")
    m.webAppUrlLabel = m.top.findNode("WebAppUrlLabel")
    m.webAppQrCodePoster = m.top.findNode("WebAppQrCodePoster")
    m.wifiNameLabel = m.top.findNode("WifiNameLabel")
    m.wifiInstructionWithDeviceNameLabel = m.top.findNode("WifiInstructionWithDeviceNameLabel")
    m.linkCodeLabel = m.top.findNode("LinkCodeLabel")
    m.wifiInstructionWithDeviceNameLabel.drawingStyles = {
        "Bold": {
            "fontSize": 22
            "fontUri": "pkg:/fonts/Roboto-Medium.ttf"
            "color": "#DDDDDDFF"
        }
        "default": {
            "fontSize": 22
            "fontUri": "pkg:/fonts/Roboto-Regular.ttf"
            "color": "#DDDDDDFF"
        }
    }
end function

function OnNodeReady()
    SetNavigation(m.webAppButton, "down", m.linkWithWifiButton)
    SetNavigation(m.linkWithWifiButton, "down", m.linkWithTvButton)
    SetNavigation(m.linkWithTvButton, "up", m.linkWithWifiButton)
    SetNavigation(m.linkWithWifiButton, "up", m.webAppButton)
    SetNavigation(invalid, "back", m.navBar)
    SetNavigation(invalid, "left", m.navBar)
    address = m.webserver.callfunc("GetServerAddress", invalid)
    isValidAddress = not StringUtils_IsNullOrEmpty(address)
    if isValidAddress
        m.top.url = address
    end if
    m.top.findNode("noInternet").visible = not isValidAddress
    m.top.findNode("yesInternet").visible = isValidAddress
    m.top.focusable = isValidAddress
    m.top.observeField("visible", FuncName(OnVisibleChanged))
    m.linkWithWifiPanel.observeField("visible", FuncName(OnLinkWithWifiPanelVisibleChanged))
    m.linkWithWifiPanel.visible = false
    m.linkWithTvPanel.observeField("visible", FuncName(OnLinkWithTvPanelVisibleChanged))
    m.linkWithTvPanel.visible = false
    m.webAppButton.observeField("contentWidth", FuncName(OnButtonSizeChange))
    m.linkWithWifiButton.observeField("contentWidth", FuncName(OnButtonSizeChange))
    m.linkWithTvButton.observeField("contentWidth", FuncName(OnButtonSizeChange))
    OnButtonSizeChange()
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    if m.currentNavigtionNode = invalid
        m.currentNavigtionNode = m.webAppButton
    end if
    NodeSetFocus(m.currentNavigtionNode, true)
    ShowTab(m.currentNavigtionNode)
end function

function OnUrlSet()
    url = m.top.url
    m.webAppUrlLabel.text = url
    m.webAppQrCodePoster.text = url
end function

function OnButtonSizeChange()
    width1 = m.webAppButton.contentWidth
    width2 = m.linkWithWifiButton.contentWidth
    width3 = m.linkWithTvButton.contentWidth
    width = MathUtils_Max(width1, MathUtils_Max(width2, width3))
    width = MathUtils_Max(width, 380)
    m.webAppButton.minWidth = width
    m.linkWithWifiButton.minWidth = width
    m.linkWithTvButton.minWidth = width
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    navigation = NavigationKeyHandler(key, press)
    if navigation.handled
        ShowTab(navigation.node)
        return true
    end if
    return false
end function

function ShowTab(button as object)
    if button.isSameNode(m.webAppButton)
        m.webAppPanel.visible = true
        m.linkWithWifiPanel.visible = false
        m.linkWithTvPanel.visible = false
        m.currentNavigtionNode = button
    else if button.isSameNode(m.linkWithWifiButton)
        m.linkWithWifiPanel.visible = true
        m.webAppPanel.visible = false
        m.linkWithTvPanel.visible = false
        m.currentNavigtionNode = button
    else if button.isSameNode(m.linkWithTvButton)
        m.linkWithTvPanel.visible = true
        m.webAppPanel.visible = false
        m.linkWithWifiPanel.visible = false
        m.currentNavigtionNode = button
    end if
end function

function OnVisibleChanged()
    if not m.top.visible
        m.currentNavigtionNode = invalid
        m.webAppPanel.visible = true
        m.linkWithWifiPanel.visible = false
        m.linkWithTvPanel.visible = false
    end if
end function

function OnLinkWithWifiPanelVisibleChanged() as void
    if not m.linkWithWifiPanel.visible
        return
    end if
    deviceInfo = CreateObject("roDeviceInfo")
    connectionInfo = deviceInfo.GetConnectionInfo()
    if connectionInfo.type = "WiFiConnection"
        m.wifiNameLabel.text = connectionInfo.ssid
    else if connectionInfo.type = "WiredConnection"
        m.wifiNameLabel.text = Tr("Wired connection")
    else
        m.wifiNameLabel.text = "N/A"
    end if
    deviceName = ("<Bold>" + chr(34) + bslib_toString(m.loungeService.deviceName) + chr(34) + "</Bold>")
    m.wifiInstructionWithDeviceNameLabel.text = Tr("Tap the cast icon and select %1").Replace("%1", deviceName)
end function

function OnLinkWithTvPanelVisibleChanged()
    if m.linkWithTvPanel.visible
        GeneratePairingCode()
    else
        if m.loungeGenerateManualPairingCodeJob <> invalid
            m.loungeGenerateManualPairingCodeJob.cancel = true
            m.loungeGenerateManualPairingCodeJob = invalid
        end if
        m.linkCodeLabel.text = ""
    end if
end function

function GeneratePairingCode()
    if m.loungeGenerateManualPairingCodeJob <> invalid
        m.loungeGenerateManualPairingCodeJob.cancel = true
    end if
    m.linkCodeLabel.text = Tr("Loading...")
    input = {
        loungeService: m.loungeService
        loungeToken: m.loungeService.loungeToken
        screenId: m.loungeService.screenId
        ' Use deviceName as screenName
        screenName: m.loungeService.deviceName
        deviceId: m.loungeService.deviceId
    }
    m.loungeGenerateManualPairingCodeJob = JobSystem_CreateCallback(OnLoungeGenerateManualPairingCodeJobDone)
    JobSystem_QueueJob(m.jobQueue, "LoungeGenerateManualPairingCodeJob", input, m.loungeGenerateManualPairingCodeJob)
end function

function OnLoungeGenerateManualPairingCodeJobDone(event as object) as void
    callback = event.getRoSGNode()
    JobSystem_UnobserveCallback(callback)
    m.loungeGenerateManualPairingCodeJob = invalid
    info = event.GetInfo()
    if info.cancel
        return
    end if
    if not info.success
        message = Tr("Failed to generate manual pairing code") + (chr(10) + bslib_toString(info.error))
        DialogUtils_ShowDialogEx({
            message: message
            title: Tr("TV code error")
            large: true
        })
        return
    end if
    m.linkCodeLabel.text = info.data.code
end function