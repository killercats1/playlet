' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "navBar": "/NavBar", 
            "webServer": "/WebServer", 
            "loungeService": "/LoungeService", 
            "jobQueue": "/JobQueue"
        },
        childProps: {
    
        }
    }
end function