'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
' preferences = invalid loads the rows as listed, without the "Edit home screen" layout.
function HomeScreenUtils_GetFeed(feedFileName as string, preferences as dynamic) as object
    feed = StringUtils_ParseJsonSafe(ReadAsciiFile(feedFileName))
    for each item in feed
        item.title = Tr(item.title)
        for each feedSource in item.feedSources
            feedSource.title = Tr(feedSource.title)
        end for
    end for
    if preferences = invalid
        return HomeScreenUtils_ExpandRows(feed)
    end if
    homeLayout = preferences["misc.home_screen_layout"]
    if not IsArray(homeLayout) or homeLayout.Count() = 0
        return HomeScreenUtils_ExpandRows(feed)
    end if
    feedItems = {}
    for each item in feed
        feedItems[item["id"]] = item
    end for
    
    filteredFeed = []
    seenIds = {}
    for each item in homeLayout
        if IsAssociativeArray(item) and IsString(item.id)
            seenIds[item.id] = true
            if item.enabled = true and feedItems[item.id] <> invalid
                filteredFeed.push(feedItems[item.id])
            end if
        end if
    end for
    for each item in feed
        if not seenIds.DoesExist(item["id"])
            filteredFeed.push(item)
        end if
    end for
    return HomeScreenUtils_ExpandRows(filteredFeed)
end function

' A section with "expandRows": N becomes N rows, each asking for its own index (the Home shelves).
function HomeScreenUtils_ExpandRows(feed as object) as object
    expanded = []
    for each item in feed
        count = ValidInt(item.expandRows)
        if count <= 0
            expanded.Push(item)
            continue for
        end if
        for i = 1 to count
            copy = StringUtils_ParseJsonSafe(FormatJson(item))
            copy.Delete("expandRows")
            copy.id = (bslib_toString(item.id) + "_" + bslib_toString(i))
            for each feedSource in copy.feedSources
                feedSource.id = (bslib_toString(feedSource.id) + "_" + bslib_toString(i))
                queryParams = feedSource.queryParams
                if not IsAssociativeArray(queryParams)
                    queryParams = {}
                end if
                queryParams.index = i.ToStr()
                feedSource.queryParams = queryParams
            end for
            expanded.Push(copy)
        end for
    end for
    return expanded
end function