'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.types.bs"
'import "pkg:/components/ContextMenu/ContextMenuUtils.bs"
'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/Screens/HomeScreen/HomeScreenUtils.bs"
'import "pkg:/components/Screens/HomeScreen/WhatsNew.bs"
'import "pkg:/components/Services/ApplicationInfo/LibManifestUtils.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/RegistryUtils.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"
' Shared by the row screens (Home, Subscriptions, Library): each has its own Init file that imports this.

' the row list moves down to make room for the topic chips while they show


' coming back to a row screen (Home, Subscriptions, Library...) after this long reloads it (like YouTube, so the feed isn't hours old)


function OnNodeReady()
    SetNavigation(invalid, "back", m.navBar)
    SetNavigation(invalid, "left", m.navBar)
    m.rowList.callfunc("BindNode", invalid)
    
    m.chipBar = m.top.findNode("chipBar")
    if m.chipBar <> invalid
        SetNavigation(m.rowList, "up", m.chipBar)
        SetNavigation(m.chipBar, "down", m.rowList)
        m.chipBar.observeFieldScoped("selected", FuncName(OnChipSelected))
        m.chipBar.observeFieldScoped("hasChips", FuncName(OnHasChipsChange))
        m.rowList.observeFieldScoped("content", FuncName(OnRowListContentChange))
        m.chipBar.chips = TopicChips("")
    end if
    
    if m.top.useHomeLayout
        m.preferences.observeFieldScoped("misc.home_screen_layout", FuncName(OnHomeLayoutChange))
        
        m.rowList.observeFieldScoped("someContentReady", FuncName(OnSomeContentReady))
        ShowUpdatedCard()
        
        profilesService = m.rowList.profilesService
        if profilesService <> invalid
            profilesService.observeFieldScoped("currentProfile", FuncName(OnCurrentProfileForSignIn))
            OnCurrentProfileForSignIn()
        end if
    end if
    OnHomeLayoutChange()
end function

function OnCurrentProfileForSignIn() as void
    if m.watchedProfile <> invalid
        m.watchedProfile.unobserveFieldScoped("authState")
        m.watchedProfile = invalid
    end if
    profile = m.rowList.profilesService.currentProfile
    if profile = invalid
        return
    end if
    m.watchedProfile = profile
    profile.observeFieldScoped("authState", FuncName(CheckSignIn))
    CheckSignIn()
end function

' Once per launch: the account needs signing in again (Profile tab).
function CheckSignIn() as void
    if m.signInDialogShown = true or m.watchedProfile = invalid
        return
    end if
    if m.watchedProfile.authState <> "NeedsReauth"
        return
    end if
    m.signInDialogShown = true
    DialogUtils_ShowDialogEx({
        title: Tr("Session expired")
        message: Tr("The session has expired. Please sign in again with this profile, or switch to another profile.")
    })
end function

function OnSomeContentReady() as void
    if m.rowList.someContentReady = true
        ShowUpdatedCard()
    end if
end function

'' After an update arrived (auto-update): a message with the new version and what's new, once per version. It
' waits until the launcher's loading screen is gone (Home gets focus while it still covers everything). A message
' box rather than the small card: the card never showed up on the TV.
function ShowUpdatedCard() as void
    if not m.top.useHomeLayout or m.updatedCardDone = true
        return
    end if
    current = LibManifestUtils_GetLibVersion()
    if ValidString(RegistryUtils_Read("last_lib_version")) = current
        m.updatedCardDone = true
        return
    end if
    loadingIndicator = m.global.loadingIndicator
    if loadingIndicator <> invalid and loadingIndicator.visible = true
        if m.updatedCardTimer = invalid
            m.updatedCardTimer = m.top.createChild("Timer")
            m.updatedCardTimer.duration = 1
            m.updatedCardTimer.repeat = false
            m.updatedCardTimer.observeFieldScoped("fire", FuncName(ShowUpdatedCard))
        end if
        m.updatedCardTries = ValidInt(m.updatedCardTries) + 1
        if m.updatedCardTries <= 60
            m.updatedCardTimer.control = "start"
        end if
        return
    end if
    m.updatedCardDone = true
    RegistryUtils_Write("last_lib_version", current)
    DialogUtils_ShowDialogEx({
        title: Tr("Updated to v%1").Replace("%1", current)
        message: "Welcome to Playlet 3! Chapters: the player's progress bar shows the chapter you're in. Comments: Video details shows the top comments (press Down to scroll). Plus a Music row fallback and a faster Home."
    })
end function

function OnHomeLayoutChange() as void
    preferences = invalid
    if m.top.useHomeLayout
        preferences = m.preferences
    end if
    m.rowList.feeds = HomeScreenUtils_GetFeed(m.top.feedFile, preferences)
    m.loadedAt = CreateObject("roDateTime").AsSeconds()
end function

function RefreshIfStale() as void
    if not IsInt(m.loadedAt)
        return
    end if
    now = CreateObject("roDateTime").AsSeconds()
    if now - m.loadedAt < 1800
        return
    end if
    LogInfo4("[RowsScreenLogic.bs:142]", "Rows were loaded", now - m.loadedAt, "seconds ago: refreshing")
    m.loadedAt = now
    m.rowList.callfunc("Refresh", invalid)
end function

' Watches the Recommended row so its topic chips (sent by YouTube with the feed) can show above the rows.
function OnRowListContentChange() as void
    content = m.rowList.content
    if content = invalid
        return
    end if
    for each row in content.getChildren(-1, 0)
        feedSources = row.feedSources
        if IsArray(feedSources) and feedSources.Count() > 0 and feedSources[0].id = "inv_auth_recommended"
            row.observeFieldScoped("feedSources", FuncName(OnRecommendedFeedSourcesChange))
        end if
    end for
end function

function OnRecommendedFeedSourcesChange(event as object) as void
    feedSources = event.getData()
    if not IsArray(feedSources) or feedSources.Count() = 0 or not IsAssociativeArray(feedSources[0].state)
        return
    end if
    chips = feedSources[0].state.sortOptions
    if IsArray(chips) and chips.Count() > 0
        m.chipBar.chips = chips
    end if
end function

function OnHasChipsChange() as void
    if m.chipBar.hasChips
        m.rowList.translation = [
            0
            90
        ]
    else
        m.rowList.translation = [
            0
            50
        ]
    end if
end function

' Playlet's own topic chips (YouTube sends none to the TV app); the backend maps each topic to a feed.
function TopicChips(selectedTopic as string) as object
    chips = [
        {
            title: Tr("All")
            topic: ""
        }
        {
            title: Tr("Music")
            topic: "music"
        }
        {
            title: Tr("News")
            topic: "news"
        }
        {
            title: Tr("Gaming")
            topic: "gaming"
        }
        {
            title: Tr("Live")
            topic: "live"
        }
    ]
    for each chip in chips
        chip.isSelected = chip.topic = selectedTopic
    end for
    return chips
end function

' Reloads Recommended for the picked chip: one of Playlet's topics, or a YouTube chip (its token goes to the
' built-in backend as "chip", not "continuation", which paging adds on its own).
function OnChipSelected() as void
    chip = m.chipBar.selected
    if not IsAssociativeArray(chip)
        return
    end if
    queryParams = invalid
    if IsString(chip.topic)
        if chip.topic <> ""
            queryParams = {
                topic: chip.topic
            }
        end if
        m.chipBar.chips = TopicChips(chip.topic)
    else if IsString(chip.continuation)
        queryParams = {
            chip: chip.continuation
        }
    else
        return
    end if
    feeds = m.rowList.feeds
    if not IsArray(feeds)
        return
    end if
    for each feed in feeds
        if IsArray(feed.feedSources)
            for each feedSource in feed.feedSources
                if feedSource.id = "inv_auth_recommended"
                    feedSource.queryParams = queryParams
                end if
            end for
        end if
    end for
    m.rowList.feeds = feeds
    NodeSetFocus(m.rowList, true)
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    RefreshIfStale()
    ShowUpdatedCard()
    NodeSetFocus(m.rowList, true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if NavigationKeyHandler(key, press).handled
        return true
    end if
    return false
end function

function GetContextMenuOptionsForItem(_rowItem as object) as object
    title = Tr("Refresh Home")
    if not m.top.useHomeLayout
        title = Tr("Refresh")
    end if
    refresh = ContextMenuUtils_CreateOption(title, m.rowList, "Refresh", [
        invalid
    ])
    return [
        refresh
    ]
end function