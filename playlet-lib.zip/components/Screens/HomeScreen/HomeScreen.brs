'import "pkg:/components/Screens/HomeScreen/RowsScreenLogic.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.top.focusable = true
    m.rowList = m.top.FindNode("rowList")
    m.rowList.screen = m.top
end function