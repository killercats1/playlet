' A no op function to silence BS1067 errors
function OnNodeReady()
end function