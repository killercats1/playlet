'import "pkg:/source/utils/NodePathUtils.bs"

' Bind all nodes that registered for auto-binding
' Should be called once from a root node
' Can be called later to rebind nodes that were added after the first call
function AutoBindSceneGraph() as void
    if not m.global.hasField("AutoBindNodes")
        m.global.addField("AutoBindNodes", "nodearray", false)
    end if
    nodes = m.global.AutoBindNodes
    m.global.AutoBindNodes = []
    for each node in nodes
        node.callfunc("BindNodeFieldsAndProps", invalid)
    end for
    for each node in nodes
        node.callfunc("BindScopeFields", invalid)
    end for
    for each node in nodes
        node.binding_done = true
    end for
end function

' Bind the node fields, to be called with interface function
function BindNodeFieldsAndProps(_unused as dynamic) as void
    node = m.top
    bindings = node.bindings
    if bindings = invalid
        return
    end if
    if bindings.fields <> invalid
        for each fieldId in bindings.fields
            if node.getField(fieldId) <> invalid
                continue for
            end if
            reference = NodePathUtils_FindNodeFromPath(node, bindings.fields[fieldId])
            if reference <> invalid
                node[fieldId] = reference
            end if
        end for
    end if
    if bindings.childProps <> invalid
        for each nodeId in bindings.childProps
            child = node.findNode(nodeId)
            if child = invalid
                continue for
            end if
            childProps = bindings.childProps[nodeId]
            for each childPropId in childProps
                if child.getField(childPropId) <> invalid
                    continue for
                end if
                reference = NodePathUtils_FindNodeFromPath(child, childProps[childPropId])
                if reference <> invalid
                    child[childPropId] = reference
                end if
            end for
        end for
    end if
end function

' Create scoped fields (m.fieldName) for all fields in this node
' To be called after BindNodeFieldsAndProps
function BindScopeFields(_unused as dynamic)
    types = m.top.getFieldTypes()
    for each key in types
        if m.DoesExist(key)
            continue for
        end if
        if types[key] <> "node"
            continue for
        end if
        node = m.top.getField(key)
        m[key] = node
    end for
end function

' Bind a single node. This for nodes created dynamically, and all its dependencies are expected to be bound already
function BindNode(_unused as dynamic)
    RemoveNodeFromGlobalAutoBind()
    BindNodeFieldsAndProps(invalid)
    BindScopeFields(invalid)
    m.top.binding_done = true
end function

function RemoveNodeFromGlobalAutoBind() as void
    if not m.global.hasField("AutoBindNodes")
        return
    end if
    nodes = m.global.AutoBindNodes
    for i = 0 to nodes.Count() - 1
        if m.top.isSameNode(nodes[i])
            nodes.Delete(i)
            m.global.AutoBindNodes = nodes
            return
        end if
    end for
end function

function OnBindingSetRegisterAutoBind()
    if not m.global.hasField("AutoBindNodes")
        m.global.addField("AutoBindNodes", "nodearray", false)
    end if
    nodes = m.global.AutoBindNodes
    newNodes = [
        m.top
    ]
    newNodes.append(nodes)
    m.global.AutoBindNodes = newNodes
end function