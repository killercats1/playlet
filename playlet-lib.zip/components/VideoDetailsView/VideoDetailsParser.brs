'import "pkg:/source/utils/ObjectUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
' Pulls the details shown on the video details page out of a video's info, as display text:
' { title, author, authorId, viewsText, dateText, likesText, subscribersText, description }.
' Anything missing is left empty, so the page just doesn't show that line.
' YouTube's /next (watch page) response, used by the built-in backend.
function VideoDetailsParser_FromWatchNext(payload as object) as object
    details = VideoDetailsParser_Empty()
    contents = ObjectUtils_Dig(payload, [
        "contents"
        "twoColumnWatchNextResults"
        "results"
        "results"
        "contents"
    ])
    if not IsArray(contents)
        return details
    end if
    for each item in contents
        if not IsAssociativeArray(item)
            continue for
        end if
        primary = item["videoPrimaryInfoRenderer"]
        if IsAssociativeArray(primary)
            details.title = VideoDetailsParser_Text(primary["title"])
            details.viewsText = VideoDetailsParser_Text(ObjectUtils_Dig(primary, [
                "viewCount"
                "videoViewCountRenderer"
                "viewCount"
            ]))
            details.dateText = VideoDetailsParser_Text(primary["dateText"])
            if details.dateText = ""
                details.dateText = VideoDetailsParser_Text(primary["relativeDateText"])
            end if
            likeButton = VideoDetailsParser_FindKey(primary["videoActions"], "likeButtonViewModel", 12)
            buttonViewModel = VideoDetailsParser_FindKey(likeButton, "buttonViewModel", 12)
            if IsAssociativeArray(buttonViewModel)
                likes = ValidString(buttonViewModel["title"])
                
                if likes.Len() < 12 and CreateObject("roRegex", "[0-9]", "").IsMatch(likes)
                    details.likesText = likes
                end if
            end if
        end if
        secondary = item["videoSecondaryInfoRenderer"]
        if IsAssociativeArray(secondary)
            owner = ObjectUtils_Dig(secondary, [
                "owner"
                "videoOwnerRenderer"
            ])
            if IsAssociativeArray(owner)
                details.author = VideoDetailsParser_Text(owner["title"])
                details.authorId = ValidString(ObjectUtils_Dig(owner, [
                    "navigationEndpoint"
                    "browseEndpoint"
                    "browseId"
                ]))
                details.subscribersText = VideoDetailsParser_Text(owner["subscriberCountText"])
            end if
            details.description = ValidString(ObjectUtils_Dig(secondary, [
                "attributedDescription"
                "content"
            ]))
            if details.description = ""
                details.description = VideoDetailsParser_Text(secondary["description"])
            end if
        end if
    end for
    return details
end function

' An Invidious /api/v1/videos/:id response, used with an Invidious instance.
function VideoDetailsParser_FromInvidious(video as object) as object
    details = VideoDetailsParser_Empty()
    if not IsAssociativeArray(video)
        return details
    end if
    details.title = ValidString(video.title)
    details.author = ValidString(video.author)
    details.authorId = ValidString(video.authorId)
    details.subscribersText = ValidString(video.subCountText)
    details.dateText = ValidString(video.publishedText)
    details.description = ValidString(video.description)
    if IsNumber(video.viewCount)
        details.viewsText = (bslib_toString(VideoDetailsParser_FormatCount(video.viewCount)) + " views")
    end if
    if IsNumber(video.likeCount) and video.likeCount > 0
        details.likesText = VideoDetailsParser_FormatCount(video.likeCount)
    end if
    return details
end function

function VideoDetailsParser_Empty() as object
    return {
        title: ""
        author: ""
        authorId: ""
        viewsText: ""
        dateText: ""
        likesText: ""
        subscribersText: ""
        description: ""
        comments: []
    }
end function

' simpleText / runs / attributed "content" text -> string
function VideoDetailsParser_Text(data as dynamic) as string
    if IsString(data)
        return data
    end if
    if not IsAssociativeArray(data)
        return ""
    end if
    if IsString(data["simpleText"])
        return data["simpleText"]
    end if
    if IsString(data["content"])
        return data["content"]
    end if
    if IsArray(data["runs"])
        joined = ""
        for each textRun in data["runs"]
            if IsAssociativeArray(textRun) and IsString(textRun["text"])
                joined += textRun["text"]
            end if
        end for
        return joined
    end if
    return ""
end function

' The first value under `key`, searching nested objects/arrays up to `depth` levels down.
function VideoDetailsParser_FindKey(data as dynamic, key as string, depth as integer) as dynamic
    if depth < 0
        return invalid
    end if
    if IsAssociativeArray(data)
        if data.DoesExist(key)
            return data[key]
        end if
        for each childKey in data
            found = VideoDetailsParser_FindKey(data[childKey], key, depth - 1)
            if found <> invalid
                return found
            end if
        end for
    else if IsArray(data)
        for each child in data
            found = VideoDetailsParser_FindKey(child, key, depth - 1)
            if found <> invalid
                return found
            end if
        end for
    end if
    return invalid
end function

' 1234567 -> "1,234,567"
function VideoDetailsParser_FormatCount(value as dynamic) as string
    digits = value.ToStr()
    result = ""
    while digits.Len() > 3
        result = "," + digits.Right(3) + result
        digits = digits.Left(digits.Len() - 3)
    end while
    return digits + result
end function

' The continuation token of the watch page's comments section, or "".
function VideoDetailsParser_CommentsToken(payload as object) as string
    contents = ObjectUtils_Dig(payload, [
        "contents"
        "twoColumnWatchNextResults"
        "results"
        "results"
        "contents"
    ])
    if not IsArray(contents)
        return ""
    end if
    for each item in contents
        section = ObjectUtils_Dig(item, [
            "itemSectionRenderer"
        ])
        if IsAssociativeArray(section) and ValidString(section["sectionIdentifier"]) = "comment-item-section"
            return ValidString(VideoDetailsParser_FindKey(VideoDetailsParser_FindKey(section, "continuationCommand", 10), "token", 2))
        end if
    end for
    return ""
end function

' The comments page -> [{ author, body, likes }], at most 20. Newer pages keep the comments in
' commentEntityPayload entities, older ones in commentRenderer.
function VideoDetailsParser_ParseComments(payload as dynamic) as object
    found = []
    VideoDetailsParser_CollectComments(payload, found, 30)
    return found
end function

function VideoDetailsParser_CollectComments(data as dynamic, found as object, depth as integer) as void
    if depth < 0 or found.Count() >= 20
        return
    end if
    if IsAssociativeArray(data)
        entity = data["commentEntityPayload"]
        if IsAssociativeArray(entity)
            body = ValidString(ObjectUtils_Dig(entity, [
                "properties"
                "content"
                "content"
            ]))
            if body <> ""
                found.Push({
                    author: ValidString(ObjectUtils_Dig(entity, [
                        "author"
                        "displayName"
                    ]))
                    body: body
                    likes: ValidString(ObjectUtils_Dig(entity, [
                        "toolbar"
                        "likeCountNotliked"
                    ]))
                })
            end if
            return
        end if
        renderer = data["commentRenderer"]
        if IsAssociativeArray(renderer)
            body = VideoDetailsParser_Text(renderer["contentText"])
            if body <> ""
                found.Push({
                    author: VideoDetailsParser_Text(renderer["authorText"])
                    body: body
                    likes: VideoDetailsParser_Text(renderer["voteCount"])
                })
            end if
            return
        end if
        for each key in data
            VideoDetailsParser_CollectComments(data[key], found, depth - 1)
        end for
    else if IsArray(data)
        for each child in data
            VideoDetailsParser_CollectComments(child, found, depth - 1)
        end for
    end if
end function