'import "pkg:/components/ChannelView/ChannelUtils.bs"
'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.top.focusable = true
    m.thumbnail = m.top.findNode("thumbnail")
    m.titleLabel = m.top.findNode("titleLabel")
    m.authorLabel = m.top.findNode("authorLabel")
    m.subscribersLabel = m.top.findNode("subscribersLabel")
    m.statsLabel = m.top.findNode("statsLabel")
    m.likesLabel = m.top.findNode("likesLabel")
    m.descriptionLabel = m.top.findNode("descriptionLabel")
    m.playButton = m.top.findNode("playButton")
    m.channelButton = m.top.findNode("channelButton")
    m.watchLaterButton = m.top.findNode("watchLaterButton")
    m.subscribeButton = m.top.findNode("subscribeButton")
    m.subscribeJob = invalid
    m.subscriptionChecked = ""
    m.detailsJob = invalid
    m.watchLaterJob = invalid
    m.authorId = ""
end function

function OnNodeReady()
    m.playButton.text = Tr("Play Video")
    m.channelButton.text = Tr("Open Channel")
    
    m.channelButton.translation = [
        m.playButton.translation[0] + m.playButton.boundingRect().width + 20
        m.playButton.translation[1]
    ]
    
    profile = CurrentProfile()
    canSave = profile <> invalid and profile.type = "youtube"
    m.watchLaterButton.text = Tr("Save to Watch later")
    m.watchLaterButton.visible = canSave
    m.watchLaterButton.focusable = canSave
    UpdateButtonLayout()
    m.playButton.ObserveField("buttonSelected", FuncName(OnPlaySelected))
    m.channelButton.ObserveField("buttonSelected", FuncName(OnChannelSelected))
    m.watchLaterButton.ObserveField("buttonSelected", FuncName(OnWatchLaterSelected))
    m.subscribeButton.ObserveField("buttonSelected", FuncName(OnSubscribeSelected))
    UpdateSubscribeButton()
    LoadDetails()
end function

' The signed-in profile, or invalid (also while the services aren't bound yet).
function CurrentProfile() as dynamic
    profilesService = m.top.profilesService
    if profilesService = invalid
        return invalid
    end if
    return profilesService.currentProfile
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.playButton, true)
end function

function OnContentSet() as void
    content = m.top.content
    if content = invalid
        return
    end if
    m.thumbnail.uri = content.thumbnail
    m.titleLabel.text = content.title
    m.authorLabel.text = content.author
    stats = []
    for each text in [
        content.viewCountText
        content.publishedText
        content.lengthText
    ]
        if not StringUtils_IsNullOrEmpty(text)
            stats.Push(text)
        end if
    end for
    m.statsLabel.text = stats.Join(" • ")
    SetAuthorId(ValidString(content.authorId))
    LoadDetails()
end function

function LoadDetails() as void
    content = m.top.content
    if content = invalid or m.top.jobQueue = invalid or m.detailsJob <> invalid
        return
    end if
    m.detailsJob = JobSystem_CreateCallback(OnDetailsJobDone)
    JobSystem_QueueJob(m.top.jobQueue, "VideoDetailsJob", {
        videoId: content.videoId
        invidious: m.top.invidious
        preferences: m.top.preferences
    }, m.detailsJob)
end function

function OnDetailsJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    info = event.getInfo()
    if not info.success or not IsAssociativeArray(info.data) or not IsAssociativeArray(info.data.details)
        LogWarnNoTelemetry3("[VideoDetailsView.bs:109]", "Video details not available:", info.error)
        return
    end if
    details = info.data.details
    if details.title <> ""
        m.titleLabel.text = details.title
    end if
    if details.author <> ""
        m.authorLabel.text = details.author
    end if
    m.subscribersLabel.text = details.subscribersText
    stats = []
    for each text in [
        details.viewsText
        details.dateText
    ]
        if text <> ""
            stats.Push(text)
        end if
    end for
    if stats.Count() > 0
        m.statsLabel.text = stats.Join(" • ")
    end if
    if details.likesText <> ""
        m.likesLabel.text = Tr("%1 likes").Replace("%1", details.likesText)
    end if
    m.descriptionLabel.text = DescriptionWithComments(details)
    m.descriptionLabel.focusable = true
    if details.authorId <> ""
        SetAuthorId(details.authorId)
    end if
end function

function SetAuthorId(authorId as string) as void
    m.authorId = authorId
    hasChannel = authorId <> ""
    m.channelButton.visible = hasChannel
    m.channelButton.focusable = hasChannel
    UpdateSubscribeButton()
end function

' Subscribe / Unsubscribe for the video's channel, once it's known; asks whether the account already follows it.
function UpdateSubscribeButton() as void
    profile = CurrentProfile()
    show = m.authorId <> "" and profile <> invalid
    m.subscribeButton.visible = show
    m.subscribeButton.focusable = show
    OnIsSubscribedChange()
    if show and m.subscriptionChecked <> m.authorId
        m.subscriptionChecked = m.authorId
        JobSystem_QueueJob(m.top.jobQueue, "FetchSubscriptionStatusJob", {
            channelView: m.top
            ucid: m.authorId
            profile: profile
            invidious: m.top.invidious
        }, JobSystem_CreateCallback())
    end if
    UpdateButtonLayout()
end function

function OnIsSubscribedChange() as void
    if m.subscribeButton = invalid
        return
    end if
    if m.top.isSubscribed
        m.subscribeButton.text = Tr("Unsubscribe")
    else
        m.subscribeButton.text = Tr("Subscribe")
    end if
    if m.subscribeButton.visible
        UpdateButtonLayout()
    end if
end function

function OnSubscribeSelected() as void
    profile = CurrentProfile()
    if m.authorId = "" or profile = invalid
        return
    end if
    if m.subscribeJob <> invalid
        m.subscribeJob.cancel = true
    end if
    m.subscribeJob = JobSystem_CreateCallback()
    JobSystem_QueueJob(m.top.jobQueue, "SubscribeJob", {
        channelView: m.top
        invidious: m.top.invidious
        ucid: m.authorId
        subscribe: not m.top.isSubscribed
        profile: profile
    }, m.subscribeJob)
end function

' The visible buttons in a row, left to right, with Left/Right between neighbors.
function UpdateButtonLayout() as void
    buttons = [
        m.playButton
    ]
    if m.channelButton.visible
        buttons.Push(m.channelButton)
    end if
    if m.subscribeButton.visible
        buttons.Push(m.subscribeButton)
    end if
    if m.watchLaterButton.visible
        buttons.Push(m.watchLaterButton)
    end if
    
    if IsAssociativeArray(m._navigation)
        for each direction in [
            "left"
            "right"
        ]
            links = m._navigation[direction]
            if IsArray(links)
                kept = []
                for each link in links
                    if link.fromNode = invalid or not (link.fromNode.isSameNode(m.playButton) or link.fromNode.isSameNode(m.channelButton) or link.fromNode.isSameNode(m.subscribeButton) or link.fromNode.isSameNode(m.watchLaterButton))
                        kept.Push(link)
                    end if
                end for
                m._navigation[direction] = kept
            end if
        end for
    end if
    x = m.playButton.translation[0]
    y = m.playButton.translation[1]
    for i = 0 to buttons.Count() - 1
        buttons[i].translation = [
            x
            y
        ]
        x += buttons[i].boundingRect().width + 20
        if i > 0
            SetNavigation(buttons[i], "left", buttons[i - 1])
            SetNavigation(buttons[i - 1], "right", buttons[i])
        end if
    end for
end function

function OnWatchLaterSelected() as void
    content = m.top.content
    if content = invalid or StringUtils_IsNullOrEmpty(content.videoId) or m.watchLaterJob <> invalid
        return
    end if
    m.watchLaterJob = JobSystem_CreateCallback(OnWatchLaterJobDone)
    JobSystem_QueueJob(m.top.jobQueue, "WatchLaterJob", {
        videoId: content.videoId
        profile: CurrentProfile()
    }, m.watchLaterJob)
end function

function OnWatchLaterJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.watchLaterJob = invalid
    if event.getInfo().success = true
        m.watchLaterButton.text = Tr("Saved to Watch later")
    else
        m.watchLaterButton.text = Tr("Couldn't save to Watch later")
    end if
end function

function OnPlaySelected() as void
    content = m.top.content
    if content = invalid
        return
    end if
    m.top.videoQueue.playVideo = content
end function

function OnChannelSelected() as void
    if m.authorId = ""
        return
    end if
    channel = InvidiousContent_ToChannelContentNode(invalid, {
        authorId: m.authorId
    })
    ChannelUtils_Open(channel, m.top.appController)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    
    if press and m.descriptionLabel.hasFocus()
        if key = "back" or key = "up"
            NodeSetFocus(m.playButton, true)
            return true
        end if
    end if
    if press and key = "down" and m.descriptionLabel.text <> "" and not m.descriptionLabel.hasFocus()
        NodeSetFocus(m.descriptionLabel, true)
        return true
    end if
    if NavigationKeyHandler(key, press).handled
        return true
    end if
    if press and key = "back"
        Close()
        return true
    end if
    return false
end function

' The description, then the top comments.
function DescriptionWithComments(details as object) as string
    parts = []
    if details.description <> ""
        parts.Push(details.description)
    end if
    if IsArray(details.comments) and details.comments.Count() > 0
        lines = [
            Tr("Comments")
        ]
        for each comment in details.comments
            heading = comment.author
            if comment.likes <> "" and comment.likes <> "0"
                heading += "  •  " + Tr("%1 likes").Replace("%1", comment.likes)
            end if
            lines.Push(heading + Chr(10) + comment.body)
        end for
        parts.Push(lines.Join(Chr(10) + Chr(10)))
    end if
    return parts.Join(Chr(10) + Chr(10) + "────────" + Chr(10) + Chr(10))
end function

function Close() as void
    if m.detailsJob <> invalid
        m.detailsJob.cancel = true
        m.detailsJob = invalid
    end if
    m.top.appController.callfunc("PopScreen", invalid)
end function