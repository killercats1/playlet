' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "appController": "/AppController", 
            "invidious": "/Invidious", 
            "preferences": "/Preferences", 
            "jobQueue": "/JobQueue", 
            "videoQueue": "/VideoQueue", 
            "profilesService": "/ProfilesService"
        },
        childProps: {
    
        }
    }
end function