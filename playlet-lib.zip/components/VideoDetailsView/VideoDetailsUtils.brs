function VideoDetailsUtils_Open(video as object, appController = invalid as object)
    view = CreateObject("roSGNode", "VideoDetailsView")
    if appController = invalid
        appController = m.appController
    end if
    appController.callfunc("PushScreen", view)
    view.callfunc("BindNode", invalid)
    view.content = video
end function