'import "pkg:/components/Services/ApplicationInfo/LibManifestUtils.bs"
'import "pkg:/source/utils/Locale.bs"



function Init()
    m.top.text = GetAppVersion()
end function

' TODO:P2: refactor and move to appropriate place, reuse with web app
function GetAppVersion() as string
    
    version = "v" + LibManifestUtils_GetLibVersion()
    scene = m.top.getScene()
    if scene.playletLibLoadedUrl <> invalid
        libUrl = scene.playletLibLoadedUrl.link
        libUrlType = scene.playletLibLoadedUrl.type
        if libUrlType = "custom" and (libUrl = "https://github.com/iBicha/playlet/releases/download/canary/playlet-lib.zip" or libUrl = "https://github.com/iBicha/playlet/releases/download/canary/playlet-lib.squashfs.pkg")
            version += "-canary"
        end if
        
        if libUrlType = "embedded-zip"
            version += " " + Tr("(built-in)")
        else if libUrlType = "update-zip-plain"
            
            version += " " + Tr("(saved copy)")
        end if
    end if
    return version
end function