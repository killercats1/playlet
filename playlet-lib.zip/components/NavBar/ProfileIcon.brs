'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    m.buttonIcon = m.top.findNode("buttonIcon")
    m.circlePoster = m.top.findNode("circlePoster")
    m.circlePosterInner = m.top.findNode("circlePosterInner")
    m.letterLabel = m.top.findNode("letterLabel")
    profilesService = m.top.getScene().findNode("ProfilesService")
    if profilesService <> invalid
        m.profilesService = profilesService
        profilesService.observeField("currentProfile", FuncName(OnCurrentProfile))
        OnCurrentProfile()
    end if
end function

function OnCurrentProfile() as void
    currentProfile = m.profilesService.currentProfile
    if currentProfile = invalid
        m.circlePoster.visible = false
        m.buttonIcon.visible = true
        return
    end if
    thumbnail = currentProfile.thumbnail
    if not StringUtils_IsNullOrEmpty(thumbnail)
        m.circlePosterInner.uri = thumbnail
        
        m.circlePosterInner.blendColor = "#FFFFFFFF"
        m.letterLabel.text = ""
    else
        m.circlePosterInner.uri = "pkg:/images/white-circle.png"
        m.circlePosterInner.blendColor = currentProfile.color
        username = currentProfile.username
        if not StringUtils_IsNullOrEmpty(username)
            letter = username.Left(1)
            if letter = "@" and Len(username) > 1
                letter = username.Mid(1, 1)
            end if
            m.letterLabel.text = UCase(letter)
        else
            m.letterLabel.text = ""
        end if
    end if
    m.circlePoster.visible = true
    m.buttonIcon.visible = false
end function