' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "itemsList": "./ItemsList"
        },
        childProps: {
    
        }
    }
end function