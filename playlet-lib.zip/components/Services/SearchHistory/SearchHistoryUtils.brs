'import "pkg:/source/utils/ArrayUtils.bs"
'import "pkg:/source/utils/RegistryUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
function SearchHistoryUtils_Save(preferencesNode as object, q as string, maxItems = 10 as integer) as void
    seachHistoryEnabled = preferencesNode["search_history.enabled"]
    if not seachHistoryEnabled
        return
    end if
    history = SearchHistoryUtils_GetAllSaved(preferencesNode)
    index = ArrayUtils_IndexOfString(history, q)
    if index <> -1
        history.Delete(index)
    end if
    history.Unshift(q)
    if history.Count() > maxItems
        history.Pop()
    end if
    history = FormatJson(history)
    RegistryUtils_Write("search_history", history)
end function

function SearchHistoryUtils_GetSaved(preferencesNode as object, q as string) as object
    history = SearchHistoryUtils_GetAllSaved(preferencesNode)
    if history.count() = 0
        return []
    end if
    if StringUtils_IsNullOrEmpty(q)
        return history
    end if
    result = []
    for each keyword in history
        if keyword.InStr(q) = 0
            result.push(keyword)
        end if
    end for
    return result
end function

function SearchHistoryUtils_GetAllSaved(preferencesNode as object) as object
    seachHistoryEnabled = preferencesNode["search_history.enabled"]
    if not seachHistoryEnabled
        return []
    end if
    history = RegistryUtils_Read("search_history")
    if history = invalid
        return []
    end if
    history = StringUtils_ParseJsonSafe(history)
    if not IsArray(history)
        return []
    end if
    return history
end function

function SearchHistoryUtils_Clear()
    RegistryUtils_Delete("search_history")
end function