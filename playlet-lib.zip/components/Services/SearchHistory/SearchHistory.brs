'import "pkg:/components/Services/SearchHistory/SearchHistoryUtils.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
end function

function OnNodeReady()
    OnSearchHistoryPreference()
    m.preferences.observeFieldScoped("search_history.enabled", FuncName(OnSearchHistoryPreference))
end function

function OnSearchHistoryPreference() as void
    seachHistoryEnabled = m.preferences["search_history.enabled"]
    if seachHistoryEnabled
        return
    end if
    SearchHistoryUtils_Clear()
end function