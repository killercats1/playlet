'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/components/Services/Innertube/Parser.bs"
'import "pkg:/components/Services/Innertube/SearchFilters.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/OptionUtils.bs"
'import "pkg:/source/utils/Types.bs"
function Innertube_Search(query as string, options = invalid as object) as object
    searchFilters = OptionUtils_Get(options, "searchFilters")
    continuation = OptionUtils_Get(options, "continuation")
    cancellation = OptionUtils_Get(options, "cancellation")
    disableShorts = OptionUtils_GetOrDefault(options, "disableShorts", false)
    raw = OptionUtils_GetOrDefault(options, "raw", false)
    deviceInfo = CreateObject("roDeviceInfo")
    payload = {
        context: Innertube_CreateContext("WEB", deviceInfo)
    }
    if not StringUtils_IsNullOrEmpty(continuation)
        payload["continuation"] = continuation
    else
        payload["query"] = query
        if searchFilters <> invalid and searchFilters.Count() > 0
            params = Innertube_GetEncodedSearchFilters(searchFilters)
            if params <> ""
                payload["params"] = Innertube_GetEncodedSearchFilters(searchFilters)
            end if
        end if
    end if
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/search?prettyPrint=false&alt=json").JsonBody(payload)
    request.Headers(Innertube_CreateHeaders("WEB"))
    request.Cancellation(cancellation)
    if raw
        request.LogCurlCommand()
    end if
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    if raw
        return response.Json()
    end if
    feeds = Innertube_ParseResponseDataForFeeds(response.Json(), {
        request: request
        disableShorts: disableShorts
    })
    result = {
        feeds: feeds
    }
    cacheControl = Innertube_ParseResponseForCacheControl(response)
    if cacheControl <> invalid
        result["cache-control"] = cacheControl
    end if
    return result
end function

' Not part of search endpoint, but this function is fine here.
function Innertube_SearchSuggestions(query as string, cancellation = invalid as object) as object
    request = HttpClient_Get("https://suggestqueries.google.com/complete/search?hl=en&gl=US&ds=yt&client=youtube&xssi=t&oe=UTF&q=" + query.EncodeUriComponent())
    request.Headers({
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    })
    request.Cancellation(cancellation)
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    text = response.Text()
    text = text.Replace(")]}'", "")
    parsed = StringUtils_ParseJsonSafe(text)
    if not IsArray(parsed) or parsed.Count() < 2
        return {
            error: "Failed to parse search suggestions"
        }
    end if
    parsed = parsed[1]
    suggestions = []
    for each suggestion in parsed
        sugg = suggestion[0]
        if not IsString(sugg)
            continue for
        end if
        suggestions.Push(sugg)
    end for
    result = {
        suggestions: suggestions
    }
    cacheControl = Innertube_ParseResponseForCacheControl(response)
    if cacheControl <> invalid
        result["cache-control"] = cacheControl
    end if
    return result
end function