'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/UrlUtils.bs"
' OTF (On-The-Fly?) segment info retrieval and parsing
' When innertube returns adaptive formats, sometimes there's a property
' attached to the object: adaptiveFormats[].type = "FORMAT_STREAM_TYPE_OTF".
' When that happens, the segment info (durations, repeat counts) is not included
' in the response. Instead, they are appended to the media init segment itself.
' The init segment would contain video init information, which is binary, appended
' with a text section in this format:
' `Segment-Count: 731\r\n` +
' `Segment-Durations-Ms: 5333,5334,5333(r=1),5334,5333(r=1),\r\n`
' Because of this, the init segment needs to be downloaded to a tmp file, loaded in
' a byte array, converted to hex, and parsed. Loading the file to ascii string directly
' would not work because it would be truncated at the first null byte.


function Innertube_OTFGetSegmentInfo(adaptiveFormats as object, client as object, cancellation as object) as void
    errors = {
        message: ""
        attachments: []
    }
    formatsToProcess = []
    for i = 0 to adaptiveFormats.Count() - 1
        formatsToProcess.Push({
            format: adaptiveFormats[i]
            filePath: ("tmp:/otf_segments/" + bslib_toString(i) + ".bin")
        })
    end for
    pendingFormats = []
    requestHeaders = Innertube_CreateHeaders(client)
    requestHeaders["origin"] = "https://www.youtube.com"
    requestHeaders["referer"] = "https://www.youtube.com"
    requestHeaders["DNT"] = "?1"
    segmentDurationsRegex = CreateObject("roRegex", "(\d+)(?:\(r=(\d+)\))?", "g")
    fs = CreateObject("roFileSystem")
    fs.Delete("tmp:/otf_segments")
    fs.CreateDirectory("tmp:/otf_segments")
    while true
        while formatsToProcess.Count() > 0 and pendingFormats.Count() < 8
            formatToProcess = formatsToProcess.Pop()
            pending = Innertube_OTFSendSegmentInfoRequest(formatToProcess.format, formatToProcess.filePath, requestHeaders, errors, cancellation)
            if pending <> invalid
                formatToProcess.pending = pending
                pendingFormats.Push(formatToProcess)
            end if
        end while
        if pendingFormats.Count() = 0
            exit while
        end if
        pendingFormat = pendingFormats.Shift()
        
        if not Innertube_OTFProcessPendingFormat(pendingFormat.format, pendingFormat.pending, pendingFormat.filePath, segmentDurationsRegex, errors)
            exit while
        end if
    end while
    for each pendingFormat in pendingFormats
        pendingFormat.pending.Cancel()
    end for
    fs.Delete("tmp:/otf_segments")
    if not StringUtils_IsNullOrEmpty(errors.message) or errors.attachments.Count() > 0
        LogTelemetryEvent({
            level: "error"
            message: ("OTF errors during segment info retrieval: " + chr(10) + bslib_toString(errors.message))
            fingerprint: [
                "OTF errors during segment info retrieval"
            ]
            attachments: errors.attachments
        })
    end if
end function

function Innertube_OTFSendSegmentInfoRequest(format as object, filePath as string, requestHeaders as object, errors as object, cancellation as object) as dynamic
    url = format.url
    if StringUtils_IsNullOrEmpty(url)
        errors.message += ("URL is empty for itag " + bslib_toString(format.itag) + "." + chr(10))
        return invalid
    end if
    queryComponents = UrlUtils_ParseQueryComponents(url)
    queryComponents["rn"] = "0"
    queryComponents["sq"] = "0"
    otfUrl = UrlUtils_SetQueryParams(url, queryComponents)
    request = HttpClient_Get(otfUrl)
    request.Headers(requestHeaders)
    request.SaveBodyToFile(filePath)
    request.NoCache()
    request.Cancellation(cancellation)
    return request.Send()
end function

function Innertube_OTFProcessPendingFormat(format as object, pending as object, filePath as string, segmentDurationsRegex as object, errors as object) as boolean
    response = pending.Await()
    if response.IsCancelled()
        return false
    end if
    if not response.IsSuccess()
        errors.message += ("Failed to get segment info for itag " + bslib_toString(format.itag) + ": " + bslib_toString(response.ErrorMessage()) + chr(10))
        return true
    end if
    segmentDurations = Innertube_OTFParseFileForSegmentDurations(filePath, segmentDurationsRegex, errors)
    if segmentDurations = invalid
        errors.message += ("Failed to parse segment durations for itag " + bslib_toString(format.itag) + "." + chr(10))
        errors.message += ("Headers: " + bslib_toString(ToString(response.Headers())) + chr(10))
        return true
    end if
    format["otfSegmentDurations"] = segmentDurations
    return true
end function

function Innertube_OTFParseFileForSegmentDurations(filePath as string, segmentDurationsRegex as object, errors as object) as dynamic
    buffer = CreateObject("roByteArray")
    buffer.FromAsciiString("Segment-Durations-Ms:")
    startMarkerHex = buffer.ToHexString()
    buffer.FromAsciiString((chr(13) + chr(10)))
    endMarkerHex = buffer.ToHexString()
    if not buffer.ReadFile(filePath)
        errors.message += ("Failed to read filePath " + bslib_toString(filePath) + "." + chr(10))
        return invalid
    end if
    contentHex = buffer.ToHexString()
    startIndex = contentHex.InStr(startMarkerHex)
    if startIndex = -1
        errors.message += ("Start marker not found in filePath " + bslib_toString(filePath) + "." + chr(10))
        errors.attachments.Push({
            filename: filePath
            content_type: "plain/text"
            data: contentHex
        })
        return invalid
    end if
    endIndex = contentHex.InStr(startIndex, endMarkerHex)
    if endIndex = -1
        errors.message += ("End marker not found in filePath " + bslib_toString(filePath) + "." + chr(10))
        errors.attachments.Push({
            filename: filePath
            content_type: "plain/text"
            data: contentHex
        })
        return invalid
    end if
    segmentDurationsMsHex = contentHex.Mid(startIndex + startMarkerHex.len(), endIndex - (startIndex + startMarkerHex.len()))
    buffer.FromHexString(segmentDurationsMsHex)
    segmentDurationsMs = buffer.ToAsciiString()
    matches = segmentDurationsRegex.MatchAll(segmentDurationsMs)
    if not IsArray(matches) or matches.Count() = 0
        errors.message += ("No segment duration matches found in filePath " + bslib_toString(filePath) + "." + chr(10))
        errors.attachments.Push({
            filename: filePath
            content_type: "plain/text"
            data: contentHex
        })
        return invalid
    end if
    segmentDurations = CreateObject("roArray", matches.Count(), false)
    for i = 0 to matches.Count() - 1
        match = matches[i]
        segment = {}
        
        if match.Count() >= 2
            segment["d"] = match[1].ToInt()
        end if
        if match.Count() >= 3
            segment["r"] = match[2].ToInt()
        end if
        segmentDurations[i] = segment
    end for
    return segmentDurations
end function