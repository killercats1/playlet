'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/components/Services/Innertube/LiveStreamInfo.bs"
'import "pkg:/components/Services/Innertube/NodesParser.bs"
'import "pkg:/components/Services/Innertube/OTFSegmentInfo.bs"
'import "pkg:/components/Services/Innertube/PostLiveDvrInfo.bs"
'import "pkg:/components/Services/Innertube/PoTokens.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/ObjectUtils.bs"
'import "pkg:/source/utils/Types.bs"
'import "pkg:/source/utils/UrlUtils.bs"
function Innertube_CreatePlayerRequest(client as object, options = invalid as object) as object
    videoId = OptionUtils_Get(options, "videoId")
    visitorData = OptionUtils_Get(options, "visitorData")
    accessToken = OptionUtils_Get(options, "accessToken")
    livingRoomPoTokenId = OptionUtils_Get(options, "livingRoomPoTokenId")
    cpn = InnertubeService_CreateClientPlaybackNonce()
    isTv = (client = "TV" or client = "TV_DOWNGRADED")
    useAccessToken = isTv and not StringUtils_IsNullOrEmpty(accessToken)
    deviceInfo = CreateObject("roDeviceInfo")
    context = Innertube_CreateContext(client, deviceInfo, options)
    if client = "TV" or client = "TV_DOWNGRADED"
        referer = "https://www.youtube.com/tv#/watch?v=" + videoId
    else
        referer = "https://www.youtube.com/watch?v=" + videoId
    end if
    payload = {
        "videoId": videoId
        "context": context
        "cpn": cpn
        "playbackContext": {
            "contentPlaybackContext": {
                "vis": 0
                "splay": false
                "referer": referer
                "currentUrl": "/watch?v=" + videoId
                "autonavState": "STATE_ON"
                "autoCaptionsDefaultOn": false
                "html5Preference": "HTML5_PREF_WANTS"
                "lactMilliseconds": "-1"
            }
        }
        "attestationRequest": {
            "omitBotguardData": true
        }
        "racyCheckOk": true
        "contentCheckOk": true
    }
    signatureTimestamp = OptionUtils_Get(options, "signatureTimestamp")
    if signatureTimestamp <> invalid
        payload["playbackContext"]["contentPlaybackContext"]["signatureTimestamp"] = signatureTimestamp
    end if
    if isTv
        payload["playbackContext"]["contentPlaybackContext"]["isLivingRoomDeeplink"] = true
    end if
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/player?prettyPrint=false&alt=json").JsonBody(payload)
    request.Headers(Innertube_CreateHeaders(client))
    if not StringUtils_IsNullOrEmpty(visitorData) and not useAccessToken
        request.Header("x-goog-visitor-id", visitorData)
    end if
    if not StringUtils_IsNullOrEmpty(livingRoomPoTokenId)
        request.poTokenIdentity = livingRoomPoTokenId
    end if
    if not StringUtils_IsNullOrEmpty(request.poTokenIdentity)
        
        request.poToken = Innertube_PoTokens_GetValidPoTokenForIdentity(request.poTokenIdentity)
    end if
    request.signatureTimestamp = signatureTimestamp
    request.cpn = cpn
    return request
end function

function Innertube_ParseInnertubePlayerResponse(playerRequest as object, playerResponse as object, client as object, cancellation as object) as object
    WriteAsciiFile("cachefs:/last_player_response.json", playerResponse.Text())
    parsedResponse = {}
    payload = playerResponse.Json()
    error = Innertube_ParsePlayerResponseForError(payload, playerRequest)
    if error <> ""
        parsedResponse["error"] = error
        if Innertube_PlayerResponseRequiresPageReload(payload)
            parsedResponse["errorCode"] = "RELOAD_PAGE"
        end if
        return parsedResponse
    end if
    videoDetails = payload["videoDetails"]
    if not IsAssociativeArray(videoDetails)
        parsedResponse["error"] = "Invalid videoDetails"
        return parsedResponse
    end if
    streamingData = payload["streamingData"]
    if not IsAssociativeArray(streamingData)
        parsedResponse["error"] = "Invalid streamingData"
        return parsedResponse
    end if
    lengthSeconds = videoDetails["lengthSeconds"].ToInt()
    isLive = ValidBool(videoDetails["isLive"])
    isPostLiveDvr = ValidBool(videoDetails["isPostLiveDvr"])
    adaptiveFormats = ValidArray(ObjectUtils_Dig(payload, [
        "streamingData"
        "adaptiveFormats"
    ]))
    formats = ValidArray(ObjectUtils_Dig(payload, [
        "streamingData"
        "formats"
    ]))
    error = Innertube_DecipherUrls(formats, adaptiveFormats, playerRequest.signatureTimestamp, cancellation, client, playerRequest.poTokenIdentity, playerRequest.poToken)
    if error <> invalid
        parsedResponse["error"] = error.error
        if error.DoesExist("errorCode")
            parsedResponse["errorCode"] = error.errorCode
        end if
        return parsedResponse
    end if
    parsedResponse["potAttached"] = Innertube_HasPotParam(adaptiveFormats) or Innertube_HasPotParam(formats)
    
    if not parsedResponse["potAttached"]
        parsedResponse["potSource"] = "none"
    else if StringUtils_IsNullOrEmpty(playerRequest.poToken)
        parsedResponse["potSource"] = "server"
    else
        parsedResponse["potSource"] = "browser"
    end if
    LogInfo5("[PlayerEndpoint.bs:139]", "poToken attached to deciphered urls:", parsedResponse["potAttached"], "source:", parsedResponse["potSource"])
    hasLiveStreamingData = Innertube_FormatsHaveLiveStreamingData(adaptiveFormats) or Innertube_FormatsHaveLiveStreamingData(formats)
    isOTF = Innertube_FormatsHasTypeOTF(adaptiveFormats)
    hasDrm = (not StringUtils_IsNullOrEmpty(streamingData.drmParams)) or IsArray(streamingData.licenseInfos)
    adaptiveFormats = Innertube_TransformFormats(adaptiveFormats)
    formats = Innertube_TransformFormats(formats)
    parsedResponse["type"] = "video"
    parsedResponse["parser"] = "playlet"
    parsedResponse["videoId"] = videoDetails["videoId"]
    parsedResponse["videoThumbnails"] = videoDetails["thumbnail"]["thumbnails"]
    parsedResponse["storyboards"] = Innertube_ParseStoryboards(payload, lengthSeconds)
    parsedResponse["author"] = videoDetails["author"]
    parsedResponse["authorId"] = videoDetails["channelId"]
    parsedResponse["lengthSeconds"] = lengthSeconds
    parsedResponse["liveNow"] = isLive
    parsedResponse["isPostLiveDvr"] = isPostLiveDvr
    parsedResponse["hasLiveStreamingData"] = hasLiveStreamingData
    parsedResponse["hlsUrl"] = streamingData["hlsManifestUrl"]
    parsedResponse["dashUrl"] = streamingData["dashManifestUrl"]
    parsedResponse["adaptiveFormats"] = adaptiveFormats
    parsedResponse["formatStreams"] = formats
    parsedResponse["captions"] = Innertube_ParseCaptions(payload)
    if not StringUtils_IsNullOrEmpty(videoDetails["title"])
        parsedResponse["title"] = videoDetails["title"]
    end if
    if not StringUtils_IsNullOrEmpty(videoDetails["author"])
        parsedResponse["author"] = videoDetails["author"]
    end if
    if videoDetails.DoesExist("viewCount")
        parsedResponse["viewCount"] = videoDetails["viewCount"].ToInt()
    end if
    if hasDrm
        parsedResponse["drmParams"] = streamingData["drmParams"]
        parsedResponse["licenseInfos"] = streamingData["licenseInfos"]
        parsedResponse["drmSessionId"] = Innertube_GenerateDrmSessionId()
    end if
    if not StringUtils_IsNullOrEmpty(playerRequest.cpn)
        parsedResponse["cpn"] = playerRequest.cpn
    end if
    parsedResponse["isLoggedIn"] = Innertube_ParseIsLoggedIn(payload)
    parsedResponse["playbackTrackingUrls"] = Innertube_ParsePlaybackTrackingUrls(payload, parsedResponse.isLoggedIn)
    if isPostLiveDvr
        
        Innertube_GetPostLiveDvrInfo(parsedResponse, adaptiveFormats, playerRequest.cpn, cancellation)
    end if
    if isOTF
        
        Innertube_OTFGetSegmentInfo(adaptiveFormats, client, cancellation)
    end if
    if isLive
        
        Innertube_GetLiveStreamInfo(parsedResponse, adaptiveFormats, ValidInt(videoDetails["liveChunkReadahead"]), playerRequest.cpn, cancellation)
    end if
    return parsedResponse
end function

function Innertube_ParsePlayerResponseForError(payload as object, playerRequest as object) as string
    if not IsAssociativeArray(payload)
        return "Invalid payload"
    end if
    playabilityStatus = payload["playabilityStatus"]
    if not IsAssociativeArray(playabilityStatus)
        return "Invalid playability status"
    end if
    status = ValidString(playabilityStatus["status"])
    if status = "OK"
        return ""
    end if
    errorLines = []
    if not StringUtils_IsNullOrEmpty(playabilityStatus["reason"])
        errorLines.Push(playabilityStatus["reason"])
    end if
    if not StringUtils_IsNullOrEmpty(playabilityStatus["reasonTitle"])
        errorLines.Push(playabilityStatus["reasonTitle"])
    end if
    subreason = Innertube_ParseText(ObjectUtils_Dig(playabilityStatus, [
        "errorScreen"
        "playerErrorMessageRenderer"
        "subreason"
    ]))
    if subreason <> ""
        errorLines.Push(subreason)
    end if
    playerErrorCommand = ObjectUtils_Dig(playabilityStatus, [
        "errorScreen"
        "playerErrorCommandRenderer"
    ])
    if IsAssociativeArray(playerErrorCommand)
        errorLines.Append(Innertube_ParsePlayerErrorCommandRenderer(playerErrorCommand))
    end if
    if errorLines.Count() = 0
        Innertube_Warning(("Unparsed playability status: " + bslib_toString(status)), playabilityStatus, {
            request: playerRequest
        })
        errorLines.Push("Video not available (Unknown)")
    end if
    if status = "LOGIN_REQUIRED"
        
        errorLines.Push("Hint: Log in to the YouTube app on your phone, then cast the video to Playlet.")
        hasAccessToken = ValidString(playerRequest.GetHeaders()["Authorization"]).Len() > "Bearer ".Len()
        hasCtt = ValidString(playerRequest.GetTextBody()).InStr("credentialTransferTokens") <> -1
        if hasAccessToken or hasCtt
            LogTelemetryEvent({
                level: "error"
                message: ("LOGIN_REQUIRED: hasAccessToken=" + bslib_toString(hasAccessToken) + " hasCtt=" + bslib_toString(hasCtt) + chr(10) + "PlayabilityStatus: " + bslib_toString(FormatJson(playabilityStatus)))
                fingerprint: [
                    "LOGIN_REQUIRED hasAccessToken hasCtt"
                ]
            })
        end if
    end if
    return errorLines.Join((chr(10)))
end function

function Innertube_ParsePlayerErrorCommandRenderer(renderer as object) as object
    lines = []
    errorMessage = Innertube_ParseText(renderer["errorMessage"])
    if errorMessage <> ""
        lines.Push(errorMessage)
    end if
    lines.Append(Innertube_ParseOpenPopupAction(ObjectUtils_Dig(renderer, [
        "command"
        "openPopupAction"
    ])))
    return lines
end function

function Innertube_ParseOpenPopupAction(openPopupAction as object) as object
    lines = []
    panel = ObjectUtils_Dig(openPopupAction, [
        "popup"
        "overlaySectionRenderer"
        "overlay"
        "overlayTwoPanelRenderer"
        "actionPanel"
        "overlayPanelRenderer"
    ])
    if not IsAssociativeArray(panel)
        return lines
    end if
    header = ObjectUtils_Dig(panel, [
        "header"
        "overlayPanelHeaderRenderer"
    ])
    title = Innertube_ParseText(ObjectUtils_Dig(header, [
        "title"
    ]))
    if title <> ""
        lines.Push(title)
    end if
    subtitle = Innertube_ParseText(ObjectUtils_Dig(header, [
        "subtitle"
    ]))
    if subtitle <> ""
        lines.Push(subtitle)
    end if
    items = ObjectUtils_Dig(panel, [
        "content"
        "overlayPanelItemListRenderer"
        "items"
    ])
    if not IsArray(items)
        return lines
    end if
    for each item in items
        url = Innertube_ParseText(ObjectUtils_Dig(item, [
            "secondScreenActionRenderer"
            "url"
        ]))
        if url <> ""
            lines.Push(url)
        end if
        lines.Append(Innertube_ParseOpenPopupAction(ObjectUtils_Dig(item, [
            "compactLinkRenderer"
            "serviceEndpoint"
            "openPopupAction"
        ])))
    end for
    return lines
end function

function Innertube_PlayerResponseRequiresPageReload(payload as object) as boolean
    signal = ObjectUtils_Dig(payload, [
        "playabilityStatus"
        "errorScreen"
        "playerErrorMessageRenderer"
        "proceedButton"
        "buttonRenderer"
        "command"
        "signalAction"
        "signal"
    ])
    return IsString(signal) and signal = "RELOAD_PAGE"
end function

function Innertube_ParseStoryboards(payload as object, lengthSeconds as integer) as object
    storyboard = ObjectUtils_Dig(payload, [
        "storyboards"
        "playerLiveStoryboardSpecRenderer"
        "spec"
    ])
    if IsString(storyboard)
        storyboard = storyboard.Split("#")
        if storyboard.Count() <> 5
            return []
        end if
        return [
            {
                "templateUrl": storyboard[0]
                "width": storyboard[1].ToInt()
                "height": storyboard[2].ToInt()
                "count": -1
                "interval": 5000
                "storyboardHeight": storyboard[3].ToInt()
                "storyboardWidth": storyboard[4].ToInt()
            }
        ]
    end if
    storyboards = ObjectUtils_Dig(payload, [
        "storyboards"
        "playerStoryboardSpecRenderer"
        "spec"
    ])
    if not IsString(storyboards)
        return []
    end if
    storyboardsData = storyboards.Split("|")
    if storyboardsData.Count() < 2
        return []
    end if
    baseUrl = storyboardsData.Shift()
    storyboards = []
    index = 0
    for each sb in storyboardsData
        sbData = sb.Split("#")
        if sbData.Count() <> 8
            index += 1
            continue for
        end if
        width = sbData[0].ToInt()
        height = sbData[1].ToInt()
        _count = sbData[2].ToInt()
        columns = sbData[3].ToInt()
        rows = sbData[4].ToInt()
        interval = sbData[5].ToInt()
        name = sbData[6]
        sigh = sbData[7]
        url = baseUrl
        url = url.Replace("$L", (bslib_toString(index)))
        url = url.Replace("$N", name)
        queryComponents = UrlUtils_ParseQueryComponents(url)
        queryComponents["sigh"] = sigh.DecodeUriComponent()
        url = UrlUtils_SetQueryParams(url, queryComponents)
        thumbnailsPerImage = columns * rows
        imagesCount = _count \ thumbnailsPerImage
        if _count mod thumbnailsPerImage > 0
            imagesCount += 1
        end if
        if interval = 0 and _count > 0
            interval = Cint(Cdbl(lengthSeconds) * 1000.0 / Cdbl(_count))
        end if
        storyboards.Push({
            "templateUrl": url
            "width": width
            "height": height
            "count": _count
            "interval": interval
            "storyboardWidth": columns
            "storyboardHeight": rows
            "storyboardCount": imagesCount
        })
        index += 1
    end for
    return storyboards
end function

function Innertube_ParseCaptions(payload as object) as object
    tracks = ObjectUtils_Dig(payload, [
        "captions"
        "playerCaptionsTracklistRenderer"
        "captionTracks"
    ])
    if not IsArray(tracks)
        return []
    end if
    captions = []
    autoCaptions = []
    for each track in tracks
        if not IsAssociativeArray(track)
            continue for
        end if
        baseUrl = track["baseUrl"]
        if not IsString(baseUrl)
            continue for
        end if
        queryComponents = UrlUtils_ParseQueryComponents(baseUrl)
        
        captionName = queryComponents["name"]
        if captionName = "CC1" or captionName = "CC2" or captionName = "CC3" or captionName = "CC4"
            queryComponents["fmt"] = "vtt"
        else
            queryComponents["fmt"] = "ttml"
        end if
        baseUrl = UrlUtils_SetQueryParams(baseUrl, queryComponents)
        languageCode = track["languageCode"]
        if not IsString(languageCode)
            continue for
        end if
        label = Innertube_ParseText(track["name"])
        thisCaption = {
            "label": label
            "language_code": languageCode
            "url": baseUrl
        }
        if track["kind"] = "asr"
            autoCaptions.Push(thisCaption)
            continue for
        end if
        captions.Push(thisCaption)
    end for
    
    captions.Append(autoCaptions)
    return captions
end function

function Innertube_TransformFormats(formats as object) as object
    result = []
    for i = 0 to formats.Count() - 1
        result.Push(Innertube_TransformFormat(formats[i]))
    end for
    return result
end function

function Innertube_TransformFormat(fmt as object) as object
    itag = (bslib_toString(fmt["itag"]))
    result = {
        "bitrate": (bslib_toString(fmt["bitrate"]))
        "url": fmt["url"]
        "itag": itag
        "type": fmt["mimeType"]
    }
    if fmt["approxDurationMs"] <> invalid
        result["approxDurationMs"] = fmt["approxDurationMs"]
    end if
    if IsAssociativeArray(fmt["initRange"])
        result["init"] = (bslib_toString(fmt["initRange"]["start"]) + "-" + bslib_toString(fmt["initRange"]["end"]))
    end if
    if IsAssociativeArray(fmt["indexRange"])
        result["index"] = (bslib_toString(fmt["indexRange"]["start"]) + "-" + bslib_toString(fmt["indexRange"]["end"]))
    end if
    if fmt["audioQuality"] <> invalid
        result["audioQuality"] = ToString(fmt["audioQuality"])
    end if
    if fmt["audioSampleRate"] <> invalid
        result["audioSampleRate"] = ToString(fmt["audioSampleRate"])
    end if
    if fmt["audioChannels"] <> invalid
        result["audioChannels"] = ToString(fmt["audioChannels"])
    end if
    if IsString(fmt["qualityLabel"])
        result["qualityLabel"] = fmt["qualityLabel"]
    end if
    if fmt["fps"] <> invalid
        result["fps"] = ToString(fmt["fps"])
    end if
    if fmt["colorInfo"] <> invalid
        result["colorInfo"] = fmt["colorInfo"]
    end if
    if fmt["audioTrack"] <> invalid
        result["audioTrack"] = fmt["audioTrack"]
    end if
    if fmt["isDrc"] <> invalid
        result["isDrc"] = fmt["isDrc"]
    end if
    if fmt["targetDurationSec"] <> invalid
        result["targetDurationSec"] = fmt["targetDurationSec"]
    end if
    if fmt["maxDvrDurationSec"] <> invalid
        result["maxDvrDurationSec"] = fmt["maxDvrDurationSec"]
    end if
    if ValidString(fmt["type"]) = "FORMAT_STREAM_TYPE_OTF"
        result["isTypeOTF"] = true
    end if
    if fmt["drmFamilies"] <> invalid
        result["drmFamilies"] = fmt["drmFamilies"]
    end if
    if fmt["xtags"] <> invalid
        result["xtags"] = fmt["xtags"]
    end if
    result["width"] = fmt["width"]
    result["height"] = fmt["height"]
    if fmt["width"] <> invalid and fmt["height"] <> invalid
        result["size"] = (bslib_toString(fmt["width"]) + "x" + bslib_toString(fmt["height"]))
        result["resolution"] = (bslib_toString(fmt["height"]) + "p")
    else
    end if
    return result
end function

function Innertube_GetSignatureTimestamp(cancellation as object) as object
    
    cache = ReadAsciiFile("tmp:/sts_cache.json")
    if not StringUtils_IsNullOrEmpty(cache)
        json = StringUtils_ParseJsonSafe(cache)
        if IsAssociativeArray(json) and json["sts"] <> invalid
            return {
                sts: json["sts"]
            }
        end if
    end if
    request = HttpClient_Get((bslib_toString("https://playlet-v8556.ondigitalocean.app") + "/v1/sts"))
    request.Cancellation(cancellation)
    request.RetryCount(2)
    request.NoCache()
    response = request.Await()
    if not response.IsSuccess()
        if response.IsCancelled()
            LogErrorNoTelemetry2("[PlayerEndpoint.bs:562]", response.ErrorMessage())
        else
            LogError2("[PlayerEndpoint.bs:564]", response.ErrorMessage())
        end if
        return {
            error: response.ErrorMessage()
        }
    end if
    text = response.Text()
    json = StringUtils_ParseJsonSafe(text)
    if not IsAssociativeArray(json) or json["sts"] = invalid
        error = "Invalid response from sts service"
        LogError3("[PlayerEndpoint.bs:573]", error, text)
        return {
            error: error
        }
    end if
    WriteAsciiFile("tmp:/sts_cache.json", text)
    return {
        sts: json["sts"]
    }
end function

function Innertube_HasPotParam(formats as object) as boolean
    for each fmt in formats
        url = fmt["url"]
        if not StringUtils_IsNullOrEmpty(url)
            if url.Instr("&pot=") <> -1
                return true
            end if
        end if
    end for
    return false
end function

function Innertube_DecipherUrls(formats as object, adaptiveFormats as object, signatureTimestamp as dynamic, cancellation as object, client = invalid as dynamic, poTokenIdentity = invalid as dynamic, poToken = invalid as dynamic) as object
    if signatureTimestamp = invalid
        
        return invalid
    end if
    reqFormats = []
    for each fmt in formats
        reqFormats.push({
            "url": fmt["url"]
            "cipher": fmt["cipher"]
            "signatureCipher": fmt["signatureCipher"]
        })
    end for
    reqAdaptiveFormats = []
    for each fmt in adaptiveFormats
        reqAdaptiveFormats.push({
            "url": fmt["url"]
            "cipher": fmt["cipher"]
            "signatureCipher": fmt["signatureCipher"]
        })
    end for
    body = {
        "sts": signatureTimestamp
        "formats": reqFormats
        "adaptiveFormats": reqAdaptiveFormats
    }
    if not StringUtils_IsNullOrEmpty(poTokenIdentity)
        body["identity"] = poTokenIdentity
    end if
    
    if not StringUtils_IsNullOrEmpty(poToken)
        body["poToken"] = poToken
    end if
    request = HttpClient_Post((bslib_toString("https://playlet-v8556.ondigitalocean.app") + "/v2/decipher")).JsonBody(body)
    request.Cancellation(cancellation)
    request.LogCurlCommand(false)
    response = request.Await()
    if not response.IsSuccess()
        errorCode = ""
        if response.StatusCode() = 400
            json = response.Json()
            if IsAssociativeArray(json)
                errorCode = ValidString(json["code"])
                if errorCode = "STS_MISMATCH"
                    DeleteFile("tmp:/sts_cache.json")
                end if
            end if
        end if
        exception = {
            error: response.ErrorMessage()
        }
        if errorCode <> ""
            exception.errorCode = errorCode
        end if
        if response.IsCancelled() or errorCode = "STS_MISMATCH"
            LogErrorNoTelemetry2("[PlayerEndpoint.bs:657]", response.ErrorMessage())
        else
            LogError2("[PlayerEndpoint.bs:659]", response.ErrorMessage())
        end if
        return exception
    end if
    json = response.Json()
    if not IsAssociativeArray(json) or not json.DoesExist("formats") or not json.DoesExist("adaptiveFormats")
        error = "Invalid response from decipher service"
        LogError2("[PlayerEndpoint.bs:668]", error)
        return {
            error: error
        }
    end if
    decipheredFormats = json["formats"]
    if not IsArray(decipheredFormats) or decipheredFormats.Count() <> formats.Count()
        error = "Invalid formats in deciphered response"
        LogError2("[PlayerEndpoint.bs:677]", error)
        return {
            error: error
        }
    end if
    for i = 0 to decipheredFormats.Count() - 1
        fmt = formats[i]
        decipheredFmt = decipheredFormats[i]
        fmt["url"] = Innertube_ResetUrlClientVersion(decipheredFmt["url"], client)
    end for
    decipheredAdaptiveFormats = json["adaptiveFormats"]
    if not IsArray(decipheredAdaptiveFormats) or decipheredAdaptiveFormats.Count() <> adaptiveFormats.Count()
        error = "Invalid adaptiveFormats in deciphered response"
        LogError2("[PlayerEndpoint.bs:691]", error)
        return {
            error: error
        }
    end if
    for i = 0 to decipheredAdaptiveFormats.Count() - 1
        fmt = adaptiveFormats[i]
        decipheredFmt = decipheredAdaptiveFormats[i]
        fmt["url"] = Innertube_ResetUrlClientVersion(decipheredFmt["url"], client)
    end for
    return invalid
end function

' YouTube.js sets cver to hardcoded values that might be different from
' What's used in Playlet. There's no indication that this makes a difference,
' but it makes sense to keep it consistent.
function Innertube_ResetUrlClientVersion(url as dynamic, requestClient = invalid as dynamic) as dynamic
    if StringUtils_IsNullOrEmpty(url)
        return url
    end if
    queryComponents = UrlUtils_ParseQueryComponents(url)
    client = ValidString(queryComponents["c"])
    if client = "TVHTML5"
        if requestClient = "TV_DOWNGRADED"
            queryComponents["cver"] = "5.20260114"
        else
            queryComponents["cver"] = "7.20260611.00.00"
        end if
    else if client = "IOS"
        queryComponents["cver"] = "21.16.2"
    else if client = "WEB"
        queryComponents["cver"] = "2.20260612.01.00"
    else
        return url
    end if
    return UrlUtils_SetQueryParams(url, queryComponents)
end function

function Innertube_ParseIsLoggedIn(payload as object) as boolean
    trackingParams = ObjectUtils_Dig(payload, [
        "responseContext"
        "serviceTrackingParams"
    ])
    if not IsArray(trackingParams)
        return false
    end if
    for each trackingParam in trackingParams
        if not IsAssociativeArray(trackingParam)
            continue for
        end if
        params = trackingParam["params"]
        if not IsArray(params)
            continue for
        end if
        for each param in params
            if not IsAssociativeArray(param)
                continue for
            end if
            if param["key"] = "logged_in" and param["value"] = "1"
                return true
            end if
        end for
    end for
    return false
end function

function Innertube_ParsePlaybackTrackingUrls(payload as object, isLoggedIn as boolean) as object
    if not isLoggedIn
        return invalid
    end if
    playbackTracking = payload["playbackTracking"]
    if not IsAssociativeArray(playbackTracking)
        return invalid
    end if
    return {
        "videostatsPlaybackUrl": ObjectUtils_Dig(playbackTracking, [
            "videostatsPlaybackUrl"
            "baseUrl"
        ])
        "videostatsWatchtimeUrl": ObjectUtils_Dig(playbackTracking, [
            "videostatsWatchtimeUrl"
            "baseUrl"
        ])
    }
end function

function Innertube_FormatsHaveLiveStreamingData(formats as object) as boolean
    if not IsArray(formats)
        return false
    end if
    for each fmt in formats
        url = fmt["url"]
        if IsString(url) and (url.InStr("yt_live_broadcast") <> -1 or url.InStr("yt_premiere_broadcast") <> -1)
            return true
        end if
    end for
    return false
end function

function Innertube_FormatsHasTypeOTF(formats as object) as boolean
    if not IsArray(formats)
        return false
    end if
    for each fmt in formats
        if ValidString(fmt["type"]) = "FORMAT_STREAM_TYPE_OTF"
            return true
        end if
    end for
    return false
end function