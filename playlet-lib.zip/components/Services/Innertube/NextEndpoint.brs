'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/components/Services/Innertube/Parser.bs"
'import "pkg:/components/Services/Innertube/protos/params.proto.gen.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/ObjectUtils.bs"
'import "pkg:/source/utils/Types.bs"
function Innertube_CreateNextRequest(payloadArgs as object, options = invalid as object) as object
    deviceInfo = CreateObject("roDeviceInfo")
    context = Innertube_CreateContext("WEB", deviceInfo, options)
    payload = {
        "context": context
    }
    payload.Append(payloadArgs)
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/next?prettyPrint=false&alt=json").JsonBody(payload)
    request.Headers(Innertube_CreateHeaders("WEB"))
    return request
end function

function Innertube_GetEncodedNextParams(videoIds as object) as string
    if not IsArray(videoIds) or videoIds.Count() = 0
        return ""
    end if
    return Protobuf_Generated_misc_encodeNextParams({
        "video_id": videoIds
    })
end function

function Innertube_ParseInnertubeNextResponse(payload as object, parsedResponse as object, request as object) as object
    if not IsAssociativeArray(payload)
        LogWarn3("[NextEndpoint.bs:38]", "Invalid payload", payload)
        return parsedResponse
    end if
    playerOverlayRenderer = ObjectUtils_Dig(payload, [
        "playerOverlays"
        "playerOverlayRenderer"
    ])
    if not IsAssociativeArray(playerOverlayRenderer)
        LogWarn3("[NextEndpoint.bs:44]", "Invalid playerOverlayRenderer", playerOverlayRenderer)
        return parsedResponse
    end if
    endscreen = playerOverlayRenderer["endScreen"]
    feeds = Innertube_ParseResponseDataForFeeds(endscreen, {
        request: request
        noContainers: true
    })
    if feeds.Count() > 0
        parsedResponse["recommendedVideos"] = ValidArray(feeds[0].items)
    end if
    
    videoChapters = Innertube_ParseNextChapters(payload)
    if videoChapters.Count() > 0
        parsedResponse["chapters"] = videoChapters
    end if
    
    if parsedResponse.error <> invalid
        return parsedResponse
    end if
    if StringUtils_IsNullOrEmpty(parsedResponse.title)
        title = Innertube_ParseText(ObjectUtils_Dig(playerOverlayRenderer, [
            "videoDetails"
            "playerOverlayVideoDetailsRenderer"
            "title"
        ]))
        if not StringUtils_IsNullOrEmpty(title)
            parsedResponse.title = title
        end if
    end if
    if StringUtils_IsNullOrEmpty(parsedResponse.author)
        subtitle = Innertube_ParseText(ObjectUtils_Dig(playerOverlayRenderer, [
            "videoDetails"
            "playerOverlayVideoDetailsRenderer"
            "subtitle"
        ]))
        if not StringUtils_IsNullOrEmpty(subtitle)
            parsedResponse.author = subtitle
        end if
    end if
    return parsedResponse
end function

' The video's chapters, [{ title, startMs }] in order: YouTube's own chapter markers (the player bar's
' chapterRenderer list), or else the timestamps in the description ("0:00 Intro").
function Innertube_ParseNextChapters(payload as object) as object
    list = []
    markers = Innertube_FindChapterMarkers(payload["playerOverlays"], 24)
    if IsArray(markers)
        for each marker in markers
            renderer = ObjectUtils_Dig(marker, [
                "chapterRenderer"
            ])
            if IsAssociativeArray(renderer) and IsNumber(renderer["timeRangeStartMillis"])
                list.Push({
                    title: Innertube_ParseText(renderer["title"])
                    startMs: renderer["timeRangeStartMillis"]
                })
            end if
        end for
    end if
    if list.Count() >= 2
        return list
    end if
    contents = ObjectUtils_Dig(payload, [
        "contents"
        "twoColumnWatchNextResults"
        "results"
        "results"
        "contents"
    ])
    if IsArray(contents)
        for each item in contents
            secondary = ObjectUtils_Dig(item, [
                "videoSecondaryInfoRenderer"
            ])
            if IsAssociativeArray(secondary)
                descriptionText = ValidString(ObjectUtils_Dig(secondary, [
                    "attributedDescription"
                    "content"
                ]))
                return Innertube_ChaptersFromDescription(descriptionText)
            end if
        end for
    end if
    return []
end function

' The first "chapters" list of chapterRenderer items under data.
function Innertube_FindChapterMarkers(data as dynamic, depth as integer) as dynamic
    if depth < 0
        return invalid
    end if
    if IsAssociativeArray(data)
        found = data["chapters"]
        if IsArray(found) and found.Count() > 0 and IsAssociativeArray(found[0]) and IsAssociativeArray(found[0]["chapterRenderer"])
            return found
        end if
        for each key in data
            found = Innertube_FindChapterMarkers(data[key], depth - 1)
            if found <> invalid
                return found
            end if
        end for
    else if IsArray(data)
        for each child in data
            found = Innertube_FindChapterMarkers(child, depth - 1)
            if found <> invalid
                return found
            end if
        end for
    end if
    return invalid
end function

' "0:00 Intro" / "1:02:03 - Part" lines of a description: chapters when there are at least 3, starting at 0:00.
function Innertube_ChaptersFromDescription(descriptionText as string) as object
    list = []
    timestampLine = CreateObject("roRegex", "^\s*[(\[]*((\d+:)*\d+:\d\d)[)\]]*\s*[-:|]*\s*(.+)$", "")
    for each line in descriptionText.Tokenize(Chr(10))
        match = timestampLine.Match(line)
        if match.Count() >= 4
            seconds = Innertube_TimestampSeconds(match[1])
            if seconds >= 0 and (list.Count() = 0 or seconds * 1000 > list[list.Count() - 1].startMs)
                list.Push({
                    title: match[3].Trim()
                    startMs: seconds * 1000
                })
            end if
        end if
    end for
    if list.Count() < 3 or list[0].startMs <> 0
        return []
    end if
    return list
end function

' "1:02:03" -> 3723, -1 when it isn't a timestamp
function Innertube_TimestampSeconds(stamp as string) as integer
    parts = stamp.Tokenize(":")
    if parts.Count() < 2 or parts.Count() > 3
        return -1
    end if
    total = 0
    for each part in parts
        total = total * 60 + part.ToInt()
    end for
    return total
end function