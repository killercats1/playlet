'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/OptionUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
function Innertube_CreateBrowseRequest(browseId as string, clienType as object, options = invalid as object) as object
    params = OptionUtils_GetOrDefault(options, "params", "")
    continuation = OptionUtils_GetOrDefault(options, "continuation", "")
    deviceInfo = CreateObject("roDeviceInfo")
    payload = {
        "context": Innertube_CreateContext(clienType, deviceInfo, options)
    }
    if not StringUtils_IsNullOrEmpty(continuation)
        payload["continuation"] = continuation
    else
        payload["browseId"] = browseId
        if not StringUtils_IsNullOrEmpty(params)
            payload["params"] = params
        end if
    end if
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/browse?prettyPrint=false&alt=json").JsonBody(payload)
    request.Headers(Innertube_CreateHeaders(clienType))
    return request
end function