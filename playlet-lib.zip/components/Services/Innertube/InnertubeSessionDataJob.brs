'import "pkg:/components/Services/Innertube/SessionData.bs"
'import "pkg:/source/utils/StringUtils.bs"

function ExecuteJob() as void
    innertubeNode = JobGetInput().innertube
    cached = Innertube_ReadSessionDataFromRegistry()
    cachedVisitorData = ""
    cachedLivingRoomPoTokenId = ""
    if IsAssociativeArray(cached)
        cachedVisitorData = ValidString(cached.visitorData)
        cachedLivingRoomPoTokenId = ValidString(cached.livingRoomPoTokenId)
    end if
    
    innertubeNode.sessionData = {
        "visitorData": cachedVisitorData
        "livingRoomPoTokenId": cachedLivingRoomPoTokenId
    }
    fresh = Innertube_RequestTvClientData(JobGetCancellation())
    if fresh = invalid
        return
    end if
    visitorData = cachedVisitorData
    timestamp = 0
    if Innertube_IsVisitorDataFresh(cached)
        visitorData = cached.visitorData
        timestamp = cached.timestamp
    else if not StringUtils_IsNullOrEmpty(fresh.visitorData)
        visitorData = fresh.visitorData
        timestamp = fresh.timestamp
    else if not StringUtils_IsNullOrEmpty(cachedVisitorData)
        visitorData = cachedVisitorData
        timestamp = cached.timestamp
    end if
    livingRoomPoTokenId = cachedLivingRoomPoTokenId
    if not StringUtils_IsNullOrEmpty(fresh.livingRoomPoTokenId)
        livingRoomPoTokenId = fresh.livingRoomPoTokenId
    end if
    Innertube_SaveSessionDataToRegistry({
        "timestamp": timestamp
        "visitorData": visitorData
        "livingRoomPoTokenId": livingRoomPoTokenId
    })
    innertubeNode.sessionData = {
        "visitorData": visitorData
        "livingRoomPoTokenId": livingRoomPoTokenId
    }
end function