'import "pkg:/components/Services/Innertube/protos/params.proto.gen.bs"
function Innertube_GetEncodedSearchFilters(searchFilters as object) as string
    searchFiltersObj = {
        filters: {}
    }
    if searchFilters.DoesExist("sort")
        sort = searchFilters["sort"]
        if sort = "relevance"
            searchFiltersObj["sort_by"] = 0
        else if sort = "rating"
            searchFiltersObj["sort_by"] = 1
        else if sort = "views"
            searchFiltersObj["sort_by"] = 3
        else if sort = "date"
            searchFiltersObj["sort_by"] = 2
        end if
    end if
    if searchFilters.DoesExist("date")
        date = searchFilters["date"]
        if date = "hour"
            searchFiltersObj["filters"]["upload_date"] = 1
        else if date = "today"
            searchFiltersObj["filters"]["upload_date"] = 2
        else if date = "week"
            searchFiltersObj["filters"]["upload_date"] = 3
        else if date = "month"
            searchFiltersObj["filters"]["upload_date"] = 4
        else if date = "year"
            searchFiltersObj["filters"]["upload_date"] = 5
        end if
    end if
    if searchFilters.DoesExist("type")
        _type = searchFilters["type"]
        if _type = "video"
            searchFiltersObj["filters"]["type"] = 1
        else if _type = "channel"
            searchFiltersObj["filters"]["type"] = 2
        else if _type = "playlist"
            searchFiltersObj["filters"]["type"] = 3
        else if _type = "movie"
            searchFiltersObj["filters"]["type"] = 4
        end if
    end if
    if searchFilters.DoesExist("duration")
        duration = searchFilters["duration"]
        if duration = "short"
            searchFiltersObj["filters"]["duration"] = 1
        else if duration = "long"
            searchFiltersObj["filters"]["duration"] = 2
        else if duration = "medium"
            searchFiltersObj["filters"]["duration"] = 3
        end if
    end if
    if searchFilters.DoesExist("features")
        features = searchFilters["features"]
        for each feature in features
            if feature = "hd"
                searchFiltersObj["filters"]["features_hd"] = true
            else if feature = "subtitles"
                searchFiltersObj["filters"]["features_subtitles"] = true
            else if feature = "creative_commons"
                searchFiltersObj["filters"]["features_creative_commons"] = true
            else if feature = "3d"
                searchFiltersObj["filters"]["features_3d"] = true
            else if feature = "live"
                searchFiltersObj["filters"]["features_live"] = true
            else if feature = "purchased"
                searchFiltersObj["filters"]["features_purchased"] = true
            else if feature = "4k"
                searchFiltersObj["filters"]["features_4k"] = true
            else if feature = "360"
                searchFiltersObj["filters"]["features_360"] = true
            else if feature = "location"
                searchFiltersObj["filters"]["features_location"] = true
            else if feature = "hdr"
                searchFiltersObj["filters"]["features_hdr"] = true
            else if feature = "vr180"
                searchFiltersObj["filters"]["features_vr180"] = true
            end if
        end for
    end if
    return Protobuf_Generated_misc_encodeSearchFilter(searchFiltersObj)
end function