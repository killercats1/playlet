'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/source/services/HttpClient.bs"
function Innertube_CreateResolveUrlRequest(url as string) as object
    deviceInfo = CreateObject("roDeviceInfo")
    payload = {
        "context": Innertube_CreateContext("WEB", deviceInfo)
        "url": url
    }
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/navigation/resolve_url?prettyPrint=false&alt=json").JsonBody(payload)
    request.Headers(Innertube_CreateHeaders("WEB"))
    return request
end function