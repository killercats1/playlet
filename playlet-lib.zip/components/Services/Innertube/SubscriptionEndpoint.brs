'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/Types.bs"
function Innertube_CreateSubscribeRequest(channelIds as dynamic, options = invalid as object) as object
    deviceInfo = CreateObject("roDeviceInfo")
    payload = {
        "context": Innertube_CreateContext("TV", deviceInfo, options)
    }
    if IsString(channelIds)
        channelIds = [
            channelIds
        ]
    end if
    payload["channelIds"] = channelIds
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/subscription/subscribe?prettyPrint=false&alt=json").JsonBody(payload)
    request.Headers(Innertube_CreateHeaders("TV"))
    return request
end function

function Innertube_CreateUnsubscribeRequest(channelIds as dynamic, options = invalid as object) as object
    deviceInfo = CreateObject("roDeviceInfo")
    payload = {
        "context": Innertube_CreateContext("TV", deviceInfo, options)
    }
    if IsString(channelIds)
        channelIds = [
            channelIds
        ]
    end if
    payload["channelIds"] = channelIds
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/subscription/unsubscribe?prettyPrint=false&alt=json").JsonBody(payload)
    request.Headers(Innertube_CreateHeaders("TV"))
    return request
end function