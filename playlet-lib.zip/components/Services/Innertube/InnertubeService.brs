'import "pkg:/components/Services/Innertube/BrowseEndpoint.bs"
'import "pkg:/components/Services/Innertube/Constants.bs"
'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/components/Services/Innertube/GetDrmLicenseEndpoint.bs"
'import "pkg:/components/Services/Innertube/NextEndpoint.bs"
'import "pkg:/components/Services/Innertube/OAuth.bs"
'import "pkg:/components/Services/Innertube/PlayerEndpoint.bs"
'import "pkg:/components/Services/Innertube/ResolveUrlEndpoint.bs"
'import "pkg:/components/Services/Innertube/SearchEndpoint.bs"
'import "pkg:/components/Services/Innertube/SearchFilters.bs"
'import "pkg:/components/Services/Innertube/SubscriptionEndpoint.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/CancellationUtils.bs"
'import "pkg:/source/utils/ObjectUtils.bs"
'import "pkg:/source/utils/OptionUtils.bs"
'import "pkg:/source/utils/TimeUtils.bs"
' DEBUG-only: force the SABR downgrade retry on every playable response.
function InnertubeService_GetVideoMetadata(videoId as string, options = invalid as object) as object
    options["videoId"] = videoId
    if not OptionUtils_GetOrDefault(options, "fetchNext", true)
        return InnertubeService_GetPlayerMetadata(videoId, options)
    end if
    raw = OptionUtils_GetOrDefault(options, "raw", false)
    nextRequest = Innertube_CreateNextRequest({
        "videoId": videoId
    }, options)
    nextRequest.Cancellation(OptionUtils_Get(options, "cancellation"))
    if raw
        nextRequest.LogCurlCommand()
    end if
    pendingNext = nextRequest.Send()
    return InnertubeService_AwaitAndParseNextResponse(raw, InnertubeService_GetPlayerMetadata(videoId, options), nextRequest, pendingNext)
end function

' The parsed player response (raw: { playerResponse }), or { error }.
function InnertubeService_GetPlayerMetadata(videoId as string, options as object) as object
    cancellation = OptionUtils_Get(options, "cancellation")
    accessToken = OptionUtils_Get(options, "accessToken")
    raw = OptionUtils_GetOrDefault(options, "raw", false)
    client = "TV"
    triedReloadRefresh = false
    
    for playerRequestCount = 1 to 3
        stsResult = Innertube_GetSignatureTimestamp(cancellation)
        if CancellationUtils_IsCancelled(cancellation)
            return {
                error: "Cancelled"
            }
        end if
        if stsResult.error <> invalid
            return stsResult
        end if
        options["signatureTimestamp"] = stsResult.sts
        playerRequest = Innertube_CreatePlayerRequest(client, options)
        if not StringUtils_IsNullOrEmpty(accessToken) and (client = "TV" or client = "TV_DOWNGRADED")
            playerRequest.Header("Authorization", "Bearer " + accessToken)
        end if
        playerRequest.Cancellation(cancellation)
        if raw
            playerRequest.LogCurlCommand()
        end if
        playerResponse = playerRequest.Await()
        if CancellationUtils_IsCancelled(cancellation)
            return {
                error: "Cancelled"
            }
        end if
        if not playerResponse.IsSuccess()
            return {
                error: playerResponse.ErrorMessage()
            }
        end if
        playerResponseJson = playerResponse.Json()
        
        if client = "TV" and InnertubeService_IsSabrLocked(playerResponseJson)
            LogInfo2("[InnertubeService.bs:91]", "SABR-locked response, retrying with downgraded TV client...")
            client = "TV_DOWNGRADED"
            continue for
        else if client = "TV_DOWNGRADED" and not InnertubeService_HasUsableAdaptiveUrl(playerResponseJson)
            LogError2("[InnertubeService.bs:95]", "Downgraded TV client did not recover SABR-withheld format URLs")
        end if
        parsedResponse = Innertube_ParseInnertubePlayerResponse(playerRequest, playerResponse, client, cancellation)
        if parsedResponse.error = invalid
            if raw
                return {
                    "playerResponse": playerResponseJson
                }
            end if
            if StringUtils_IsNullOrEmpty(parsedResponse.videoId)
                parsedResponse["videoId"] = videoId
            end if
            return parsedResponse
        end if
        if parsedResponse.errorCode <> invalid
            if parsedResponse.errorCode = "STS_MISMATCH"
                LogInfo2("[InnertubeService.bs:114]", "STS_MISMATCH error, retrying...")
                continue for
            else if parsedResponse.errorCode = "RELOAD_PAGE" and not triedReloadRefresh
                triedReloadRefresh = true
                LogInfo2("[InnertubeService.bs:118]", "RELOAD_PAGE: clearing stale STS cache and retrying...")
                DeleteFile("tmp:/sts_cache.json")
                continue for
            else if parsedResponse.errorCode = "MISSING_FORMAT_FIELD"
                useServerDrivenAbr = (bslib_toString(ObjectUtils_Dig(playerResponseJson, [
                    "playerConfig"
                    "mediaCommonConfig"
                    "useServerDrivenAbr"
                ])))
                LogTelemetryEvent({
                    level: "error"
                    message: parsedResponse.errorCode + (chr(10) + "playerConfig.mediaCommonConfig.useServerDrivenAbr:") + useServerDrivenAbr
                    fingerprint: parsedResponse.errorCode + useServerDrivenAbr
                    attachments: [
                        {
                            filename: "request.txt"
                            content_type: "text/plain"
                            data: playerRequest.ToCurlCommand()
                        }
                        {
                            filename: "response.json"
                            content_type: "application/json"
                            data: playerResponse.Text()
                        }
                    ]
                })
            end if
        end if
        return parsedResponse
    end for
    LogError2("[InnertubeService.bs:143]", "Too many player requests, aborting.")
    return {
        error: "Too many player requests"
    }
end function

' True when the TV client's response is SABR-locked: server-driven ABR signaled with no usable
' adaptive URL.
function InnertubeService_IsSabrLocked(playerResponseJson as object) as boolean
    if not IsAssociativeArray(ObjectUtils_Dig(playerResponseJson, [
        "streamingData"
    ]))
        return false
    end if
    serverDrivenAbr = ValidBool(ObjectUtils_Dig(playerResponseJson, [
        "playerConfig"
        "mediaCommonConfig"
        "useServerDrivenAbr"
    ]))
    locked = serverDrivenAbr and not InnertubeService_HasUsableAdaptiveUrl(playerResponseJson)
    return locked
end function

' True if any adaptive format carries a playable field (url / signatureCipher / cipher).
function InnertubeService_HasUsableAdaptiveUrl(playerResponseJson as object) as boolean
    adaptiveFormats = ObjectUtils_Dig(playerResponseJson, [
        "streamingData"
        "adaptiveFormats"
    ])
    if not IsArray(adaptiveFormats)
        return false
    end if
    for each format in adaptiveFormats
        if IsAssociativeArray(format) and (not StringUtils_IsNullOrEmpty(format["url"]) or not StringUtils_IsNullOrEmpty(format["signatureCipher"]) or not StringUtils_IsNullOrEmpty(format["cipher"]))
            return true
        end if
    end for
    return false
end function

function InnertubeService_AwaitAndParseNextResponse(raw as boolean, parsedResponse as object, nextRequest as object, pendingNext as object) as object
    nextResponse = pendingNext.Await()
    if not nextResponse.IsSuccess()
        if nextResponse.IsCancelled()
            return parsedResponse
        end if
        error = nextResponse.ErrorMessage()
        LogWarn2("[InnertubeService.bs:188]", error)
        if raw
            parsedResponse["nextError"] = error
        end if
        return parsedResponse
    end if
    if raw
        parsedResponse["nextResponse"] = nextResponse.Json()
        return parsedResponse
    end if
    return Innertube_ParseInnertubeNextResponse(nextResponse.Json(), parsedResponse, nextRequest)
end function

function InnertubeService_GetVideoInfoBatched(videoIds as object, options = invalid as object) as object
    if not IsArray(videoIds) or videoIds.Count() = 0
        return {
            videos: []
        }
    end if
    cancellation = OptionUtils_Get(options, "cancellation")
    retry = OptionUtils_GetOrDefault(options, "retry", true)
    params = Innertube_GetEncodedNextParams(videoIds)
    request = Innertube_CreateNextRequest({
        "params": params
    })
    request.Cancellation(cancellation)
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    responseData = response.Json()
    error = Innertube_ParseResponseDataForError(responseData)
    if error <> ""
        return {
            error: error
        }
    end if
    
    if videoIds.Count() > 1
        responseData = ObjectUtils_Dig(responseData, [
            "contents"
            "twoColumnWatchNextResults"
            "playlist"
            "playlist"
        ])
        if responseData = invalid
            
            if retry
                LogWarn2("[InnertubeService.bs:246]", "Response data missing playlist. Retrying in a bit...")
                newOptions = {}
                if options <> invalid
                    newOptions.Append(options)
                end if
                newOptions["retry"] = false
                sleep(200 + Rnd(500))
                return InnertubeService_GetVideoInfoBatched(videoIds, newOptions)
            else
                LogWarn2("[InnertubeService.bs:255]", "Response data missing playlist. Not retrying.")
            end if
        end if
    end if
    feeds = Innertube_ParseResponseDataForFeeds(responseData, {
        request: request
    })
    if videoIds.Count() > 1
        if feeds.Count() > 0
            return {
                videos: ValidArray(feeds[0].items)
            }
        end if
    else
        if feeds.Count() > 0
            foundVideos = feeds[0].items
            for each video in foundVideos
                if video.videoId = videoIds[0]
                    return {
                        videos: [
                            video
                        ]
                    }
                end if
            end for
        end if
    end if
    return {
        videos: []
    }
end function

function InnertubeService_SearchSuggestions(q as string, cancellation = invalid as object) as object
    return Innertube_SearchSuggestions(q, cancellation)
end function

function InnertubeService_Search(query as string, options = invalid as object) as object
    return Innertube_Search(query, options)
end function

function InnertubeService_GetTrending(options = invalid as object) as object
    cancellation = OptionUtils_Get(options, "cancellation")
    trendingType = LCase(OptionUtils_GetOrDefault(options, "type", ""))
    disableShorts = OptionUtils_GetOrDefault(options, "disableShorts", false)
    raw = OptionUtils_GetOrDefault(options, "raw", false)
    if trendingType = "gaming"
        browseId = "UCOpNcN46UbXVtpKMrmU4Abg" 
        params = "Egh0cmVuZGluZw%3D%3D"
    else if trendingType = "music"
        browseId = "UC-9-kyTW8ZkZNDHQJ6FgpwQ" 
        params = "Egh0cmVuZGluZw%3D%3D"
    else
        browseId = "UC4R8DWoMoI7CAwX8_LjQHig" 
        params = "EgdsaXZldGFikgEDCKEK"
    end if
    request = Innertube_CreateBrowseRequest(browseId, "WEB", {
        params: params
    })
    request.Cancellation(cancellation)
    if raw
        request.LogCurlCommand()
    end if
    response = request.Await()
    if not response.IsSuccess() and trendingType = "music"
        
        request = Innertube_CreateBrowseRequest(browseId, "WEB")
        request.Cancellation(cancellation)
        response = request.Await()
    end if
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    if raw
        return response.Json()
    end if
    feeds = Innertube_ParseResponseDataForFeeds(response.Json(), {
        request: request
        disableCreatorOnTheRise: true
        disableShorts: disableShorts
        browseId: browseId
    })
    
    if trendingType = "music" and (feeds.Count() = 0 or not IsArray(feeds[0].items) or feeds[0].items.Count() = 0)
        fallbackRequest = Innertube_CreateBrowseRequest(browseId, "WEB")
        fallbackRequest.Cancellation(cancellation)
        fallbackResponse = fallbackRequest.Await()
        if fallbackResponse.IsSuccess()
            response = fallbackResponse
            feeds = Innertube_ParseResponseDataForFeeds(fallbackResponse.Json(), {
                request: fallbackRequest
                disableCreatorOnTheRise: true
                disableShorts: disableShorts
                browseId: browseId
            })
        end if
    end if
    result = {
        feeds: feeds
    }
    cacheControl = Innertube_ParseResponseForCacheControl(response)
    if cacheControl <> invalid
        result["cache-control"] = cacheControl
    end if
    return result
end function

function InnertubeService_GetHome(options = invalid as object) as object
    return InnertubeService_GetBrowseAuthenticatedPage("FEwhat_to_watch", options)
end function

function InnertubeService_GetSubscriptions(options = invalid as object) as object
    return InnertubeService_GetBrowseAuthenticatedPage("FEsubscriptions", options)
end function

function InnertubeService_GetWatchHistory(options = invalid as object) as object
    return InnertubeService_GetBrowseAuthenticatedPage("FEhistory", options)
end function

function InnertubeService_GetPlaylists(options = invalid as object) as object
    return InnertubeService_GetBrowseAuthenticatedPage("FEplaylist_aggregation", options)
end function

function InnertubeService_GetBrowseAuthenticatedPage(browseId as string, options = invalid as object) as object
    cancellation = OptionUtils_Get(options, "cancellation")
    accessToken = OptionUtils_Get(options, "accessToken")
    disableShorts = OptionUtils_GetOrDefault(options, "disableShorts", false)
    request = Innertube_CreateBrowseRequest(browseId, "TV", options)
    if accessToken <> invalid
        request.Header("Authorization", "Bearer " + accessToken)
    end if
    request.Cancellation(cancellation)
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    feeds = Innertube_ParseResponseDataForFeeds(response.Json(), {
        request: request
        disableShorts: disableShorts
        browseId: browseId
    })
    result = {
        feeds: feeds
    }
    cacheControl = Innertube_ParseResponseForCacheControl(response)
    if cacheControl <> invalid
        result["cache-control"] = cacheControl
    end if
    return result
end function

function InnertubeService_AuthGetPlaybackTrackingUrls(videoId as string, options as object) as object
    cancellation = invalid
    accessToken = options.accessToken
    if options.DoesExist("cancellation")
        cancellation = options.cancellation
    end if
    options["videoId"] = videoId
    stsResult = Innertube_GetSignatureTimestamp(cancellation)
    if stsResult.error <> invalid
        return stsResult
    end if
    options["signatureTimestamp"] = stsResult.sts
    playerRequest = Innertube_CreatePlayerRequest("TV", options)
    playerRequest.Cancellation(cancellation)
    playerRequest.Header("Authorization", "Bearer " + accessToken)
    playerResponse = playerRequest.Await()
    if not playerResponse.IsSuccess()
        return {
            error: playerResponse.ErrorMessage()
        }
    end if
    json = playerResponse.Json()
    error = Innertube_ParsePlayerResponseForError(json, playerRequest)
    if error <> ""
        return {
            error: error
        }
    end if
    videostatsPlaybackUrl = ObjectUtils_Dig(json, [
        "playbackTracking"
        "videostatsPlaybackUrl"
        "baseUrl"
    ])
    videostatsWatchtimeUrl = ObjectUtils_Dig(json, [
        "playbackTracking"
        "videostatsWatchtimeUrl"
        "baseUrl"
    ])
    return {
        videostatsPlaybackUrl: videostatsPlaybackUrl
        videostatsWatchtimeUrl: videostatsWatchtimeUrl
    }
end function

function InnertubeService_AuthMarkVideoWatched(videostatsPlaybackUrl as string, options as object) as boolean
    cancellation = OptionUtils_Get(options, "cancellation")
    accessToken = OptionUtils_Get(options, "accessToken")
    onBehalfOfUser = OptionUtils_Get(options, "onBehalfOfUser")
    cpn = OptionUtils_Get(options, "cpn")
    videostatsPlaybackUrl = videostatsPlaybackUrl.replace("https://s.", "https://www.")
    queryParams = UrlUtils_ParseQueryComponents(videostatsPlaybackUrl)
    queryParams["c"] = "TVHTML5"
    queryParams["cbrver"] = "7.20260611.00.00"
    queryParams["cver"] = "7.20260611.00.00"
    queryParams["ver"] = "2"
    queryParams["cmt"] = "0"
    queryParams["cpn"] = cpn
    queryParams["final"] = "1"
    videostatsPlaybackUrl = UrlUtils_SetQueryParams(videostatsPlaybackUrl, queryParams)
    request = HttpClient_Get(videostatsPlaybackUrl)
    request.Cancellation(cancellation)
    request.NoCache()
    request.Headers(Innertube_CreateHeaders("TV"))
    request.Header("Authorization", "Bearer " + accessToken)
    if not StringUtils_IsNullOrEmpty(onBehalfOfUser)
        request.Header("X-Goog-Pageid", onBehalfOfUser)
    end if
    response = request.Await()
    if not response.IsSuccess()
        LogError3("[InnertubeService.bs:496]", "Error marking video as watched:", response.ErrorMessage())
        return false
    end if
    
    return true
end function

function InnertubeService_AuthMarkVideoWatchTime(time as float, videostatsWatchtimeUrl as string, options = invalid as object) as boolean
    cancellation = OptionUtils_Get(options, "cancellation")
    accessToken = OptionUtils_Get(options, "accessToken")
    onBehalfOfUser = OptionUtils_Get(options, "onBehalfOfUser")
    timeStr = time.ToStr("%.3f")
    cpn = OptionUtils_Get(options, "cpn")
    videostatsWatchtimeUrl = videostatsWatchtimeUrl.replace("https://s.", "https://www.")
    queryParams = UrlUtils_ParseQueryComponents(videostatsWatchtimeUrl)
    queryParams["c"] = "TVHTML5"
    queryParams["cbrver"] = "7.20260611.00.00"
    queryParams["cver"] = "7.20260611.00.00"
    queryParams["ver"] = "2"
    queryParams["cpn"] = cpn
    queryParams["cmt"] = "0"
    queryParams["st"] = timeStr
    queryParams["et"] = timeStr
    queryParams["final"] = "1"
    videostatsWatchtimeUrl = UrlUtils_SetQueryParams(videostatsWatchtimeUrl, queryParams)
    request = HttpClient_Get(videostatsWatchtimeUrl)
    request.Cancellation(cancellation)
    request.NoCache()
    request.Headers(Innertube_CreateHeaders("TV"))
    request.Header("Authorization", "Bearer " + accessToken)
    if not StringUtils_IsNullOrEmpty(onBehalfOfUser)
        request.Header("X-Goog-Pageid", onBehalfOfUser)
    end if
    response = request.Await()
    if not response.IsSuccess()
        LogError3("[InnertubeService.bs:536]", "Error marking video watch time:", response.ErrorMessage())
        return false
    end if
    
    return true
end function

function InnertubeService_CreateClientPlaybackNonce() as string
    length = 16
    result = []
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
    alphabetLen = alphabet.len()
    for i = 1 to length
        result.push(alphabet.mid(Rnd(alphabetLen - 1), 1))
    end for
    return result.join("")
end function

function InnertubeService_GetChannel(channelId as string, options = invalid as object) as object
    cancellation = OptionUtils_Get(options, "cancellation")
    raw = OptionUtils_GetOrDefault(options, "raw", false)
    request = Innertube_CreateBrowseRequest(channelId, "WEB", options)
    request.Cancellation(cancellation)
    if raw
        request.LogCurlCommand()
    end if
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    if raw
        return response.Json()
    end if
    result = Innertube_ParseChannelPageResponseData(channelId, response.Json(), request)
    if result.authorId = invalid and result.error = invalid
        result["authorId"] = channelId
    end if
    cacheControl = Innertube_ParseResponseForCacheControl(response)
    if cacheControl <> invalid
        result["cache-control"] = cacheControl
    end if
    return result
end function

function InnertubeService_GetSubscriptionStatusForChannel(channelId as string, options = invalid as object) as object
    cancellation = OptionUtils_Get(options, "cancellation")
    accessToken = OptionUtils_Get(options, "accessToken")
    request = Innertube_CreateBrowseRequest(channelId, "TV", options)
    request.Cancellation(cancellation)
    if accessToken <> invalid
        request.Header("Authorization", "Bearer " + accessToken)
    end if
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    responseData = response.Json()
    error = Innertube_ParseResponseDataForError(responseData)
    if error <> ""
        return {
            error: error
        }
    end if
    channelHeaderButtons = ObjectUtils_Dig(responseData, [
        "contents"
        "tvBrowseRenderer"
        "content"
        "tvSurfaceContentRenderer"
        "header"
        "channelHeaderRenderer"
        "buttons"
    ])
    if not IsArray(channelHeaderButtons)
        return {
            error: "Node 'contents.tvBrowseRenderer.content.tvSurfaceContentRenderer.header.channelHeaderRenderer.buttons' not found"
        }
    end if
    subscribeButtonRenderer = invalid
    for each button in channelHeaderButtons
        if not IsAssociativeArray(button) or not button.DoesExist("subscribeButtonRenderer")
            continue for
        end if
        subscribeButtonRenderer = button.subscribeButtonRenderer
        exit for
    end for
    if subscribeButtonRenderer = invalid
        return {
            error: "no 'subscribeButtonRenderer' found under 'buttons'"
        }
    end if
    if not IsBool(subscribeButtonRenderer["subscribed"])
        return {
            error: "no 'subscribed' status found under 'subscribeButtonRenderer'"
        }
    end if
    return {
        success: true
        isSubscribed: subscribeButtonRenderer["subscribed"]
    }
end function

function InnertubeService_SubscribeToChannel(channelId as string, options = invalid as object) as object
    cancellation = OptionUtils_Get(options, "cancellation")
    accessToken = OptionUtils_Get(options, "accessToken")
    request = Innertube_CreateSubscribeRequest(channelId, options)
    request.Cancellation(cancellation)
    if accessToken <> invalid
        request.Header("Authorization", "Bearer " + accessToken)
    end if
    response = request.Await()
    return {
        success: response.IsSuccess()
        error: response.ErrorMessage()
    }
end function

function InnertubeService_UnsubscribeFromChannel(channelId as string, options = invalid as object) as object
    cancellation = OptionUtils_Get(options, "cancellation")
    accessToken = OptionUtils_Get(options, "accessToken")
    request = Innertube_CreateUnsubscribeRequest(channelId, options)
    request.Cancellation(cancellation)
    if accessToken <> invalid
        request.Header("Authorization", "Bearer " + accessToken)
    end if
    response = request.Await()
    return {
        success: response.IsSuccess()
        error: response.ErrorMessage()
    }
end function

function InnertubeService_GetPlaylist(playlistId as string, options = invalid as object) as object
    cancellation = OptionUtils_Get(options, "cancellation")
    raw = OptionUtils_GetOrDefault(options, "raw", false)
    accessToken = OptionUtils_Get(options, "accessToken")
    if not playlistId.StartsWith("VL")
        playlistId = "VL" + playlistId
    end if
    client = "WEB"
    if accessToken <> invalid
        client = "TV"
    end if
    request = Innertube_CreateBrowseRequest(playlistId, client, options)
    request.Cancellation(cancellation)
    if accessToken <> invalid
        request.Header("Authorization", "Bearer " + accessToken)
    end if
    if raw
        request.LogCurlCommand()
    end if
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    if raw
        return response.Json()
    end if
    result = Innertube_ParsePlaylistPageResponseData(playlistId, response.Json(), request)
    if result.playlistId = invalid and result.error = invalid
        result["playlistId"] = playlistId
    end if
    cacheControl = Innertube_ParseResponseForCacheControl(response)
    if cacheControl <> invalid
        result["cache-control"] = cacheControl
    end if
    return result
end function

function InnertubeService_GetMix(mixId as string, options = invalid as object) as object
    videoId = OptionUtils_Get(options, "videoId")
    cancellation = OptionUtils_Get(options, "cancellation")
    raw = OptionUtils_GetOrDefault(options, "raw", false)
    args = {
        "playlistId": mixId
    }
    if not StringUtils_IsNullOrEmpty(videoId)
        args["videoId"] = videoId
    end if
    request = Innertube_CreateNextRequest(args)
    request.Cancellation(cancellation)
    if raw
        request.LogCurlCommand()
    end if
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    if raw
        return response.Json()
    end if
    result = Innertube_ParseMixPageResponseData(response.Json(), request)
    cacheControl = Innertube_ParseResponseForCacheControl(response)
    if cacheControl <> invalid
        result["cache-control"] = cacheControl
    end if
    return result
end function

function InnertubeService_ResolveUrl(url as string, options = invalid as object) as object
    cancellation = OptionUtils_Get(options, "cancellation")
    request = Innertube_CreateResolveUrlRequest(url)
    request.Cancellation(cancellation)
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    json = response.Json()
    return json
end function

function InnertubeService_AuthGetCode(cancellation = invalid as object) as object
    result = Innertube_GetClientIdentity(cancellation)
    if CancellationUtils_IsCancelled(cancellation) or result.error <> invalid
        return result
    end if
    result2 = Innertube_GetDeviceAndUserCode(result.clientId, cancellation)
    if CancellationUtils_IsCancelled(cancellation) or result2.error <> invalid
        return result2
    end if
    result.Append(result2)
    return result
end function

function InnertubeService_AuthGetActivationUrl(code as object) as string
    return ("https://www.youtube.com/tv/activate?user_code=" + bslib_toString(code.userCode))
end function

function InnertubeService_AuthPollForAccessToken(code as object, cancellation = invalid as object) as object
    return Innertube_PollForAccessToken(code, code, cancellation)
end function

function InnertubeService_AuthRefreshAccessToken(accessToken as object, cancellation = invalid as object) as boolean
    if not IsAssociativeArray(accessToken)
        return false
    end if
    refreshed = Innertube_RefreshAccessToken(accessToken, cancellation)
    if IsAssociativeArray(refreshed) and refreshed.DoesExist("accessToken")
        accessToken.Append(refreshed)
        if accessToken.DoesExist("expiresIn")
            accessToken["expiresTimestamp"] = TimeUtils_Now().AsSeconds() + accessToken["expiresIn"]
        end if
        return true
    end if
    return false
end function

function InnertubeService_AuthRevokeToken(token as string, cancellation = invalid as object) as boolean
    return Innertube_RevokeToken(token, cancellation)
end function

function InnertubeService_AuthListAccounts(accessToken as string, cancellation = invalid as object) as object
    return Innertube_ListAccounts(accessToken, cancellation)
end function

function InnertubeService_GetDrmLicense(options as object) as object
    request = Innertube_CreateGetDrmLicenceRequest(options)
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    return Innertube_ParseGetDrmLicenseResponse(response.Json())
end function