'import "pkg:/components/Services/Innertube/LiveStreamInfo.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/UrlUtils.bs"
function Innertube_GetPostLiveDvrInfo(parsedResponse as object, adaptiveFormats as object, cpn as dynamic, cancellation as object) as void
    if adaptiveFormats.Count() = 0
        LogWarn2("[PostLiveDvrInfo.bs:9]", "GetPostLiveDvrInfo: No adaptive formats available")
        return
    end if
    formatUrl = adaptiveFormats[0]["url"]
    if StringUtils_IsNullOrEmpty(formatUrl)
        LogWarn2("[PostLiveDvrInfo.bs:15]", "GetPostLiveDvrInfo: URL is empty")
        return
    end if
    
    headUrl = Innertube_GetLiveHeadUrl(formatUrl, cpn)
    response = Innertube_FetchLiveHead(headUrl, cancellation)
    if not Innertube_HasLiveHead(response)
        
        fallback = Innertube_FetchLiveHead(UrlUtils_AppendQueryParams(headUrl, {
            "sq": "0"
        }), cancellation)
        diagnostics = Innertube_PostLiveDvrDiagnostics(parsedResponse["videoId"], headUrl, response, fallback)
        if not Innertube_HasLiveHead(fallback)
            
            LogTelemetryEvent({
                level: "warning"
                message: ("GetPostLiveDvrInfo: both no-sq and sq=0 missing head" + chr(10) + bslib_toString(diagnostics))
                fingerprint: [
                    "GetPostLiveDvrInfo: both no-sq and sq=0 missing head"
                ]
            })
            return
        end if
        LogTelemetryEvent({
            level: "warning"
            message: ("GetPostLiveDvrInfo: no-sq missing head, sq=0 fallback recovered" + chr(10) + bslib_toString(diagnostics))
            fingerprint: [
                "GetPostLiveDvrInfo: sq=0 fallback recovered"
            ]
        })
        response = fallback
    end if
    durationMs = Innertube_ReadLiveHeadAnyTimeMs(response)
    segmentCount = Innertube_ReadLiveHeadSeqnum(response)
    if durationMs > 0
        parsedResponse["postLiveDvrDurationMs"] = durationMs
    end if
    if segmentCount > 0
        parsedResponse["postLiveDvrSegmentCount"] = segmentCount
    end if
end function

function Innertube_PostLiveDvrDiagnostics(videoId as dynamic, headUrl as string, primary as object, fallback as object) as string
    return ("VideoID: " + bslib_toString(ValidString(videoId))) + Chr(10) + ("URL (no-sq; sq=0 appends &sq=0): " + bslib_toString(headUrl)) + Chr(10) + ("no-sq HEAD status: " + bslib_toString(primary.StatusCode().ToStr()) + " headers: " + bslib_toString(FormatJson(primary.Headers()))) + Chr(10) + ("sq=0 HEAD status: " + bslib_toString(fallback.StatusCode().ToStr()) + " headers: " + bslib_toString(FormatJson(fallback.Headers())))
end function