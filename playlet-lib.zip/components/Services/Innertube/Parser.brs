'import "pkg:/components/Services/Innertube/NodesParser.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/ObjectUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
function Innertube_ParseResponseDataForFeeds(responseData as object, context as object) as object
    if responseData = invalid
        return []
    end if
    if not ValidBool(context.noContainers)
        containers = Innertube_GetContainers(responseData)
        if containers.Count() = 0
            return []
        end if
    else
        containers = responseData
    end if
    context.Append({
        directives: Innertube_GetParsingDirectives()
        feeds: []
        currentFeed: {
            title: ""
            items: []
        }
        generateVideoThumbnails: true
    })
    Innertube_ParseNode(containers, context)
    if context.currentFeed <> invalid
        hasTitle = context.currentFeed.title <> ""
        hasItems = context.currentFeed.items.Count() > 0
        hasContinuation = context.currentFeed.DoesExist("continuation")
        if hasTitle or hasItems or hasContinuation
            context.feeds.Push(context.currentFeed)
            context.currentFeed = invalid
        end if
    end if
    
    if IsString(context.sectionContinuation) and context.feeds.Count() > 0
        context.feeds[0]["sectionContinuation"] = context.sectionContinuation
    end if
    return context.feeds
end function

function Innertube_ParseChannelPageResponseData(browseId as string, responseData as object, request as object) as object
    if responseData = invalid
        return {
            error: "Invalid response data"
        }
    end if
    error = Innertube_ParseResponseDataForError(responseData)
    if error <> ""
        return {
            error: error
        }
    end if
    author = ObjectUtils_Dig(responseData, [
        "metadata"
        "channelMetadataRenderer"
        "title"
    ])
    if author = invalid
        author = ObjectUtils_Dig(responseData, [
            "header"
            "pageHeaderRenderer"
            "pageTitle"
        ])
    end if
    authorId = ObjectUtils_Dig(responseData, [
        "metadata"
        "channelMetadataRenderer"
        "externalId"
    ])
    if StringUtils_IsNullOrEmpty(authorId)
        authorId = browseId
    end if
    thumbnails = ObjectUtils_Dig(responseData, [
        "metadata"
        "channelMetadataRenderer"
        "avatar"
        "thumbnails"
    ])
    if thumbnails = invalid
        thumbnails = ObjectUtils_Dig(responseData, [
            "header"
            "pageHeaderRenderer"
            "content"
            "pageHeaderViewModel"
            "image"
            "decoratedAvatarViewModel"
            "avatar"
            "avatarViewModel"
            "image"
            "sources"
        ])
        if thumbnails = invalid
            thumbnails = ObjectUtils_Dig(responseData, [
                "microformat"
                "microformatDataRenderer"
                "thumbnail"
                "thumbnails"
            ])
            if thumbnails = invalid
                thumbnails = []
            end if
        end if
    end if
    banners = ObjectUtils_Dig(responseData, [
        "header"
        "pageHeaderRenderer"
        "content"
        "pageHeaderViewModel"
        "banner"
        "imageBannerViewModel"
        "image"
        "sources"
    ])
    if banners = invalid
        banners = []
    end if
    authorSubTitle = ""
    contentMetadata = ObjectUtils_Dig(responseData, [
        "header"
        "pageHeaderRenderer"
        "content"
        "pageHeaderViewModel"
        "metadata"
        "contentMetadataViewModel"
    ])
    if contentMetadata <> invalid
        metadataRows = contentMetadata["metadataRows"]
        delimiter = (" " + bslib_toString(ValidString(contentMetadata["delimiter"])) + " ")
        if metadataRows <> invalid
            parts = []
            for each row in metadataRows
                metadataParts = row["metadataParts"]
                if metadataParts = invalid
                    continue for
                end if
                for each part in metadataParts
                    text = ObjectUtils_Dig(part, [
                        "text"
                        "content"
                    ])
                    if IsString(text)
                        parts.Push(text)
                    end if
                end for
            end for
            if parts.Count() > 0
                authorSubTitle = parts.Join(delimiter)
            end if
        end if
    end if
    tabsNames = []
    tabsParams = {}
    tabsTitles = {}
    tabs = ObjectUtils_Dig(responseData, [
        "contents"
        "twoColumnBrowseResultsRenderer"
        "tabs"
    ])
    if tabs <> invalid
        for each t in tabs
            tabRenderer = t["tabRenderer"]
            if tabRenderer = invalid
                continue for
            end if
            tabName = ObjectUtils_Dig(tabRenderer, [
                "endpoint"
                "commandMetadata"
                "webCommandMetadata"
                "url"
            ])
            if tabName = invalid
                continue for
            end if
            tabName = tabName.Split("?")[0]
            tabName = tabName.Split("/")
            tabName = tabName[tabName.Count() - 1]
            if StringUtils_IsNullOrEmpty(tabName)
                continue for
            end if
            tabsNames.Push(tabName)
            tabTitle = tabRenderer["title"]
            if IsString(tabTitle)
                tabsTitles[tabName] = tabTitle
            end if
            tabParams = ObjectUtils_Dig(tabRenderer, [
                "endpoint"
                "browseEndpoint"
                "params"
            ])
            if IsString(tabParams)
                tabsParams[tabName] = tabParams
            end if
        end for
    end if
    items = []
    continuation = invalid
    sortOptions = invalid
    feeds = Innertube_ParseResponseDataForFeeds(responseData, {
        request: request
        "currentAuthor": author
        "currentAuthorId": authorId
        browseId: browseId
    })
    if feeds.Count() > 0
        items = ValidArray(feeds[0].items)
        if feeds[0].DoesExist("continuation")
            continuation = feeds[0].continuation
        end if
        if feeds[0].DoesExist("sortOptions")
            sortOptions = feeds[0].sortOptions
        end if
    end if
    channel = {
        "author": author
        "authorId": authorId
        "authorThumbnails": thumbnails
        "authorBanners": banners
        "authorSubTitle": authorSubTitle
        "tabs": tabsNames
        "tabsParams": tabsParams
        "tabsTitles": tabsTitles
        "items": items
    }
    
    if continuation <> invalid
        channel["continuation"] = continuation
    end if
    if sortOptions <> invalid
        channel["sortOptions"] = sortOptions
    end if
    return channel
end function

function Innertube_ParsePlaylistPageResponseData(browseId as string, responseData as object, request as object) as object
    if responseData = invalid
        return {
            error: "Invalid response data"
        }
    end if
    error = Innertube_ParseResponseDataForError(responseData)
    if error <> ""
        return {
            error: error
        }
    end if
    playlistId = invalid
    title = invalid
    author = invalid
    authorId = invalid
    description = invalid
    videoCount = -1
    thumbnail = invalid
    statsText = invalid
    playlistSidebarRendererItems = ObjectUtils_Dig(responseData, [
        "sidebar"
        "playlistSidebarRenderer"
        "items"
    ])
    if playlistSidebarRendererItems <> invalid
        primaryInfo = ObjectUtils_Dig(playlistSidebarRendererItems, [
            0
            "playlistSidebarPrimaryInfoRenderer"
        ])
        secondaryInfo = ObjectUtils_Dig(playlistSidebarRendererItems, [
            1
            "playlistSidebarSecondaryInfoRenderer"
        ])
        playlistId = ObjectUtils_Dig(primaryInfo, [
            "navigationEndpoint"
            "watchEndpoint"
            "playlistId"
        ])
        title = Innertube_ParseText(ObjectUtils_Dig(primaryInfo, [
            "title"
        ]))
        description = Innertube_ParseText(ObjectUtils_Dig(primaryInfo, [
            "description"
        ]))
        videoCount = Innertube_ParseText(ObjectUtils_Dig(primaryInfo, [
            "stats"
            0
            "runs"
            0
            "text"
        ])).Replace(",", "").ToInt()
        thumbnail = ObjectUtils_Dig(primaryInfo, [
            "thumbnailRenderer"
            "playlistVideoThumbnailRenderer"
            "thumbnail"
            "thumbnails"
            0
            "url"
        ])
        author = Innertube_ParseText(ObjectUtils_Dig(secondaryInfo, [
            "videoOwner"
            "videoOwnerRenderer"
            "title"
        ]))
        authorId = ObjectUtils_Dig(secondaryInfo, [
            "videoOwner"
            "videoOwnerRenderer"
            "navigationEndpoint"
            "browseEndpoint"
            "browseId"
        ])
        stats = ObjectUtils_Dig(primaryInfo, [
            "stats"
        ])
        if IsArray(stats)
            statsTexts = []
            for each stat in stats
                statText = Innertube_ParseText(stat)
                if statText <> ""
                    statsTexts.Push(statText)
                end if
            end for
            statsText = statsTexts.Join(" • ")
        end if
    end if
    twoColumnRenderer = ObjectUtils_Dig(responseData, [
        "contents"
        "tvBrowseRenderer"
        "content"
        "tvSurfaceContentRenderer"
        "content"
        "twoColumnRenderer"
    ])
    if twoColumnRenderer <> invalid
        entityMetadataRenderer = ObjectUtils_Dig(twoColumnRenderer, [
            "leftColumn"
            "entityMetadataRenderer"
        ])
        if entityMetadataRenderer <> invalid
            if title = invalid
                title = Innertube_ParseText(entityMetadataRenderer["title"])
            end if
            if statsText = invalid
                statsText = Innertube_ParseLineRenderer(ObjectUtils_Dig(entityMetadataRenderer, [
                    "bylines"
                    0
                    "lineRenderer"
                ]))
            end if
            if description = invalid
                description = Innertube_ParseText(entityMetadataRenderer["description"])
            end if
            if playlistId = invalid
                playlistId = ObjectUtils_Dig(twoColumnRenderer, [
                    "rightColumn"
                    "playlistVideoListRenderer"
                    "playlistId"
                ])
            end if
        end if
    end if
    if StringUtils_IsNullOrEmpty(playlistId)
        playlistId = browseId
    end if
    playlist = {
        "playlistId": playlistId
        "videoCount": videoCount
        "videos": []
    }
    if title <> invalid
        playlist["title"] = title
    end if
    if author <> invalid
        playlist["author"] = author
    end if
    if authorId <> invalid
        playlist["authorId"] = authorId
    end if
    if description <> invalid
        playlist["description"] = description
    end if
    if thumbnail <> invalid
        playlist["playlistThumbnail"] = thumbnail
    end if
    if statsText <> invalid
        playlist["statsText"] = statsText
    end if
    feeds = Innertube_ParseResponseDataForFeeds(responseData, {
        request: request
        browseId: browseId
    })
    if feeds.Count() > 0
        playlist["videos"] = ValidArray(feeds[0].items)
        if feeds[0].DoesExist("continuation")
            playlist["continuation"] = feeds[0].continuation
        end if
    end if
    if playlist["playlistThumbnail"] = invalid and playlist["videos"].Count() > 0
        playlist["playlistThumbnail"] = ObjectUtils_Dig(playlist, [
            "videos"
            0
            "thumbnails"
            0
            "url"
        ])
    end if
    return playlist
end function

function Innertube_ParseMixPageResponseData(responseData as object, request as object) as object
    if responseData = invalid
        return {
            error: "Invalid response data"
        }
    end if
    error = Innertube_ParseResponseDataForError(responseData)
    if error <> ""
        return {
            error: error
        }
    end if
    playlist = ObjectUtils_Dig(responseData, [
        "contents"
        "twoColumnWatchNextResults"
        "playlist"
        "playlist"
    ])
    if playlist = invalid
        return {
            error: "Invalid playlist data"
        }
    end if
    playlistId = playlist["playlistId"]
    title = Innertube_ParseText(playlist["title"])
    if title = ""
        title = Innertube_ParseText(playlist["titleText"])
    end if
    author = Innertube_ParseText(playlist["ownerName"])
    if author = ""
        author = Innertube_ParseText(playlist["shortBylineText"])
        if author = ""
            author = Innertube_ParseText(playlist["longBylineText"])
        end if
    end if
    result = {
        "playlistId": playlistId
        "title": title
        "author": author
        "videos": []
        "videoCount": -1
        "videoCountText": ""
    }
    feeds = Innertube_ParseResponseDataForFeeds(playlist, {
        request: request
    })
    if feeds.Count() > 0
        result["videos"] = ValidArray(feeds[0].items)
    end if
    return result
end function

function Innertube_ParseResponseDataForError(responseData as object) as string
    error = ""
    if responseData = invalid
        return error
    end if
    alerts = responseData["alerts"]
    if not IsArray(alerts) or alerts.Count() = 0
        return error
    end if
    for each alert in alerts
        if not IsAssociativeArray(alert)
            continue for
        end if
        alertRenderer = alert["alertRenderer"]
        if alertRenderer = invalid
            alertRenderer = alert["alertWithButtonRenderer"]
        end if
        if not IsAssociativeArray(alertRenderer)
            continue for
        end if
        alertText = Innertube_ParseText(alertRenderer.text)
        if ValidString(alertRenderer.type) = "INFO"
            LogWarnNoTelemetry4("[Parser.bs:390]", "Innertube Alert:", ("[" + bslib_toString(alertRenderer.type) + "]"), alertText)
        else
            LogWarn4("[Parser.bs:392]", "Innertube Alert:", ("[" + bslib_toString(alertRenderer.type) + "]"), alertText)
        end if
        if alertRenderer.type = "ERROR"
            error += alertText
        end if
    end for
    return error
end function

function Innertube_ParseResponseForCacheControl(response as object) as dynamic
    if not response.IsSuccess()
        return invalid
    end if
    headers = response.Headers()
    if headers.DoesExist("cache-control")
        return headers["cache-control"]
    end if
    json = response.Json()
    maxAgeSeconds = ObjectUtils_Dig(json, [
        "responseContext"
        "maxAgeSeconds"
    ])
    if IsInt(maxAgeSeconds)
        return ("max-age=" + bslib_toString(maxAgeSeconds))
    end if
    return invalid
end function

function Innertube_GetContainers(responseData as object) as object
    return [
        responseData["contents"]
        responseData["response"]
        responseData["onResponseReceivedActions"]
        responseData["onResponseReceivedCommands"]
        responseData["continuationContents"]
    ]
end function