' Auto-generated file - do not modify manually
' md5:6966cee321cfa827e09c0f49b10a3fa8
'import "pkg:/source/Protobuf/BinaryReader.bs"
'import "pkg:/source/Protobuf/BinaryWriter.bs"
'import "pkg:/source/Protobuf/Decoder.bs"
'import "pkg:/source/Protobuf/Encoder.bs"





function Protobuf_Generated_misc_encodeFilters(message as dynamic, asByteArray = false as boolean) as dynamic
    buffer = CreateObject("roByteArray")
    writer = Protobuf_BinaryWriter()
    writer.SetBuffer(buffer)
    encoder = Protobuf_Encoder(writer)
    if message.DoesExist("upload_date")
        value = message["upload_date"]
        encoder.EncodeInt32(1, value)
    end if
    if message.DoesExist("type")
        value = message["type"]
        encoder.EncodeInt32(2, value)
    end if
    if message.DoesExist("duration")
        value = message["duration"]
        encoder.EncodeInt32(3, value)
    end if
    if message.DoesExist("features_hd")
        value = message["features_hd"]
        encoder.EncodeBool(4, value)
    end if
    if message.DoesExist("features_subtitles")
        value = message["features_subtitles"]
        encoder.EncodeBool(5, value)
    end if
    if message.DoesExist("features_creative_commons")
        value = message["features_creative_commons"]
        encoder.EncodeBool(6, value)
    end if
    if message.DoesExist("features_3d")
        value = message["features_3d"]
        encoder.EncodeBool(7, value)
    end if
    if message.DoesExist("features_live")
        value = message["features_live"]
        encoder.EncodeBool(8, value)
    end if
    if message.DoesExist("features_purchased")
        value = message["features_purchased"]
        encoder.EncodeBool(9, value)
    end if
    if message.DoesExist("features_4k")
        value = message["features_4k"]
        encoder.EncodeBool(14, value)
    end if
    if message.DoesExist("features_360")
        value = message["features_360"]
        encoder.EncodeBool(15, value)
    end if
    if message.DoesExist("features_location")
        value = message["features_location"]
        encoder.EncodeBool(23, value)
    end if
    if message.DoesExist("features_hdr")
        value = message["features_hdr"]
        encoder.EncodeBool(25, value)
    end if
    if message.DoesExist("features_vr180")
        value = message["features_vr180"]
        encoder.EncodeBool(26, value)
    end if
    if asByteArray
        return buffer
    else
        return buffer.ToBase64String().EncodeUriComponent()
    end if
end function

function Protobuf_Generated_misc_encodeSearchFilter(message as dynamic, asByteArray = false as boolean) as dynamic
    buffer = CreateObject("roByteArray")
    writer = Protobuf_BinaryWriter()
    writer.SetBuffer(buffer)
    encoder = Protobuf_Encoder(writer)
    if message.DoesExist("sort_by")
        value = message["sort_by"]
        encoder.EncodeInt32(1, value)
    end if
    if message.DoesExist("filters")
        value = message["filters"]
        encoder.EncodeMessage(2, Protobuf_Generated_misc_encodeFilters(value, true))
    end if
    if asByteArray
        return buffer
    else
        return buffer.ToBase64String().EncodeUriComponent()
    end if
end function

function Protobuf_Generated_misc_encodeNextParams(message as dynamic, asByteArray = false as boolean) as dynamic
    buffer = CreateObject("roByteArray")
    writer = Protobuf_BinaryWriter()
    writer.SetBuffer(buffer)
    encoder = Protobuf_Encoder(writer)
    if message.DoesExist("video_id")
        for each value in message["video_id"]
            encoder.EncodeString(5, value)
        end for
    end if
    if asByteArray
        return buffer
    else
        return buffer.ToBase64String().EncodeUriComponent()
    end if
end function