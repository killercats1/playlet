'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/MathUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/UrlUtils.bs"
' Hard ceiling for the exposed DVR window. availabilityStartTime is anchored this
' far back at most so the player's ms-scale presentation time (now - AST) stays well
' under INT32_MAX (~24.8 days at timescale=1000). YouTube caps live DVR at 12h.

' videoDetails.liveChunkReadahead when /player omits it: what YouTube sends for normal
' and low latency streams.

' liveChunkReadahead is clamped to at least 3 seconds' worth and at most this many segments.

' Live streams come back with no hlsManifestUrl/dashManifestUrl, just
' adaptiveFormats with a `targetDurationSec` and segments addressed by `&sq=N`.
' The generated dynamic DASH manifest lists the segments that exist (a
' SegmentTimeline ending behind the live head, see DashManifest), anchored here once
' per video load: availabilityStartTime and the segment numbering must not change
' across manifest refreshes.
'
' Works off the signed `adaptiveFormats[0].url` alone: googlevideo answers the head
' check with the X-Head-* headers whatever the backend. Without them there is no
' timeline to list, so the load fails with the cause in parsedResponse.error.
function Innertube_GetLiveStreamInfo(parsedResponse as object, adaptiveFormats as object, chunkReadahead as integer, cpn as dynamic, cancellation as object) as void
    if adaptiveFormats.Count() = 0 or StringUtils_IsNullOrEmpty(adaptiveFormats[0]["url"])
        parsedResponse["error"] = "Live stream has no format url to read its head from"
        return
    end if
    headUrl = Innertube_GetLiveHeadUrl(adaptiveFormats[0]["url"], cpn)
    response = Innertube_FetchLiveHead(headUrl, cancellation)
    if not Innertube_HasLiveHead(response)
        parsedResponse["error"] = ("Live stream head check returned no X-Head-Seqnum / X-Head-Time (HTTP " + bslib_toString(response.StatusCode()) + ")" + chr(10) + bslib_toString(response.ErrorMessage()))
        return
    end if
    now = CreateObject("roDateTime")
    timeline = Innertube_GetLiveTimeline(Innertube_ReadLiveHeadSeqnum(response), Innertube_ReadLiveHeadAnyTimeMs(response), ValidInt(adaptiveFormats[0]["targetDurationSec"]), ValidInt(adaptiveFormats[0]["maxDvrDurationSec"]), chunkReadahead, now.AsSeconds(), now.GetMilliseconds())
    parsedResponse.Append(timeline)
    parsedResponse["liveHeadUrl"] = headUrl
    parsedResponse["liveHeadTimeMs"] = Innertube_ReadLiveHeadTimeMs(response)
end function

' The live timeline fields for a stream whose head (newest segment) is
' `headSeqnum`, `headTimeMs` into the stream, observed at `nowSec`.`nowMs`.
function Innertube_GetLiveTimeline(headSeqnum as integer, headTimeMs as dynamic, targetDurationSec as integer, maxDvrDurationSec as integer, chunkReadahead as integer, nowSec as integer, nowMs as integer) as object
    
    segmentDurationMs = 0
    if headSeqnum > 0
        segmentDurationMs = Cint(headTimeMs / headSeqnum)
    end if
    if segmentDurationMs <= 0
        segmentDurationMs = MathUtils_Max(targetDurationSec, 1) * 1000
    end if
    
    windowSec = maxDvrDurationSec
    if windowSec <= 0 or windowSec > 43200
        windowSec = 43200
    end if
    windowSegments = MathUtils_Max(windowSec * 1000 \ segmentDurationMs, 1)
    firstSeqnum = MathUtils_Max(headSeqnum - windowSegments + 1, 0)
    
    chunks = chunkReadahead
    if chunks <= 0
        chunks = 3
    end if
    minChunks = MathUtils_Max((3000 + segmentDurationMs - 1) \ segmentDurationMs, 1)
    chunks = MathUtils_Clamp(chunks, minChunks, 8)
    cushionMs = chunks * segmentDurationMs
    
    if cushionMs >= (headSeqnum - firstSeqnum + 1) * segmentDurationMs
        cushionMs = 0
    end if
    
    shiftedMs = 43200 * 1000 + nowMs + cushionMs - (headSeqnum - firstSeqnum + 1) * segmentDurationMs
    astDate = CreateObject("roDateTime")
    astDate.FromSeconds(nowSec - 43200 + shiftedMs \ 1000)
    return {
        "liveHeadSeqnum": headSeqnum
        "liveFirstSeqnum": firstSeqnum
        "liveWindowSegments": windowSegments
        "liveSegmentDurationMs": segmentDurationMs
        "liveTimelineOffsetMs": shiftedMs mod 1000
        "liveAvailabilityStartUtc": astDate.ToISOString()
        ' The player's seek floor: the window less the cushion, and less a segment for
        ' the listed timeline's alignment (DashRouter.AlignLiveTimeline).
        "liveSeekableWindowSec": MathUtils_Max((windowSegments - 1) * segmentDurationMs - cushionMs, 0) \ 1000
    }
end function

' The format url with NO `sq` queries the stream's live head: googlevideo answers
' at once with the X-Head-* headers (X-Head-Seqnum = newest available segment).
' Pinning `sq=0` instead makes googlevideo answer about segment 0 specifically, and for
' some streams (observed targetDurationSec=5) it then omits X-Head-* entirely
' (only X-Sequence-Num/X-Walltime-Ms).
function Innertube_GetLiveHeadUrl(formatUrl as string, cpn as dynamic) as string
    queryComponents = UrlUtils_ParseQueryComponents(formatUrl)
    queryComponents["rn"] = "0"
    if not StringUtils_IsNullOrEmpty(cpn)
        queryComponents["cpn"] = cpn
    end if
    return UrlUtils_SetQueryParams(formatUrl, queryComponents)
end function

function Innertube_CreateLiveHeadRequest(headUrl as string) as object
    request = HttpClient_Head(headUrl)
    request.Headers({
        "origin": "https://www.youtube.com"
        "referer": "https://www.youtube.com"
        "DNT": "?1"
    })
    return request
end function

' The head check's answer, sent once more when it lacks the head (HasLiveHead), whatever its HTTP status.
function Innertube_FetchLiveHead(headUrl as string, cancellation as object) as object
    request = Innertube_CreateLiveHeadRequest(headUrl)
    request.RetryCount(1)
    request.RetryIf(function(response as object) as string
        if not Innertube_HasLiveHead(response)
            return ("no X-Head-* in the response (HTTP " + bslib_toString(response.StatusCode()) + ")")
        end if
        return ""
    end function)
    request.Cancellation(cancellation)
    return request.Await()
end function

' Whether a head check's answer carries the head's seqnum and time.
function Innertube_HasLiveHead(response as object) as boolean
    return Innertube_ReadLiveHeadSeqnum(response) >= 0 and Innertube_ReadLiveHeadAnyTimeMs(response) <> invalid
end function

' X-Head-Seqnum of a live head response, -1 if absent. Not gated on HTTP status: a
' head check can come back non-2xx yet still carry the X-Head-* headers
' (observed: one stream returns 500, another 200; both include them).
function Innertube_ReadLiveHeadSeqnum(response as object) as integer
    headers = response.Headers()
    if not headers.DoesExist("X-Head-Seqnum")
        return -1
    end if
    return ValidString(headers["X-Head-Seqnum"]).ToInt()
end function

' How far into the stream the head is (ms, X-Head-Time-Millis), invalid if absent. A
' long-running stream's (e.g. 207 days = 1.79e10 ms) overflows BrightScript's 32-bit
' int: ParseJson keeps it as a LongInteger, which .ToInt() and Cdbl() would truncate
' (measured).
function Innertube_ReadLiveHeadTimeMs(response as object) as dynamic
    return StringUtils_ParseJsonSafe(ValidString(response.Headers()["X-Head-Time-Millis"]))
end function

' X-Head-Time-Millis, else X-Head-Time-Sec in ms, invalid if neither.
function Innertube_ReadLiveHeadAnyTimeMs(response as object) as dynamic
    timeMs = Innertube_ReadLiveHeadTimeMs(response)
    if timeMs = invalid
        timeMs = Innertube_ReadLiveHeadTimeSecAsMs(response)
    end if
    return timeMs
end function

' X-Head-Time-Sec in ms, invalid if absent: whole seconds, too coarse to average a
' young stream's few segments or to time the head between checks.
function Innertube_ReadLiveHeadTimeSecAsMs(response as object) as dynamic
    headers = response.Headers()
    if not headers.DoesExist("X-Head-Time-Sec")
        return invalid
    end if
    return ValidString(headers["X-Head-Time-Sec"]).ToInt() * 1000&
end function