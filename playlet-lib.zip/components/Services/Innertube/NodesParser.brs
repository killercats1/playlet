' Throw an error if an unknown node is encountered.
' Only used in debug mode.
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/ObjectUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
function Innertube_ParseNode(nodeData as object, context as object) as void
    if IsArray(nodeData)
        for each item in nodeData
            Innertube_ParseNode(item, context)
        end for
        return
    end if
    if not IsAssociativeArray(nodeData)
        return
    end if
    directives = context["directives"]
    for each key in nodeData
        directive = directives[key]
        if directive = invalid
            Innertube_Warning(("Unknown node " + bslib_toString(key)), nodeData[key], context)
            
            continue for
        end if
        subdata = directive(nodeData[key], context)
        Innertube_ParseNode(subdata, context)
    end for
end function

function Innertube_GetParsingDirectives() as object
    return {
        "twoColumnSearchResultsRenderer": Innertube_ParseTwoColumnSearchResultsRenderer
        "singleColumnBrowseResultsRenderer": Innertube_ParseSingleColumnBrowseResultsRenderer
        "twoColumnBrowseResultsRenderer": Innertube_ParseTwoColumnBrowseResultsRenderer
        "twoColumnWatchNextResults": Innertube_ParseTwoColumnWatchNextResults
        "watchNextEndScreenRenderer": Innertube_ParseWatchNextEndScreenRenderer
        "tabRenderer": Innertube_ParseTabRenderer
        "sectionListRenderer": Innertube_ParseSectionListRenderer
        "sectionListContinuation": Innertube_ParseSectionListRenderer
        "richSectionRenderer": Innertube_ParseRichSectionRenderer
        "itemSectionRenderer": Innertube_ParseItemSectionRenderer
        "shelfRenderer": Innertube_ParseShelfRenderer
        "richShelfRenderer": Innertube_ParseRichShelfRenderer
        "reelShelfRenderer": Innertube_ParseReelShelfRenderer
        "verticalListRenderer": Innertube_ParseVerticalListRenderer
        "horizontalListRenderer": Innertube_ParseHorizontalListRenderer
        "horizontalListContinuation": Innertube_ParseHorizontalListContinuation
        "expandedShelfContentsRenderer": Innertube_ParseExpandedShelfContentsRenderer
        "channelFeaturedContentRenderer": Innertube_ParseChannelFeaturedContentRenderer
        "playlistVideoListRenderer": Innertube_ParsePlaylistVideoListRenderer
        "playlistVideoListContinuation": Innertube_ParsePlaylistVideoListContinuation
        "videoRenderer": Innertube_ParseVideoRenderer
        "gridVideoRenderer": Innertube_ParseGridVideoRenderer
        "compactVideoRenderer": Innertube_ParseCompactVideoRenderer
        "videoPrimaryInfoRenderer": Innertube_ParseVideoPrimaryInfoRenderer
        "channelVideoPlayerRenderer": Innertube_ParseChannelVideoPlayerRenderer
        "playlistVideoRenderer": Innertube_ParsePlaylistVideoRenderer
        "playlistPanelVideoRenderer": Innertube_ParsePlaylistPanelVideoRenderer
        "endScreenVideoRenderer": Innertube_ParseEndScreenVideoRenderer
        "channelRenderer": Innertube_ParseChannelRenderer
        "gridChannelRenderer": Innertube_ParseGridChannelRenderer
        "playlistRenderer": Innertube_ParsePlaylistRenderer
        "gridPlaylistRenderer": Innertube_ParseGridPlaylistRenderer
        "gridShelfViewModel": Innertube_ParseGridShelfViewModel
        "lockupViewModel": Innertube_ParseLockupViewModel
        "shortsLockupViewModel": Innertube_ParseShortsLockupViewModel
        "tvBrowseRenderer": Innertube_ParseTvBrowseRenderer
        "tvSurfaceContentRenderer": Innertube_ParseTvSurfaceContentRenderer
        "tvSecondaryNavRenderer": Innertube_ParseTvSecondaryNavRenderer
        "tvSecondaryNavSectionRenderer": Innertube_ParseTvSecondaryNavSectionRenderer
        "twoColumnRenderer": Innertube_ParseTwoColumnRenderer
        "tileRenderer": Innertube_ParseTileRenderer
        "gridRenderer": Innertube_ParseGridRenderer
        "richGridRenderer": Innertube_ParseRichGridRenderer
        "richItemRenderer": Innertube_ParseRichItemRenderer
        "feedFilterChipBarRenderer": Innertube_ParseFeedFilterChipBarRenderer
        "chipBarViewModel": Innertube_ParseChipBarViewModel
        "continuationItemRenderer": Innertube_ParseContinuationItemRenderer
        "continuationItemViewModel": Innertube_ParseContinuationItemViewModel
        "appendContinuationItemsAction": Innertube_ParseAppendContinuationItemsAction
        "reloadContinuationItemsCommand": Innertube_ParseReloadContinuationItemsCommand
        "gridContinuation": Innertube_ParseGridContinuation
        "tvSurfaceContentContinuation": Innertube_ParseTvSurfaceContentContinuation
        "gridButtonRenderer": Innertube_ParseGridButtonRenderer
        "movieRenderer": Innertube_ParseMovieRenderer
        "gridMovieRenderer": Innertube_ParseGridMovieRenderer
        "compactMovieRenderer": Innertube_ParseCompactMovieRenderer
        "horizontalMovieListRenderer": Innertube_ParseHorizontalMovieListRenderer
        ' Movies and shows are partially supported, but these renderers are not yet implemented.
        ' TODO:P1 implement show support in grid
        "gridShowRenderer": Innertube_ParseNotImplemented
        "playlistShowMetadataRenderer": Innertube_ParseNotImplemented
        ' Ignored nodes:
        ' TODO:P2 handle navigateAction - which are usually a redirect
        ' "navigateAction": ParseNotImplemented
        "radioRenderer": Innertube_ParseRadioRenderer
        "compactRadioRenderer": Innertube_ParseCompactRadioRenderer
        ' TODO:P2 A carousel of videos, found on the home tab of a channel.
        ' Should probably be parsed.
        ' "carouselItemRenderer": ParseNotImplemented
        ' When searching for hashtags, this renderer is used.
        ' It redirects to a page similar to a channel page, with browseId "FEhashtag"
        ' the hashtag name is encoded in a proto and passed as a param to the browseEndpoint.
        "hashtagTileRenderer": Innertube_ParseNotImplemented
        ' Contains comments "teaser".
        "commentsEntryPointHeaderRenderer": Innertube_ParseNotImplemented
        ' Contains the owner of the video from "videoPrimaryInfoRenderer"
        "videoSecondaryInfoRenderer": Innertube_ParseNotImplemented
        ' Empty node? Perhaps used in some cases
        "compositeVideoPrimaryInfoRenderer": Innertube_ParseNotImplemented
        ' An information panel, could contain a link to some website, or a message.
        "infoPanelContainerRenderer": Innertube_ParseNotImplemented
        ' When you mispell something in the search bar, this renderer shows
        "didYouMeanRenderer": Innertube_ParseNotImplemented
        ' A list of subscribers in a channel with a CTA to subscribe.
        "recognitionShelfRenderer": Innertube_ParseNotImplemented
        ' A playlist at the end of a video. We don't need that for now.
        "endScreenPlaylistRenderer": Innertube_ParseNotImplemented
        ' Posts not yet supported
        "postRenderer": Innertube_ParseNotImplemented
        ' a "View all posts" button
        "buttonCardViewModel": Innertube_ParseNotImplemented
        ' to show chapters of a particular video in the search results
        "horizontalCardListRenderer": Innertube_ParseNotImplemented
        ' expandableTabRenderer contains the search tab with a channel. Ignored.
        "expandableTabRenderer": Innertube_ParseNotImplemented
        ' Shows a view of an official channel (like an artist) with tracks or albums.
        ' Shows up in search results. Safe to ignore since the channel itself will also
        ' be shown in the search results, so this is kind of a duplicate.
        "officialCardViewModel": Innertube_ParseNotImplemented
        ' Usually contains a "X unavailable video(s) are hidden" message. Ignored.
        "messageRenderer": Innertube_ParseNotImplemented
        ' Messages like "Videos you watch will be saved here"
        "genericPromoRenderer": Innertube_ParseNotImplemented
        ' "Sign in to see the latest videos tailored to your interests"
        "feedNudgeRenderer": Innertube_ParseNotImplemented
        ' "Your watch history is off" - "You can change your setting at any time to get the latest videos tailored to you."
        "alertWithActionsRenderer": Innertube_ParseNotImplemented
        ' "No results found, Try different keywords or remove search filters"
        "backgroundPromoRenderer": Innertube_ParseNotImplemented
        ' Autocorrect for search terms
        "showingResultsForRenderer": Innertube_ParseNotImplemented
        "includingResultsForRenderer": Innertube_ParseNotImplemented
        ' "This channel has no podcasts."
        "channelOwnerEmptyStateRenderer": Innertube_ParseNotImplemented
        ' Live chat replay ("See what others said about this video while it was live.")
        "videoMetadataCarouselViewModel": Innertube_ParseNotImplemented
        ' A link to some content, like a wikipedia article.
        "infoPanelContentRenderer": Innertube_ParseNotImplemented
        ' {"blockCurrentSession":true,"error":"SUPEX_ONBOARDING_ERROR_KIDS_ONLY"}
        "supexOnboardingErrorCommand": Innertube_ParseNotImplemented
        ' Suicide & crisis lifeline, shown on sensitive content
        "emergencyOneboxRenderer": Innertube_ParseNotImplemented
        ' Suicide & crisis lifeline, within search
        "searchFrictionViewModel": Innertube_ParseNotImplemented
        "shoppingTimelyShelfViewModel": Innertube_ParseNotImplemented
        "backstagePostRenderer": Innertube_ParseNotImplemented
        "backstagePostThreadRenderer": Innertube_ParseNotImplemented
        "counterfactualRenderer": Innertube_ParseNotImplemented
        "ticketShelfRenderer": Innertube_ParseNotImplemented
        "videoSurveyShelfRenderer": Innertube_ParseNotImplemented
        "popupSurveyShelfRenderer": Innertube_ParseNotImplemented
        "searchBarRenderer": Innertube_ParseNotImplemented
        "clickTrackingParams": Innertube_ParseNotImplemented
        "promoShelfRenderer": Innertube_ParseNotImplemented
        "merchandiseShelfRenderer": Innertube_ParseNotImplemented
        "statementBannerRenderer": Innertube_ParseNotImplemented
        "adSlotRenderer": Innertube_ParseNotImplemented
        "adsControlFlowOpportunityReceivedCommand": Innertube_ParseNotImplemented
    }
end function

function Innertube_ParseTwoColumnSearchResultsRenderer(nodeData as object, _context as object) as object
    return nodeData["primaryContents"]
end function

function Innertube_ParseSingleColumnBrowseResultsRenderer(nodeData as object, _context as object) as object
    return nodeData["tabs"]
end function

function Innertube_ParseTwoColumnBrowseResultsRenderer(nodeData as object, _context as object) as object
    return nodeData["tabs"]
end function

function Innertube_ParseTwoColumnWatchNextResults(nodeData as object, context as object) as object
    subItems = []
    results = ObjectUtils_Dig(nodeData, [
        "results"
        "results"
        "contents"
    ])
    if results <> invalid
        subItems.Push(results)
    end if
    secondaryResults = ObjectUtils_Dig(nodeData, [
        "secondaryResults"
        "secondaryResults"
        "results"
    ])
    if secondaryResults <> invalid
        subItems.Push(secondaryResults)
    end if
    
    playlist = ObjectUtils_Dig(nodeData, [
        "playlist"
        "playlist"
        "contents"
    ])
    if playlist <> invalid
        subItems.Push(playlist)
    end if
    if subItems.Count() = 0
        Innertube_Warning("No results found in twoColumnWatchNextResults", nodeData, context)
        return invalid
    end if
    return subItems
end function

function Innertube_ParseWatchNextEndScreenRenderer(nodeData as object, _context as object) as object
    return nodeData["results"]
end function

function Innertube_ParseTabRenderer(nodeData as object, context as object) as object
    selected = nodeData["selected"]
    if not ValidBool(selected)
        return invalid
    end if
    Innertube_StartNewFeed(Innertube_ParseText(nodeData["title"]), context)
    return nodeData["content"]
end function

function Innertube_ParseSectionListRenderer(nodeData as object, context as object) as object
    sortSubMenuItems = ObjectUtils_Dig(nodeData, [
        "subMenu"
        "channelSubMenuRenderer"
        "sortSetting"
        "sortFilterSubMenuRenderer"
        "subMenuItems"
    ])
    if IsArray(sortSubMenuItems)
        sortOptions = []
        for each item in sortSubMenuItems
            params = ValidString(ObjectUtils_Dig(item, [
                "navigationEndpoint"
                "browseEndpoint"
                "params"
            ]))
            title = Innertube_ParseText(item["title"])
            isSelected = ValidBool(item["selected"])
            if params <> "" and title <> ""
                sortOptions.Push({
                    "title": title
                    "params": params
                    "isSelected": isSelected
                })
            end if
        end for
        if sortOptions.Count() > 0
            context.currentFeed.sortOptions = sortOptions
        end if
    end if
    continuation = ObjectUtils_Dig(nodeData, [
        "continuations"
        0
        "nextContinuationData"
        "continuation"
    ])
    if IsString(continuation)
        
        context.sectionContinuation = continuation
        if not StringUtils_IsNullOrEmpty(context.currentFeed.continuation)
            Innertube_StartNewFeed("", context)
        end if
        context.currentFeed.continuation = continuation
    end if
    return nodeData["contents"]
end function

function Innertube_ParseRichSectionRenderer(nodeData as object, _context as object) as object
    return nodeData["content"]
end function

function Innertube_ParseItemSectionRenderer(nodeData as object, _context as object) as object
    return nodeData["contents"]
end function

function Innertube_ParseShelfRenderer(nodeData as object, context as object) as object
    if context.disableCreatorOnTheRise = true
        badges = nodeData["badges"]
        if IsArray(badges)
            for each badge in badges
                if ValidString(ObjectUtils_Dig(badge, [
                    "metadataBadgeRenderer"
                    "style"
                ])) = "BADGE_STYLE_TYPE_FEATURED"
                    label = Innertube_ParseText(ObjectUtils_Dig(badge, [
                        "metadataBadgeRenderer"
                        "label"
                    ]))
                    LogInfo2("[NodesParser.bs:286]", ("Skipping 'Creator on the Rise' shelf (" + bslib_toString(label) + ")"))
                    return invalid
                end if
            end for
        end if
    end if
    if ValidString(context.browseId) = "FEwhat_to_watch"
        
        heroCarouselHeader = ObjectUtils_Dig(nodeData, [
            "headerRenderer"
            "heroCarouselHeaderRenderer"
        ])
        if heroCarouselHeader <> invalid
            LogInfo2("[NodesParser.bs:299]", "Skipping shelf with heroCarouselHeaderRenderer")
            return invalid
        end if
    end if
    
    browseId = ValidString(context.browseId)
    if browseId = "FEwhat_to_watch" or browseId.StartsWith("FEtopics_")
        if context.currentFeed <> invalid and context.currentFeed.items.Count() > 0
            Innertube_StartNewFeed("", context)
        end if
        context.shelfTitle = Innertube_ShelfTitle(nodeData)
    end if
    return nodeData["content"]
end function

function Innertube_ShelfTitle(nodeData as object) as string
    header = ObjectUtils_Dig(nodeData, [
        "headerRenderer"
        "shelfHeaderRenderer"
    ])
    title = Innertube_ParseText(ObjectUtils_Dig(header, [
        "title"
    ]))
    if title = ""
        title = Innertube_ParseText(ObjectUtils_Dig(header, [
            "avatarLockup"
            "avatarLockupRenderer"
            "title"
        ]))
    end if
    if title = ""
        title = Innertube_ParseText(nodeData["title"])
    end if
    return title
end function

function Innertube_ParseRichShelfRenderer(nodeData as object, _context as object) as object
    
    return nodeData["contents"]
end function

function Innertube_ParseReelShelfRenderer(nodeData as object, context as object) as object
    if context.disableShorts = true
        LogInfo2("[NodesParser.bs:336]", "Skipping ReelShelfRenderer based on user settings")
        return invalid
    end if
    
    return nodeData["items"]
end function

function Innertube_ParseVerticalListRenderer(nodeData as object, _context as object) as object
    return nodeData["items"]
end function

function Innertube_ParseHorizontalListRenderer(nodeData as object, context as object) as object
    continuation = ObjectUtils_Dig(nodeData, [
        "continuations"
        0
        "nextContinuationData"
        "continuation"
    ])
    if IsString(continuation)
        if not StringUtils_IsNullOrEmpty(context.currentFeed.continuation)
            Innertube_StartNewFeed("", context)
        end if
        context.currentFeed.continuation = continuation
    end if
    return nodeData["items"]
end function

function Innertube_ParseHorizontalListContinuation(nodeData as object, context as object) as object
    continuation = ObjectUtils_Dig(nodeData, [
        "continuations"
        0
        "nextContinuationData"
        "continuation"
    ])
    if IsString(continuation)
        if not StringUtils_IsNullOrEmpty(context.currentFeed.continuation)
            Innertube_StartNewFeed("", context)
        end if
        context.currentFeed.continuation = continuation
    end if
    return nodeData["items"]
end function

function Innertube_ParseExpandedShelfContentsRenderer(nodeData as object, _context as object) as object
    return nodeData["items"]
end function

function Innertube_ParseChannelFeaturedContentRenderer(nodeData as object, _context as object) as object
    return nodeData["items"]
end function

function Innertube_ParsePlaylistVideoListRenderer(nodeData as object, context as object) as object
    continuation = ObjectUtils_Dig(nodeData, [
        "continuations"
        0
        "nextContinuationData"
        "continuation"
    ])
    if IsString(continuation)
        context.currentFeed.continuation = continuation
    end if
    return nodeData["contents"]
end function

function Innertube_ParsePlaylistVideoListContinuation(nodeData as object, context as object) as object
    continuation = ObjectUtils_Dig(nodeData, [
        "continuations"
        0
        "nextContinuationData"
        "continuation"
    ])
    if IsString(continuation)
        context.currentFeed.continuation = continuation
    end if
    return nodeData["contents"]
end function

function Innertube_ParseVideoRenderer(nodeData as object, context as object) as object
    videoId = nodeData["videoId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid video ID in videoRenderer", nodeData, context)
        return invalid
    end if
    author = invalid
    authorId = invalid
    authorPossibleNodes = [
        "ownerText"
        "shortBylineText"
        "longBylineText"
    ]
    for each authorPossibleNode in authorPossibleNodes
        node = nodeData[authorPossibleNode]
        author = Innertube_ParseText(node)
        authorId = ObjectUtils_Dig(node, [
            "runs"
            0
            "navigationEndpoint"
            "browseEndpoint"
            "browseId"
        ])
        if author <> "" and authorId <> invalid
            exit for
        end if
    end for
    if StringUtils_IsNullOrEmpty(author) and StringUtils_IsNullOrEmpty(authorId)
        if IsString(context.currentAuthor) and IsString(context.currentAuthorId)
            author = context.currentAuthor
            authorId = context.currentAuthorId
        end if
    end if
    viewCountText = Innertube_ParseText(nodeData["shortViewCountText"])
    if viewCountText = ""
        viewCountText = Innertube_ParseText(nodeData["viewCountText"])
    end if
    publishedText = Innertube_ParseText(nodeData["publishedTimeText"])
    lengthText = Innertube_ParseText(nodeData["lengthText"])
    if context.generateVideoThumbnails = true
        videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
    else
        videoThumbnails = ObjectUtils_Dig(nodeData, [
            "thumbnail"
            "thumbnails"
        ])
        if videoThumbnails = invalid
            videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
        end if
    end if
    isUpcoming = false
    liveNow = false
    thumbnailOverlays = nodeData["thumbnailOverlays"]
    if IsArray(thumbnailOverlays)
        for each overlay in thumbnailOverlays
            parsedTimeStatusRenderer = Innertube_ParseThumbnailOverlayTimeStatusRenderer(overlay)
            if parsedTimeStatusRenderer <> invalid
                if parsedTimeStatusRenderer.isShort
                    if context.disableShorts = true
                        LogInfo2("[NodesParser.bs:445]", "Skipping Short based on user settings")
                        return invalid
                    end if
                end if
                liveNow = liveNow or parsedTimeStatusRenderer.isLive
                isUpcoming = isUpcoming or parsedTimeStatusRenderer.isUpcoming
            end if
        end for
    end if
    if ValidString(ObjectUtils_Dig(nodeData, [
        "badges"
        0
        "metadataBadgeRenderer"
        "icon"
        "iconType"
    ])) = "LIVE"
        liveNow = true
    end if
    premiereTimestamp = ObjectUtils_Dig(nodeData, [
        "upcomingEventData"
        "startTime"
    ])
    if IsString(premiereTimestamp)
        premiereTimestamp = premiereTimestamp.ToInt()
        isUpcoming = true
    end if
    video = {
        "type": "video"
        "videoId": videoId
        "author": author
        "authorId": authorId
        "title": Innertube_ParseText(nodeData["title"])
        "videoThumbnails": videoThumbnails
        "viewCountText": viewCountText
        "publishedText": publishedText
        "lengthText": lengthText
        "liveNow": liveNow
    }
    if author <> ""
        video["author"] = author
    end if
    if authorId <> invalid
        video["authorId"] = authorId
    end if
    if isUpcoming
        video["isUpcoming"] = true
        video["premiereTimestamp"] = premiereTimestamp
    end if
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParseGridVideoRenderer(nodeData as object, context as object) as object
    videoId = nodeData["videoId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid video ID in gridVideoRenderer", nodeData, context)
        return invalid
    end if
    author = invalid
    authorId = invalid
    authorPossibleNodes = [
        "ownerText"
        "shortBylineText"
        "longBylineText"
    ]
    for each authorPossibleNode in authorPossibleNodes
        node = nodeData[authorPossibleNode]
        author = Innertube_ParseText(node)
        authorId = ObjectUtils_Dig(node, [
            "runs"
            0
            "navigationEndpoint"
            "browseEndpoint"
            "browseId"
        ])
        if author <> "" and authorId <> invalid
            exit for
        end if
    end for
    if StringUtils_IsNullOrEmpty(author) and StringUtils_IsNullOrEmpty(authorId)
        if IsString(context.currentAuthor) and IsString(context.currentAuthorId)
            author = context.currentAuthor
            authorId = context.currentAuthorId
        end if
    end if
    viewCountText = Innertube_ParseText(nodeData["shortViewCountText"])
    if viewCountText = ""
        viewCountText = Innertube_ParseText(nodeData["viewCountText"])
    end if
    publishedText = Innertube_ParseText(nodeData["publishedTimeText"])
    lengthText = Innertube_ParseText(nodeData["lengthText"])
    if lengthText = ""
        thumbnailOverlays = nodeData["thumbnailOverlays"]
        if IsArray(thumbnailOverlays)
            for each overlay in thumbnailOverlays
                parsedTimeStatusRenderer = Innertube_ParseThumbnailOverlayTimeStatusRenderer(overlay)
                if parsedTimeStatusRenderer <> invalid
                    lengthText = parsedTimeStatusRenderer.text
                    if lengthText <> ""
                        exit for
                    end if
                end if
            end for
        end if
    end if
    if context.generateVideoThumbnails = true
        videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
    else
        videoThumbnails = ObjectUtils_Dig(nodeData, [
            "thumbnail"
            "thumbnails"
        ])
        if videoThumbnails = invalid
            videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
        end if
    end if
    isUpcoming = false
    premiereTimestamp = ObjectUtils_Dig(nodeData, [
        "upcomingEventData"
        "startTime"
    ])
    if IsString(premiereTimestamp)
        premiereTimestamp = premiereTimestamp.ToInt()
        isUpcoming = true
    end if
    video = {
        "type": "video"
        "videoId": videoId
        "author": author
        "authorId": authorId
        "title": Innertube_ParseText(nodeData["title"])
        "videoThumbnails": videoThumbnails
        "publishedText": publishedText
        "viewCountText": viewCountText
        "lengthText": lengthText
    }
    if isUpcoming
        video["isUpcoming"] = true
        video["premiereTimestamp"] = premiereTimestamp
    end if
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParseCompactVideoRenderer(nodeData as object, context as object) as object
    videoId = nodeData["videoId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid video ID in compactVideoRenderer", nodeData, context)
        return invalid
    end if
    author = invalid
    authorId = invalid
    authorPossibleNodes = [
        "ownerText"
        "shortBylineText"
        "longBylineText"
    ]
    for each authorPossibleNode in authorPossibleNodes
        node = nodeData[authorPossibleNode]
        author = Innertube_ParseText(node)
        authorId = ObjectUtils_Dig(node, [
            "runs"
            0
            "navigationEndpoint"
            "browseEndpoint"
            "browseId"
        ])
        if author <> "" and authorId <> invalid
            exit for
        end if
    end for
    viewCountText = Innertube_ParseText(nodeData["shortViewCountText"])
    if viewCountText = ""
        viewCountText = Innertube_ParseText(nodeData["viewCountText"])
    end if
    publishedText = Innertube_ParseText(nodeData["publishedTimeText"])
    lengthText = Innertube_ParseText(nodeData["lengthText"])
    if lengthText = ""
        thumbnailOverlays = nodeData["thumbnailOverlays"]
        if IsArray(thumbnailOverlays)
            for each overlay in thumbnailOverlays
                parsedTimeStatusRenderer = Innertube_ParseThumbnailOverlayTimeStatusRenderer(overlay)
                if parsedTimeStatusRenderer <> invalid
                    lengthText = parsedTimeStatusRenderer.text
                    if lengthText <> ""
                        exit for
                    end if
                end if
            end for
        end if
    end if
    if context.generateVideoThumbnails = true
        videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
    else
        videoThumbnails = ObjectUtils_Dig(nodeData, [
            "thumbnail"
            "thumbnails"
        ])
        if videoThumbnails = invalid
            videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
        end if
    end if
    isUpcoming = false
    liveNow = ValidString(ObjectUtils_Dig(nodeData, [
        "badges"
        0
        "metadataBadgeRenderer"
        "icon"
        "iconType"
    ])) = "LIVE"
    thumbnailOverlays = nodeData["thumbnailOverlays"]
    if IsArray(thumbnailOverlays)
        for each overlay in thumbnailOverlays
            parsedTimeStatusRenderer = Innertube_ParseThumbnailOverlayTimeStatusRenderer(overlay)
            if parsedTimeStatusRenderer <> invalid
                if parsedTimeStatusRenderer.isShort
                    if context.disableShorts = true
                        LogInfo2("[NodesParser.bs:641]", "Skipping Short based on user settings")
                        return invalid
                    end if
                end if
                liveNow = liveNow or parsedTimeStatusRenderer.isLive
                isUpcoming = isUpcoming or parsedTimeStatusRenderer.isUpcoming
            end if
        end for
    end if
    premiereTimestamp = ObjectUtils_Dig(nodeData, [
        "upcomingEventData"
        "startTime"
    ])
    if IsString(premiereTimestamp)
        premiereTimestamp = premiereTimestamp.ToInt()
        isUpcoming = true
    end if
    video = {
        "type": "video"
        "videoId": videoId
        "author": author
        "authorId": authorId
        "title": Innertube_ParseText(nodeData["title"])
        "videoThumbnails": videoThumbnails
        "viewCountText": viewCountText
        "publishedText": publishedText
        "lengthText": lengthText
        "liveNow": liveNow
    }
    if isUpcoming
        video["isUpcoming"] = true
        video["premiereTimestamp"] = premiereTimestamp
    end if
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParseVideoPrimaryInfoRenderer(nodeData as object, context as object) as object
    videoId = nodeData["videoId"]
    if not IsString(videoId)
        videoId = ObjectUtils_Dig(nodeData, [
            "updatedMetadataEndpoint"
            "updatedMetadataEndpoint"
            "videoId"
        ])
        if not IsString(videoId)
            
            LogWarnNoTelemetry2("[NodesParser.bs:689]", "Invalid video ID in videoPrimaryInfoRenderer")
            return invalid
        end if
    end if
    title = Innertube_ParseText(nodeData["title"])
    videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
    publishedText = Innertube_ParseText(nodeData["relativeDateText"])
    if publishedText = ""
        publishedText = Innertube_ParseText(nodeData["dateText"])
    end if
    viewCountText = Innertube_ParseText(ObjectUtils_Dig(nodeData, [
        "viewCount"
        "videoViewCountRenderer"
        "viewCount"
    ]))
    
    video = {
        "type": "video"
        "videoId": videoId
        "title": title
        "videoThumbnails": videoThumbnails
        "viewCountText": viewCountText
        "publishedText": publishedText
    }
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParseChannelVideoPlayerRenderer(nodeData as object, context as object) as object
    videoId = nodeData["videoId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid video ID in channelVideoPlayerRenderer", nodeData, context)
        return invalid
    end if
    author = invalid
    authorId = invalid
    if IsString(context.currentAuthor) and IsString(context.currentAuthorId)
        author = context.currentAuthor
        authorId = context.currentAuthorId
    end if
    video = {
        "type": "video"
        "videoId": videoId
        "author": author
        "authorId": authorId
        "title": Innertube_ParseText(nodeData["title"])
        "videoThumbnails": Innertube_GenerateVideoThumbnails(videoId)
        "viewCountText": Innertube_ParseText(nodeData["viewCountText"])
        "publishedText": Innertube_ParseText(nodeData["publishedTimeText"])
    }
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParsePlaylistVideoRenderer(nodeData as object, context as object) as object
    videoId = nodeData["videoId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid video ID playlistVideoRenderer", nodeData, context)
        return invalid
    end if
    lengthText = Innertube_ParseText(nodeData["lengthText"])
    lengthSeconds = ValidString(nodeData["lengthSeconds"]).ToInt()
    videoInfo = Innertube_ParseText(nodeData["videoInfo"])
    author = invalid
    authorId = invalid
    authorPossibleNodes = [
        "shortBylineText"
        "ownerText"
        "longBylineText"
    ]
    for each authorPossibleNode in authorPossibleNodes
        node = nodeData[authorPossibleNode]
        author = Innertube_ParseText(node)
        authorId = ObjectUtils_Dig(node, [
            "runs"
            0
            "navigationEndpoint"
            "browseEndpoint"
            "browseId"
        ])
        if author <> "" and authorId <> invalid
            exit for
        end if
    end for
    if context.generateVideoThumbnails = true
        videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
    else
        videoThumbnails = ObjectUtils_Dig(nodeData, [
            "thumbnail"
            "thumbnails"
        ])
        if videoThumbnails = invalid
            videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
        end if
    end if
    video = {
        "type": "video"
        "videoId": videoId
        "author": author
        "authorId": authorId
        "title": Innertube_ParseText(nodeData["title"])
        "videoThumbnails": videoThumbnails
        "index": Innertube_ParseText(nodeData["index"]).ToInt()
        "lengthText": lengthText
        "lengthSeconds": lengthSeconds
        "videoInfo": videoInfo
    }
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParsePlaylistPanelVideoRenderer(nodeData as object, context as object) as object
    videoId = nodeData["videoId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid video ID in playlistPanelVideoRenderer", nodeData, context)
        return invalid
    end if
    author = invalid
    authorId = invalid
    authorPossibleNodes = [
        "shortBylineText"
        "ownerText"
        "longBylineText"
    ]
    for each authorPossibleNode in authorPossibleNodes
        node = nodeData[authorPossibleNode]
        author = Innertube_ParseText(node)
        authorId = ObjectUtils_Dig(node, [
            "runs"
            0
            "navigationEndpoint"
            "browseEndpoint"
            "browseId"
        ])
        if author <> "" and authorId <> invalid
            exit for
        end if
    end for
    if context.generateVideoThumbnails = true
        videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
    else
        videoThumbnails = ObjectUtils_Dig(nodeData, [
            "thumbnail"
            "thumbnails"
        ])
        if videoThumbnails = invalid
            videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
        end if
    end if
    isUpcoming = false
    liveNow = ValidString(ObjectUtils_Dig(nodeData, [
        "badges"
        0
        "metadataBadgeRenderer"
        "icon"
        "iconType"
    ])) = "LIVE"
    thumbnailOverlays = nodeData["thumbnailOverlays"]
    if IsArray(thumbnailOverlays)
        for each overlay in thumbnailOverlays
            parsedTimeStatusRenderer = Innertube_ParseThumbnailOverlayTimeStatusRenderer(overlay)
            if parsedTimeStatusRenderer <> invalid
                if parsedTimeStatusRenderer.isShort
                    if context.disableShorts = true
                        LogInfo2("[NodesParser.bs:837]", "Skipping Short based on user settings")
                        return invalid
                    end if
                end if
                liveNow = liveNow or parsedTimeStatusRenderer.isLive
                isUpcoming = isUpcoming or parsedTimeStatusRenderer.isUpcoming
            end if
        end for
    end if
    lengthText = Innertube_ParseText(nodeData["lengthText"])
    video = {
        "type": "video"
        "videoId": videoId
        "author": author
        "authorId": authorId
        "title": Innertube_ParseText(nodeData["title"])
        "videoThumbnails": videoThumbnails
        "lengthText": lengthText
        "liveNow": liveNow
        "isUpcoming": isUpcoming
    }
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParseEndScreenVideoRenderer(nodeData as object, context as object) as object
    videoId = nodeData["videoId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid video ID in endScreenVideoRenderer", nodeData, context)
        return invalid
    end if
    author = invalid
    authorId = invalid
    authorPossibleNodes = [
        "shortBylineText"
        "ownerText"
        "longBylineText"
    ]
    for each authorPossibleNode in authorPossibleNodes
        node = nodeData[authorPossibleNode]
        author = Innertube_ParseText(node)
        authorId = ObjectUtils_Dig(node, [
            "runs"
            0
            "navigationEndpoint"
            "browseEndpoint"
            "browseId"
        ])
        if author <> "" and authorId <> invalid
            exit for
        end if
    end for
    video = {
        "type": "video"
        "videoId": videoId
        "author": author
        "authorId": authorId
        "title": Innertube_ParseText(nodeData["title"])
        "videoThumbnails": ObjectUtils_Dig(nodeData, [
            "thumbnail"
            "thumbnails"
        ])
    }
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParseChannelRenderer(nodeData as object, context as object) as object
    channelId = nodeData["channelId"]
    if not IsString(channelId)
        Innertube_Warning("Invalid channel ID in channelRenderer", nodeData, context)
        return invalid
    end if
    channel = {
        "type": "channel"
        "authorId": channelId
        "author": Innertube_ParseText(nodeData["title"])
        "authorThumbnails": ObjectUtils_Dig(nodeData, [
            "thumbnail"
            "thumbnails"
        ])
        "subCountText": Innertube_ParseText(nodeData["subscriberCountText"])
        "videoCountText": Innertube_ParseText(nodeData["videoCountText"])
    }
    Innertube_PushFeedItem(channel, context)
    return invalid
end function

function Innertube_ParseGridChannelRenderer(nodeData as object, context as object) as object
    channelId = nodeData["channelId"]
    if not IsString(channelId)
        Innertube_Warning("Invalid channel ID gridChannelRenderer", nodeData, context)
        return invalid
    end if
    channel = {
        "type": "channel"
        "authorId": channelId
        "author": Innertube_ParseText(nodeData["title"])
        "authorThumbnails": ObjectUtils_Dig(nodeData, [
            "thumbnail"
            "thumbnails"
        ])
        "subCountText": Innertube_ParseText(nodeData["subscriberCountText"])
        "videoCountText": Innertube_ParseText(nodeData["videoCountText"])
    }
    Innertube_PushFeedItem(channel, context)
    return invalid
end function

function Innertube_ParsePlaylistRenderer(nodeData as object, context as object) as object
    playlistId = nodeData["playlistId"]
    if not IsString(playlistId)
        Innertube_Warning("Invalid playlist ID in playlistRenderer", nodeData, context)
        return invalid
    end if
    author = invalid
    authorId = invalid
    authorPossibleNodes = [
        "shortBylineText"
        "ownerText"
        "longBylineText"
    ]
    for each authorPossibleNode in authorPossibleNodes
        node = nodeData[authorPossibleNode]
        author = Innertube_ParseText(node)
        authorId = ObjectUtils_Dig(node, [
            "runs"
            0
            "navigationEndpoint"
            "browseEndpoint"
            "browseId"
        ])
        if author <> "" and authorId <> invalid
            exit for
        end if
    end for
    videoCountText = ""
    thumbnailOverlays = nodeData["thumbnailOverlays"]
    if IsArray(thumbnailOverlays)
        for each overlay in thumbnailOverlays
            videoCountText = Innertube_ParseText(ObjectUtils_Dig(overlay, [
                "thumbnailOverlayBottomPanelRenderer"
                "text"
            ]))
            if videoCountText <> ""
                exit for
            end if
        end for
    end if
    if videoCountText = ""
        videoCountText = Innertube_ParseText(nodeData["videoCountText"])
    end if
    videoCount = Innertube_ParseText(nodeData["videoCount"]).ToInt()
    playlist = {
        "type": "playlist"
        "playlistId": playlistId
        "title": Innertube_ParseText(nodeData["title"])
        "playlistThumbnail": ObjectUtils_Dig(nodeData, [
            "thumbnails"
            0
            "thumbnails"
            0
            "url"
        ])
        "author": author
        "authorId": authorId
        "videoCount": videoCount
        "videoCountText": videoCountText
    }
    Innertube_PushFeedItem(playlist, context)
    return invalid
end function

function Innertube_ParseGridPlaylistRenderer(nodeData as object, context as object) as object
    playlistId = nodeData["playlistId"]
    if not IsString(playlistId)
        Innertube_Warning("Invalid playlist ID gridPlaylistRenderer", nodeData, context)
        return invalid
    end if
    author = invalid
    authorId = invalid
    authorPossibleNodes = [
        "shortBylineText"
        "ownerText"
        "longBylineText"
    ]
    for each authorPossibleNode in authorPossibleNodes
        node = nodeData[authorPossibleNode]
        author = Innertube_ParseText(node)
        authorId = ObjectUtils_Dig(node, [
            "runs"
            0
            "navigationEndpoint"
            "browseEndpoint"
            "browseId"
        ])
        if author <> "" and authorId <> invalid
            exit for
        end if
    end for
    if StringUtils_IsNullOrEmpty(author) and StringUtils_IsNullOrEmpty(authorId)
        if IsString(context.currentAuthor) and IsString(context.currentAuthorId)
            author = context.currentAuthor
            authorId = context.currentAuthorId
        end if
    end if
    videoCountText = ""
    thumbnailOverlays = nodeData["thumbnailOverlays"]
    if IsArray(thumbnailOverlays)
        for each overlay in thumbnailOverlays
            videoCountText = Innertube_ParseText(ObjectUtils_Dig(overlay, [
                "thumbnailOverlayBottomPanelRenderer"
                "text"
            ]))
            if videoCountText <> ""
                exit for
            end if
        end for
    end if
    if videoCountText = ""
        videoCountText = Innertube_ParseText(nodeData["videoCountText"])
    end if
    if videoCountText = ""
        videoCountText = Innertube_ParseText(nodeData["videoCountShortText"])
    end if
    videoCount = Innertube_ParseText(nodeData["videoCount"])
    if videoCount = ""
        videoCount = Innertube_ParseText(nodeData["videoCountShortText"])
    end if
    videoCount = videoCount.ToInt()
    playlist = {
        "type": "playlist"
        "playlistId": playlistId
        "title": Innertube_ParseText(nodeData["title"])
        "playlistThumbnail": ObjectUtils_Dig(nodeData, [
            "thumbnail"
            "thumbnails"
            0
            "url"
        ])
        "author": author
        "authorId": authorId
        "videoCount": videoCount
        "videoCountText": videoCountText
    }
    Innertube_PushFeedItem(playlist, context)
    return invalid
end function

function Innertube_ParseRadioRenderer(nodeData as object, context as object) as object
    playlistId = nodeData["playlistId"]
    if not IsString(playlistId)
        Innertube_Warning("Invalid playlist ID in radioRenderer", nodeData, context)
        return invalid
    end if
    videoCountText = Innertube_ParseText(nodeData["videoCountText"])
    playlist = {
        "type": "playlist"
        "playlistId": playlistId
        "title": Innertube_ParseText(nodeData["title"])
        "playlistThumbnail": ObjectUtils_Dig(nodeData, [
            "thumbnail"
            "thumbnails"
            0
            "url"
        ])
        "videoCountText": videoCountText
    }
    
    videoId = ObjectUtils_Dig(nodeData, [
        "navigationEndpoint"
        "watchEndpoint"
        "videoId"
    ])
    if IsString(videoId)
        playlist["videoId"] = videoId
    end if
    Innertube_PushFeedItem(playlist, context)
    return invalid
end function

function Innertube_ParseCompactRadioRenderer(nodeData as object, context as object) as object
    playlistId = nodeData["playlistId"]
    if not IsString(playlistId)
        Innertube_Warning("Invalid playlist ID in compactRadioRenderer", nodeData, context)
        return invalid
    end if
    videoCountText = Innertube_ParseText(nodeData["videoCountText"])
    if videoCountText = ""
        videoCountText = Innertube_ParseText(nodeData["videoCountShortText"])
    end if
    playlist = {
        "type": "playlist"
        "playlistId": playlistId
        "title": Innertube_ParseText(nodeData["title"])
        "playlistThumbnail": ObjectUtils_Dig(nodeData, [
            "thumbnail"
            "thumbnails"
            0
            "url"
        ])
        "videoCountText": videoCountText
    }
    
    videoId = ObjectUtils_Dig(nodeData, [
        "navigationEndpoint"
        "watchEndpoint"
        "videoId"
    ])
    if IsString(videoId)
        playlist["videoId"] = videoId
    end if
    Innertube_PushFeedItem(playlist, context)
    return invalid
end function

function Innertube_ParseGridShelfViewModel(nodeData as object, _context as object) as object
    return nodeData["contents"]
end function

function Innertube_ParseLockupViewModel(nodeData as object, context as object) as object
    contentType = ValidString(nodeData["contentType"])
    if contentType = "LOCKUP_CONTENT_TYPE_VIDEO" or contentType = "LOCKUP_CONTENT_TYPE_MOVIE"
        return Innertube_LockupViewModelTypeVideo(nodeData, context)
    else if contentType = "LOCKUP_CONTENT_TYPE_SHORT"
        return Innertube_LockupViewModelTypeShort(nodeData, context)
    else if contentType = "LOCKUP_CONTENT_TYPE_PLAYLIST" or contentType = "LOCKUP_CONTENT_TYPE_PODCAST" or contentType = "LOCKUP_CONTENT_TYPE_ALBUM"
        return Innertube_LockupViewModelTypePlaylist(nodeData, context)
    else if contentType = "LOCKUP_CONTENT_TYPE_SHOW" or contentType = "LOCKUP_CONTENT_TYPE_SEASON" or contentType = "LOCKUP_CONTENT_TYPE_COURSE" or contentType = "LOCKUP_CONTENT_TYPE_STATION"
        
        contentId = ValidString(nodeData["contentId"])
        command = ObjectUtils_Dig(nodeData, [
            "rendererContext"
            "commandContext"
            "onTap"
            "innertubeCommand"
        ])
        if contentId <> ""
            if ValidString(ObjectUtils_Dig(command, [
                "watchEndpoint"
                "videoId"
            ])) = contentId
                return Innertube_LockupViewModelTypeVideo(nodeData, context)
            end if
            if ValidString(ObjectUtils_Dig(command, [
                "watchEndpoint"
                "playlistId"
            ])) = contentId or ValidString(ObjectUtils_Dig(command, [
                "watchPlaylistEndpoint"
                "playlistId"
            ])) = contentId or ValidString(ObjectUtils_Dig(command, [
                "browseEndpoint"
                "browseId"
            ])) = "VL" + contentId
                return Innertube_LockupViewModelTypePlaylist(nodeData, context)
            end if
        end if
    end if
    Innertube_Warning(("Unknown content type: " + bslib_toString(contentType)), nodeData, context)
    
    return invalid
end function

' The badge overlay has two shapes: thumbnailOverlayBadgeViewModel.thumbnailBadges (older, still
' used on playlist lockups) and thumbnailBottomOverlayViewModel.badges (video lockups)
function Innertube_ParseThumbnailBadge(thumbnailViewModel as object) as object
    overlays = ObjectUtils_Dig(thumbnailViewModel, [
        "overlays"
    ])
    if not IsArray(overlays)
        return invalid
    end if
    for each overlay in overlays
        badges = ObjectUtils_Dig(overlay, [
            "thumbnailBottomOverlayViewModel"
            "badges"
        ])
        if not IsArray(badges)
            badges = ObjectUtils_Dig(overlay, [
                "thumbnailOverlayBadgeViewModel"
                "thumbnailBadges"
            ])
        end if
        if not IsArray(badges)
            continue for
        end if
        for each badge in badges
            badgeViewModel = badge["thumbnailBadgeViewModel"]
            if not IsAssociativeArray(badgeViewModel)
                continue for
            end if
            text = ValidString(badgeViewModel["text"])
            if text = ""
                continue for
            end if
            return {
                "text": text
                "isLive": ValidString(badgeViewModel["badgeStyle"]) = "THUMBNAIL_OVERLAY_BADGE_STYLE_LIVE"
            }
        end for
    end for
    return invalid
end function

function Innertube_GetThumbnailBadgeText(thumbnailViewModel as object) as string
    parsedBadge = Innertube_ParseThumbnailBadge(thumbnailViewModel)
    if parsedBadge = invalid
        return ""
    end if
    return parsedBadge.text
end function

function Innertube_LockupViewModelTypeVideo(nodeData as object, context as object) as object
    videoId = nodeData["contentId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid video ID in lockupViewModelTypeVideo", nodeData, context)
        return invalid
    end if
    metadata = ObjectUtils_Dig(nodeData, [
        "metadata"
        "lockupMetadataViewModel"
    ])
    title = ObjectUtils_Dig(metadata, [
        "title"
        "content"
    ])
    contentImage = nodeData["contentImage"]
    thumbnailViewModel = ObjectUtils_Dig(contentImage, [
        "thumbnailViewModel"
    ])
    if thumbnailViewModel = invalid
        
        thumbnailViewModel = ObjectUtils_Dig(contentImage, [
            "collectionThumbnailViewModel"
            "primaryThumbnail"
            "thumbnailViewModel"
        ])
    end if
    if context.generateVideoThumbnails = true
        videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
    else
        videoThumbnails = ObjectUtils_Dig(thumbnailViewModel, [
            "image"
            "sources"
        ])
        if videoThumbnails = invalid
            videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
        end if
    end if
    lengthText = ""
    liveNow = false
    parsedBadge = Innertube_ParseThumbnailBadge(thumbnailViewModel)
    if parsedBadge <> invalid
        if parsedBadge.isLive
            liveNow = true
        else
            lengthText = parsedBadge.text
        end if
    end if
    authorId = ObjectUtils_Dig(metadata, [
        "image"
        "decoratedAvatarViewModel"
        "rendererContext"
        "commandContext"
        "onTap"
        "innertubeCommand"
        "browseEndpoint"
        "browseId"
    ])
    lines = Innertube_ParseLockupMetadataLines(metadata)
    video = {
        "type": "video"
        "videoId": videoId
        "title": title
        "authorId": authorId
        "lines": lines
        "videoThumbnails": videoThumbnails
        "lengthText": lengthText
        "liveNow": liveNow
    }
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParseLockupMetadataLines(metadata as object) as object
    contentMetadataViewModel = ObjectUtils_Dig(metadata, [
        "metadata"
        "contentMetadataViewModel"
    ])
    metadataRows = ObjectUtils_Dig(contentMetadataViewModel, [
        "metadataRows"
    ])
    if not IsArray(metadataRows) or metadataRows.Count() = 0
        return invalid
    end if
    delimiter = ValidString(contentMetadataViewModel["delimiter"])
    lines = []
    for each metadataRow in metadataRows
        parts = []
        metadataParts = ObjectUtils_Dig(metadataRow, [
            "metadataParts"
        ])
        if IsArray(metadataParts)
            for each metadataPart in metadataParts
                text = ValidString(ObjectUtils_Dig(metadataPart, [
                    "text"
                    "content"
                ]))
                if text <> ""
                    parts.Push(text)
                end if
            end for
        end if
        badges = ObjectUtils_Dig(metadataRow, [
            "badges"
        ])
        if IsArray(badges)
            for each badge in badges
                text = ValidString(ObjectUtils_Dig(badge, [
                    "badgeViewModel"
                    "badgeText"
                ]))
                if text <> ""
                    parts.Push(text)
                end if
            end for
        end if
        if parts.Count() > 0
            lines.Push(parts.Join(delimiter))
        end if
    end for
    return lines
end function

function Innertube_LockupViewModelTypeShort(nodeData as object, context as object) as object
    if context.disableShorts = true
        LogInfo2("[NodesParser.bs:1286]", "Skipping Short based on user settings")
        return invalid
    end if
    videoId = nodeData["contentId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid video ID in lockupViewModelTypeShort", nodeData, context)
        return invalid
    end if
    metadata = ObjectUtils_Dig(nodeData, [
        "metadata"
        "lockupMetadataViewModel"
    ])
    title = ObjectUtils_Dig(metadata, [
        "title"
        "content"
    ])
    authorId = ObjectUtils_Dig(metadata, [
        "image"
        "decoratedAvatarViewModel"
        "rendererContext"
        "commandContext"
        "onTap"
        "innertubeCommand"
        "browseEndpoint"
        "browseId"
    ])
    thumbnailViewModel = ObjectUtils_Dig(nodeData, [
        "contentImage"
        "thumbnailViewModel"
    ])
    if context.generateVideoThumbnails = true
        videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
    else
        videoThumbnails = ObjectUtils_Dig(thumbnailViewModel, [
            "image"
            "sources"
        ])
        if videoThumbnails = invalid
            videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
        end if
    end if
    lines = Innertube_ParseLockupMetadataLines(metadata)
    video = {
        "type": "video"
        "videoId": videoId
        "title": title
        "authorId": authorId
        "lines": lines
        "videoThumbnails": videoThumbnails
        "isShort": true
    }
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_LockupViewModelTypePlaylist(nodeData as object, context as object) as object
    playlistId = nodeData["contentId"]
    if not IsString(playlistId)
        Innertube_Warning("Invalid playlist ID in lockupViewModelTypePlaylist", nodeData, context)
        return invalid
    end if
    metadata = ObjectUtils_Dig(nodeData, [
        "metadata"
        "lockupMetadataViewModel"
    ])
    title = ObjectUtils_Dig(metadata, [
        "title"
        "content"
    ])
    thumbnailViewModel = ObjectUtils_Dig(nodeData, [
        "contentImage"
        "collectionThumbnailViewModel"
        "primaryThumbnail"
        "thumbnailViewModel"
    ])
    thumbnail = ObjectUtils_Dig(thumbnailViewModel, [
        "image"
        "sources"
        0
        "url"
    ])
    videoCountText = Innertube_GetThumbnailBadgeText(thumbnailViewModel)
    author = invalid
    authorId = invalid
    maybeAuthorNode = ObjectUtils_Dig(metadata, [
        "metadata"
        "contentMetadataViewModel"
        "metadataRows"
        0
        "metadataParts"
        0
        "text"
    ])
    maybeAuthorId = ObjectUtils_Dig(maybeAuthorNode, [
        "commandRuns"
        0
        "onTap"
        "innertubeCommand"
        "browseEndpoint"
        "browseId"
    ])
    if IsString(maybeAuthorId) and maybeAuthorId.StartsWith("UC")
        authorId = maybeAuthorId
        author = ValidString(maybeAuthorNode["content"])
    else if IsString(context.currentAuthor) and IsString(context.currentAuthorId)
        author = context.currentAuthor
        authorId = context.currentAuthorId
    end if
    playlist = {
        "type": "playlist"
        "playlistId": playlistId
        "title": title
        "author": author
        "authorId": authorId
        "playlistThumbnail": thumbnail
        "videoCountText": videoCountText
    }
    
    if playlistId.StartsWith("RD")
        videoId = ObjectUtils_Dig(nodeData, [
            "rendererContext"
            "commandContext"
            "onTap"
            "innertubeCommand"
            "watchEndpoint"
            "videoId"
        ])
        if IsString(videoId)
            playlist["videoId"] = videoId
        end if
    end if
    Innertube_PushFeedItem(playlist, context)
    return invalid
end function

function Innertube_ParseShortsLockupViewModel(nodeData as object, context as object) as object
    if context.disableShorts = true
        LogInfo2("[NodesParser.bs:1379]", "Skipping Short based on user settings")
        return invalid
    end if
    videoId = ObjectUtils_Dig(nodeData, [
        "onTap"
        "innertubeCommand"
        "reelWatchEndpoint"
        "videoId"
    ])
    if not IsString(videoId)
        Innertube_Warning("Invalid video ID in shortsLockupViewModel", nodeData, context)
        return invalid
    end if
    if context.generateVideoThumbnails = true
        videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
    else
        videoThumbnails = ObjectUtils_Dig(nodeData, [
            "thumbnail"
            "sources"
        ])
        if videoThumbnails = invalid
            videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
        end if
    end if
    author = invalid
    authorId = invalid
    if IsString(context.currentAuthor) and IsString(context.currentAuthorId)
        author = context.currentAuthor
        authorId = context.currentAuthorId
    end if
    video = {
        "type": "video"
        "videoId": videoId
        "author": author
        "authorId": authorId
        "title": ObjectUtils_Dig(nodeData, [
            "overlayMetadata"
            "primaryText"
            "content"
        ])
        "viewCountText": ObjectUtils_Dig(nodeData, [
            "overlayMetadata"
            "secondaryText"
            "content"
        ])
        "videoThumbnails": videoThumbnails
        "isShort": true
    }
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParseTvBrowseRenderer(nodeData as object, _context as object) as object
    return nodeData["content"]
end function

function Innertube_ParseTvSurfaceContentRenderer(nodeData as object, context as object) as object
    
    continuation = ObjectUtils_Dig(nodeData, [
        "continuation"
        "nextContinuationData"
        "continuation"
    ])
    if IsString(continuation) and continuation <> "" and not IsString(context.sectionContinuation)
        context.sectionContinuation = continuation
    end if
    return nodeData["content"]
end function

function Innertube_ParseTvSecondaryNavRenderer(nodeData as object, _context as object) as object
    return nodeData["sections"]
end function

function Innertube_ParseTvSecondaryNavSectionRenderer(nodeData as object, _context as object) as object
    return nodeData["tabs"]
end function

function Innertube_ParseTwoColumnRenderer(nodeData as object, _context as object) as object
    
    return nodeData["rightColumn"]
end function

function Innertube_ParseTileRenderer(nodeData as object, context as object) as object
    contentType = ValidString(nodeData["contentType"])
    
    if contentType = ""
        
        eventTrigger = ValidString(ObjectUtils_Dig(nodeData, [
            "onSelectCommand"
            "authDeterminedCommand"
            "authenticatedCommand"
            "authRequiredCommand"
            "identityActionContext"
            "eventTrigger"
        ]))
        if eventTrigger = "ACCOUNT_EVENT_TRIGGER_YTK_WORMHOLE"
            LogWarnNoTelemetry2("[NodesParser.bs:1457]", "Skipping tileRenderer without contentType for YouTube Kids")
            return invalid
        end if
        
        thumbailUrl = ValidString(ObjectUtils_Dig(nodeData, [
            "header"
            "tileHeaderRenderer"
            "thumbnail"
            "thumbnails"
            0
            "url"
        ]))
        if thumbailUrl.InStr("gstatic.com/youtube/img/promos") <> -1
            LogWarnNoTelemetry2("[NodesParser.bs:1464]", "Skipping tileRenderer without contentType for YouTube promo")
            return invalid
        end if
        
        browseId = ValidString(ObjectUtils_Dig(nodeData, [
            "onSelectCommand"
            "browseEndpoint"
            "browseId"
        ]))
        if browseId = "FEtopics_news"
            LogWarnNoTelemetry2("[NodesParser.bs:1471]", "Skipping tileRenderer without contentType for FEtopics_news")
            return invalid
        end if
        if browseId = "FEtopics_music"
            LogWarnNoTelemetry2("[NodesParser.bs:1475]", "Skipping tileRenderer without contentType for FEtopics_music")
            return invalid
        end if
        
        if Innertube_TileRendererHasSearchEndpoint(nodeData["onSelectCommand"])
            LogWarnNoTelemetry2("[NodesParser.bs:1481]", "Skipping tileRenderer without contentType for search endpoint")
            return invalid
        end if
        Innertube_Warning("TileRenderer without contentType", nodeData, context)
        return invalid
    end if
    if contentType = "TILE_CONTENT_TYPE_VIDEO"
        return Innertube_TileRendererTypeVideo(nodeData, context)
    else if contentType = "TILE_CONTENT_TYPE_SHORTS"
        return Innertube_TileRendererTypeShorts(nodeData, context)
    else if contentType = "TILE_CONTENT_TYPE_PLAYLIST"
        return Innertube_TileRendererTypePlaylist(nodeData, context)
    else if contentType = "TILE_CONTENT_TYPE_CHANNEL"
        return Innertube_TileRendererTypeChannel(nodeData, context)
    else if contentType = "TILE_CONTENT_TYPE_EDU"
        
        return invalid
    end if
    Innertube_Warning(("Unknown content type: " + bslib_toString(contentType)), nodeData, context)
    
    return invalid
end function

function Innertube_TileRendererHasSearchEndpoint(onSelectCommand as object) as boolean
    if not IsAssociativeArray(onSelectCommand)
        return false
    end if
    if IsAssociativeArray(onSelectCommand["searchEndpoint"])
        return true
    end if
    commands = ObjectUtils_Dig(onSelectCommand, [
        "commandExecutorCommand"
        "commands"
    ])
    if not IsArray(commands)
        return false
    end if
    for each command in commands
        if IsAssociativeArray(command) and IsAssociativeArray(command["searchEndpoint"])
            return true
        end if
    end for
    return false
end function

function Innertube_TileRendererTypeVideo(nodeData as object, context as object) as object
    videoId = nodeData["contentId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid video ID in tileRendererTypeVideo", nodeData, context)
        return invalid
    end if
    if context.generateVideoThumbnails = true
        videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
    else
        videoThumbnails = ObjectUtils_Dig(nodeData, [
            "header"
            "tileHeaderRenderer"
            "thumbnail"
            "thumbnails"
        ])
        if videoThumbnails = invalid
            videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
        end if
    end if
    lengthText = ""
    isUpcoming = false
    liveNow = false
    percentDurationWatched = 0
    thumbnailOverlays = ObjectUtils_Dig(nodeData, [
        "header"
        "tileHeaderRenderer"
        "thumbnailOverlays"
    ])
    if IsArray(thumbnailOverlays)
        for each overlay in thumbnailOverlays
            parsedTimeStatusRenderer = Innertube_ParseThumbnailOverlayTimeStatusRenderer(overlay)
            if parsedTimeStatusRenderer <> invalid
                if parsedTimeStatusRenderer.isShort
                    if context.disableShorts = true
                        LogInfo2("[NodesParser.bs:1565]", "Skipping Short based on user settings")
                        return invalid
                    end if
                end if
                maybeLengthText = parsedTimeStatusRenderer.text
                if maybeLengthText <> ""
                    lengthText = maybeLengthText
                end if
                liveNow = liveNow or parsedTimeStatusRenderer.isLive
                isUpcoming = isUpcoming or parsedTimeStatusRenderer.isUpcoming
            end if
            maybePercentDurationWatched = ObjectUtils_Dig(overlay, [
                "thumbnailOverlayResumePlaybackRenderer"
                "percentDurationWatched"
            ])
            if maybePercentDurationWatched <> invalid
                percentDurationWatched = maybePercentDurationWatched
            end if
        end for
        if liveNow or isUpcoming
            lengthText = ""
        end if
    end if
    if lengthText = ""
        lengthText = Innertube_ParseText(ObjectUtils_Dig(nodeData, [
            "header"
            "trackTileHeaderRenderer"
            "duration"
        ]))
    end if
    renderedLines = []
    lines = ObjectUtils_Dig(nodeData, [
        "metadata"
        "tileMetadataRenderer"
        "lines"
    ])
    if IsArray(lines)
        for each line in lines
            if not IsAssociativeArray(line)
                continue for
            end if
            renderedLines.Push(Innertube_ParseLineRenderer(line["lineRenderer"]))
        end for
    end if
    title = Innertube_ParseText(ObjectUtils_Dig(nodeData, [
        "metadata"
        "tileMetadataRenderer"
        "title"
    ]))
    if title = ""
        title = Innertube_ParseText(ObjectUtils_Dig(nodeData, [
            "header"
            "trackTileHeaderRenderer"
            "title"
        ]))
    end if
    video = {
        "type": "video"
        "videoId": videoId
        "title": title
        "videoThumbnails": videoThumbnails
        "lengthText": lengthText
        "liveNow": liveNow
        "isUpcoming": isUpcoming
        "lines": renderedLines
        "percentDurationWatched": percentDurationWatched
    }
    authorId = Innertube_ParseTileRendererAuthorId(nodeData)
    if authorId <> invalid
        video["authorId"] = authorId
    end if
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_TileRendererTypeShorts(nodeData as object, context as object) as object
    if context.disableShorts = true
        LogInfo2("[NodesParser.bs:1634]", "Skipping Short based on user settings")
        return invalid
    end if
    videoId = nodeData["contentId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid video ID in tileRendererTypeShorts", nodeData, context)
        return invalid
    end if
    if context.generateVideoThumbnails = true
        videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
    else
        videoThumbnails = ObjectUtils_Dig(nodeData, [
            "header"
            "tileHeaderRenderer"
            "thumbnail"
            "thumbnails"
        ])
        if videoThumbnails = invalid
            videoThumbnails = Innertube_GenerateVideoThumbnails(videoId)
        end if
    end if
    title = ""
    thumbnailOverlays = ObjectUtils_Dig(nodeData, [
        "header"
        "tileHeaderRenderer"
        "thumbnailOverlays"
    ])
    if IsArray(thumbnailOverlays)
        for each overlay in thumbnailOverlays
            title = Innertube_ParseText(ObjectUtils_Dig(overlay, [
                "tileMetadataRenderer"
                "title"
            ]))
            if title <> ""
                exit for
            end if
        end for
    end if
    video = {
        "type": "video"
        "videoId": videoId
        "title": title
        "videoThumbnails": videoThumbnails
        "isShort": true
    }
    authorId = Innertube_ParseTileRendererAuthorId(nodeData)
    if authorId <> invalid
        video["authorId"] = authorId
    end if
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_TileRendererTypePlaylist(nodeData as object, context as object) as object
    playlistId = nodeData["contentId"]
    if not IsString(playlistId)
        Innertube_Warning("Invalid playlist ID in tileRendererTypePlaylist", nodeData, context)
        return invalid
    end if
    videoCountText = ""
    thumbnailOverlays = ObjectUtils_Dig(nodeData, [
        "header"
        "tileHeaderRenderer"
        "thumbnailOverlays"
    ])
    if IsArray(thumbnailOverlays)
        for each overlay in thumbnailOverlays
            videoCountText = Innertube_ParseText(ObjectUtils_Dig(overlay, [
                "thumbnailOverlayTimeStatusRenderer"
                "text"
            ]))
            if videoCountText <> ""
                exit for
            end if
        end for
    end if
    renderedLines = []
    lines = ObjectUtils_Dig(nodeData, [
        "metadata"
        "tileMetadataRenderer"
        "lines"
    ])
    if IsArray(lines)
        for each line in lines
            if not IsAssociativeArray(line)
                continue for
            end if
            renderedLines.Push(Innertube_ParseLineRenderer(line["lineRenderer"]))
        end for
    end if
    playlist = {
        "type": "playlist"
        "playlistId": playlistId
        "title": Innertube_ParseText(ObjectUtils_Dig(nodeData, [
            "metadata"
            "tileMetadataRenderer"
            "title"
        ]))
        "playlistThumbnail": ObjectUtils_Dig(nodeData, [
            "header"
            "tileHeaderRenderer"
            "thumbnail"
            "thumbnails"
            0
            "url"
        ])
        "videoCountText": videoCountText
        "lines": renderedLines
    }
    authorId = Innertube_ParseTileRendererAuthorId(nodeData)
    if authorId <> invalid
        playlist["authorId"] = authorId
    end if
    Innertube_PushFeedItem(playlist, context)
    return invalid
end function

function Innertube_TileRendererTypeChannel(nodeData as object, context as object) as object
    channelId = nodeData["contentId"]
    if not IsString(channelId)
        Innertube_Warning("Invalid channel ID in tileRendererTypeChannel", nodeData, context)
        return invalid
    end if
    
    if channelId.StartsWith("SC")
        LogWarnNoTelemetry2("[NodesParser.bs:1738]", "Shows are not supported yet in TileRendererTypeChannel")
        return invalid
    end if
    renderedLines = []
    lines = ObjectUtils_Dig(nodeData, [
        "metadata"
        "tileMetadataRenderer"
        "lines"
    ])
    if IsArray(lines)
        for each line in lines
            if not IsAssociativeArray(line)
                continue for
            end if
            renderedLines.Push(Innertube_ParseLineRenderer(line["lineRenderer"]))
        end for
    end if
    channel = {
        "type": "channel"
        "authorId": channelId
        "author": Innertube_ParseText(ObjectUtils_Dig(nodeData, [
            "metadata"
            "tileMetadataRenderer"
            "title"
        ]))
        "authorThumbnails": ObjectUtils_Dig(nodeData, [
            "header"
            "tileHeaderRenderer"
            "thumbnail"
            "thumbnails"
        ])
        "lines": renderedLines
    }
    Innertube_PushFeedItem(channel, context)
    return invalid
end function

function Innertube_ParseTileRendererAuthorId(nodeData as object) as dynamic
    
    menuItems = ObjectUtils_Dig(nodeData, [
        "onLongPressCommand"
        "showMenuCommand"
        "menu"
        "menuRenderer"
        "items"
    ])
    if not IsArray(menuItems)
        return invalid
    end if
    for each item in menuItems
        if not IsAssociativeArray(item) or not item.DoesExist("menuNavigationItemRenderer")
            continue for
        end if
        menuNavigationItemRenderer = item["menuNavigationItemRenderer"]
        browseId = ObjectUtils_Dig(menuNavigationItemRenderer, [
            "navigationEndpoint"
            "browseEndpoint"
            "browseId"
        ])
        if not IsString(browseId) or not browseId.StartsWith("UC")
            continue for
        end if
        return browseId
    end for
    return invalid
end function

function Innertube_ParseGridRenderer(nodeData as object, context as object) as object
    continuation = ObjectUtils_Dig(nodeData, [
        "continuations"
        0
        "nextContinuationData"
        "continuation"
    ])
    if IsString(continuation)
        context.currentFeed.continuation = continuation
    end if
    return nodeData["items"]
end function

function Innertube_ParseRichGridRenderer(nodeData as object, context as object) as object
    header = nodeData["header"]
    feedFilterChipBarRenderer = invalid
    chipBarViewModel = invalid
    if IsAssociativeArray(header)
        feedFilterChipBarRenderer = header["feedFilterChipBarRenderer"]
        chipBarViewModel = header["chipBarViewModel"]
    end if
    if feedFilterChipBarRenderer <> invalid
        Innertube_ParseFeedFilterChipBarRenderer(feedFilterChipBarRenderer, context)
    else if chipBarViewModel <> invalid
        Innertube_ParseChipBarViewModel(chipBarViewModel, context)
    end if
    return nodeData["contents"]
end function

function Innertube_ParseChipBarViewModel(nodeData as object, context as object) as object
    chips = ObjectUtils_Dig(nodeData, [
        "chips"
    ])
    if not IsArray(chips)
        return invalid
    end if
    sortOptions = []
    for each chip in chips
        chipViewModel = chip["chipViewModel"]
        if not IsAssociativeArray(chipViewModel)
            continue for
        end if
        title = ValidString(chipViewModel["text"])
        isSelected = ValidBool(chipViewModel["selected"])
        token = invalid
        tapCommand = chipViewModel["tapCommand"]
        if IsAssociativeArray(tapCommand)
            innertubeCommand = tapCommand["innertubeCommand"]
            if IsAssociativeArray(innertubeCommand)
                continuationCommand = innertubeCommand["continuationCommand"]
                if IsAssociativeArray(continuationCommand)
                    token = ValidString(continuationCommand["token"])
                end if
            end if
        end if
        if title = "" or StringUtils_IsNullOrEmpty(token)
            continue for
        end if
        sortOptions.Push({
            "title": title
            "continuation": token
            "isSelected": isSelected
        })
    end for
    if sortOptions.Count() > 0
        context.currentFeed.sortOptions = sortOptions
    end if
    return invalid
end function

function Innertube_ParseRichItemRenderer(nodeData as object, _context as object) as object
    return nodeData["content"]
end function

function Innertube_ParseFeedFilterChipBarRenderer(nodeData as object, context as object) as object
    contents = ObjectUtils_Dig(nodeData, [
        "contents"
    ])
    if not IsArray(contents)
        return invalid
    end if
    sortOptions = []
    for each item in contents
        if not IsAssociativeArray(item) or not item.DoesExist("chipCloudChipRenderer")
            continue for
        end if
        chipCloudChipRenderer = item["chipCloudChipRenderer"]
        if not IsAssociativeArray(chipCloudChipRenderer)
            continue for
        end if
        continuationCommand = ObjectUtils_Dig(chipCloudChipRenderer, [
            "navigationEndpoint"
            "continuationCommand"
        ])
        if not IsAssociativeArray(continuationCommand) or ValidString(continuationCommand["request"]) <> "CONTINUATION_REQUEST_TYPE_BROWSE"
            continue for
        end if
        title = Innertube_ParseText(chipCloudChipRenderer["text"])
        token = ValidString(continuationCommand["token"])
        isSelected = ValidBool(chipCloudChipRenderer["isSelected"])
        if title = "" or token = ""
            continue for
        end if
        sortOptions.Push({
            "title": title
            "continuation": token
            "isSelected": isSelected
        })
    end for
    if sortOptions.Count() > 0
        context.currentFeed.sortOptions = sortOptions
    end if
    return invalid
end function

function Innertube_ParseContinuationItemViewModel(nodeData as object, context as object) as object
    if not StringUtils_IsNullOrEmpty(context.currentFeed.continuation)
        return invalid
    end if
    continuation = ObjectUtils_Dig(nodeData, [
        "continuationCommand"
        "innertubeCommand"
        "continuationCommand"
        "token"
    ])
    if IsString(continuation)
        context.currentFeed.continuation = continuation
    end if
    return invalid
end function

function Innertube_ParseContinuationItemRenderer(nodeData as object, context as object) as object
    
    if not StringUtils_IsNullOrEmpty(context.currentFeed.continuation)
        return invalid
    end if
    continuationEndpoint = nodeData["continuationEndpoint"]
    if not IsAssociativeArray(continuationEndpoint)
        return invalid
    end if
    continuation = ObjectUtils_Dig(continuationEndpoint, [
        "continuationCommand"
        "token"
    ])
    if IsString(continuation)
        context.currentFeed.continuation = continuation
        return invalid
    end if
    commands = ObjectUtils_Dig(continuationEndpoint, [
        "commandExecutorCommand"
        "commands"
    ])
    if not IsArray(commands)
        return invalid
    end if
    for each command in commands
        continuation = ObjectUtils_Dig(command, [
            "continuationCommand"
            "token"
        ])
        if IsString(continuation)
            context.currentFeed.continuation = continuation
            return invalid
        end if
    end for
    return invalid
end function

function Innertube_ParseAppendContinuationItemsAction(nodeData as object, _context as object) as object
    return nodeData["continuationItems"]
end function

function Innertube_ParseReloadContinuationItemsCommand(nodeData as object, _context as object) as object
    return nodeData["continuationItems"]
end function

function Innertube_ParseGridContinuation(nodeData as object, context as object) as object
    continuation = ObjectUtils_Dig(nodeData, [
        "continuations"
        0
        "nextContinuationData"
        "continuation"
    ])
    if IsString(continuation)
        context.currentFeed.continuation = continuation
    end if
    return nodeData["items"]
end function

function Innertube_ParseTvSurfaceContentContinuation(nodeData as object, _context as object) as object
    
    return nodeData["content"]
end function

function Innertube_ParseGridButtonRenderer(nodeData as object, context as object) as object
    signal = ObjectUtils_Dig(nodeData, [
        "navigationEndpoint"
        "signalServiceEndpoint"
        "actions"
        0
        "signalAction"
        "signal"
    ])
    isRefreshButton = signal = "SOFT_RELOAD_PAGE"
    if not isRefreshButton
        Innertube_Warning("Unknown node gridButtonRenderer", nodeData, context)
    end if
    return invalid
end function

function Innertube_ParseMovieRenderer(nodeData as object, context as object) as object
    videoId = nodeData["videoId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid videoId in movieRenderer", nodeData, context)
        return invalid
    end if
    title = Innertube_ParseText(nodeData["title"])
    author = Innertube_ParseText(nodeData["longBylineText"])
    if author = ""
        author = Innertube_ParseText(nodeData["shortBylineText"])
    end if
    authorId = ObjectUtils_Dig(nodeData, [
        "channelThumbnailSupportedRenderers"
        "channelThumbnailWithLinkRenderer"
        "navigationEndpoint"
        "browseEndpoint"
        "browseId"
    ])
    lengthText = Innertube_ParseText(nodeData["lengthText"])
    if lengthText = ""
        thumbnailOverlays = nodeData["thumbnailOverlays"]
        if IsArray(thumbnailOverlays)
            for each overlay in thumbnailOverlays
                parsedTimeStatusRenderer = Innertube_ParseThumbnailOverlayTimeStatusRenderer(overlay)
                if parsedTimeStatusRenderer <> invalid
                    lengthText = parsedTimeStatusRenderer.text
                    if lengthText <> ""
                        exit for
                    end if
                end if
            end for
        end if
    end if
    lines = invalid
    description = Innertube_ParseText(nodeData["descriptionSnippet"])
    if description <> ""
        lines = [
            author
            description
        ]
    end if
    video = {
        "type": "video"
        "videoId": videoId
        "title": title
        "videoThumbnails": Innertube_GenerateVideoThumbnails(videoId)
        "author": author
        "authorId": authorId
        "lines": lines
        "lengthText": lengthText
    }
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParseGridMovieRenderer(nodeData as object, context as object) as object
    videoId = nodeData["videoId"]
    if not IsString(videoId)
        Innertube_Warning("Invalid videoId in gridMovieRenderer", nodeData, context)
        return invalid
    end if
    title = Innertube_ParseText(nodeData["title"])
    metadata = Innertube_ParseText(nodeData["metadata"])
    author = invalid
    authorId = invalid
    if IsString(context.currentAuthor) and IsString(context.currentAuthorId)
        author = context.currentAuthor
        authorId = context.currentAuthorId
    end if
    lines = invalid
    if metadata <> ""
        lines = [
            author
            metadata
        ]
    end if
    lengthText = Innertube_ParseText(nodeData["lengthText"])
    if lengthText = ""
        thumbnailOverlays = nodeData["thumbnailOverlays"]
        if IsArray(thumbnailOverlays)
            for each overlay in thumbnailOverlays
                parsedTimeStatusRenderer = Innertube_ParseThumbnailOverlayTimeStatusRenderer(overlay)
                if parsedTimeStatusRenderer <> invalid
                    lengthText = parsedTimeStatusRenderer.text
                    if lengthText <> ""
                        exit for
                    end if
                end if
            end for
        end if
    end if
    video = {
        "type": "video"
        "videoId": videoId
        "title": title
        "author": author
        "authorId": authorId
        "videoThumbnails": Innertube_GenerateVideoThumbnails(videoId)
        "lines": lines
        "lengthText": lengthText
    }
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParseCompactMovieRenderer(nodeData as object, context as object) as object
    videoId = nodeData["videoId"]
    if not IsString(videoId)
        
        Innertube_Warning("Invalid videoId in compactMovieRenderer", nodeData, context)
        return invalid
    end if
    title = Innertube_ParseText(nodeData["title"])
    author = Innertube_ParseText(nodeData["longBylineText"])
    if author = ""
        author = Innertube_ParseText(nodeData["shortBylineText"])
    end if
    lengthText = Innertube_ParseText(nodeData["lengthText"])
    if lengthText = ""
        thumbnailOverlays = nodeData["thumbnailOverlays"]
        if IsArray(thumbnailOverlays)
            for each overlay in thumbnailOverlays
                parsedTimeStatusRenderer = Innertube_ParseThumbnailOverlayTimeStatusRenderer(overlay)
                if parsedTimeStatusRenderer <> invalid
                    lengthText = parsedTimeStatusRenderer.text
                    if lengthText <> ""
                        exit for
                    end if
                end if
            end for
        end if
    end if
    video = {
        "type": "video"
        "videoId": videoId
        "title": title
        "videoThumbnails": Innertube_GenerateVideoThumbnails(videoId)
        "author": author
        "lengthText": lengthText
    }
    Innertube_AnnotateFeedItem(video, nodeData)
    Innertube_PushFeedItem(video, context)
    return invalid
end function

function Innertube_ParseHorizontalMovieListRenderer(nodeData as object, _context as object) as object
    return nodeData["items"]
end function

function Innertube_ParseText(data as dynamic) as string
    if IsString(data)
        return data
    end if
    if not IsAssociativeArray(data)
        return ""
    end if
    if data.DoesExist("simpleText")
        return data["simpleText"]
    end if
    if data.DoesExist("runs")
        text = ""
        for each _run in data["runs"]
            text += _run["text"]
        end for
        return text
    end if
    return ""
end function

function Innertube_ParseLineRenderer(data as object) as string
    if data = invalid
        return ""
    end if
    if IsString(data)
        return data
    end if
    if not IsAssociativeArray(data) or not data.DoesExist("items")
        return ""
    end if
    items = data["items"]
    if not IsArray(items)
        return ""
    end if
    texts = []
    for each item in items
        if IsString(item)
            texts.Push(item)
        else if IsAssociativeArray(item) and item.DoesExist("lineItemRenderer")
            texts.Push(Innertube_ParseLineItemRenderer(item["lineItemRenderer"]))
        end if
    end for
    return texts.Join(" ")
end function

function Innertube_ParseLineItemRenderer(data as object) as string
    if data = invalid
        return ""
    end if
    if IsString(data)
        return data
    end if
    if not IsAssociativeArray(data)
        return ""
    end if
    text = Innertube_ParseText(data["text"])
    if text <> ""
        return text
    end if
    return ValidString(ObjectUtils_Dig(data, [
        "badge"
        "metadataBadgeRenderer"
        "label"
    ]))
end function

function Innertube_ParseThumbnailOverlayTimeStatusRenderer(data as object) as object
    if data = invalid
        return invalid
    end if
    if not IsAssociativeArray(data) or not data.DoesExist("thumbnailOverlayTimeStatusRenderer")
        return invalid
    end if
    renderer = data["thumbnailOverlayTimeStatusRenderer"]
    if not IsAssociativeArray(renderer)
        return invalid
    end if
    text = Innertube_ParseText(renderer["text"])
    overlayStyle = ValidString(renderer["style"])
    isLive = overlayStyle = "LIVE"
    isUpcoming = overlayStyle = "UPCOMING"
    isShort = overlayStyle = "SHORTS"
    return {
        "text": text
        "isLive": isLive
        "isUpcoming": isUpcoming
        "isShort": isShort
    }
end function

function Innertube_StartNewFeed(title as string, context as object) as void
    if context.currentFeed <> invalid
        if context.currentFeed.items.Count() = 0 and context.currentFeed.title = ""
            context.currentFeed.title = title
            return
        end if
        context.feeds.Push(context.currentFeed)
    end if
    context.currentFeed = {
        "title": title
        "items": []
    }
end function

' YouTube's "Not interested" / "Don't recommend channel" feedback tokens from an item's menu (the TV
' long-press menu, the web overflow menu), for Playlet's options menu. The menu labels pick them (English);
' when no label matches, the first token is taken as "Not interested".
' Called for every video added to a feed: Not interested tokens, and a members-only mark (feeds can hide those).
function Innertube_AnnotateFeedItem(item as object, nodeData as object) as void
    Innertube_AddFeedbackTokens(item, nodeData)
    if Innertube_HasMembersOnlyBadge(nodeData, 14)
        item["membersOnly"] = true
    end if
end function

' A "Members only" badge anywhere in the item (badge styles differ between the web, TV and lockup layouts).
function Innertube_HasMembersOnlyBadge(data as dynamic, depth as integer) as boolean
    if depth < 0
        return false
    end if
    if IsAssociativeArray(data)
        for each key in data
            value = data[key]
            if IsString(value)
                if key = "style" or key = "iconType" or key = "badgeStyle"
                    upper = UCase(value)
                    if upper.InStr("MEMBERS_ONLY") <> -1 or upper.InStr("MEMBER_ONLY") <> -1 or upper.InStr("MEMBERS_FIRST") <> -1
                        return true
                    end if
                else if key = "label" or key = "text" or key = "simpleText" or key = "content"
                    lower = LCase(value)
                    if lower = "members only" or lower = "members first"
                        return true
                    end if
                end if
            else if Innertube_HasMembersOnlyBadge(value, depth - 1)
                return true
            end if
        end for
    else if IsArray(data)
        for each child in data
            if Innertube_HasMembersOnlyBadge(child, depth - 1)
                return true
            end if
        end for
    end if
    return false
end function

function Innertube_AddFeedbackTokens(item as object, nodeData as object) as void
    found = []
    Innertube_CollectFeedbackTokens(nodeData, found, "", 16)
    if found.Count() = 0
        return
    end if
    notInterested = ""
    dontRecommend = ""
    removeFromHistory = ""
    for each entry in found
        menuLabel = LCase(entry.label)
        if dontRecommend = "" and menuLabel.InStr("recommend channel") <> -1
            dontRecommend = entry.token
        else if notInterested = "" and menuLabel.InStr("not interested") <> -1
            notInterested = entry.token
        else if removeFromHistory = "" and menuLabel.InStr("history") <> -1
            
            removeFromHistory = entry.token
        end if
    end for
    if removeFromHistory <> ""
        item["removeFromHistoryToken"] = removeFromHistory
    end if
    
    if notInterested = "" and dontRecommend = "" and removeFromHistory = ""
        notInterested = found[0].token
    end if
    if notInterested <> ""
        item["notInterestedToken"] = notInterested
    end if
    if dontRecommend <> ""
        item["dontRecommendChannelToken"] = dontRecommend
    end if
end function

' Every feedbackEndpoint token below data, with the label of the nearest menu item above it.
function Innertube_CollectFeedbackTokens(data as dynamic, found as object, menuLabel as string, depth as integer) as void
    if depth < 0
        return
    end if
    if IsArray(data)
        for each child in data
            Innertube_CollectFeedbackTokens(child, found, menuLabel, depth - 1)
        end for
        return
    end if
    if not IsAssociativeArray(data)
        return
    end if
    ownLabel = Innertube_ParseText(data["text"])
    if ownLabel = "" and IsAssociativeArray(data["title"])
        ownLabel = ValidString(data["title"]["content"])
    end if
    if ownLabel <> ""
        menuLabel = ownLabel
    end if
    endpoint = data["feedbackEndpoint"]
    if IsAssociativeArray(endpoint) and IsString(endpoint["feedbackToken"]) and endpoint["feedbackToken"] <> ""
        found.Push({
            token: endpoint["feedbackToken"]
            label: menuLabel
        })
        return
    end if
    for each key in data
        Innertube_CollectFeedbackTokens(data[key], found, menuLabel, depth - 1)
    end for
end function

function Innertube_PushFeedItem(item as object, context as object) as void
    if context.currentFeed = invalid
        context.currentFeed = {
            "title": ""
            "items": []
        }
    end if
    if context.currentFeed.title = "" and not StringUtils_IsNullOrEmpty(context.shelfTitle)
        context.currentFeed.title = context.shelfTitle
    end if
    context.currentFeed.items.Push(item)
end function

function Innertube_ParseNotImplemented(_data as object, _context as object) as object
    return invalid
end function

function Innertube_GenerateVideoThumbnails(videoId as string) as object
    return [
        {
            "quality": "maxres"
            "url": ("https://i.ytimg.com/vi/" + bslib_toString(videoId) + "/maxresdefault.jpg")
            "width": 1280
            "height": 720
        }
        {
            "quality": "sddefault"
            "url": ("https://i.ytimg.com/vi/" + bslib_toString(videoId) + "/sddefault.jpg")
            "width": 640
            "height": 480
        }
        {
            "quality": "high"
            "url": ("https://i.ytimg.com/vi/" + bslib_toString(videoId) + "/hqdefault.jpg")
            "width": 480
            "height": 360
        }
        {
            "quality": "medium"
            "url": ("https://i.ytimg.com/vi/" + bslib_toString(videoId) + "/mqdefault.jpg")
            "width": 320
            "height": 180
        }
    ]
end function

function Innertube_Warning(message as string, nodeData as object, context as object) as void
    nodeDataString = FormatJson(nodeData)
    LogWarnNoTelemetry2("[NodesParser.bs:2399]", message + (chr(10)) + nodeDataString)
    LogTelemetryEvent({
        level: "warning"
        message: message
        fingerprint: message
        attachments: [
            {
                filename: "node_data.json"
                content_type: "application/json"
                data: nodeDataString
            }
            {
                filename: "request.txt"
                content_type: "text/plain"
                data: context.request.ToCurlCommand()
            }
        ]
    })
end function