'import "pkg:/components/Services/Innertube/Constants.bs"
'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/CancellationUtils.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RegistryUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/TimeUtils.bs"

 ' 14 days


function Innertube_IsVisitorDataFresh(sessionData as object) as boolean
    if sessionData = invalid or not IsInt(sessionData.timestamp)
        return false
    end if
    if StringUtils_IsNullOrEmpty(sessionData.visitorData)
        return false
    end if
    nowSeconds = TimeUtils_Now().AsSeconds()
    return nowSeconds - sessionData.timestamp <= (60 * 60 * 24 * 14)
end function

function Innertube_RequestTvClientData(cancellation = invalid as object) as object
    visitorData = ""
    livingRoomPoTokenId = ""
    visitorDataResponse = ""
    livingRoomPoTokenIdResponse = ""
    for attempt = 1 to 3
        text = Innertube_FetchTvClientPage(cancellation)
        if not StringUtils_IsNullOrEmpty(text)
            if StringUtils_IsNullOrEmpty(visitorData)
                visitorData = Innertube_ExtractEscapedJsonString(text, "visitorData")
                if StringUtils_IsNullOrEmpty(visitorData)
                    visitorDataResponse = text
                end if
            end if
            if StringUtils_IsNullOrEmpty(livingRoomPoTokenId)
                livingRoomPoTokenId = Innertube_ExtractEscapedJsonString(text, "LIVING_ROOM_PO_TOKEN_ID")
                if StringUtils_IsNullOrEmpty(livingRoomPoTokenId)
                    livingRoomPoTokenIdResponse = text
                end if
            end if
            if not StringUtils_IsNullOrEmpty(visitorData) and not StringUtils_IsNullOrEmpty(livingRoomPoTokenId)
                exit for
            end if
        end if
        if CancellationUtils_IsCancelled(cancellation)
            exit for
        end if
        if attempt < 3
            sleep(attempt * 1000)
        end if
    end for
    if StringUtils_IsNullOrEmpty(visitorData)
        Innertube_ReportTvClientDataFailure("Could not extract visitorData from tv client data", visitorDataResponse)
    end if
    if StringUtils_IsNullOrEmpty(livingRoomPoTokenId)
        Innertube_ReportTvClientDataFailure("Could not extract livingRoomPoTokenId from tv client data", livingRoomPoTokenIdResponse)
    end if
    if StringUtils_IsNullOrEmpty(visitorData) and StringUtils_IsNullOrEmpty(livingRoomPoTokenId)
        return invalid
    end if
    return {
        "timestamp": TimeUtils_Now().AsSeconds()
        "visitorData": visitorData
        "livingRoomPoTokenId": livingRoomPoTokenId
    }
end function

function Innertube_ReportTvClientDataFailure(message as string, responseText as dynamic) as void
    LogErrorNoTelemetry2("[SessionData.bs:77]", message)
    event = {
        level: "error"
        message: message
    }
    if not StringUtils_IsNullOrEmpty(responseText)
        event.attachments = [
            {
                filename: "response.html"
                content_type: "text/html"
                data: responseText
            }
        ]
    end if
    LogTelemetryEvent(event)
end function

function Innertube_FetchTvClientPage(cancellation as object) as dynamic
    request = HttpClient_Get("https://www.youtube.com/tv")
    headers = Innertube_CreateHeaders("TV")
    headers["Referer"] = "https://www.youtube.com/tv"
    request.Headers(headers)
    request.Cancellation(cancellation)
    request.NoCache()
    response = request.Await()
    if not response.IsSuccess()
        LogError3("[SessionData.bs:102]", "Failed to fetch tv client data:", response.ErrorMessage())
        return invalid
    end if
    return response.Text()
end function

function Innertube_ExtractEscapedJsonString(text as string, key as string) as string
    regex = CreateObject("roRegex", (chr(34) + bslib_toString(key) + chr(34) + ":" + chr(34) + "([^" + chr(34) + "]*)" + chr(34)), "")
    match = regex.Match(text)
    if match.Count() < 2
        return ""
    end if
    decoded = StringUtils_ParseJsonSafe(("[" + chr(34) + bslib_toString(match[1]) + chr(34) + "]"))
    if not IsArray(decoded) or decoded.Count() <> 1
        return ""
    end if
    return decoded[0]
end function

function Innertube_SaveSessionDataToRegistry(sessionData as object) as void
    sessionData.__version = 1
    RegistryUtils_Write("innertube_session_data", FormatJson(sessionData))
end function

function Innertube_ReadSessionDataFromRegistry() as object
    sessionData = RegistryUtils_Read("innertube_session_data")
    if StringUtils_IsNullOrEmpty(sessionData)
        return invalid
    end if
    return StringUtils_ParseJsonSafe(sessionData)
end function