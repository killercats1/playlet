'import "pkg:/components/Services/Innertube/GetDrmLicenseEndpoint.types.bs"
function Innertube_CreateGetDrmLicenceRequest(options as object) as object
    videoId = OptionUtils_Get(options, "videoId")
    licenseRequest = OptionUtils_Get(options, "licenseRequest")
    drmParams = OptionUtils_Get(options, "drmParams")
    drmSessionId = OptionUtils_Get(options, "drmSessionId")
    cpn = OptionUtils_Get(options, "cpn")
    cancellation = OptionUtils_Get(options, "cancellation")
    visitorData = OptionUtils_Get(options, "visitorData")
    accessToken = OptionUtils_Get(options, "accessToken")
    deviceInfo = CreateObject("roDeviceInfo")
    
    context = Innertube_CreateContext("TV", deviceInfo, options)
    payload = {
        "videoId": videoId
        "context": context
        "sessionId": drmSessionId
        "cpn": cpn
        "licenseRequest": licenseRequest
        "drmParams": drmParams
        "drmSystem": "DRM_SYSTEM_WIDEVINE"
        "drmVideoFeature": "DRM_VIDEO_FEATURE_SDR"
    }
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/player/get_drm_license?alt=json").JsonBody(payload)
    request.Headers(Innertube_CreateHeaders("TV"))
    if not StringUtils_IsNullOrEmpty(accessToken)
        request.Header("Authorization", "Bearer " + accessToken)
    else if not StringUtils_IsNullOrEmpty(visitorData)
        request.Header("x-goog-visitor-id", visitorData)
    end if
    request.Cancellation(cancellation)
    return request
end function

function Innertube_ParseGetDrmLicenseResponse(payload as object) as object
    if not IsAssociativeArray(payload)
        return {
            "error": "Invalid JSON response"
        }
    end if
    status = ValidString(payload.status)
    if status <> "LICENSE_STATUS_OK"
        return {
            "error": "DRM license request failed with status: " + status
            "payload": payload
        }
    end if
    license = ValidString(payload.license)
    if StringUtils_IsNullOrEmpty(license)
        return {
            "error": "DRM license is missing in the response"
            "payload": payload
        }
    end if
    buffer = createObject("roByteArray")
    buffer.FromBase64String(license.Replace("-", "+").Replace("_", "/"))
    if buffer.Count() = 0
        return {
            "error": "DRM license decodes to no bytes"
            "payload": payload
        }
    end if
    payload.Delete("license")
    return {
        "license": buffer
        "payload": payload
    }
end function

function Innertube_GenerateDrmSessionId() as string
    sessionId = ""
    for i = 0 to 15
        sessionId = sessionId + StrI(rnd(16), 16)
    end for
    return sessionId
end function