'import "pkg:/components/Services/Innertube/GetDrmLicenseEndpoint.types.bs"
'import "pkg:/components/Telemetry/VideoLoadHandoff.bs"


function DrmLicenseRequests_RecordSent(videoLoadId as string) as void
    requests = DrmLicenseRequests_Load(videoLoadId)
    requests["sent"] += 1
    VideoLoadHandoff_Write("tmp:/drm_license_requests.json", videoLoadId, requests)
end function

function DrmLicenseRequests_RecordResponse(videoLoadId as string, response as object) as void
    requests = DrmLicenseRequests_Load(videoLoadId)
    responses = requests["responses"]
    if responses.Count() >= 10
        return
    end if
    if response.payload <> invalid
        responses.Push({
            "payload": response.payload
        })
    else
        responses.Push({
            "error": response.error
        })
    end if
    VideoLoadHandoff_Write("tmp:/drm_license_requests.json", videoLoadId, requests)
end function

function DrmLicenseRequests_Load(videoLoadId as string) as object
    requests = VideoLoadHandoff_Read("tmp:/drm_license_requests.json", videoLoadId)
    if not IsAssociativeArray(requests)
        return {
            "sent": 0
            "responses": []
        }
    end if
    return requests
end function