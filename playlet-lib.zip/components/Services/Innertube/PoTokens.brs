'import "pkg:/source/utils/RegistryUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/TimeUtils.bs"


function Innertube_PoTokens_IsPoTokenEntryValid(entry as object) as boolean
    if not IsAssociativeArray(entry) or StringUtils_IsNullOrEmpty(entry.token) or not IsInt(entry.expiresAt)
        return false
    end if
    return TimeUtils_Now().AsSeconds() < entry.expiresAt
end function

function Innertube_PoTokens_PrunePoTokens(poTokens as object) as object
    pruned = {}
    for each identity in poTokens
        if Innertube_PoTokens_IsPoTokenEntryValid(poTokens[identity])
            pruned[identity] = poTokens[identity]
        end if
    end for
    return pruned
end function

' Stored as { identity: { token, expiresAt, mintedAt } }; identity = visitorData or datasyncIdToken.
' Returns the valid token string for an identity (for playback), or "" if there is none.
function Innertube_PoTokens_GetValidPoTokenForIdentity(identity as string) as string
    if StringUtils_IsNullOrEmpty(identity)
        return ""
    end if
    entry = Innertube_PoTokens_ReadPoTokensFromRegistry()[identity]
    if Innertube_PoTokens_IsPoTokenEntryValid(entry)
        return entry.token
    end if
    return ""
end function

' Returns the stored entry { token, expiresAt, mintedAt } for an identity, or invalid. The web
' app reads this to decide whether to re-mint.
function Innertube_PoTokens_GetPoTokenEntryForIdentity(identity as string) as object
    if StringUtils_IsNullOrEmpty(identity)
        return invalid
    end if
    entry = Innertube_PoTokens_ReadPoTokensFromRegistry()[identity]
    if not IsAssociativeArray(entry)
        return invalid
    end if
    return entry
end function

function Innertube_PoTokens_StorePoToken(identity as string, token as string, expiresAt as integer, mintedAt as integer) as void
    poTokens = Innertube_PoTokens_PrunePoTokens(Innertube_PoTokens_ReadPoTokensFromRegistry())
    poTokens[identity] = {
        "token": token
        "expiresAt": expiresAt
        "mintedAt": mintedAt
    }
    Innertube_PoTokens_SavePoTokensToRegistry(poTokens)
end function

function Innertube_PoTokens_ClearAllPoTokens() as void
    Innertube_PoTokens_SavePoTokensToRegistry({})
end function

function Innertube_PoTokens_ReadPoTokensFromRegistry() as object
    stored = RegistryUtils_Read("innertube_potokens")
    if StringUtils_IsNullOrEmpty(stored)
        return {}
    end if
    parsed = StringUtils_ParseJsonSafe(stored)
    if not IsAssociativeArray(parsed)
        return {}
    end if
    if parsed.__version <> 1
        return {}
    end if
    if not IsAssociativeArray(parsed.tokens)
        return {}
    end if
    return parsed.tokens
end function

function Innertube_PoTokens_SavePoTokensToRegistry(poTokens as object) as void
    RegistryUtils_Write("innertube_potokens", FormatJson({
        "__version": 1
        "tokens": poTokens
    }))
end function