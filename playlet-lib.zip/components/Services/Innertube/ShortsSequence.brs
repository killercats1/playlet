'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
' YouTube's endless Shorts feed (what the phone app loads while you swipe): reel_item_watch on a Short gives the
' sequence parameters, reel_watch_sequence gives the next Shorts and a token for the batch after.
' Parsing is deliberately loose (any reelWatchEndpoint video, any continuation token) since these responses
' change shape often.
' -> { items: [{ type: "video", videoId }], continuation } or { error }
' more: "v:<videoId>" to start from a Short, "c:<token>" to continue. When YouTube's Shorts sequence gives
' nothing, falls back to the Shorts YouTube recommends next to fallbackVideoId (no continuation then: the
' queue goes on from the last of them).
function InnertubeShorts_GetMore(more as string, fallbackVideoId as string, accessToken as dynamic, onBehalfOfUser as dynamic, cancellation as dynamic) as object
    result = InnertubeShorts_GetFromSequence(more, accessToken, onBehalfOfUser, cancellation)
    if result.error = invalid and IsArray(result.items) and result.items.Count() > 0
        return result
    end if
    if fallbackVideoId = ""
        return result
    end if
    related = InnertubeShorts_GetRelatedShorts(fallbackVideoId, accessToken, onBehalfOfUser, cancellation)
    if related.error <> invalid
        return {
            error: (bslib_toString(ValidString(result.error)) + "; related Shorts: " + bslib_toString(related.error))
        }
    end if
    return related
end function

' The Shorts linked from a video's watch page (YouTube lists a Shorts shelf beside most videos).
function InnertubeShorts_GetRelatedShorts(videoId as string, accessToken as dynamic, onBehalfOfUser as dynamic, cancellation as dynamic) as object
    nextResponse = InnertubeShorts_Request("next", {
        "videoId": videoId
    }, accessToken, onBehalfOfUser, cancellation)
    if nextResponse.error <> invalid
        return nextResponse
    end if
    result = InnertubeShorts_ParseSequence(nextResponse.json, videoId)
    if result.items.Count() = 0
        return {
            error: "No related Shorts for " + videoId
        }
    end if
    
    result.continuation = ""
    return result
end function

' YouTube's Shorts sequence (reel_item_watch, then reel_watch_sequence).
function InnertubeShorts_GetFromSequence(more as string, accessToken as dynamic, onBehalfOfUser as dynamic, cancellation as dynamic) as object
    excludeId = ""
    if more.StartsWith("v:")
        excludeId = more.Mid(2)
        itemWatch = InnertubeShorts_Request("reel/reel_item_watch", {
            "playerRequest": {
                "videoId": excludeId
            }
            "params": "CAUwAg%3D%3D"
            "disablePlayerResponse": true
        }, accessToken, onBehalfOfUser, cancellation)
        if itemWatch.error <> invalid
            return itemWatch
        end if
        sequenceParams = InnertubeShorts_FindString(itemWatch.json, "sequenceContinuation", 12)
        if sequenceParams = ""
            return {
                error: "No Shorts sequence for " + excludeId
            }
        end if
        sequence = InnertubeShorts_Request("reel/reel_watch_sequence", {
            "sequenceParams": sequenceParams
        }, accessToken, onBehalfOfUser, cancellation)
    else if more.StartsWith("c:")
        token = more.Mid(2)
        sequence = InnertubeShorts_Request("reel/reel_watch_sequence", {
            "continuation": token
        }, accessToken, onBehalfOfUser, cancellation)
        if sequence.error <> invalid or InnertubeShorts_ParseSequence(sequence.json, "").items.Count() = 0
            sequence = InnertubeShorts_Request("reel/reel_watch_sequence", {
                "sequenceParams": token
            }, accessToken, onBehalfOfUser, cancellation)
        end if
    else
        return {
            error: "Invalid Shorts request"
        }
    end if
    if sequence.error <> invalid
        return sequence
    end if
    result = InnertubeShorts_ParseSequence(sequence.json, excludeId)
    if result.items.Count() = 0
        return {
            error: "No more Shorts"
        }
    end if
    return result
end function

' A WEB client request, signed in when possible; if YouTube refuses the sign-in, retried without it (the
' Shorts are then not personalized, but keep coming).
function InnertubeShorts_Request(path as string, body as object, accessToken as dynamic, onBehalfOfUser as dynamic, cancellation as dynamic) as object
    attempts = [
        false
    ]
    if not StringUtils_IsNullOrEmpty(accessToken)
        attempts = [
            true
            false
        ]
    end if
    lastError = ""
    for each signedIn in attempts
        options = {}
        if signedIn and not StringUtils_IsNullOrEmpty(onBehalfOfUser)
            options.onBehalfOfUser = onBehalfOfUser
        end if
        payload = {
            "context": Innertube_CreateContext("WEB", CreateObject("roDeviceInfo"), options)
        }
        payload.Append(body)
        httpRequest = HttpClient_Post(("https://www.youtube.com/youtubei/v1/" + bslib_toString(path) + "?prettyPrint=false&alt=json")).JsonBody(payload)
        httpRequest.Headers(Innertube_CreateHeaders("WEB"))
        if signedIn
            httpRequest.Header("Authorization", "Bearer " + accessToken)
        end if
        httpRequest.Cancellation(cancellation)
        response = httpRequest.Await()
        if response.IsSuccess()
            json = response.Json()
            if IsAssociativeArray(json)
                return {
                    json: json
                }
            end if
        end if
        lastError = response.ErrorMessage()
    end for
    return {
        error: lastError
    }
end function

function InnertubeShorts_ParseSequence(json as dynamic, excludeId as string) as object
    items = []
    seen = {}
    if excludeId <> ""
        seen[excludeId] = true
    end if
    InnertubeShorts_CollectReelVideos(json, items, seen, 20)
    return {
        items: items
        continuation: InnertubeShorts_TokenOf(InnertubeShorts_FindKey(json, "continuationCommand", 12))
    }
end function

function InnertubeShorts_CollectReelVideos(data as dynamic, items as object, seen as object, depth as integer) as void
    if depth < 0
        return
    end if
    if IsAssociativeArray(data)
        endpoint = data["reelWatchEndpoint"]
        if IsAssociativeArray(endpoint) and IsString(endpoint["videoId"]) and endpoint["videoId"] <> ""
            videoId = endpoint["videoId"]
            if not seen.DoesExist(videoId)
                seen[videoId] = true
                items.Push({
                    "type": "video"
                    "videoId": videoId
                })
            end if
        end if
        for each key in data
            InnertubeShorts_CollectReelVideos(data[key], items, seen, depth - 1)
        end for
    else if IsArray(data)
        for each child in data
            InnertubeShorts_CollectReelVideos(child, items, seen, depth - 1)
        end for
    end if
end function

function InnertubeShorts_TokenOf(continuationCommand as dynamic) as string
    if IsAssociativeArray(continuationCommand)
        return ValidString(continuationCommand["token"])
    end if
    return ""
end function

function InnertubeShorts_FindString(data as dynamic, key as string, depth as integer) as string
    return ValidString(InnertubeShorts_FindKey(data, key, depth))
end function

function InnertubeShorts_FindKey(data as dynamic, key as string, depth as integer) as dynamic
    if depth < 0
        return invalid
    end if
    if IsAssociativeArray(data)
        if data.DoesExist(key)
            return data[key]
        end if
        for each childKey in data
            found = InnertubeShorts_FindKey(data[childKey], key, depth - 1)
            if found <> invalid
                return found
            end if
        end for
    else if IsArray(data)
        for each child in data
            found = InnertubeShorts_FindKey(child, key, depth - 1)
            if found <> invalid
                return found
            end if
        end for
    end if
    return invalid
end function