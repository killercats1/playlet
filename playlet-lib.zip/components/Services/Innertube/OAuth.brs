'import "pkg:/components/Services/Innertube/Constants.bs"
'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/components/Services/Innertube/NodesParser.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/ObjectUtils.bs"
'import "pkg:/source/utils/TimeUtils.bs"


function Innertube_IsTerminalRefreshError(json as object) as boolean
    if not IsAssociativeArray(json)
        return false
    end if
    oauthError = ValidString(json.error)
    return oauthError = "invalid_grant" or oauthError = "invalid_client" or oauthError = "unauthorized_client"
end function

' A failed refresh is retried, unless the token endpoint rejected the credential or the client.
function Innertube_RefreshRetryReason(response as object) as string
    if response.IsSuccess() or Innertube_IsTerminalRefreshError(response.Json())
        return ""
    end if
    return response.ErrorMessage()
end function

function Innertube_GetClientIdentity(cancellation = invalid as dynamic) as object
    request = HttpClient_Get("https://www.youtube.com/tv")
    request.Headers({
        "User-Agent": "Mozilla/5.0(SMART-TV; Linux; Tizen 4.0.0.2) AppleWebkit/605.1.15 (KHTML, like Gecko) SamsungBrowser/9.2 TV Safari/605.1.15"
        "Referer": "https://www.youtube.com/tv"
        "Accept-Language": "en-US"
    })
    request.Cancellation(cancellation)
    response = request.Await()
    if not response.IsSuccess()
        return {
            "error": ("Failed to get client id: " + bslib_toString(response.ErrorMessage()))
        }
    end if
    text = response.Text()
    scriptRegex = CreateObject("roRegex", "<script\s+id=" + chr(34) + "base-js" + chr(34) + "\s+src=" + chr(34) + "([^" + chr(34) + "]+)" + chr(34) + "[^>]*><\/script>", "")
    match = scriptRegex.Match(text)
    if match.Count() < 2
        return {
            "error": "Could not find base-js script"
        }
    end if
    baseJsUrl = "https://www.youtube.com" + match[1]
    request = HttpClient_Get(baseJsUrl)
    request.Cancellation(cancellation)
    response = request.Await()
    if not response.IsSuccess()
        return {
            "error": ("Failed to get base js: " + bslib_toString(response.ErrorMessage()))
        }
    end if
    text = response.Text()
    clientIdRegex = CreateObject("roRegex", "clientId:" + chr(34) + "(?<client_id>[^" + chr(34) + "]+)" + chr(34) + ",[^" + chr(34) + "]*?:" + chr(34) + "(?<client_secret>[^" + chr(34) + "]+)" + chr(34) + "", "")
    match = clientIdRegex.Match(text)
    if match.Count() < 3
        return {
            "error": "Could not find client id and secret"
        }
    end if
    return {
        "clientId": match[1]
        "clientSecret": match[2]
    }
end function

function Innertube_GetDeviceAndUserCode(clientId as string, cancellation = invalid as dynamic) as object
    deviceInfo = CreateObject("roDeviceInfo")
    payload = {
        "client_id": clientId
        "scope": "http://gdata.youtube.com https://www.googleapis.com/auth/youtube-paid-content"
        "device_id": deviceInfo.GetRandomUUID()
        "device_model": "ytlr::"
    }
    request = HttpClient_Post("https://www.youtube.com/o/oauth2/device/code").JsonBody(payload)
    request.Cancellation(cancellation)
    response = request.Await()
    if not response.IsSuccess()
        return {
            "error": ("Failed to get device code: " + bslib_toString(response.ErrorMessage()))
        }
    end if
    responseData = Innertube_ToCamelCase(response.Json())
    if responseData.DoesExist("errorCode")
        return {
            "error": "Failed to get device code: " + ToString(responseData)
        }
    end if
    if responseData.DoesExist("expiresIn")
        responseData["expiresTimestamp"] = TimeUtils_Now().AsSeconds() + responseData["expiresIn"]
    end if
    return responseData
end function

function Innertube_PollForAccessToken(clientIdentity as object, deviceAndUserCode as object, cancellation = invalid as dynamic) as object
    payload = {
        "client_id": clientIdentity.clientId
        "client_secret": clientIdentity.clientSecret
        "code": deviceAndUserCode.deviceCode
        "grant_type": "http://oauth.net/grant_type/device/1.0"
    }
    intervalMs = deviceAndUserCode.interval * 1000
    while true
        request = HttpClient_Post("https://www.youtube.com/o/oauth2/token").JsonBody(payload)
        request.Cancellation(cancellation)
        response = request.Await()
        if not response.IsSuccess()
            errorMessage = response.ErrorMessage()
            LogError2("[OAuth.bs:139]", errorMessage)
            return {
                "error": errorMessage
            }
        end if
        responseData = Innertube_ToCamelCase(response.Json())
        if not responseData.DoesExist("error")
            if responseData.DoesExist("expiresIn")
                responseData["expiresTimestamp"] = TimeUtils_Now().AsSeconds() + responseData["expiresIn"]
            end if
            responseData["clientId"] = clientIdentity["clientId"]
            responseData["clientSecret"] = clientIdentity["clientSecret"]
            return responseData
        end if
        if responseData.error = "authorization_pending"
            LogInfo3("[OAuth.bs:156]", "Waiting for user to authorize device", responseData)
            sleep(intervalMs)
            if CancellationUtils_IsCancelled(cancellation)
                return invalid
            end if
            continue while
        else if responseData.error = "slow_down"
            LogWarn3("[OAuth.bs:163]", "Polling too fast, slowing down", responseData)
            sleep(intervalMs + 3000)
            if CancellationUtils_IsCancelled(cancellation)
                return invalid
            end if
            continue while
        else if responseData.error = "expired_token"
            return responseData
        else if responseData.error = "access_denied"
            return responseData
        else
            return {
                "error": "Failed to get access token: " + ToString(responseData)
            }
        end if
    end while
    return invalid
end function

function Innertube_RefreshAccessToken(accessToken as object, cancellation = invalid as dynamic) as object
    payload = {
        "client_id": accessToken.clientId
        "client_secret": accessToken.clientSecret
        "refresh_token": accessToken.refreshToken
        "grant_type": "refresh_token"
    }
    request = HttpClient_Post("https://www.youtube.com/o/oauth2/token").JsonBody(payload)
    request.Cancellation(cancellation)
    request.RetryCount(2)
    request.RetryIf(Innertube_RefreshRetryReason)
    response = request.Await()
    if not response.IsSuccess()
        json = response.Json()
        oauthError = ""
        if IsAssociativeArray(json)
            oauthError = ValidString(json.error)
        end if
        if oauthError = "invalid_grant"
            
            accessToken.terminalRefreshError = true
        else if oauthError = "invalid_client" or oauthError = "unauthorized_client"
            
            LogError7("[OAuth.bs:209]", "OAuth client rejected by token endpoint:", response.ErrorMessage(), "client_id:", accessToken.clientId, "client_secret:", accessToken.clientSecret)
        end if
        throw ("Failed to refresh token: " + bslib_toString(response.ErrorMessage()))
    end if
    responseData = Innertube_ToCamelCase(response.Json())
    if responseData.DoesExist("errorCode")
        throw "Failed to refresh token: " + ToString(responseData)
    end if
    return responseData
end function

function Innertube_RevokeToken(token as string, cancellation = invalid as dynamic) as boolean
    request = HttpClient_Post("https://www.youtube.com/o/oauth2/revoke").JsonBody({
        "token": token
    })
    request.Cancellation(cancellation)
    response = request.Await()
    success = response.IsSuccess()
    if not success
        LogError2("[OAuth.bs:230]", ("Failed to revoke token: " + bslib_toString(response.ErrorMessage())))
    end if
    return success
end function

function Innertube_ListAccounts(accessToken as string, cancellation = invalid as dynamic) as object
    deviceInfo = CreateObject("roDeviceInfo")
    payload = {
        "context": Innertube_CreateContext("TV", deviceInfo)
        "accountReadMask": {
            "returnOwner": true
            "returnBrandAccounts": true
            "returnPersonaAccounts": true
            "returnFamilyChildAccounts": true
        }
    }
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/account/accounts_list").JsonBody(payload)
    headers = {
        "Authorization": ("Bearer " + bslib_toString(accessToken))
    }
    headers.Append(Innertube_CreateHeaders("TV"))
    request.Headers(headers)
    request.Cancellation(cancellation)
    response = request.Await()
    if not response.IsSuccess()
        return {
            "error": ("Failed to list accounts: " + bslib_toString(response.ErrorMessage()))
        }
    end if
    accounts = ObjectUtils_Dig(response.Json(), [
        "contents"
        0
        "accountSectionListRenderer"
        "contents"
        0
        "accountItemSectionRenderer"
        "contents"
    ])
    if not IsArray(accounts)
        return {
            "error": "Could not parse accounts"
        }
    end if
    parsedAccounts = []
    for each account in accounts
        accountItem = account["accountItem"]
        if not IsAssociativeArray(accountItem)
            continue for
        end if
        parsedAccount = {
            "accountName": Innertube_ParseText(accountItem["accountName"])
            "accountPhoto": ObjectUtils_Dig(accountItem, [
                "accountPhoto"
                "thumbnails"
                0
                "url"
            ])
            "isSelected": ValidBool(accountItem["isSelected"])
            "isDisabled": ValidBool(accountItem["isDisabled"])
            "hasChannel": ValidBool(accountItem["hasChannel"])
            "accountByline": Innertube_ParseText(accountItem["accountByline"])
            "channelHandle": Innertube_ParseText(accountItem["channelHandle"])
            "activeIdentifyToken": Innertube_ParseAccountItemIdentityToken(accountItem)
        }
        parsedAccounts.Push(parsedAccount)
    end for
    return parsedAccounts
end function

function Innertube_ParseAccountItemIdentityToken(accountItem as object) as string
    
    if ValidBool(accountItem.isSelected)
        return ""
    end if
    supportedTokens = ObjectUtils_Dig(accountItem, [
        "serviceEndpoint"
        "selectActiveIdentityEndpoint"
        "supportedTokens"
    ])
    if not IsArray(supportedTokens) or supportedTokens.Count() = 0
        return ""
    end if
    for each supportedToken in supportedTokens
        if not IsAssociativeArray(supportedToken)
            continue for
        end if
        
        pageId = ObjectUtils_Dig(supportedToken, [
            "pageIdToken"
            "pageId"
        ])
        if not StringUtils_IsNullOrEmpty(pageId)
            return pageId
        end if
        obfuscatedGaiaId = ObjectUtils_Dig(supportedToken, [
            "accountStateToken"
            "obfuscatedGaiaId"
        ])
        if not StringUtils_IsNullOrEmpty(obfuscatedGaiaId)
            return obfuscatedGaiaId
        end if
        datasyncIdToken = ObjectUtils_Dig(supportedToken, [
            "datasyncIdToken"
            "datasyncIdToken"
        ])
        if not StringUtils_IsNullOrEmpty(datasyncIdToken)
            
            match = CreateObject("roRegex", "(\d+)\|\|(\d+)", "").match(datasyncIdToken)
            if match.Count() = 3
                return match[1]
            end if
        end if
    end for
    return ""
end function

function Innertube_ToCamelCase(obj as object) as object
    if not IsAssociativeArray(obj)
        return obj
    end if
    newObj = {}
    for each key in obj
        newKey = key
        underScoreIndex = newKey.InStr("_")
        while underScoreIndex <> -1 and underScoreIndex < newKey.Len() - 2
            newKey = newKey.Left(underScoreIndex) + UCase(newKey.Mid(underScoreIndex + 1, 1)) + newKey.Mid(underScoreIndex + 2)
            underScoreIndex = newKey.InStr("_")
        end while
        newObj[newKey] = obj[key]
    end for
    return newObj
end function