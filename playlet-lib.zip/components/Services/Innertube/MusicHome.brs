'import "pkg:/components/Services/Innertube/Constants.bs"
'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/ObjectUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
' The signed-in account's YouTube Music home (Quick picks, Listen again, Mixed for you, ...), as one list of
' Invidious-style items (songs/videos, playlists, artists) for the Music tab's "Recommended music" row.
' Uses the same (TV) sign-in as the rest of the app; if YouTube Music refuses it, this returns { error }.
function InnertubeMusic_GetHome(accessToken as string, onBehalfOfUser as dynamic, cancellation as dynamic) as object
    deviceInfo = CreateObject("roDeviceInfo")
    context = {
        "client": {
            "clientName": "WEB_REMIX"
            "clientVersion": "1.20260610.01.00"
            "hl": Innertube_GetCurrentLocale(deviceInfo).Replace("_", "-")
            "gl": Innertube_GetContentRegion(deviceInfo)
        }
    }
    if not StringUtils_IsNullOrEmpty(onBehalfOfUser)
        context["user"] = {
            "onBehalfOfUser": onBehalfOfUser
        }
    end if
    request = HttpClient_Post("https://music.youtube.com/youtubei/v1/browse?prettyPrint=false").JsonBody({
        "context": context
        "browseId": "FEmusic_home"
    })
    request.Headers({
        "Authorization": "Bearer " + accessToken
        "Origin": "https://music.youtube.com"
        "Referer": "https://music.youtube.com/"
        "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:150.0) Gecko/20100101 Firefox/150.0"
        "X-Youtube-Client-Name": "67"
        "X-Youtube-Client-Version": "1.20260610.01.00"
    })
    request.Cancellation(cancellation)
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    items = InnertubeMusic_ParseHome(response.Json())
    if items.Count() = 0
        return {
            error: "YouTube Music returned no recommendations"
        }
    end if
    return {
        items: items
    }
end function

' FEmusic_home -> [{ type: "video"|"playlist"|"channel", ... }], every shelf in order, without duplicates.
function InnertubeMusic_ParseHome(payload as object) as object
    items = []
    sections = ObjectUtils_Dig(payload, [
        "contents"
        "singleColumnBrowseResultsRenderer"
        "tabs"
        0
        "tabRenderer"
        "content"
        "sectionListRenderer"
        "contents"
    ])
    if not IsArray(sections)
        return items
    end if
    seen = {}
    for each section in sections
        if not IsAssociativeArray(section)
            continue for
        end if
        shelf = section["musicCarouselShelfRenderer"]
        if not IsAssociativeArray(shelf)
            shelf = section["musicImmersiveCarouselShelfRenderer"]
        end if
        if not IsAssociativeArray(shelf) or not IsArray(shelf["contents"])
            continue for
        end if
        for each content in shelf["contents"]
            item = invalid
            if IsAssociativeArray(content)
                if IsAssociativeArray(content["musicTwoRowItemRenderer"])
                    item = InnertubeMusic_ParseTwoRowItem(content["musicTwoRowItemRenderer"])
                else if IsAssociativeArray(content["musicResponsiveListItemRenderer"])
                    item = InnertubeMusic_ParseListItem(content["musicResponsiveListItemRenderer"])
                end if
            end if
            if item = invalid
                continue for
            end if
            key = item.type + ":" + ValidString(item.videoId) + ValidString(item.playlistId) + ValidString(item.authorId)
            if seen.DoesExist(key)
                continue for
            end if
            seen[key] = true
            items.Push(item)
        end for
    end for
    return items
end function

' Cards: songs/videos, playlists, mixes, albums, artists.
function InnertubeMusic_ParseTwoRowItem(renderer as object) as dynamic
    title = InnertubeMusic_Text(renderer["title"])
    if title = ""
        return invalid
    end if
    subtitle = InnertubeMusic_Text(renderer["subtitle"])
    authorId = InnertubeMusic_ChannelIdFromRuns(ObjectUtils_Dig(renderer, [
        "subtitle"
        "runs"
    ]))
    navigation = renderer["navigationEndpoint"]
    videoId = ValidString(ObjectUtils_Dig(navigation, [
        "watchEndpoint"
        "videoId"
    ]))
    if videoId <> ""
        return InnertubeMusic_Video(videoId, title, subtitle, authorId)
    end if
    browseId = ValidString(ObjectUtils_Dig(navigation, [
        "browseEndpoint"
        "browseId"
    ]))
    if browseId.StartsWith("UC")
        thumbnails = ObjectUtils_Dig(renderer, [
            "thumbnailRenderer"
            "musicThumbnailRenderer"
            "thumbnail"
            "thumbnails"
        ])
        return {
            "type": "channel"
            "author": title
            "authorId": browseId
            "authorThumbnails": ValidArray(thumbnails)
        }
    end if
    
    playlistId = ""
    if browseId.StartsWith("VL")
        playlistId = browseId.Mid(2)
    else
        watchPlaylist = InnertubeMusic_FindKey(renderer["thumbnailOverlay"], "watchPlaylistEndpoint", 10)
        playlistId = ValidString(ObjectUtils_Dig(watchPlaylist, [
            "playlistId"
        ]))
    end if
    if playlistId = ""
        return invalid
    end if
    return {
        "type": "playlist"
        "playlistId": playlistId
        "title": title
        "author": subtitle
        "playlistThumbnail": InnertubeMusic_LargestThumbnail(ObjectUtils_Dig(renderer, [
            "thumbnailRenderer"
            "musicThumbnailRenderer"
            "thumbnail"
            "thumbnails"
        ]))
    }
end function

' List rows (e.g. Quick picks): songs.
function InnertubeMusic_ParseListItem(renderer as object) as dynamic
    videoId = ValidString(ObjectUtils_Dig(renderer, [
        "playlistItemData"
        "videoId"
    ]))
    if videoId = ""
        videoId = ValidString(ObjectUtils_Dig(InnertubeMusic_FindKey(renderer["overlay"], "watchEndpoint", 10), [
            "videoId"
        ]))
    end if
    if videoId = ""
        return invalid
    end if
    title = InnertubeMusic_Text(ObjectUtils_Dig(renderer, [
        "flexColumns"
        0
        "musicResponsiveListItemFlexColumnRenderer"
        "text"
    ]))
    if title = ""
        return invalid
    end if
    subtitleRuns = ObjectUtils_Dig(renderer, [
        "flexColumns"
        1
        "musicResponsiveListItemFlexColumnRenderer"
        "text"
        "runs"
    ])
    subtitle = InnertubeMusic_Text(ObjectUtils_Dig(renderer, [
        "flexColumns"
        1
        "musicResponsiveListItemFlexColumnRenderer"
        "text"
    ]))
    return InnertubeMusic_Video(videoId, title, subtitle, InnertubeMusic_ChannelIdFromRuns(subtitleRuns))
end function

' The thumbnail comes from i.ytimg.com by videoId (the tiles are 16:9).
function InnertubeMusic_Video(videoId as string, title as string, author as string, authorId as string) as object
    item = {
        "type": "video"
        "videoId": videoId
        "title": title
        "author": author
    }
    if authorId <> ""
        item["authorId"] = authorId
    end if
    return item
end function

function InnertubeMusic_ChannelIdFromRuns(runs as dynamic) as string
    if not IsArray(runs)
        return ""
    end if
    for each textRun in runs
        browseId = ValidString(ObjectUtils_Dig(textRun, [
            "navigationEndpoint"
            "browseEndpoint"
            "browseId"
        ]))
        if browseId.StartsWith("UC")
            return browseId
        end if
    end for
    return ""
end function

' YouTube Music art comes small (e.g. "=w120-h120..."); ask for a bigger size.
function InnertubeMusic_LargestThumbnail(thumbnails as dynamic) as string
    if not IsArray(thumbnails) or thumbnails.Count() = 0
        return ""
    end if
    url = ValidString(ObjectUtils_Dig(thumbnails[thumbnails.Count() - 1], [
        "url"
    ]))
    if url.InStr("googleusercontent.com") <> -1
        url = CreateObject("roRegex", "=w\d+-h\d+", "").Replace(url, "=w544-h544")
    end if
    return url
end function

function InnertubeMusic_Text(data as dynamic) as string
    if IsString(data)
        return data
    end if
    if not IsAssociativeArray(data)
        return ""
    end if
    if IsString(data["simpleText"])
        return data["simpleText"]
    end if
    if IsArray(data["runs"])
        joined = ""
        for each textRun in data["runs"]
            if IsAssociativeArray(textRun) and IsString(textRun["text"])
                joined += textRun["text"]
            end if
        end for
        return joined
    end if
    return ""
end function

function InnertubeMusic_FindKey(data as dynamic, key as string, depth as integer) as dynamic
    if depth < 0
        return invalid
    end if
    if IsAssociativeArray(data)
        if data.DoesExist(key)
            return data[key]
        end if
        for each childKey in data
            found = InnertubeMusic_FindKey(data[childKey], key, depth - 1)
            if found <> invalid
                return found
            end if
        end for
    else if IsArray(data)
        for each child in data
            found = InnertubeMusic_FindKey(child, key, depth - 1)
            if found <> invalid
                return found
            end if
        end for
    end if
    return invalid
end function