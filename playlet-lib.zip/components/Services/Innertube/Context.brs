'import "pkg:/components/Services/Innertube/Constants.bs"
'import "pkg:/source/utils/OptionUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"


function Innertube_CreateHeaders(client as object) as object
    if client = "WEB"
        return {
            "accept": "*/*"
            "accept-language": "*"
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
            "x-youtube-client-name": "1"
            "x-youtube-client-version": "2.20260612.01.00"
        }
    else if client = "IOS"
        return {
            "accept": "*/*"
            "accept-language": "*"
            "user-agent": "com.google.ios.youtube/21.16.2 (iPhone16,2; U; CPU iOS 18_1_0 like Mac OS X)"
            "x-youtube-client-name": "5"
            "x-youtube-client-version": "21.16.2"
        }
    else if client = "TV"
        return {
            "accept": "*/*"
            "accept-language": "*"
            "user-agent": "Mozilla/5.0(SMART-TV; Linux; Tizen 4.0.0.2) AppleWebkit/605.1.15 (KHTML, like Gecko) SamsungBrowser/9.2 TV Safari/605.1.15"
            "x-youtube-client-name": "2"
            "x-youtube-client-version": "7.20260611.00.00"
        }
    else if client = "TV_DOWNGRADED"
        return {
            "accept": "*/*"
            "accept-language": "*"
            "user-agent": "Mozilla/5.0(SMART-TV; Linux; Tizen 4.0.0.2) AppleWebkit/605.1.15 (KHTML, like Gecko) SamsungBrowser/9.2 TV Safari/605.1.15"
            "x-youtube-client-name": "2"
            "x-youtube-client-version": "5.20260114"
        }
    else
        throw "Invalid client type"
    end if
end function

function Innertube_CreateContext(client as object, deviceInfo as object, options = invalid as object) as object
    contextClient = invalid
    livingRoomPoTokenId = OptionUtils_Get(options, "livingRoomPoTokenId")
    if client = "WEB"
        contextClient = Innertube_CreateContextClientWeb(deviceInfo)
    else if client = "IOS"
        contextClient = Innertube_CreateContextClientIOS(deviceInfo)
    else if client = "TV" or client = "TV_DOWNGRADED"
        contextClient = Innertube_CreateContextClientTv(deviceInfo, client, livingRoomPoTokenId)
    else
        throw "Invalid client type"
    end if
    credentialTransferToken = OptionUtils_Get(options, "credentialTransferToken")
    visitorData = OptionUtils_Get(options, "visitorData")
    onBehalfOfUser = OptionUtils_Get(options, "onBehalfOfUser")
    accessToken = OptionUtils_Get(options, "accessToken")
    videoId = OptionUtils_Get(options, "videoId")
    useAccessToken = (client = "TV" or client = "TV_DOWNGRADED") and not StringUtils_IsNullOrEmpty(accessToken)
    useCtt = (client = "TV" or client = "TV_DOWNGRADED") and IsAssociativeArray(credentialTransferToken) and not StringUtils_IsNullOrEmpty(videoId)
    context = {
        "client": contextClient
        "user": {
            "enableSafetyMode": false
            "lockedSafetyMode": false
        }
        "request": {
            "useSsl": true
            "internalExperimentFlags": []
        }
    }
    if useCtt
        cttCideoId = credentialTransferToken.videoId
        cttToken = credentialTransferToken.token
        if not StringUtils_IsNullOrEmpty(cttToken) and videoId = cttCideoId
            context["user"]["credentialTransferTokens"] = [
                {
                    "token": cttToken
                    "scope": "VIDEO"
                }
            ]
        end if
    end if
    if not StringUtils_IsNullOrEmpty(visitorData) and not useAccessToken
        context["client"]["visitorData"] = visitorData
    end if
    if not StringUtils_IsNullOrEmpty(onBehalfOfUser) and useAccessToken
        context["user"]["onBehalfOfUser"] = onBehalfOfUser
    end if
    return context
end function

function Innertube_CreateContextClientWeb(deviceInfo as object) as object
    return {
        "hl": Innertube_GetCurrentLocale(deviceInfo)
        "gl": Innertube_GetContentRegion(deviceInfo)
        "remoteHost": ""
        "screenDensityFloat": 1
        "screenHeightPoints": 1440
        "screenPixelDensity": 1
        "screenWidthPoints": 2560
        "clientName": "WEB"
        "clientVersion": "2.20260612.01.00"
        "osName": "Windows"
        "osVersion": "10.0"
        "platform": "DESKTOP"
        "clientFormFactor": "UNKNOWN_FORM_FACTOR"
        "userInterfaceTheme": "USER_INTERFACE_THEME_LIGHT"
        "timeZone": deviceInfo.GetTimeZone()
        "originalUrl": "https://www.youtube.com"
        "deviceMake": ""
        "deviceModel": ""
        "browserName": "Chrome"
        "browserVersion": "147.0.0.0"
        "utcOffsetMinutes": -240
        "memoryTotalKbytes": "8000000"
        "mainAppWebInfo": {
            "graftUrl": "https://www.youtube.com"
            "pwaInstallabilityStatus": "PWA_INSTALLABILITY_STATUS_UNKNOWN"
            "webDisplayMode": "WEB_DISPLAY_MODE_BROWSER"
            "isWebNativeShareAvailable": true
        }
    }
end function

function Innertube_CreateContextClientIOS(deviceInfo as object) as object
    return {
        "hl": Innertube_GetCurrentLocale(deviceInfo)
        "gl": Innertube_GetContentRegion(deviceInfo)
        "remoteHost": ""
        "screenDensityFloat": 1
        "screenHeightPoints": 1440
        "screenPixelDensity": 1
        "screenWidthPoints": 2560
        "clientName": "iOS"
        "clientVersion": "21.16.2"
        "osName": "iOS"
        "osVersion": "18.1"
        "platform": "MOBILE"
        "clientFormFactor": "UNKNOWN_FORM_FACTOR"
        "userInterfaceTheme": "USER_INTERFACE_THEME_LIGHT"
        "timeZone": deviceInfo.GetTimeZone()
        "originalUrl": "https://www.youtube.com"
        "deviceMake": "Apple"
        "deviceModel": "iPhone16,2"
        "utcOffsetMinutes": -240
        "memoryTotalKbytes": "8000000"
    }
end function

function Innertube_CreateContextClientTv(deviceInfo as object, client as object, livingRoomPoTokenId = "" as dynamic) as object
    tvClientVersion = "7.20260611.00.00"
    if client = "TV_DOWNGRADED"
        tvClientVersion = "5.20260114"
    end if
    contextClient = {
        "hl": Innertube_GetCurrentLocale(deviceInfo)
        "gl": Innertube_GetContentRegion(deviceInfo)
        "remoteHost": ""
        "deviceMake": "Samsung"
        "deviceModel": "SmartTV"
        "userAgent": "Mozilla/5.0(SMART-TV; Linux; Tizen 4.0.0.2) AppleWebkit/605.1.15 (KHTML, like Gecko) SamsungBrowser/9.2 TV Safari/605.1.15"
        "clientName": "TVHTML5"
        "clientVersion": tvClientVersion
        "osName": "Tizen"
        "osVersion": "4.0.0.2"
        "originalUrl": "https://www.youtube.com/tv"
        "theme": "CLASSIC"
        "platform": "TV"
        "clientFormFactor": "UNKNOWN_FORM_FACTOR"
        "webpSupport": false
        "tvAppInfo": {
            ' Merge Shorts with Subscriptions: TV_APP_QUALITY_LIMITED_ANIMATION
            ' Separate Shorts from Subscriptions: TV_APP_QUALITY_FULL_ANIMATION
            "appQuality": "TV_APP_QUALITY_FULL_ANIMATION"
            "useStartPlaybackPreviewCommand": false
            "voiceCapability": {
                "hasSoftMicSupport": false
                "hasHardMicSupport": false
            }
            "supportsNativeScrolling": false
        }
        "browserName": "SamsungBrowser"
        "browserVersion": "9.2"
        "acceptHeader": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
        "screenHeightPoints": 1440
        "screenWidthPoints": 2560
        "screenPixelDensity": 2
        "utcOffsetMinutes": -300
        "playerType": "UNIPLAYER"
        "connectionType": "CONN_CELLULAR_4G"
    }
    if not StringUtils_IsNullOrEmpty(livingRoomPoTokenId)
        contextClient.tvAppInfo["livingRoomPoTokenId"] = livingRoomPoTokenId
    end if
    return contextClient
end function

function Innertube_GetCurrentLocale(deviceInfo as object) as string
    currentLocale = deviceInfo.GetCurrentLocale()
    
    if currentLocale = "en_CA" or currentLocale = "en_AU"
        return "en_US"
    end if
    return currentLocale
end function

function Innertube_GetContentRegion(deviceInfo as object) as string
    region = deviceInfo.GetUserCountryCode()
    if region.len() <> 2 or region = "OT"
        region = "US"
    end if
    return region
end function