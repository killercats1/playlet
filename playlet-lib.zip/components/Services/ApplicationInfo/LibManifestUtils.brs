'import "pkg:/source/utils/Types.bs"
function LibManifestUtils_GetLibVersion() as string
    values = LibManifestUtils_GetValues()
    major = ValidString(values["major_version"]).ToInt()
    minor = ValidString(values["minor_version"]).ToInt()
    build = ValidString(values["build_version"]).ToInt()
    return (bslib_toString(major) + "." + bslib_toString(minor) + "." + bslib_toString(build))
end function

function LibManifestUtils_GetLibGitCommitHash() as string
    return ValidString(LibManifestUtils_GetValues()["git_commit_sha"])
end function

function LibManifestUtils_GetValues() as object
    if m.libManifestValues = invalid
        m.libManifestValues = LibManifestUtils_Parse(ReadAsciiFile("libpkg:/manifest"))
    end if
    return m.libManifestValues
end function

function LibManifestUtils_Parse(manifest as string) as object
    values = {}
    for each line in manifest.Tokenize((chr(13) + chr(10)))
        if line.left(1) = "#"
            continue for
        end if
        keyValuePair = line.Tokenize("=")
        if keyValuePair.Count() <> 2
            continue for
        end if
        values[keyValuePair[0]] = keyValuePair[1]
    end for
    return values
end function