'import "pkg:/source/services/ApplicationInfo.bs"

function Init()
    m.service = ApplicationInfo(m.top)
end function

function GetAppInfo(_unused as dynamic) as object
    return m.service.GetAppInfo()
end function

function GetDeviceInfo(_unused as dynamic) as object
    return m.service.GetDeviceInfo()
end function

function GetUserCountryCode(_unused as dynamic) as string
    return m.service.GetUserCountryCode()
end function

function GetLocalIpAddress(_unused as dynamic) as dynamic
    return m.service.GetLocalIpAddress()
end function