

function SponsorBlock_GetCurrentNotification(notifications as object) as object
    childCount = notifications.getChildCount()
    for i = 0 to childCount - 1
        child = notifications.getChild(i)
        if child.id = "SponsorBlockNotification"
            return child
        end if
    end for
    return invalid
end function

function SponsorBlock_ShowNotifcation(notifications as object, segment as object) as void
    
    notification = SponsorBlock_GetCurrentNotification(notifications)
    if notification = invalid
        notification = notifications.createChild("SponsorBlockNotification")
        notification.id = "SponsorBlockNotification"
    end if
    notification.segmentId = segment.UUID
    notification.categoryText = segment.shortTitle
    notification.actionText = segment.actionText
    notification.doShow = true
end function

function SponsorBlock_RemoveNotifcation(notifications as object) as void
    notification = SponsorBlock_GetCurrentNotification(notifications)
    if notification <> invalid
        notifications.RemoveChild(notification)
    end if
end function

function SponsorBlock_SetVisible(notifications as object, visible as boolean)
    notification = SponsorBlock_GetCurrentNotification(notifications)
    if notification <> invalid
        notification.visible = visible
    end if
end function