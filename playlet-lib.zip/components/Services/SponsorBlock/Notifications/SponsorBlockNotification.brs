'import "pkg:/components/VideoPlayer/SponsorBlockSegmentAction.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    m.categoryLabel = m.top.findNode("categoryLabel")
    m.translationAnimation = m.top.findNode("translationAnimation")
    m.translationAnimationInterpolator = m.top.findNode("translationAnimationInterpolator")
    m.animationTimer = m.top.findNode("animationTimer")
    m.top.translation = [
        1280
        20
    ]
    m.translationAnimation.observeField("state", FuncName(OnAnimationState))
    m.animationTimer.observeField("fire", FuncName(OnAnimationTimer))
end function

function OnDoShow() as void
    AnimateIn()
end function

function OnAnimationTimer()
    AnimateOut()
end function

function AnimateIn()
    m.translationAnimation.unobserveField("state")
    m.animationTimer.control = "stop"
    m.animationTimer.control = "start"
    m.translationAnimation.observeField("state", FuncName(OnAnimationState))
    Animate(false)
end function

function AnimateOut()
    Animate(true)
end function

function Animate(reverse as boolean) as void
    
    if m.translationAnimationInterpolator.reverse = reverse and m.translationAnimation.control <> "none"
        return
    end if
    m.translationAnimationInterpolator.reverse = reverse
    m.translationAnimation.control = "start"
end function

function OnAnimationState()
    if m.translationAnimation.state = "stopped" and m.translationAnimationInterpolator.reverse = true
        m.top.getParent().removeChild(m.top)
    end if
end function