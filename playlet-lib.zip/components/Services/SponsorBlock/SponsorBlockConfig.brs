'import "pkg:/source/utils/ColorUtils.bs"
function __SponsorBlock_SponsorBlockConfig_method_new()
    
    m.config = StringUtils_ParseJsonSafe(ReadAsciiFile("libpkg:/config/sponsorblock_config.json5"))
end function
function __SponsorBlock_SponsorBlockConfig_method_GetServerAddress() as string
    if m.config = invalid
        return ""
    end if
    return ValidString(m.config.serverAddress)
end function
function __SponsorBlock_SponsorBlockConfig_method_GetCategories() as object
    if m.config = invalid
        return []
    end if
    return ValidArray(m.config.categoryList)
end function
function __SponsorBlock_SponsorBlockConfig_method_GetOptionsForCategory(category as string) as object
    if m.config = invalid
        return []
    end if
    if not m.config.categories.doesexist(category)
        return []
    end if
    return ValidArray(m.config.categories[category].options)
end function
function __SponsorBlock_SponsorBlockConfig_method_SegmentColor(category as string) as integer
    if m.config = invalid
        return 0
    end if
    if not m.config.categories.doesexist(category)
        return 0
    end if
    color = m.config.categories[category].color
    return ColorUtils_HexToInt(color)
end function
function __SponsorBlock_SponsorBlockConfig_method_SegmentTitle(category as string) as string
    if m.config = invalid
        return category
    end if
    if not m.config.categories.doesexist(category)
        return category
    end if
    return m.config.categories[category].title
end function
function __SponsorBlock_SponsorBlockConfig_method_SegmentShortTitle(category as string) as string
    if m.config = invalid
        return category
    end if
    if not m.config.categories.doesexist(category)
        return category
    end if
    return m.config.categories[category].short_title
end function
function __SponsorBlock_SponsorBlockConfig_builder()
    instance = {}
    instance.new = __SponsorBlock_SponsorBlockConfig_method_new
    instance.GetServerAddress = __SponsorBlock_SponsorBlockConfig_method_GetServerAddress
    instance.GetCategories = __SponsorBlock_SponsorBlockConfig_method_GetCategories
    instance.GetOptionsForCategory = __SponsorBlock_SponsorBlockConfig_method_GetOptionsForCategory
    instance.SegmentColor = __SponsorBlock_SponsorBlockConfig_method_SegmentColor
    instance.SegmentTitle = __SponsorBlock_SponsorBlockConfig_method_SegmentTitle
    instance.SegmentShortTitle = __SponsorBlock_SponsorBlockConfig_method_SegmentShortTitle
    return instance
end function
function SponsorBlock_SponsorBlockConfig()
    instance = __SponsorBlock_SponsorBlockConfig_builder()
    instance.new()
    return instance
end function