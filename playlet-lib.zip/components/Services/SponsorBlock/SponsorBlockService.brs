'import "pkg:/components/Services/SponsorBlock/SponsorBlockConfig.bs"
'import "pkg:/components/Services/SponsorBlock/SponsorBlockTimeline.types.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/CryptoUtils.bs"


function __SponsorBlock_SponsorBlockService_method_new(config as object)
    m.config = config
end function
function __SponsorBlock_SponsorBlockService_method_GetSkipSegmentsForVideo(videoId as string, cancellation = invalid as dynamic) as object
    serverAddress = m.config.GetServerAddress()
    if StringUtils_IsNullOrEmpty(serverAddress)
        return invalid
    end if
    
    categories = [
        "sponsor"
        "selfpromo"
        "interaction"
        "intro"
        "outro"
        "preview"
        "hook"
        "music_offtopic"
        "poi_highlight"
        "filler"
    ]
    
    actionTypes = [
        "skip"
        "mute"
        "poi"
    ]
    categoriesJson = FormatJson(categories).EncodeUriComponent()
    actionTypesJson = FormatJson(actionTypes).EncodeUriComponent()
    
    hashPrefix = CryptoUtils_GetSha256(videoId).Left(4)
    url = (bslib_toString(serverAddress) + bslib_toString("/api/skipSegments") + "/" + bslib_toString(hashPrefix) + "?categories=" + bslib_toString(categoriesJson) + "&actionTypes=" + bslib_toString(actionTypesJson))
    response = HttpClient_Get(url).Cancellation(cancellation).Await()
    if not response.IsSuccess()
        if response.IsCancelled()
            LogErrorNoTelemetry2("[SponsorBlockService.bs:34]", response.ErrorMessage())
        else if response.StatusCode() >= 500
            LogErrorNoTelemetry3("[SponsorBlockService.bs:36]", "SponsorBlock server error:", response.StatusCode())
        else
            LogError2("[SponsorBlockService.bs:38]", response.ErrorMessage())
        end if
        return invalid
    end if
    json = response.Json()
    if json = invalid
        return invalid
    end if
    for each item in json
        if item.videoId = videoId
            return item.segments
        end if
    end for
    return invalid
end function
function __SponsorBlock_SponsorBlockService_method_PostSegmentViewed(segmentId as string, cancellation = invalid as object) as void
    serverAddress = m.config.GetServerAddress()
    if StringUtils_IsNullOrEmpty(serverAddress)
        return
    end if
    url = (bslib_toString(serverAddress) + bslib_toString("/api/viewedVideoSponsorTime") + "?UUID=" + bslib_toString(segmentId))
    HttpClient_Post(url).Cancellation(cancellation).Await()
end function
function __SponsorBlock_SponsorBlockService_method_GenerateProgressBarBackground(segments as object, timeline as object, lengthSeconds as integer, path as string)
    
    bar = CreateObject("roBitmap", {
        width: 1144
        height: 20
        AlphaEnable: true
    })
    bar.Clear(&hFFFFFF80)
    starts = timeline.starts
    ends = timeline.ends
    segmentIndexes = timeline.segmentIndexes
    for i = 0 to starts.Count() - 1
        m.DrawSegment(bar, segments[segmentIndexes[i]], starts[i], ends[i], lengthSeconds)
    end for
    
    for each segment in segments
        if segment.start = segment.end
            m.DrawSegment(bar, segment, segment.start, segment.end, lengthSeconds)
        end if
    end for
    bar.Finish()
    buffer = bar.GetPng(0, 0, bar.GetWidth(), bar.GetHeight())
    buffer.WriteFile(path)
end function
function __SponsorBlock_SponsorBlockService_method_DrawSegment(bar as object, segment as object, startSeconds as float, endSeconds as float, lengthSeconds as integer) as void
    videoDuration = lengthSeconds
    if videoDuration = 0 or videoDuration = invalid
        
        videoDuration = segment.videoDuration
    end if
    if videoDuration = 0 or videoDuration = invalid
        return
    end if
    
    width = bar.GetWidth()
    pixelStart = Int((startSeconds / videoDuration) * width)
    pixelEnd = Int((endSeconds / videoDuration) * width)
    
    if startSeconds = endSeconds
        pixelEnd += 5
    end if
    bar.DrawRect(pixelStart, 0, pixelEnd - pixelStart, bar.GetHeight(), m.config.SegmentColor(segment.category))
end function
function __SponsorBlock_SponsorBlockService_builder()
    instance = {}
    instance.new = __SponsorBlock_SponsorBlockService_method_new
    instance.GetSkipSegmentsForVideo = __SponsorBlock_SponsorBlockService_method_GetSkipSegmentsForVideo
    instance.PostSegmentViewed = __SponsorBlock_SponsorBlockService_method_PostSegmentViewed
    instance.GenerateProgressBarBackground = __SponsorBlock_SponsorBlockService_method_GenerateProgressBarBackground
    instance.DrawSegment = __SponsorBlock_SponsorBlockService_method_DrawSegment
    return instance
end function
function SponsorBlock_SponsorBlockService(config as object)
    instance = __SponsorBlock_SponsorBlockService_builder()
    instance.new(config)
    return instance
end function