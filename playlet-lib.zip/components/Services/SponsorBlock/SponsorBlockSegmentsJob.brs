'import "pkg:/components/Services/SponsorBlock/SponsorBlockConfig.bs"
'import "pkg:/components/Services/SponsorBlock/SponsorBlockService.bs"
'import "pkg:/components/Services/SponsorBlock/SponsorBlockTimeline.bs"
'import "pkg:/components/VideoPlayer/SponsorBlockSegmentAction.bs"
'import "pkg:/source/utils/Types.bs"

function ExecuteJob() as void
    input = JobGetInput()
    videoId = input.videoId
    lengthSeconds = input.lengthSeconds
    showNotifications = input.showNotifications
    categories = input.categories
    config = SponsorBlock_SponsorBlockConfig()
    service = SponsorBlock_SponsorBlockService(config)
    cancellation = JobGetCancellation()
    skipSegments = service.GetSkipSegmentsForVideo(videoId, cancellation)
    skipSegments = ProcessSkipSegments(skipSegments, showNotifications, categories, config)
    barPath = invalid
    timeline = invalid
    if skipSegments <> invalid
        barDir = "tmp:/sponsorblock"
        fs = CreateObject("roFileSystem")
        fs.Delete(barDir)
        fs.CreateDirectory(barDir)
        
        barPath = (bslib_toString(barDir) + "/" + bslib_toString(videoId) + ".png")
        service.GenerateProgressBarBackground(skipSegments, SponsorBlock_BuildTimeline(skipSegments), lengthSeconds, barPath)
        
        skipSegments = PadHightlightSegment(skipSegments, lengthSeconds)
        timeline = SponsorBlock_BuildTimeline(skipSegments)
    end if
    JobSuccessData({
        videoId: videoId
        skipSegments: skipSegments
        timeline: timeline
        barPath: barPath
    })
end function

function ProcessSkipSegments(skipSegments as object, showNotifications as boolean, categories as object, config as object) as object
    if skipSegments = invalid
        return invalid
    end if
    processedSegments = []
    for each segment in skipSegments
        
        if ValidInt(segment.votes) < -1
            continue for
        end if
        option = GetOptionForSegment(segment, categories)
        if option = "disable"
            continue for
        end if
        segment.option = option
        segment.showNotification = showNotifications and ShouldShowNotification(segment, categories)
        if segment.showNotification
            if option = "auto_skip"
                segment.actionText = Tr("Skipped")
            else if option = "manual_skip"
                segment.actionText = Tr("Press OK to skip")
            else
                segment.actionText = ""
            end if
        end if
        segmentRange = segment["segment"]
        segmentStart = segmentRange[0]
        segmentEnd = segmentRange[1]
        segment.Delete("segment")
        segment.start = segmentStart
        segment.end = segmentEnd
        segment.title = Tr(ValidString(config.SegmentTitle(segment.category)))
        segment.shortTitle = Tr(ValidString(config.SegmentShortTitle(segment.category)))
        processedSegments.push(segment)
    end for
    return processedSegments
end function

function GetOptionForSegment(segment as object, categories as object) as string
    category = categories[segment.category]
    if not IsAssociativeArray(category)
        return "disable"
    end if
    option = category.option
    if StringUtils_IsNullOrEmpty(option)
        option = "disable"
    end if
    return option
end function

function ShouldShowNotification(segment as object, categories as object) as boolean
    option = GetOptionForSegment(segment, categories)
    return option = "auto_skip" or option = "manual_skip"
end function

function PadHightlightSegment(skipSegments as object, lengthSeconds as integer) as object
    if skipSegments = invalid
        return invalid
    end if
    for each segment in skipSegments
        if not segment.category = "poi_highlight"
            continue for
        end if
        segmentPaddedDuration = 5
        if lengthSeconds > 0
            if lengthSeconds < 120
                segmentPaddedDuration = 1
            else if lengthSeconds < 300
                segmentPaddedDuration = 2
            else if lengthSeconds < 900
                segmentPaddedDuration = 5
            else
                segmentPaddedDuration = 10
            end if
        end if
        segmentDuration = Abs(segment.end - segment.start)
        padding = Abs(segmentPaddedDuration - segmentDuration) / 2
        segment.start = segment.start - padding
        segment.end = segment.end + padding
    end for
    return skipSegments
end function