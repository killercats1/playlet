'import "pkg:/components/Services/SponsorBlock/SponsorBlockConfig.bs"
'import "pkg:/components/Services/SponsorBlock/SponsorBlockService.bs"

function ExecuteJob()
    input = JobGetInput()
    segmentId = input.segmentId
    service = SponsorBlock_SponsorBlockService(SponsorBlock_SponsorBlockConfig())
    service.PostSegmentViewed(segmentId, m.top.cancellation)
end function