'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.bs"
'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/Services/Innertube/InnertubeService.bs"
'import "pkg:/components/Services/Innertube/LiveStreamInfo.bs"
'import "pkg:/components/VideoFeed/PaginationType.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/CryptoUtils.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/OptionUtils.bs"
'import "pkg:/source/utils/OptionUtils.bs"
'import "pkg:/source/utils/RegistryUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/TimeUtils.bs"















 '2 years

function __Invidious_InvidiousService_method_new(invidiousNode as object)
    m.invidiousNode = invalid
    m.invidiousNode = invidiousNode
end function
function __Invidious_InvidiousService_method_GetUserCountryCode() as string
    if m._userCountryCode = invalid
        m._userCountryCode = m.invidiousNode.applicationInfo.callfunc("GetUserCountryCode", invalid)
        
        if ValidString(m._userCountryCode) = "OT"
            m._userCountryCode = "US"
        end if
    end if
    return m._userCountryCode
end function
function __Invidious_InvidiousService_method_GetAuthenticationHeaders(token as string) as object
    return {
        "Authorization": ("Bearer " + bslib_toString(token))
    }
end function
function __Invidious_InvidiousService_method_GetCurrentProfile() as object
    if m.profilesService = invalid
        m.profilesService = m.invidiousNode.profilesService
    end if
    if m.profilesService = invalid
        return invalid
    end if
    return m.profilesService.currentProfile
end function
function __Invidious_InvidiousService_method_GetInstance() as string
    if m.preferences = invalid
        m.preferences = m.invidiousNode.preferences
    end if
    backend = m.preferences["backend.selected"]
    if backend = "invidious"
        instance = m.GetInvidiousInstance()
        if not StringUtils_IsNullOrEmpty(instance)
            return instance
        end if
    end if
    return "http://127.0.0.1:8888/playlet-invidious-backend"
end function
function __Invidious_InvidiousService_method_GetInvidiousInstance() as string
    if m.preferences = invalid
        m.preferences = m.invidiousNode.preferences
    end if
    return m.preferences["invidious.instance"]
end function
function __Invidious_InvidiousService_method_MarkVideoWatched(auth as object, videoId as dynamic, cancellation = invalid as object) as void
    if StringUtils_IsNullOrEmpty(videoId) or auth = invalid or auth.state <> "Ok"
        return
    end if
    url = (bslib_toString(auth.serverUrl) + bslib_toString("/api/v1/auth/history") + "/" + bslib_toString(videoId))
    request = HttpClient_Post(url)
    request.Headers(m.GetAuthenticationHeaders(auth.token))
    request.Cancellation(cancellation)
    response = request.Await()
    m.MarkNeedsReauthIfCredentialsRejected(response, auth.profile)
end function
function __Invidious_InvidiousService_method_SearchSuggestions(q as string, cancellation = invalid as object) as object
    instance = m.GetInstance()
    url = (bslib_toString(instance) + bslib_toString("/api/v1/search/suggestions"))
    request = HttpClient_Get(url)
    request.QueryParam("region", m.GetUserCountryCode())
    request.QueryParam("q", q)
    request.CacheForSeconds(60 * 60 * 24)
    request.Cancellation(cancellation)
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    return response.Json()
end function
function __Invidious_InvidiousService_method_GetVideoMetadata(videoId as string, options = invalid as object) as object
    cancellation = OptionUtils_Get(options, "cancellation")
    retryCount = OptionUtils_GetOrDefault(options, "retryCount", 1)
    instance = m.GetInstance()
    url = (bslib_toString(instance) + bslib_toString("/api/v1/videos") + "/" + bslib_toString(videoId))
    request = HttpClient_Get(url)
    request.Cancellation(cancellation)
    request.RetryCount(retryCount)
    
    request.RetryIf(function(response as object) as string
        errorMessage = response.ErrorMessage()
        if response.StatusCode() = -1 and errorMessage.InStr("HTTP/0.9") <> -1
            return errorMessage
        end if
        return ""
    end function)
    response = request.Await()
    if not response.IsSuccess()
        return {
            error: response.ErrorMessage()
        }
    end if
    metadata = response.Json()
    if not IsAssociativeArray(metadata)
        return metadata
    end if
    
    if StringUtils_IsNullOrEmpty(metadata["parser"])
        metadata["parser"] = "invidious"
    end if
    
    if Invidious_NeedsLiveStreamInfo(metadata)
        Innertube_GetLiveStreamInfo(metadata, metadata.adaptiveFormats, 0, invalid, cancellation)
    end if
    return metadata
end function
function __Invidious_InvidiousService_method_GetPlaylist(playlistId as string, index = 0 as integer, continuation = "" as string, cancellation = invalid as object) as object
    profile = m.GetCurrentProfile()
    auth = invalid
    if profile <> invalid
        auth = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(profile)
    end if
    isAuthenticatedRequest = auth <> invalid and auth.state = "Ok"
    if isAuthenticatedRequest
        url = (bslib_toString(auth.serverUrl) + bslib_toString("/api/v1/auth/playlists") + "/" + bslib_toString(playlistId))
        request = HttpClient_Get(url)
        request.Headers(m.GetAuthenticationHeaders(auth.token))
        if not StringUtils_IsNullOrEmpty(auth.activeIdentifyToken)
            request.QueryParam("activeIdentifyToken", auth.activeIdentifyToken)
        end if
    else
        instance = m.GetInstance()
        url = (bslib_toString(instance) + bslib_toString("/api/v1/playlists") + "/" + bslib_toString(playlistId))
        request = HttpClient_Get(url)
    end if
    if continuation <> ""
        request.QueryParam("continuation", continuation)
    else
        request.QueryParam("index", index)
    end if
    request.Cancellation(cancellation)
    response = request.Await()
    if isAuthenticatedRequest
        m.MarkNeedsReauthIfCredentialsRejected(response, auth.profile)
    end if
    return response
end function
function __Invidious_InvidiousService_method_GetChannel(authorId as string, cancellation = invalid as object) as object
    instance = m.GetInstance()
    url = (bslib_toString(instance) + bslib_toString("/api/v1/channels") + "/" + bslib_toString(authorId))
    request = HttpClient_Get(url)
    request.Cancellation(cancellation)
    request.CacheForSeconds(60 * 60 * 24) 
    request.RetryCount(2)
    return request.Await()
end function
function __Invidious_InvidiousService_method_MarkFeedPagination(feedContentNode as object) as object
    feedSources = feedContentNode.feedSources
    feedSourcesIndex = feedContentNode.feedSourcesIndex
    feedSource = feedSources[feedSourcesIndex]
    if m.endpoints = invalid
        m.endpoints = m.invidiousNode.apiDefinitions
    end if
    endpoint = m.endpoints[feedSource.endpoint]
    if endpoint = invalid or StringUtils_IsNullOrEmpty(endpoint.paginationType)
        return feedSource
    end if
    feedSourceState = feedSource.state
    if not feedSourceState.DoesExist("queryParams")
        feedSourceState["queryParams"] = {}
    end if
    feedSourceState.paginationType = endpoint.paginationType
    continuation = feedSourceState.continuation
    hasContinuation = not StringUtils_IsNullOrEmpty(continuation)
    if not hasContinuation
        feedSourceState.queryParams.Delete("continuation")
    end if
    if feedSourceState.paginationType = "Continuation" or hasContinuation
        if hasContinuation
            feedSourceState.queryParams.continuation = continuation
        end if
        feedSourceState.queryParams.Delete("page")
    else if feedSourceState.paginationType = "Pages"
        if not IsInt(feedSourceState.page)
            feedSourceState.page = 0
        end if
        feedSourceState.page += 1
        feedSourceState.queryParams.page = feedSourceState.page
    end if
    feedSource.state = feedSourceState
    feedSources[feedSourcesIndex] = feedSource
    feedContentNode.feedSources = feedSources
    return feedSource
end function
function __Invidious_InvidiousService_method_MakeRequest(feedSource as object, options = invalid as dynamic) as object
    additionalQueryParams = OptionUtils_Get(options, "additionalQueryParams")
    cancellation = OptionUtils_Get(options, "cancellation")
    httpServer = OptionUtils_Get(options, "httpServer")
    if m.endpoints = invalid
        m.endpoints = m.invidiousNode.apiDefinitions
    end if
    endpoint = m.endpoints[feedSource.endpoint]
    if endpoint = invalid
        return {
            success: false
            error: ("Endpoint " + bslib_toString(feedSource.endpoint) + " not found")
        }
    end if
    profile = invalid
    if endpoint.authenticated = true
        profile = m.GetCurrentProfile()
        auth = invalid
        if profile <> invalid
            auth = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(profile)
        end if
        if auth = invalid or auth.state <> "Ok"
            return {
                success: false
                error: "Not authenticated"
            }
        end if
        request = HttpClient_Get(auth.serverUrl + endpoint.url)
        request.Headers(m.GetAuthenticationHeaders(auth.token))
        if not StringUtils_IsNullOrEmpty(auth.activeIdentifyToken)
            request.QueryParam("activeIdentifyToken", auth.activeIdentifyToken)
        end if
    else
        request = HttpClient_Get(m.GetInstance() + endpoint.url)
    end if
    if endpoint.queryParams <> invalid
        for each queryParamKey in endpoint.queryParams
            queryParam = endpoint.queryParams[queryParamKey]
            if queryParam.default <> invalid
                if IsString(queryParam.type) and queryParam.type = "#ISO3166"
                    if queryParam.default = "GetUserCountryCode"
                        request.QueryParam(queryParamKey, m.GetUserCountryCode())
                    else
                        request.QueryParam(queryParamKey, queryParam.default)
                    end if
                else if IsArray(queryParam.default) and queryParam.arrayType <> invalid
                    request.QueryParamArray(queryParamKey, queryParam.default, queryParam.arrayType)
                else
                    request.QueryParam(queryParamKey, queryParam.default)
                end if
            end if
        end for
    end if
    if feedSource.cacheSeconds <> invalid
        request.CacheForSeconds(feedSource.cacheSeconds)
    else if endpoint.cacheSeconds <> invalid
        request.CacheForSeconds(endpoint.cacheSeconds)
    end if
    if feedSource.tryCount <> invalid
        request.RetryCount(feedSource.tryCount - 1)
    else if endpoint.tryCount <> invalid
        request.RetryCount(endpoint.tryCount - 1)
    end if
    if feedSource.queryParams <> invalid
        request.QueryParams(feedSource.queryParams)
    end if
    if additionalQueryParams <> invalid
        request.QueryParams(additionalQueryParams)
    end if
    if feedSource.pathParams <> invalid
        request.PathParams(feedSource.pathParams)
    end if
    request.Cancellation(cancellation)
    response = m.SendRequest(request, httpServer)
    responseHandler = invalid
    if IsString(endpoint.responseHandler) and m.DoesExist(endpoint.responseHandler)
        responseHandler = endpoint.responseHandler
    else
        responseHandler = "DefaultHandler"
    end if
    result = m[responseHandler]({
        feedSource: feedSource
        response: response
        profile: profile
    })
    if result <> invalid
        return {
            success: true
            result: result
        }
    else
        return {
            success: false
            error: response.ErrorMessage()
            cancelled: response.IsCancelled()
        }
    end if
end function
function __Invidious_InvidiousService_method_SendRequest(request as object, httpServer as dynamic) as object
    if httpServer = invalid
        return request.Await()
    end if
    url = request.GetFullUrl()
    isUrlToLocalServer = url.StartsWith("http://127.0.0.1:8888") or url.StartsWith(m.invidiousNode.webServer.callfunc("GetServerAddress", invalid))
    if not isUrlToLocalServer
        return request.Await()
    end if
    parsedUrl = UrlUtils_ParseUrl(url)
    responseObj = httpServer.ProcessRequestLocal(request.GetMethod(), parsedUrl.path, request.GetHeaders(), ValidString(request.GetTextBody()))
    body = ""
    if responseObj.body <> invalid
        body = responseObj.body.ToAsciiString()
    end if
    return HttpClient_Response({
        statusCode: responseObj.http_code
        headers: responseObj.headers
        text: body
    })
end function
function __Invidious_InvidiousService_method_DefaultHandler(context as object) as object
    response = context.response
    if not response.IsSuccess()
        return invalid
    end if
    json = response.Json()
    if json = invalid
        return invalid
    end if
    if IsArray(json)
        json = {
            items: json
        }
    end if
    return json
end function
function __Invidious_InvidiousService_method_PlaylistHandler(context as object) as object
    response = context.response
    if not response.IsSuccess()
        
        return {
            isLastPage: true
            items: [
                {
                    "type": "playlist"
                    "playlistId": context.feedSource.pathParams.plid
                    "title": "[Playlist not found]"
                }
            ]
        }
    end if
    json = response.Json()
    if json = invalid
        return invalid
    end if
    result = {
        items: json.videos
    }
    if json.continuation <> invalid
        result.continuation = json.continuation
    end if
    return result
end function
function __Invidious_InvidiousService_method_PlaylistVideosHandler(context as object) as object
    response = context.response
    if not response.IsSuccess()
        return invalid
    end if
    json = response.Json()
    if not IsAssociativeArray(json)
        return invalid
    end if
    result = {
        items: ValidArray(json.videos)
    }
    if json.continuation <> invalid
        result.continuation = json.continuation
    end if
    return result
end function
function __Invidious_InvidiousService_method_ChannelVideosHandler(context as object) as object
    response = context.response
    if not response.IsSuccess()
        
        return {
            isLastPage: true
            items: [
                {
                    "type": "video"
                    "videoId": "-----------"
                    "title": "[Channel videos not found]"
                }
            ]
        }
    end if
    json = response.Json()
    if json = invalid
        return invalid
    end if
    return {
        items: json.videos
        continuation: json.continuation
        sortOptions: json.sortOptions
    }
end function
function __Invidious_InvidiousService_method_ChannelPlaylistsHandler(context as object) as object
    response = context.response
    if not response.IsSuccess()
        return invalid
    end if
    json = response.Json()
    if json = invalid
        json = {
            playlists: []
        }
    end if
    return {
        items: json.playlists
        continuation: json.continuation
        sortOptions: json.sortOptions
    }
end function
function __Invidious_InvidiousService_method_VideoInfoHandler(context as object) as object
    response = context.response
    if not response.IsSuccess()
        
        return {
            items: [
                {
                    "type": "video"
                    "videoId": context.feedSource.pathParams.id
                    "title": "[Video not available]"
                }
            ]
        }
    end if
    json = response.Json()
    if json = invalid
        return invalid
    end if
    json.type = "video"
    return {
        items: [
            json
        ]
    }
end function
function __Invidious_InvidiousService_method_PlaylistInfoHandler(context as object) as object
    response = context.response
    if not response.IsSuccess()
        
        return {
            items: [
                {
                    "type": "playlist"
                    "playlistId": context.feedSource.pathParams.plid
                    "title": "[Playlist not found]"
                }
            ]
        }
    end if
    json = response.Json()
    if json = invalid
        return invalid
    end if
    json.type = "playlist"
    
    json.Delete("videos")
    return {
        items: [
            json
        ]
    }
end function
function __Invidious_InvidiousService_method_ChannelInfoHandler(context as object) as object
    response = context.response
    if not response.IsSuccess()
        
        return {
            items: [
                {
                    "type": "channel"
                    "authorId": context.feedSource.pathParams.ucid
                    "author": "[Channel not found]"
                }
            ]
        }
    end if
    json = response.Json()
    if json = invalid
        return invalid
    end if
    json.type = "channel"
    return {
        items: [
            json
        ]
    }
end function
function __Invidious_InvidiousService_method_AuthFeedHandler(context as object) as object
    response = context.response
    m.MarkNeedsReauthIfCredentialsRejected(response, context.profile)
    if not response.IsSuccess()
        return invalid
    end if
    json = response.Json()
    if json = invalid
        return invalid
    end if
    videos = []
    if IsArray(json.notifications)
        videos.Append(json.notifications)
    end if
    if IsArray(json.videos)
        videos.Append(json.videos)
    end if
    result = {
        items: videos
    }
    if json.continuation <> invalid
        result.continuation = json.continuation
    end if
    return result
end function
function __Invidious_InvidiousService_method_WatchHistoryHandler(context as object) as object
    response = context.response
    m.MarkNeedsReauthIfCredentialsRejected(response, context.profile)
    if not response.IsSuccess()
        return invalid
    end if
    json = response.Json()
    if IsArray(json)
        videos = []
        if json.Count() = 0
            return {
                items: videos
            }
        end if
        videoDictionary = {}
        videosMetadata = InnertubeService_GetVideoInfoBatched(json)
        if not StringUtils_IsNullOrEmpty(videosMetadata.error)
            LogError3("[InvidiousService.bs:670]", "Failed to load video metadata", videosMetadata.error)
        else
            for each video in videosMetadata.videos
                videoDictionary[video.videoId] = video
            end for
        end if
        for each videoId in json
            video = videoDictionary[videoId]
            if video = invalid
                video = {
                    "type": "video"
                    "videoId": videoId
                    "videoThumbnails": [
                        {
                            "quality": "medium"
                            "url": ("https://i.ytimg.com/vi/" + bslib_toString(videoId) + "/mqdefault.jpg")
                            "width": 320
                            "height": 180
                        }
                    ]
                }
            end if
            videos.push(video)
        end for
        json = {
            items: videos
        }
    end if
    return json
end function
function __Invidious_InvidiousService_method_MarkNeedsReauthIfCredentialsRejected(response as object, profile as object) as void
    if response.StatusCode() <> 403
        return
    end if
    body = response.Text()
    LogWarn2("[InvidiousService.bs:709]", ("Invidious instance responded with 403: " + bslib_toString(body)))
    if profile = invalid or profile.type <> "invidious"
        return
    end if
    
    if body.InStr("Request must be authenticated") <> -1 or body.InStr("Invalid signature") <> -1 or body.InStr("Erroneous token") <> -1 or body.InStr("Token is expired") <> -1
        profile.callfunc("MarkNeedsReauth", invalid)
    end if
end function
function __Invidious_InvidiousService_method_VerifyTokenScope(token as string) as boolean
    tokenObject = StringUtils_ParseJsonSafe(token)
    if tokenObject = invalid
        LogWarn3("[InvidiousService.bs:724]", "Failed to json parse token:", token)
        return false
    end if
    if not IsArray(tokenObject.scopes)
        LogWarn3("[InvidiousService.bs:728]", "Token scopes are not an array:", tokenObject.scopes)
        return false
    end if
    scopes = tokenObject.scopes.join(",")
    expectedScopes = "GET:feed,GET:playlists*,POST:tokens/*,:history*,:subscriptions*"
    validScopes = expectedScopes = scopes
    if not validScopes
        LogWarn2("[InvidiousService.bs:737]", ("Token scopes do not match expected scopes. Expected: " + chr(34) + bslib_toString(expectedScopes) + chr(34) + ", got: " + chr(34) + bslib_toString(scopes) + chr(34)))
    end if
    return validScopes
end function
function __Invidious_InvidiousService_method_UnregisterToken(instance as string, token as string) as object
    url = (bslib_toString(instance) + bslib_toString("/api/v1/auth/tokens/unregister"))
    request = HttpClient_Post(url).TextBody(token)
    request.Headers(m.GetAuthenticationHeaders(token))
    request.Header("Content-Type", "application/json")
    return request.Await()
end function
function __Invidious_InvidiousService_method_GetAuthorizeTokenLink(serverUrl as string, loginNonce as string) as dynamic
    instance = serverUrl
    if StringUtils_IsNullOrEmpty(instance)
        instance = m.GetInvidiousInstance()
    end if
    if StringUtils_IsNullOrEmpty(instance)
        return invalid
    end if
    
    invidiousHost = instance.Replace("https://", "http://")
    address = m.invidiousNode.webServer.callfunc("GetServerAddress", invalid)
    if address = invalid
        return invalid
    end if
    expire = TimeUtils_Now().AsSeconds() + (60 * 60 * 24 * 365 * 2)
    callbackUrl = (bslib_toString(address) + bslib_toString("/invidious/token_callback") + "?ref=" + bslib_toString(instance) + "&nonce=" + bslib_toString(loginNonce)).EncodeUriComponent()
    scope = (bslib_toString("GET:feed,GET:playlists*,POST:tokens/*,:history*,:subscriptions*")).EncodeUriComponent()
    return (bslib_toString(invidiousHost) + "/authorize_token?scopes=" + bslib_toString(scope) + "&callback_url=" + bslib_toString(callbackUrl) + "&expire=" + bslib_toString(expire))
end function
function __Invidious_InvidiousService_method_GetSubscriptions(auth as object, cancellation = invalid as object) as object
    url = (bslib_toString(auth.serverUrl) + bslib_toString("/api/v1/auth/subscriptions"))
    request = HttpClient_Get(url)
    request.Headers(m.GetAuthenticationHeaders(auth.token))
    request.Cancellation(cancellation)
    response = request.Await()
    m.MarkNeedsReauthIfCredentialsRejected(response, auth.profile)
    return response
end function
function __Invidious_InvidiousService_method_Subscribe(auth as object, channelId as string, cancellation = invalid as object) as object
    url = (bslib_toString(auth.serverUrl) + bslib_toString("/api/v1/auth/subscriptions") + "/" + bslib_toString(channelId))
    request = HttpClient_Post(url)
    if not StringUtils_IsNullOrEmpty(auth.activeIdentifyToken)
        request.QueryParam("activeIdentifyToken", auth.activeIdentifyToken)
    end if
    request.Headers(m.GetAuthenticationHeaders(auth.token))
    request.Cancellation(cancellation)
    response = request.Await()
    m.MarkNeedsReauthIfCredentialsRejected(response, auth.profile)
    return response
end function
function __Invidious_InvidiousService_method_Unsubscribe(auth as object, channelId as string, cancellation = invalid as object) as object
    url = (bslib_toString(auth.serverUrl) + bslib_toString("/api/v1/auth/subscriptions") + "/" + bslib_toString(channelId))
    request = HttpClient_Delete(url)
    if not StringUtils_IsNullOrEmpty(auth.activeIdentifyToken)
        request.QueryParam("activeIdentifyToken", auth.activeIdentifyToken)
    end if
    request.Headers(m.GetAuthenticationHeaders(auth.token))
    request.Cancellation(cancellation)
    response = request.Await()
    m.MarkNeedsReauthIfCredentialsRejected(response, auth.profile)
    return response
end function
function __Invidious_InvidiousService_builder()
    instance = {}
    instance.new = __Invidious_InvidiousService_method_new
    instance.GetUserCountryCode = __Invidious_InvidiousService_method_GetUserCountryCode
    instance.GetAuthenticationHeaders = __Invidious_InvidiousService_method_GetAuthenticationHeaders
    instance.GetCurrentProfile = __Invidious_InvidiousService_method_GetCurrentProfile
    instance.GetInstance = __Invidious_InvidiousService_method_GetInstance
    instance.GetInvidiousInstance = __Invidious_InvidiousService_method_GetInvidiousInstance
    instance.MarkVideoWatched = __Invidious_InvidiousService_method_MarkVideoWatched
    instance.SearchSuggestions = __Invidious_InvidiousService_method_SearchSuggestions
    instance.GetVideoMetadata = __Invidious_InvidiousService_method_GetVideoMetadata
    instance.GetPlaylist = __Invidious_InvidiousService_method_GetPlaylist
    instance.GetChannel = __Invidious_InvidiousService_method_GetChannel
    instance.MarkFeedPagination = __Invidious_InvidiousService_method_MarkFeedPagination
    instance.MakeRequest = __Invidious_InvidiousService_method_MakeRequest
    instance.SendRequest = __Invidious_InvidiousService_method_SendRequest
    instance.DefaultHandler = __Invidious_InvidiousService_method_DefaultHandler
    instance.PlaylistHandler = __Invidious_InvidiousService_method_PlaylistHandler
    ' Like PlaylistHandler, but a failure is an error (the row is dropped) instead of a "[Playlist not found]" tile.
    instance.PlaylistVideosHandler = __Invidious_InvidiousService_method_PlaylistVideosHandler
    instance.ChannelVideosHandler = __Invidious_InvidiousService_method_ChannelVideosHandler
    instance.ChannelPlaylistsHandler = __Invidious_InvidiousService_method_ChannelPlaylistsHandler
    instance.VideoInfoHandler = __Invidious_InvidiousService_method_VideoInfoHandler
    instance.PlaylistInfoHandler = __Invidious_InvidiousService_method_PlaylistInfoHandler
    instance.ChannelInfoHandler = __Invidious_InvidiousService_method_ChannelInfoHandler
    instance.AuthFeedHandler = __Invidious_InvidiousService_method_AuthFeedHandler
    instance.WatchHistoryHandler = __Invidious_InvidiousService_method_WatchHistoryHandler
    instance.MarkNeedsReauthIfCredentialsRejected = __Invidious_InvidiousService_method_MarkNeedsReauthIfCredentialsRejected
    instance.VerifyTokenScope = __Invidious_InvidiousService_method_VerifyTokenScope
    instance.UnregisterToken = __Invidious_InvidiousService_method_UnregisterToken
    instance.GetAuthorizeTokenLink = __Invidious_InvidiousService_method_GetAuthorizeTokenLink
    instance.GetSubscriptions = __Invidious_InvidiousService_method_GetSubscriptions
    instance.Subscribe = __Invidious_InvidiousService_method_Subscribe
    instance.Unsubscribe = __Invidious_InvidiousService_method_Unsubscribe
    return instance
end function
function Invidious_InvidiousService(invidiousNode as object)
    instance = __Invidious_InvidiousService_builder()
    instance.new(invidiousNode)
    return instance
end function

' Whether a /videos response is a live video still missing the live timeline the
' innertube path gets: the built-in instance's responses carry it already.
function Invidious_NeedsLiveStreamInfo(metadata as object) as boolean
    return ValidBool(metadata.liveNow) and IsArray(metadata.adaptiveFormats) and StringUtils_IsNullOrEmpty(metadata.liveHeadUrl)
end function