'import "InvidiousService.bs"

function Init()
    m.top.apiDefinitions = StringUtils_ParseJsonSafe(ReadAsciiFile("libpkg:/config/invidious_video_api.yaml"))
    m.service = Invidious_InvidiousService(m.top)
end function

function GetInstance(_unused as dynamic) as string
    return m.service.GetInstance()
end function

function GetInvidiousInstance(_unused as dynamic) as string
    return m.service.GetInvidiousInstance()
end function