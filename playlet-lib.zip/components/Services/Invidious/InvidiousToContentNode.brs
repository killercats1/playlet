'import "pkg:/components/VideoFeed/FeedLoadState.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/LocaleUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/TimeUtils.bs"
function InvidiousContent_ToRowCellContentNode(item as object, instance as dynamic) as object
    if item.playlistId <> invalid and (item.type = invalid or item.type = "invidiousPlaylist")
        item.type = "playlist"
    end if
    if item.videoId <> invalid and (item.type = invalid or item.type = "shortVideo")
        item.type = "video"
    end if
    if item.type <> "video" and item.type <> "playlist" and item.type <> "channel"
        return invalid
    end if
    if item.type = "video"
        return InvidiousContent_ToVideoContentNode(invalid, item, instance)
    else if item.type = "playlist"
        return InvidiousContent_ToPlaylistContentNode(invalid, item, instance)
    else if item.type = "channel"
        return InvidiousContent_ToChannelContentNode(invalid, item)
    else
        return invalid
    end if
end function

function InvidiousContent_ToVideoContentNode(node as object, item as object, instance as dynamic) as object
    if node = invalid
        node = CreateObject("roSGNode", "VideoContentNode")
    end if
    node.type = "video"
    
    InvidiousContent_SetIfExists(node, "_author", item, "author")
    InvidiousContent_SetIfExists(node, "authorId", item, "authorId")
    InvidiousContent_SetIfExists(node, "notInterestedToken", item, "notInterestedToken")
    InvidiousContent_SetIfExists(node, "dontRecommendChannelToken", item, "dontRecommendChannelToken")
    InvidiousContent_SetIfExists(node, "removeFromHistoryToken", item, "removeFromHistoryToken")
    InvidiousContent_SetIfExists(node, "lengthSeconds", item, "lengthSeconds")
    node.lengthText = InvidiousContent_VideoGetLengthText(item)
    node.liveNow = InvidiousContent_VideoIsLive(item)
    InvidiousContent_VideoSetPremiereTimestampText(node, item)
    node.publishedText = InvidiousContent_VideoGetPublishedText(item)
    InvidiousContent_VideoSetThumbnail(node, item, instance)
    InvidiousContent_SetIfExists(node, "title", item, "title")
    InvidiousContent_SetIfExists(node, "timestamp", item, "timestamp")
    InvidiousContent_SetIfExists(node, "id", item, "videoId")
    InvidiousContent_SetIfExists(node, "videoId", item, "videoId")
    node.viewCountText = InvidiousContent_VideoGetViewCountText(item)
    InvidiousContent_SetIfExists(node, "index", item, "index")
    InvidiousContent_SetIfExists(node, "lines", item, "lines")
    InvidiousContent_SetIfExists(node, "videoInfo", item, "videoInfo")
    InvidiousContent_SetIfExists(node, "percentDurationWatched", item, "percentDurationWatched")
    return node
end function

function InvidiousContent_ToPlaylistContentNode(node as object, item as object, instance as dynamic) as object
    if node = invalid
        node = CreateObject("roSGNode", "PlaylistContentNode")
        node.loadState = "None"
    end if
    node.type = "playlist"
    
    InvidiousContent_SetIfExists(node, "_author", item, "author")
    InvidiousContent_SetIfExists(node, "authorId", item, "authorId")
    InvidiousContent_SetIfExists(node, "description", item, "description")
    InvidiousContent_SetIfExists(node, "id", item, "playlistId")
    InvidiousContent_SetIfExists(node, "playlistId", item, "playlistId")
    InvidiousContent_SetIfExists(node, "videoId", item, "videoId")
    InvidiousContent_SetIfExists(node, "title", item, "title")
    InvidiousContent_SetIfExists(node, "videoCount", item, "videoCount")
    InvidiousContent_SetVideoCountText(item, node)
    InvidiousContent_SetIfExists(node, "viewCount", item, "viewCount")
    node.viewCountText = InvidiousContent_PlaylistGetViewCountText(item)
    InvidiousContent_SetIfExists(node, "updated", item, "updated")
    node.updatedText = InvidiousContent_PlaylistGetUpdatedText(item)
    InvidiousContent_SetIfExists(node, "statsText", item, "statsText")
    InvidiousContent_SetIfExists(node, "lines", item, "lines")
    if IsArray(item.videos) and item.videos.Count() > 0
        childCount = node.getChildCount()
        
        videosHasIndex = IsInt(item.videos[0].index)
        videoIds = invalid
        if not videosHasIndex
            videoIds = {}
            childVideos = node.getChildren(-1, 0)
            for each child in childVideos
                videoIds[child.videoId] = true
            end for
        end if
        newNodes = []
        for each video in item.videos
            
            if ValidString(video.type) = "playlist"
                continue for
            end if
            video.type = "video"
            videoNode = InvidiousContent_ToVideoContentNode(invalid, video, instance)
            if videoNode <> invalid
                if not videosHasIndex
                    if videoIds[video.videoId] = true
                        continue for
                    end if
                end if
                index = video.index
                if index <> invalid and index > -1 and index < childCount
                    node.replaceChild(videoNode, index)
                else
                    newNodes.push(videoNode)
                end if
            end if
        end for
        if newNodes.Count() > 0
            node.appendChildren(newNodes)
        end if
    end if
    InvidiousContent_PlaylistSetThumbnail(node, "thumbnail", item, instance)
    InvidiousContent_PlaylistSetThumbnail(node, "thumbnailBackground", item, instance, "maxres")
    node.continuation = ValidString(item.continuation)
    return node
end function

function InvidiousContent_ToChannelContentNode(node as object, item as object) as object
    if node = invalid
        node = CreateObject("roSGNode", "ChannelContentNode")
        node.loadState = "None"
    end if
    node.type = "channel"
    
    InvidiousContent_SetIfExists(node, "_author", item, "author")
    InvidiousContent_SetIfExists(node, "id", item, "authorId")
    InvidiousContent_SetIfExists(node, "authorId", item, "authorId")
    InvidiousContent_SetIfExists(node, "channelHandle", item, "channelHandle")
    InvidiousContent_SetIfExists(node, "description", item, "description")
    InvidiousContent_SetIfExists(node, "subCount", item, "subCount")
    InvidiousContent_SetIfExists(node, "authorSubTitle", item, "authorSubTitle")
    node.subCountText = InvidiousContent_GetChannelSubCountText(item)
    InvidiousContent_SetIfExists(node, "videoCount", item, "videoCount")
    InvidiousContent_SetVideoCountText(item, node)
    node.thumbnail = InvidiousContent_GetChannelThumbnail(item.authorThumbnails)
    node.banner = InvidiousContent_GetChannelBanner(item.authorBanners)
    
    InvidiousContent_SetIfExists(node, "tabsParams", item, "tabsParams")
    InvidiousContent_SetIfExists(node, "tabsTitles", item, "tabsTitles")
    InvidiousContent_SetIfExists(node, "tabs", item, "tabs")
    return node
end function

function InvidiousContent_SetIfExists(dst as object, dstField as string, src as object, srcField as string)
    if src.DoesExist(srcField)
        dst[dstField] = src[srcField]
    end if
end function

function InvidiousContent_VideoSetThumbnail(node as object, videoItem as object, instance as dynamic, quality = "medium" as string) as void
    videoThumbnails = videoItem.videoThumbnails
    hasValidInstance = not StringUtils_IsNullOrEmpty(instance) and instance.InStr(":8888/playlet-invidious-backend") = -1
    if videoThumbnails = invalid or videoThumbnails.Count() = 0
        if hasValidInstance
            node.thumbnail = (bslib_toString(instance) + "/vi/" + bslib_toString(videoItem.videoId) + "/mqdefault.jpg")
        else
            node.thumbnail = ("https://i.ytimg.com/vi/" + bslib_toString(videoItem.videoId) + "/mqdefault.jpg")
        end if
        return
    end if
    url = invalid
    for each thumbnail in videoThumbnails
        if thumbnail.quality = quality
            url = thumbnail.url
            exit for
        end if
    end for
    if url = invalid
        url = videoThumbnails[0].url
    end if
    if url.startsWith("/")
        if hasValidInstance
            url = instance + url
        else
            url = ("https://i.ytimg.com/vi/" + bslib_toString(videoItem.videoId) + "/mqdefault.jpg")
        end if
    end if
    node.thumbnail = url
end function

function InvidiousContent_VideoIsLive(videoItem as object) as boolean
    if videoItem.liveNow = true
        return true
    end if
    
    return videoItem.lengthSeconds = 0 and videoItem.viewCount = 0
end function

function InvidiousContent_VideoIsUpcoming(videoItem as object) as boolean
    return videoItem.isUpcoming = true
end function

function InvidiousContent_VideoSetPremiereTimestampText(node as object, videoItem as object) as void
    if InvidiousContent_VideoIsUpcoming(videoItem)
        node.isUpcoming = true
        timestamp = videoItem.premiereTimestamp
        if not IsInt(timestamp)
            node.premiereTimestampText = ""
            return
        end if
        currentTime = TimeUtils_Now().AsSeconds()
        timeLeft = timestamp - currentTime
        if timeLeft <= 0
            node.premiereTimestampText = Tr("Premiering now")
            return
        end if
        if timeLeft < 60
            if timeLeft = 1
                node.premiereTimestampText = Tr("Premieres in 1 second")
            else
                node.premiereTimestampText = Tr("Premieres in ^n seconds").Replace("^n", timeLeft.toStr())
            end if
            return
        end if
        if timeLeft < 3600
            minutes = timeLeft \ 60
            if minutes = 1
                node.premiereTimestampText = Tr("Premieres in 1 minute")
            else
                node.premiereTimestampText = Tr("Premieres in ^n minutes").Replace("^n", minutes.toStr())
            end if
            return
        end if
        if timeLeft < 86400
            hours = timeLeft \ 3600
            if hours = 1
                node.premiereTimestampText = Tr("Premieres in 1 hour")
            else
                node.premiereTimestampText = Tr("Premieres in ^n hours").Replace("^n", hours.toStr())
            end if
            return
        end if
        days = timeLeft \ 86400
        if days = 1
            node.premiereTimestampText = Tr("Premieres in 1 day")
        else
            node.premiereTimestampText = Tr("Premieres in ^n days").Replace("^n", days.toStr())
        end if
    end if
end function

function InvidiousContent_VideoGetViewCountText(videoItem as object) as string
    viewCountText = videoItem.viewCountText
    if not StringUtils_IsNullOrEmpty(viewCountText)
        return viewCountText
    end if
    viewCount = videoItem.viewCount
    if viewCount = invalid
        return ""
    end if
    return LocaleUtils_GetFormattedPluralString(viewCount, "0 views", "1 view", "^n views")
end function

function InvidiousContent_PlaylistSetThumbnail(node as object, nodeField as string, playlistItem as object, instance as dynamic, quality = "medium" as string) as void
    currentThumbnail = node[nodeField]
    if currentThumbnail <> "" and currentThumbnail <> "pkg:/images/thumbnail-missing.jpg"
        return
    end if
    thumbnail = ""
    hasValidInstance = not StringUtils_IsNullOrEmpty(instance) and instance.InStr(":8888/playlet-invidious-backend") = -1
    if IsString(playlistItem.playlistThumbnail)
        thumbnailUrl = playlistItem.playlistThumbnail
        if thumbnailUrl.startsWith("/") and hasValidInstance
            thumbnailUrl = playlistItem.instance + thumbnailUrl
        end if
        thumbnail = thumbnailUrl
    else if playlistItem.videos <> invalid and playlistItem.videos.Count() > 0 and playlistItem.videos[0].index = 0
        InvidiousContent_VideoSetThumbnail(node, playlistItem.videos[0], instance, quality)
        return
    else if node.getChildCount() > 0
        thumbnail = node.getChild(0).thumbnail
    end if
    if StringUtils_IsNullOrEmpty(thumbnail)
        thumbnail = "pkg:/images/thumbnail-missing.jpg"
    end if
    node[nodeField] = thumbnail
end function

function InvidiousContent_GetChannelThumbnail(authorThumbnails as object) as string
    if authorThumbnails = invalid or authorThumbnails.Count() = 0
        return "pkg:/images/icons/user-200.png"
    end if
    url = authorThumbnails[authorThumbnails.Count() - 1].url
    if url.startsWith("//")
        url = "https:" + url
    end if
    return url
end function

function InvidiousContent_GetChannelBanner(authorBanners as object) as string
    if authorBanners = invalid or authorBanners.Count() = 0
        return ""
    end if
    return authorBanners[0].url
end function

function InvidiousContent_SetVideoCountText(item as object, node as object) as void
    videoCountText = item.videoCountText
    if not StringUtils_IsNullOrEmpty(videoCountText)
        node.videoCountText = videoCountText
        return
    end if
    
    if not StringUtils_IsNullOrEmpty(node.videoCountText)
        return
    end if
    videoCount = ValidInt(item.videoCount)
    if videoCount = -1
        return
    end if
    node.videoCountText = LocaleUtils_GetPluralString(videoCount, "0 videos", "1 video", "^n videos")
end function

function InvidiousContent_GetChannelSubCountText(channel as object) as string
    subCount = ValidInt(channel.subCount)
    return LocaleUtils_GetFormattedPluralString(subCount, "0 subscribers", "1 subscriber", "^n subscribers")
end function

function InvidiousContent_PlaylistGetViewCountText(playlistItem as object) as string
    return InvidiousContent_VideoGetViewCountText(playlistItem)
end function

function InvidiousContent_VideoGetPublishedText(videoItem as object) as string
    published = ValidInt(videoItem.published)
    if published = 0
        return ValidString(videoItem.publishedText)
    end if
    span = TimeUtils_Now().AsSeconds() - published
    if span < 1
        return ValidString(videoItem.publishedText)
    end if
    total_days = span \ 86400
    if total_days > 365
        years = total_days \ 365
        if years = 1
            return Tr("1 year ago")
        else
            return Tr("^n years ago").Replace("^n", years.toStr())
        end if
    else if total_days > 30
        months = total_days \ 30
        if months = 1
            return Tr("1 month ago")
        else
            return Tr("^n months ago").Replace("^n", months.toStr())
        end if
    else if total_days > 7
        weeks = total_days \ 7
        if weeks = 1
            return Tr("1 week ago")
        else
            return Tr("^n weeks ago").Replace("^n", weeks.toStr())
        end if
    else if total_days > 0
        if total_days = 1
            return Tr("1 day ago")
        else
            return Tr("^n days ago").Replace("^n", total_days.toStr())
        end if
    else if span > 3600
        hours = span \ 3600
        if hours = 1
            return Tr("1 hour ago")
        else
            return Tr("^n hours ago").Replace("^n", hours.toStr())
        end if
    else if span > 60
        minutes = span \ 60
        if minutes = 1
            return Tr("1 minute ago")
        else
            return Tr("^n minutes ago").Replace("^n", minutes.toStr())
        end if
    else
        return Tr("1 minute ago")
    end if
end function

function InvidiousContent_VideoGetLengthText(videoItem as object) as string
    if not StringUtils_IsNullOrEmpty(videoItem.lengthText)
        return videoItem.lengthText
    end if
    return TimeUtils_GetFormattedTime(videoItem.lengthSeconds)
end function

function InvidiousContent_PlaylistGetUpdatedText(playlistItem as object) as string
    updated = playlistItem.updated
    if not IsInt(updated)
        return ""
    end if
    span = TimeUtils_Now().AsSeconds() - updated
    if span < 1
        return ""
    end if
    total_days = span \ 86400
    if total_days > 365
        years = total_days \ 365
        if years = 1
            return Tr("Updated 1 year ago")
        else
            return Tr("Updated ^n years ago").Replace("^n", years.toStr())
        end if
    else if total_days > 30
        months = total_days \ 30
        if months = 1
            return Tr("Updated 1 month ago")
        else
            return Tr("Updated ^n months ago").Replace("^n", months.toStr())
        end if
    else if total_days > 7
        weeks = total_days \ 7
        if weeks = 1
            return Tr("Updated 1 week ago")
        else
            return Tr("Updated ^n weeks ago").Replace("^n", weeks.toStr())
        end if
    else if total_days > 1
        return Tr("Updated ^n days ago").Replace("^n", total_days.toStr())
    else if span > 3600
        hours = span \ 3600
        if hours = 1
            return Tr("Updated 1 hour ago")
        else
            return Tr("Updated ^n hours ago").Replace("^n", hours.toStr())
        end if
    else if span > 60
        minutes = span \ 60
        if minutes = 1
            return Tr("Updated 1 minute ago")
        else
            return Tr("Updated ^n minutes ago").Replace("^n", minutes.toStr())
        end if
    else
        return Tr("Updated 1 minute ago")
    end if
end function