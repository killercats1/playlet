function BookmarksServiceUtils_BookmarksContentToFeed(content as object) as object
    bookmarkGroupNodes = content.getChildren(-1, 0)
    feeds = []
    for each bookmarkGroupNode in bookmarkGroupNodes
        bookmarkNodes = bookmarkGroupNode.getChildren(-1, 0)
        feedSources = []
        for each bookmarkNode in bookmarkNodes
            feedSources.push(bookmarkNode.feedSource)
        end for
        feeds.push({
            "title": bookmarkGroupNode.title
            "feedSources": feedSources
        })
    end for
    return feeds
end function