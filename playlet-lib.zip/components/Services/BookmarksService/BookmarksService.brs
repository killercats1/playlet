'import "pkg:/components/ContextMenu/ContextMenuUtils.bs"
'import "pkg:/source/utils/CryptoUtils.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RegistryUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    m.top.content = m.top.findNode("content")
    m.bookmarksString = ""
    Load()
    m.top.ObserveField("contentChange", FuncName(OnContentChange))
end function

function Load() as void
    bookmarksString = RegistryUtils_Read("bookmarks")
    if bookmarksString = invalid
        return
    end if
    m.bookmarksString = bookmarksString
    bookmarks = StringUtils_ParseJsonSafe(bookmarksString)
    if bookmarks = invalid
        LogWarn2("[BookmarksService.bs:24]", "Failed to parse bookmarks json")
        return
    end if
    groupCount = bookmarks.groups.Count()
    
    for i = groupCount - 1 to 0 step -1
        bookmarkGroup = bookmarks.groups[i]
        bookmarkGroupNode = GetOrCreateBookmarkGroup(bookmarkGroup.title)
        bookmarksCount = bookmarkGroup.bookmarks.Count()
        
        for j = bookmarksCount - 1 to 0 step -1
            bookmark = bookmarkGroup.bookmarks[j]
            AddFeedSourceBookmark(bookmark.feedSource, bookmark.id, bookmarkGroupNode)
        end for
    end for
end function

function Save() as void
    bookmarkGroupNodes = m.top.content.getChildren(-1, 0)
    if bookmarkGroupNodes.Count() = 0
        RegistryUtils_Delete("bookmarks")
        return
    end if
    groups = []
    for each bookmarkGroupNode in bookmarkGroupNodes
        bookmarks = []
        bookmarkNodes = bookmarkGroupNode.getChildren(-1, 0)
        for each bookmarkNode in bookmarkNodes
            bookmarks.push({
                "id": bookmarkNode.id
                "feedSource": bookmarkNode.feedSource
            })
        end for
        groups.push({
            "title": bookmarkGroupNode.title
            "bookmarks": bookmarks
        })
    end for
    bookmarksString = FormatJson({
        "__version": m.top.__version
        "groups": groups
    })
    if m.bookmarksString = bookmarksString
        return
    end if
    RegistryUtils_Write("bookmarks", bookmarksString)
    m.bookmarksString = bookmarksString
end function

function GetOrCreateBookmarkGroup(groupName as string) as object
    id = CryptoUtils_GetMd5(groupName)
    node = m.top.content.findNode(id)
    if node <> invalid
        return node
    end if
    node = CreateObject("roSGNode", "ContentNode")
    node.id = id
    node.title = groupName
    m.top.content.insertChild(node, 0)
    LogInfo3("[BookmarksService.bs:88]", "Added bookmark group:", groupName)
    return node
end function

function AddFeedSourceBookmark(feedSource as object, id as string, bookmarkGroupNode as dynamic)
    if IsString(bookmarkGroupNode)
        bookmarkGroupNode = GetOrCreateBookmarkGroup(bookmarkGroupNode)
    end if
    feedSource.Delete("state")
    bookmarkNode = CreateObject("roSGNode", "BookmarkContentNode")
    bookmarkNode.id = id
    bookmarkNode.feedSource = feedSource
    bookmarkGroupNode.insertChild(bookmarkNode, 0)
    LogInfo5("[BookmarksService.bs:104]", "Added feedSource bookmark. title:", feedSource.title, "id:", id)
    m.top.contentChange = true
end function

function AddVideoBookmark(id as string, groupName as string)
    bookmarkGroupNode = GetOrCreateBookmarkGroup(groupName)
    
    feedSource = {
        "apiType": "Invidious"
        "endpoint": "video_info"
        "pathParams": {
            "id": id
        }
    }
    AddFeedSourceBookmark(feedSource, id, bookmarkGroupNode)
end function

function AddPlaylistBookmark(id as string, groupName as string)
    bookmarkGroupNode = GetOrCreateBookmarkGroup(groupName)
    feedSource = {
        "apiType": "Invidious"
        "endpoint": "playlist_info"
        "pathParams": {
            "plid": id
        }
    }
    AddFeedSourceBookmark(feedSource, id, bookmarkGroupNode)
end function

function AddPlaylistBookmarkWithSpread(id as string, groupName as string)
    bookmarkGroupNode = GetOrCreateBookmarkGroup(groupName)
    feedSource = {
        "id": ("inv_playlist_" + bslib_toString(id))
        "title": (bslib_toString(groupName) + " " + bslib_toString(Tr("Videos")))
        "apiType": "Invidious"
        "endpoint": "playlist"
        "pathParams": {
            "plid": id
        }
    }
    AddFeedSourceBookmark(feedSource, ("inv_playlist_" + bslib_toString(id)), bookmarkGroupNode)
    feedSource = {
        "apiType": "Invidious"
        "endpoint": "playlist_info"
        "pathParams": {
            "plid": id
        }
    }
    AddFeedSourceBookmark(feedSource, id, bookmarkGroupNode)
end function

function AddChannelBookmark(id as string, groupName as string)
    bookmarkGroupNode = GetOrCreateBookmarkGroup(groupName)
    feedSource = {
        "apiType": "Invidious"
        "endpoint": "channel_info"
        "pathParams": {
            "ucid": id
        }
    }
    AddFeedSourceBookmark(feedSource, id, bookmarkGroupNode)
end function

function AddChannelBookmarkWithSpread(id as string, groupName as string)
    bookmarkGroupNode = GetOrCreateBookmarkGroup(groupName)
    feedSource = {
        "id": ("inv_channel_videos_" + bslib_toString(id))
        "title": (bslib_toString(groupName) + " " + bslib_toString(Tr("Videos")))
        "apiType": "Invidious"
        "endpoint": "channel_videos"
        "pathParams": {
            "ucid": id
        }
    }
    AddFeedSourceBookmark(feedSource, ("inv_channel_videos_" + bslib_toString(id)), bookmarkGroupNode)
    feedSource = {
        "apiType": "Invidious"
        "endpoint": "channel_info"
        "pathParams": {
            "ucid": id
        }
    }
    AddFeedSourceBookmark(feedSource, id, bookmarkGroupNode)
end function

function RemoveBookmark(id as string) as void
    node = m.top.content.findNode(id)
    if node = invalid
        return
    end if
    group = node.getParent()
    group.removeChild(node)
    LogInfo3("[BookmarksService.bs:207]", "Removed bookmark:", id)
    if group.getChildCount() = 0
        m.top.content.removeChild(group)
        LogInfo3("[BookmarksService.bs:211]", "Removed bookmark group:", group.title)
    end if
    m.top.contentChange = true
end function

function OnContentChange() as void
    Save()
end function

function GetContextMenuOptionsForItem(item as object) as object
    options = []
    if item.type = "video"
        options.append(GetMenuForVideo(item))
    else if item.type = "playlist"
        options.append(GetMenuForPlaylist(item))
    else if item.type = "channel"
        options.append(GetMenuForChannel(item))
    end if
    options.append(GetMenuForParentFeedSource(item))
    return options
end function

function GetMenuForVideo(videoNode as object) as object
    videoId = videoNode.videoId
    if StringUtils_IsNullOrEmpty(videoId)
        return []
    end if
    menu = []
    bookmark = m.top.content.findNode(videoId)
    isInBookmarks = bookmark <> invalid
    if isInBookmarks
        bookmarkGroup = bookmark.getParent()
        title = Tr("Remove from %1 bookmarks").Replace("%1", (chr(34) + bslib_toString(bookmarkGroup.title) + chr(34)))
        item = ContextMenuUtils_CreateOption(title, m.top, "RemoveBookmark", [
            videoId
        ])
        menu.push(item)
    else
        
        group = Tr("Videos")
        title = Tr("Add to %1 bookmark").Replace("%1", (chr(34) + bslib_toString(group) + chr(34)))
        item = ContextMenuUtils_CreateOption(title, m.top, "AddVideoBookmark", [
            videoId
            group
        ])
        menu.push(item)
    end if
    return menu
end function

function GetMenuForPlaylist(playlistNode as object) as object
    playlistId = playlistNode.playlistId
    if StringUtils_IsNullOrEmpty(playlistId) or playlistId.StartsWith("IV")
        return []
    end if
    menu = []
    bookmark = m.top.content.findNode(playlistId)
    isInBookmarks = bookmark <> invalid
    if isInBookmarks
        bookmarkGroup = bookmark.getParent()
        title = Tr("Remove from %1 bookmarks").Replace("%1", (chr(34) + bslib_toString(bookmarkGroup.title) + chr(34)))
        item = ContextMenuUtils_CreateOption(title, m.top, "RemoveBookmark", [
            playlistId
        ])
        menu.push(item)
    else
        
        group = Tr("Playlists")
        title = Tr("Add to %1 bookmark").Replace("%1", (chr(34) + bslib_toString(group) + chr(34)))
        item = ContextMenuUtils_CreateOption(title, m.top, "AddPlaylistBookmark", [
            playlistId
            group
        ])
        menu.push(item)
        title = Tr("Add to %1 bookmark").Replace("%1", (chr(34) + bslib_toString(playlistNode.title) + chr(34)))
        item = ContextMenuUtils_CreateOption(title, m.top, "AddPlaylistBookmarkWithSpread", [
            playlistId
            playlistNode.title
        ])
        menu.push(item)
    end if
    return menu
end function

function GetMenuForChannel(channelNode as object) as object
    authorId = channelNode.authorId
    if StringUtils_IsNullOrEmpty(authorId)
        return []
    end if
    menu = []
    bookmark = m.top.content.findNode(authorId)
    isInBookmarks = bookmark <> invalid
    if isInBookmarks
        bookmarkGroup = bookmark.getParent()
        title = Tr("Remove from %1 bookmarks").Replace("%1", (chr(34) + bslib_toString(bookmarkGroup.title) + chr(34)))
        item = ContextMenuUtils_CreateOption(title, m.top, "RemoveBookmark", [
            authorId
        ])
        menu.push(item)
    else
        group = Tr("Channels")
        title = Tr("Add to %1 bookmark").Replace("%1", (chr(34) + bslib_toString(group) + chr(34)))
        item = ContextMenuUtils_CreateOption(title, m.top, "AddChannelBookmark", [
            authorId
            group
        ])
        menu.push(item)
        title = Tr("Add to %1 bookmark").Replace("%1", (chr(34) + bslib_toString(channelNode._author) + chr(34)))
        item = ContextMenuUtils_CreateOption(title, m.top, "AddChannelBookmarkWithSpread", [
            authorId
            channelNode._author
        ])
        menu.push(item)
    end if
    return menu
end function

function GetMenuForParentFeedSource(itemNode as object) as object
    if itemNode = invalid
        return []
    end if
    if itemNode.type <> "video" and itemNode.type <> "playlist" and itemNode.type <> "channel"
        return []
    end if
    if not IsInt(itemNode.feedSourcesIndex) or itemNode.feedSourcesIndex = -1
        return []
    end if
    feedContentNode = itemNode.getParent()
    if feedContentNode = invalid or feedContentNode.subtype() <> "FeedContentNode"
        return []
    end if
    feedSource = feedContentNode.feedSources[itemNode.feedSourcesIndex]
    if StringUtils_IsNullOrEmpty(feedSource.title) or StringUtils_IsNullOrEmpty(feedSource.id)
        return []
    end if
    feedSourceTitle = feedSource.title
    feedSourceId = feedSource.id
    menu = []
    isInBookmarks = m.top.content.findNode(feedSourceId) <> invalid
    if isInBookmarks
        title = Tr("Remove from %1 bookmarks").Replace("%1", (chr(34) + bslib_toString(feedSourceTitle) + chr(34)))
        item = ContextMenuUtils_CreateOption(title, m.top, "RemoveBookmark", [
            feedSourceId
        ])
        menu.push(item)
    else
        title = Tr("Add to %1 bookmark").Replace("%1", (chr(34) + bslib_toString(feedSourceTitle) + chr(34)))
        item = ContextMenuUtils_CreateOption(title, m.top, "AddFeedSourceBookmark", [
            feedSource
            feedSourceId
            feedSourceTitle
        ])
        menu.push(item)
    end if
    return menu
end function