'import "pkg:/source/utils/RegistryUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
' Videos and channels the user marked "Not interested" / "Don't recommend channel", kept on the TV so they leave
' every feed right away (YouTube itself can take a while to stop sending them).
' The registry is small (16KB for the whole app), so only the latest ids are kept.




' -> { videos: [ids], channels: [ids] }
function FeedFilters_Load() as object
    saved = StringUtils_ParseJsonSafe(ValidString(RegistryUtils_Read("feed_hidden")))
    result = {
        videos: []
        channels: []
    }
    if IsAssociativeArray(saved)
        if IsArray(saved.videos)
            result.videos = saved.videos
        end if
        if IsArray(saved.channels)
            result.channels = saved.channels
        end if
    end if
    return result
end function

' kind: "video" or "channel"
function FeedFilters_Remember(kind as string, id as string) as void
    if id = ""
        return
    end if
    saved = FeedFilters_Load()
    if kind = "channel"
        saved.channels = FeedFilters_AddCapped(saved.channels, id, 60)
    else
        saved.videos = FeedFilters_AddCapped(saved.videos, id, 100)
    end if
    RegistryUtils_Write("feed_hidden", FormatJson(saved))
end function

function FeedFilters_AddCapped(ids as object, id as string, maxCount as integer) as object
    kept = []
    for each existing in ids
        if IsString(existing) and existing <> id
            kept.Push(existing)
        end if
    end for
    kept.Push(id)
    while kept.Count() > maxCount
        kept.Shift()
    end while
    return kept
end function

' -> { videos: { id: true }, channels: { id: true } } for quick lookups
function FeedFilters_LoadLookup() as object
    saved = FeedFilters_Load()
    lookup = {
        videos: {}
        channels: {}
    }
    for each id in saved.videos
        if IsString(id)
            lookup.videos[id] = true
        end if
    end for
    for each id in saved.channels
        if IsString(id)
            lookup.channels[id] = true
        end if
    end for
    return lookup
end function

function FeedFilters_Clear() as void
    RegistryUtils_Delete("feed_hidden")
end function