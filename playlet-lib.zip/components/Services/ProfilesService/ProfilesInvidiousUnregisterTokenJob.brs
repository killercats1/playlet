'import "pkg:/components/Services/Invidious/InvidiousService.bs"

function ExecuteJob() as void
    input = JobGetInput()
    profileContentNodes = input.profileNodes
    invidiousNode = input.invidious
    service = Invidious_InvidiousService(invidiousNode)
    for each profileNode in profileContentNodes
        
        token = profileNode.refreshToken
        if StringUtils_IsNullOrEmpty(token)
            token = profileNode.accessToken
        end if
        response = service.UnregisterToken(profileNode.serverUrl, token)
        if not response.IsSuccess()
            LogWarn2("[ProfilesInvidiousUnregisterTokenJob.bs:20]", ("Failed to unregister token: " + bslib_toString(response.ErrorMessage())))
        end if
    end for
end function