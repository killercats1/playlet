'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.types.bs"
'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/source/utils/StringUtils.bs"

function ExecuteJob() as void
    input = JobGetInput()
    invidiousNode = input.invidious
    profileContentNodes = input.profileNodes
    service = Invidious_InvidiousService(invidiousNode)
    for each profileNode in profileContentNodes
        if profileNode.type <> "invidious"
            continue for
        end if
        if profileNode.authState = "NeedsReauth"
            continue for
        end if
        if not service.VerifyTokenScope(profileNode.accessToken)
            
            profileNode.callfunc("MarkNeedsReauth", invalid)
        end if
    end for
end function