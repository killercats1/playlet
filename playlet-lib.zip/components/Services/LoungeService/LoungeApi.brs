'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/components/Services/LoungeService/LoungeBackchannel.bs"
'import "pkg:/components/Services/LoungeService/LoungeConstants.bs"
'import "pkg:/components/Services/LoungeService/LoungeMessages.bs"
'import "pkg:/components/Services/LoungeService/LoungeVideoQueue.bs"
'import "pkg:/components/Services/LoungeService/Notifications/DeviceConnectedNotificationUtils.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RegistryUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

' Apparently devices can be connected and disconnected very frequently.
' We don't want to spam the user with notifications, so we'll only show a notification
' if the last notification was more than 30 minutes ago.

function __LoungeApi_method_new(loungeServiceNode as object, videoQueueNode as object, notificationsNode as object, invidiousNode as object, messagePort as object)
    m.loungeServiceNode = invalid
    m.videoQueueNode = invalid
    m.notificationsNode = invalid
    m.invService = invalid
    m.deviceId = invalid
    m.deviceName = invalid
    m.screenId = invalid
    m.screenName = invalid
    m.loungeToken = invalid
    m.sessionId = invalid
    m.gSessionId = invalid
    m.devices = invalid
    m.sessionGone = false
    m.tokenExpired = false
    m.backchannel = invalid
    m.ofs = invalid
    m.messagePort = invalid
    m.pendingOutgoingMessages = invalid
    m.lastLoungeDisconnect = invalid
    m.loungeServiceNode = loungeServiceNode
    m.videoQueueNode = videoQueueNode
    m.notificationsNode = notificationsNode
    m.invService = Invidious_InvidiousService(invidiousNode)
    m.dateTime = CreateObject("roDateTime")
    m.deviceId = loungeServiceNode.deviceId
    deviceName = loungeServiceNode.deviceName
    m.deviceName = deviceName
    m.screenName = deviceName
    m.ofs = 0
    m.messagePort = messagePort
    m.backchannel = LoungeBackchannel()
    m.pendingOutgoingMessages = []
    m.devices = {}
    commandHandlers = {}
    commandHandlers["noop"] = m.HandleIgnoreCommand
    commandHandlers["getVolume"] = m.HandleIgnoreCommand
    commandHandlers["setVolume"] = m.HandleIgnoreCommand
    commandHandlers["getSubtitlesTrack"] = m.HandleIgnoreCommand
    commandHandlers["setSubtitlesTrack"] = m.HandleIgnoreCommand
    commandHandlers["setAudioTrack"] = m.HandleIgnoreCommand
    commandHandlers["dpadCommand"] = m.HandleIgnoreCommand
    commandHandlers["voiceCommand"] = m.HandleIgnoreCommand
    commandHandlers["onUserActivity"] = m.HandleIgnoreCommand
    commandHandlers["remoteDisconnected"] = m.HandleIgnoreCommand
    commandHandlers["getDiscoveryDeviceId"] = m.HandleIgnoreCommand
    commandHandlers["gracefulReconnect"] = m.HandleIgnoreCommand
    commandHandlers["getReceiverStatus"] = m.HandleIgnoreCommand
    commandHandlers["sendDebugCommand"] = m.HandleIgnoreCommand
    commandHandlers["setAutoplayMode"] = m.HandleIgnoreCommand
    commandHandlers["getPartyGamesMode"] = m.HandleIgnoreCommand
    commandHandlers["setImpactedSessionsServerEvent"] = m.HandleIgnoreCommand
    commandHandlers["getNowPlaying"] = m.HandleGetPlayingNow
    commandHandlers["c"] = m.HandleSessionId
    commandHandlers["S"] = m.HandleGSessionId
    commandHandlers["loungeStatus"] = m.HandleLoungeStatus
    commandHandlers["remoteConnected"] = m.HandleRemoteConnected
    commandHandlers["setPlaylist"] = m.HandleSetPlaylist
    commandHandlers["updatePlaylist"] = m.HandleUpdatePlaylist
    commandHandlers["pause"] = m.HandlePause
    commandHandlers["play"] = m.HandlePlay
    commandHandlers["previous"] = m.HandlePrevious
    commandHandlers["next"] = m.HandleNext
    commandHandlers["stopVideo"] = m.HandleStopVideo
    commandHandlers["seekTo"] = m.HandleSeekTo
    commandHandlers["setPlaybackSpeed"] = m.HandleSetPlaybackSpeed
    commandHandlers["getPlaybackSpeed"] = m.HandleGetPlaybackSpeed
    for each key in commandHandlers
        m["_Handle_" + key] = commandHandlers[key]
    end for
end function
function __LoungeApi_method_Zx() as string
    
    rnd1% = rnd(2147483647)
    rnd2& = rnd(2147483647)
    m.dateTime.mark()
    now& = m.dateTime.AsSeconds()
    now& = now& * 1000 + m.dateTime.GetMilliseconds()
    rnd2xor& = (rnd2& or now&) and not (rnd2& and now&)
    return StrI(rnd1%, 36) + StrI(Abs(rnd2xor&), 36)
end function
function __LoungeApi_method_GetScreenId() as dynamic
    if not StringUtils_IsNullOrEmpty(m.screenId)
        return m.screenId
    end if
    request = HttpClient_Get("https://www.youtube.com/api/lounge/pairing/generate_screen_id")
    response = request.Await()
    if not response.IsSuccess()
        LogError2("[LoungeApi.bs:120]", ("Failed to get lounge screen ID" + chr(10) + bslib_toString(response.ErrorMessage())))
        return invalid
    end if
    id = response.Text()
    if StringUtils_IsNullOrEmpty(id)
        LogError2("[LoungeApi.bs:126]", "Failed to get lounge screen ID: empty response")
        return invalid
    end if
    m.screenId = id
    return id
end function
function __LoungeApi_method_GetToken() as dynamic
    if not StringUtils_IsNullOrEmpty(m.loungeToken)
        return m.loungeToken
    end if
    request = HttpClient_Post("https://www.youtube.com/api/lounge/pairing/get_lounge_token_batch")
    request.FormBody({
        "screen_ids": m.screenId
    })
    response = request.Await()
    if not response.IsSuccess()
        LogError2("[LoungeApi.bs:146]", ("Failed to get lounge token" + chr(10) + bslib_toString(response.ErrorMessage())))
        return invalid
    end if
    json = response.Json()
    screens = ValidAssociativeArray(json).screens
    if not IsArray(screens) or screens.Count() <> 1
        LogError2("[LoungeApi.bs:153]", ("Failed to get lounge token: invalid response" + chr(10) + "Body: " + bslib_toString(response.Text())))
        return invalid
    end if
    
    m.loungeToken = screens[0].loungeToken
    return m.loungeToken
end function
function __LoungeApi_method_BindQueryParams(loungeData as object) as object
    return {
        "device": "LOUNGE_SCREEN"
        "theme": "cl"
        "capabilities": "vsp"
        "mdxVersion": "2"
        "VER": "8"
        "v": "2"
        "t": "1"
        "app": "lb-v4"
        "name": loungeData.screenName
        "id": loungeData.deviceId
        "loungeIdToken": loungeData.loungeToken
        "zx": m.Zx()
    }
end function
function __LoungeApi_method_GetSessionData() as boolean
    queryParams = m.BindQueryParams(m)
    queryParams["RID"] = "1337"
    request = HttpClient_Post("https://www.youtube.com/api/lounge/bc/bind")
    request.QueryParams(queryParams)
    request.FormBody({
        "count": 0
    })
    response = request.Await()
    if not response.IsSuccess()
        LogError2("[LoungeApi.bs:191]", ("Failed to get lounge session data" + chr(10) + bslib_toString(response.ErrorMessage())))
        return false
    end if
    m.ofs = 0
    m.sessionGone = false
    m.tokenExpired = false
    messagesToSend = []
    for each command in m.backchannel.StartSession(response.Text())
        m.ProcessCommand(command, messagesToSend)
    end for
    if StringUtils_IsNullOrEmpty(m.sessionId) or StringUtils_IsNullOrEmpty(m.gSessionId)
        LogTelemetryEvent({
            level: "error"
            message: "Lounge bind succeeded but yielded no session id"
            fingerprint: "lounge-bind-no-sid"
        })
    end if
    m.SendMessages(messagesToSend)
    return true
end function
function __LoungeApi_method_StartPoll() as void
    queryParams = m.BindQueryParams(m)
    queryParams["RID"] = "rpc"
    queryParams["SID"] = m.sessionId
    queryParams["gsessionid"] = m.gSessionId
    queryParams["CI"] = "1"
    queryParams["TYPE"] = "xmlhttp"
    request = HttpClient_Get("https://www.youtube.com/api/lounge/bc/bind")
    request.QueryParams(queryParams)
    m.backchannel.Open(request, m.messagePort)
end function
function __LoungeApi_method_HandleMessage(message as dynamic, messagesToSend as object) as void
    for each command in m.backchannel.Handle(message)
        m.ProcessCommand(command, messagesToSend)
    end for
    m.HandleSends(message)
end function
function __LoungeApi_method_MaxWaitMs() as integer
    waitMs = m.backchannel.MaxWaitMs()
    for each pending in m.pendingOutgoingMessages
        pendingWaitMs = pending.MaxWaitMs()
        if waitMs = 0 or pendingWaitMs < waitMs
            waitMs = pendingWaitMs
        end if
    end for
    return waitMs
end function
function __LoungeApi_method_RefreshToken() as dynamic
    m.loungeToken = invalid
    return m.GetToken()
end function
function __LoungeApi_method_Bind() as boolean
    if not m.GetSessionData()
        return false
    end if
    m.SaveCurrentLoungeData()
    return true
end function
function __LoungeApi_method_Rebind(withNewToken as boolean) as boolean
    m.CancelSends()
    if withNewToken
        LogWarnNoTelemetry2("[LoungeApi.bs:261]", "Lounge token expired, refreshing")
        if StringUtils_IsNullOrEmpty(m.RefreshToken())
            return false
        end if
    end if
    LogWarnNoTelemetry2("[LoungeApi.bs:267]", "Rebinding lounge session")
    return m.Bind()
end function
function __LoungeApi_method_EndSession() as void
    m.backchannel.Close()
    m.CancelSends()
    m.loungeToken = invalid
end function
function __LoungeApi_method_CancelSends() as void
    for each pending in m.pendingOutgoingMessages
        pending.Cancel()
    end for
    m.pendingOutgoingMessages = []
end function
function __LoungeApi_method_ProcessCommand(command as object, messagesToSend as object) as void
    handler = "_Handle_" + command.type
    if m.DoesExist(handler)
        LogInfo3("[LoungeApi.bs:287]", command.index, command.type)
        m[handler](command.index, command.type, command.args, messagesToSend)
        return
    end if
    fingerprint = "Unknown command type:" + command.type
    message = fingerprint + " command:" + ToString(command)
    LogWarnNoTelemetry2("[LoungeApi.bs:294]", message)
    LogTelemetryEvent({
        level: "warning"
        message: message
        fingerprint: fingerprint
    })
end function
function __LoungeApi_method_HandleIgnoreCommand(_commandId as integer, commandType as string, commandArgs as object, _messagesToSend as object)
    
end function
function __LoungeApi_method_HandleSessionId(_commandId as integer, _commandType as string, commandArgs as object, _messagesToSend as object)
    m.sessionId = commandArgs
    LogInfo3("[LoungeApi.bs:311]", "sessionId:", m.sessionId)
end function
function __LoungeApi_method_HandleGSessionId(_commandId as integer, _commandType as string, commandArgs as object, _messagesToSend as object)
    m.gSessionId = commandArgs
    LogInfo3("[LoungeApi.bs:316]", "gSessionId:", m.gSessionId)
end function
function __LoungeApi_method_HandleGetPlayingNow(_commandId as integer, _commandType as string, _commandArgs as object, messagesToSend as object) as void
    player = m.videoQueueNode.player
    messagesToSend.Push(LoungeMessages_OnHasPreviousNextChanged(m.videoQueueNode.hasPrevious, m.videoQueueNode.hasNext))
    messagesToSend.Push(LoungeMessages_NowPlaying(player))
    messagesToSend.Push(LoungeMessages_OnStateChange(player))
end function
function __LoungeApi_method_HandleLoungeStatus(_commandId as integer, commandType as string, commandArgs as object, _messagesToSend as object) as void
    LogInfo3("[LoungeApi.bs:327]", commandType, FormatJson(commandArgs))
    devices = commandArgs["devices"]
    if not IsString(devices)
        return
    end if
    devices = StringUtils_ParseJsonSafe(devices)
    if devices = invalid
        return
    end if
    for each device in devices
        if m.devices.DoesExist(device.id)
            device.lastConnectNotificationTime = m.devices[device.id].lastConnectNotificationTime
        end if
        m.devices[device.id] = device
    end for
end function
function __LoungeApi_method_HandleRemoteConnected(_commandId as integer, commandType as string, commandArgs as object, _messagesToSend as object) as void
    LogInfo3("[LoungeApi.bs:346]", commandType, FormatJson(commandArgs))
    newDevice = commandArgs
    id = newDevice.id
    if StringUtils_IsNullOrEmpty(id)
        return
    end if
    if m.devices.DoesExist(id)
        device = m.devices[id]
        device.Append(newDevice)
        newDevice = device
    end if
    m.devices[id] = newDevice
    nowSeconds = TimeUtils_Now().AsSeconds()
    lastConnectNotificationInterval = nowSeconds - ValidInt(newDevice.lastConnectNotificationTime)
    if lastConnectNotificationInterval < 1800
        LogInfo4("[LoungeApi.bs:364]", "Skipping connect notification. Last connect notification interval:", lastConnectNotificationInterval, "seconds")
        return
    end if
    newDevice.lastConnectNotificationTime = nowSeconds
    userName = newDevice.user
    deviceName = newDevice.name
    userAvatarUri = newDevice.userAvatarUri
    LoungeDeviceConnected_ShowNotifcation(m.notificationsNode, deviceName, userName, userAvatarUri)
end function
function __LoungeApi_method_HandleSetPlaylist(_commandId as integer, commandType as string, commandArgs as object, _messagesToSend as object)
    
    
    if not StringUtils_IsNullOrEmpty(commandArgs["ctt"]) and not StringUtils_IsNullOrEmpty(commandArgs["videoId"])
        m.loungeServiceNode.credentialTransferToken = {
            "token": commandArgs["ctt"]
            "videoId": commandArgs["videoId"]
        }
    end if
    LoungeVideoQueue_SetPlaylist(m.videoQueueNode, m.invService, commandArgs)
end function
function __LoungeApi_method_HandleUpdatePlaylist(_commandId as integer, commandType as string, commandArgs as object, _messagesToSend as object)
    
    LoungeVideoQueue_UpdatePlaylist(m.videoQueueNode, m.invService, commandArgs)
end function
function __LoungeApi_method_HandlePause(_commandId as integer, _commandType as string, _commandArgs as object, _messagesToSend as object)
    m.videoQueueNode.pause = true
end function
function __LoungeApi_method_HandlePlay(_commandId as integer, _commandType as string, _commandArgs as object, _messagesToSend as object)
    m.videoQueueNode.play = true
end function
function __LoungeApi_method_HandlePrevious(_commandId as integer, _commandType as string, _commandArgs as object, _messagesToSend as object)
    m.videoQueueNode.previous = true
end function
function __LoungeApi_method_HandleNext(_commandId as integer, _commandType as string, _commandArgs as object, _messagesToSend as object)
    m.videoQueueNode.next = true
end function
function __LoungeApi_method_HandleStopVideo(_commandId as integer, _commandType as string, _commandArgs as object, _messagesToSend as object)
    m.videoQueueNode.closePlayer = true
end function
function __LoungeApi_method_HandleSeekTo(_commandId as integer, _commandType as string, commandArgs as object, _messagesToSend as object) as void
    player = m.videoQueueNode.player
    if player = invalid
        return
    end if
    seekTo = Val(commandArgs["newTime"])
    LogInfo3("[LoungeApi.bs:428]", "Seeking to:", seekTo)
    player.setSeek = seekTo
end function
function __LoungeApi_method_HandleSetPlaybackSpeed(_commandId as integer, _commandType as string, commandArgs as object, messagesToSend as object) as void
    player = m.videoQueueNode.player
    if player = invalid
        return
    end if
    if not player.hasField("playbackSpeed")
        LogWarn2("[LoungeApi.bs:439]", "Video node does not support 'playbackSpeed' field on this device, ignoring setPlaybackSpeed command")
        return
    end if
    speed = Val(commandArgs["playbackSpeed"])
    if speed <= 0
        speed = 1.0
    end if
    content = player.content
    if content <> invalid and content.live = true
        return
    end if
    currentSpeed = ValidFloat(player.playbackSpeed)
    if Abs(currentSpeed - speed) < 0.001
        
        return
    end if
    LogInfo3("[LoungeApi.bs:460]", "Setting playback speed to:", speed)
    
    didPause = false
    state = player.state
    if state = "playing"
        player.control = "pause"
        didPause = true
    end if
    player.playbackSpeed = speed
    if didPause
        player.control = "resume"
    end if
    messagesToSend.Push(LoungeMessages_OnPlaybackSpeedChanged(speed, true))
end function
function __LoungeApi_method_HandleGetPlaybackSpeed(_commandId as integer, _commandType as string, _commandArgs as object, messagesToSend as object) as void
    player = m.videoQueueNode.player
    if player = invalid
        return
    end if
    if not player.hasField("playbackSpeed")
        LogWarn2("[LoungeApi.bs:486]", "Video node does not support 'playbackSpeed' field on this device, ignoring getPlaybackSpeed command")
        return
    end if
    speed = ValidFloat(player.playbackSpeed)
    if speed <= 0
        speed = 1.0
    end if
    messagesToSend.Push(LoungeMessages_OnPlaybackSpeedChanged(speed))
end function
function __LoungeApi_method_SendMessages(messages as object) as void
    if messages.Count() = 0
        return
    end if
    m.pendingOutgoingMessages.Push(m.SendRequest(m, messages, m.backchannel.ackedCommandIndex).SendOn(m.messagePort))
end function
function __LoungeApi_method_SendRequest(loungeData as object, messages as object, ackedCommandIndex as integer) as object
    queryParams = m.BindQueryParams(loungeData)
    queryParams["RID"] = "1337"
    queryParams["SID"] = loungeData.sessionId
    queryParams["gsessionid"] = loungeData.gSessionId
    if ackedCommandIndex >= 0
        queryParams["AID"] = ackedCommandIndex
    end if
    postData = [
        {
            key: "count"
            value: messages.Count()
        }
        {
            key: "ofs"
            value: loungeData.ofs
        }
    ]
    loungeData.ofs += messages.Count()
    for i = 0 to messages.Count() - 1
        message = messages[i]
        keyPrefix = ("req" + bslib_toString(i) + "_")
        postData.Push({
            key: (bslib_toString(keyPrefix) + bslib_toString("_sc"))
            value: message.commandType
        })
        commandArgs = message.commandArgs
        if commandArgs <> invalid
            for each key in commandArgs
                postData.Push({
                    key: (bslib_toString(keyPrefix) + bslib_toString(key))
                    value: commandArgs[key]
                })
            end for
        end if
    end for
    
    request = HttpClient_Post("https://www.youtube.com/api/lounge/bc/bind")
    request.QueryParams(queryParams)
    request.FormBody(postData)
    return request
end function
function __LoungeApi_method_HandleSends(message as dynamic) as void
    for i = m.pendingOutgoingMessages.Count() - 1 to 0 step -1
        response = m.pendingOutgoingMessages[i].Handle(message)
        if response <> invalid
            m.pendingOutgoingMessages.Delete(i)
            if not response.IsSuccess()
                m.OnSendFailed(response)
            end if
        end if
    end for
end function
function __LoungeApi_method_OnSendFailed(response as object) as void
    status = response.StatusCode()
    error = response.ErrorMessage()
    isGone = status = 410
    unknownSid = status = 400 and error.InStr("Unknown SID") <> -1
    expiredToken = status = 401 and error.InStr("Expired lounge id token") <> -1
    if isGone or unknownSid
        m.sessionGone = true
    else if expiredToken
        m.tokenExpired = true
    end if
    if isGone or unknownSid or expiredToken
        
        LogErrorNoTelemetry2("[LoungeApi.bs:569]", error)
        if expiredToken
            LogTelemetryEvent({
                level: "warning"
                message: "Lounge id token expired"
                fingerprint: "lounge-expired-token"
            })
        end if
    else
        LogErrorNoTelemetry2("[LoungeApi.bs:578]", error)
        LogTelemetryEvent({
            level: "error"
            message: error
            fingerprint: [
                "lounge-send-failure"
                status
            ]
        })
    end if
end function
function __LoungeApi_method_SaveCurrentLoungeData() as void
    loungeData = {
        "__version": 1
    }
    fields = [
        "screenName"
        "deviceId"
        "loungeToken"
        "sessionId"
        "gSessionId"
    ]
    for each field in fields
        if StringUtils_IsNullOrEmpty(m[field])
            LogWarn3("[LoungeApi.bs:594]", "Lounge data will not be saved. missing field:", field)
            return
        end if
        loungeData[field] = m[field]
    end for
    loungeData = FormatJson(loungeData)
    RegistryUtils_Write("last_lounge_data", loungeData)
end function
function __LoungeApi_method_DisconnectFromLastLounge() as void
    loungeData = RegistryUtils_Read("last_lounge_data")
    if loungeData = invalid
        return
    end if
    RegistryUtils_Delete("last_lounge_data")
    loungeData = StringUtils_ParseJsonSafe(loungeData)
    if not IsAssociativeArray(loungeData)
        LogWarn3("[LoungeApi.bs:615]", "Can't disconnect from lounge. Invalid data:", loungeData)
        return
    end if
    if ValidInt(loungeData.__version) <> 1
        LogWarn3("[LoungeApi.bs:620]", "Can't disconnect from lounge. Unknown version:", loungeData.__version)
        return
    end if
    fields = [
        "screenName"
        "deviceId"
        "loungeToken"
        "sessionId"
        "gSessionId"
    ]
    for each field in fields
        if StringUtils_IsNullOrEmpty(loungeData[field])
            LogWarn3("[LoungeApi.bs:627]", "Can't disconnect from lounge. Missing field:", field)
            return
        end if
    end for
    messages = [
        {
            "commandType": "loungeScreenDisconnected"
        }
    ]
    LogInfo2("[LoungeApi.bs:636]", "Disconnecting from last lounge")
    
    loungeData.ofs = 99999999
    
    m.lastLoungeDisconnect = m.SendRequest(loungeData, messages, -1).Send()
end function
function __LoungeApi_builder()
    instance = {}
    ' Set by a send's failure, until the next bind.
    instance.new = __LoungeApi_method_new
    instance.Zx = __LoungeApi_method_Zx
    instance.GetScreenId = __LoungeApi_method_GetScreenId
    instance.GetToken = __LoungeApi_method_GetToken
    instance.BindQueryParams = __LoungeApi_method_BindQueryParams
    instance.GetSessionData = __LoungeApi_method_GetSessionData
    instance.StartPoll = __LoungeApi_method_StartPoll
    instance.HandleMessage = __LoungeApi_method_HandleMessage
    instance.MaxWaitMs = __LoungeApi_method_MaxWaitMs
    instance.RefreshToken = __LoungeApi_method_RefreshToken
    instance.Bind = __LoungeApi_method_Bind
    instance.Rebind = __LoungeApi_method_Rebind
    instance.EndSession = __LoungeApi_method_EndSession
    instance.CancelSends = __LoungeApi_method_CancelSends
    instance.ProcessCommand = __LoungeApi_method_ProcessCommand
    instance.HandleIgnoreCommand = __LoungeApi_method_HandleIgnoreCommand
    instance.HandleSessionId = __LoungeApi_method_HandleSessionId
    instance.HandleGSessionId = __LoungeApi_method_HandleGSessionId
    instance.HandleGetPlayingNow = __LoungeApi_method_HandleGetPlayingNow
    instance.HandleLoungeStatus = __LoungeApi_method_HandleLoungeStatus
    instance.HandleRemoteConnected = __LoungeApi_method_HandleRemoteConnected
    instance.HandleSetPlaylist = __LoungeApi_method_HandleSetPlaylist
    instance.HandleUpdatePlaylist = __LoungeApi_method_HandleUpdatePlaylist
    instance.HandlePause = __LoungeApi_method_HandlePause
    instance.HandlePlay = __LoungeApi_method_HandlePlay
    instance.HandlePrevious = __LoungeApi_method_HandlePrevious
    instance.HandleNext = __LoungeApi_method_HandleNext
    instance.HandleStopVideo = __LoungeApi_method_HandleStopVideo
    instance.HandleSeekTo = __LoungeApi_method_HandleSeekTo
    instance.HandleSetPlaybackSpeed = __LoungeApi_method_HandleSetPlaybackSpeed
    instance.HandleGetPlaybackSpeed = __LoungeApi_method_HandleGetPlaybackSpeed
    instance.SendMessages = __LoungeApi_method_SendMessages
    instance.SendRequest = __LoungeApi_method_SendRequest
    instance.HandleSends = __LoungeApi_method_HandleSends
    instance.OnSendFailed = __LoungeApi_method_OnSendFailed
    instance.SaveCurrentLoungeData = __LoungeApi_method_SaveCurrentLoungeData
    instance.DisconnectFromLastLounge = __LoungeApi_method_DisconnectFromLastLounge
    return instance
end function
function LoungeApi(loungeServiceNode as object, videoQueueNode as object, notificationsNode as object, invidiousNode as object, messagePort as object)
    instance = __LoungeApi_builder()
    instance.new(loungeServiceNode, videoQueueNode, notificationsNode, invidiousNode, messagePort)
    return instance
end function