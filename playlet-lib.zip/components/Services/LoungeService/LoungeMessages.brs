'import "pkg:/components/Services/LoungeService/LoungeConstants.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
function LoungeMessages_OnHasPreviousNextChanged(hasPrevious as boolean, hasNext as boolean) as object
    message = {
        commandType: "onHasPreviousNextChanged"
    }
    commandArgs = {}
    commandArgs["hasPrevious"] = hasPrevious
    commandArgs["hasNext"] = hasNext
    message.commandArgs = commandArgs
    return message
end function

function LoungeMessages_OnPlaybackSpeedChanged(speed as float, isContentSupportVSP = invalid as dynamic) as object
    message = {
        commandType: "onPlaybackSpeedChanged"
    }
    commandArgs = {}
    commandArgs["playbackSpeed"] = speed
    if isContentSupportVSP <> invalid
        commandArgs["playbackSpeedInfo"] = FormatJson({
            "playbackSpeed": speed
            "isContentSupportVSP": isContentSupportVSP
        })
    end if
    message.commandArgs = commandArgs
    return message
end function

function LoungeMessages_OnStateChange(player as object, overrides = invalid as object) as object
    message = {
        commandType: "onStateChange"
    }
    commandArgs = {}
    if player = invalid
        commandArgs["state"] = -1
        commandArgs["currentTime"] = 0
        commandArgs["duration"] = 0
        commandArgs["loadedTime"] = 0
        commandArgs["seekableStartTime"] = 0
        commandArgs["seekableEndTime"] = 0
        message.commandArgs = commandArgs
        return message
    end if
    commandArgs["state"] = LoungeMessages_GetPlayerState(player)
    commandArgs["currentTime"] = ValidDouble(player.position)
    commandArgs["seekableStartTime"] = 0
    content = player.content
    if content <> invalid
        metadata = content.metadata
        if metadata <> invalid
            lengthSeconds = metadata.lengthSeconds
            if IsInt(lengthSeconds)
                commandArgs["duration"] = lengthSeconds
                commandArgs["seekableEndTime"] = lengthSeconds
                if commandArgs["state"] = 1 or commandArgs["state"] = 2 or commandArgs["state"] = 3
                    commandArgs["loadedTime"] = lengthSeconds
                end if
            end if
        end if
    end if
    if overrides <> invalid
        commandArgs.Append(overrides)
    end if
    message.commandArgs = commandArgs
    return message
end function

function LoungeMessages_NowPlaying(player as object, overrides = invalid as object) as object
    message = {
        commandType: "nowPlaying"
    }
    if player = invalid
        return message
    end if
    commandArgs = {}
    commandArgs["currentTime"] = ValidDouble(player.position)
    commandArgs["seekableStartTime"] = 0
    commandArgs["currentIndex"] = 0
    commandArgs["state"] = LoungeMessages_GetPlayerState(player)
    content = player.content
    if content <> invalid
        metadata = content.metadata
        if metadata <> invalid
            lengthSeconds = metadata.lengthSeconds
            if IsInt(lengthSeconds)
                commandArgs["duration"] = lengthSeconds
                commandArgs["seekableEndTime"] = lengthSeconds
                if commandArgs["state"] = 1 or commandArgs["state"] = 2 or commandArgs["state"] = 3
                    commandArgs["loadedTime"] = lengthSeconds
                end if
            end if
            videoId = metadata.videoId
            if not StringUtils_IsNullOrEmpty(videoId)
                commandArgs["videoId"] = videoId
            end if
        end if
    end if
    if overrides <> invalid
        commandArgs.Append(overrides)
    end if
    message.commandArgs = commandArgs
    return message
end function

function LoungeMessages_GetPlayerState(player as object) as object
    if player = invalid
        return -1
    end if
    state = player.state
    if state = "playing"
        return 1
    else if state = "paused"
        return 2
    else if state = "buffering"
        return 3
    else if state = "finished"
        return 0
    end if
    return -1
end function