'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/StringUtils.bs"


function LoungeDeviceConnected_ShowNotifcation(notifications as object, deviceName as dynamic, userName as dynamic, userAvatarUri as dynamic) as void
    notification = notifications.findNode("DeviceConnectedNotification")
    if notification = invalid
        notification = notifications.createChild("DeviceConnectedNotification")
        notification.id = "DeviceConnectedNotification"
    end if
    if StringUtils_IsNullOrEmpty(deviceName)
        deviceName = Tr("Device")
    end if
    if StringUtils_IsNullOrEmpty(userAvatarUri)
        userAvatarUri = "pkg:/images/icons/user.png"
    end if
    notification.line1 = deviceName
    notification.line2 = userName
    notification.thumbnail = userAvatarUri
    notification.show = true
end function

function LoungeDeviceConnected_RemoveNotifcation(notifications as object) as void
    notification = notifications.findNode("DeviceConnectedNotification")
    if notification <> invalid
        notifications.RemoveChild(notification)
    end if
end function

function LoungeDeviceConnected_SetVisible(notifications as object, visible as boolean)
    notification = notifications.findNode("DeviceConnectedNotification")
    if notification <> invalid
        notification.visible = visible
    end if
end function