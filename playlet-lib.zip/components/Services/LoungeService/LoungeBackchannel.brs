'import "pkg:/components/Services/LoungeService/LoungeService.types.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/ByteArrayUtils.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
' The server answers a poll with a noop after at most ~30 s idle, and drops a session that goes 55-60 s without a poll.
' Giving up on a dead connection by 40 s lets the next poll, after the first backoff, land before the session is gone.

sub __LoungeBackchannel_method_new()
    m.statusCode = 0
    m.closeReason = invalid
    m.ackedCommandIndex = -1
    m.stalledPolls = 0
    m.pollTimeoutMs = 40000
    m.pending = invalid
    m.polledCommandIndex = -1
end sub
function __LoungeBackchannel_method_StartSession(bindResponseText as string) as dynamic
    m.ackedCommandIndex = -1
    m.stalledPolls = 0
    return m.Receive(m.ExtractFrames(bindResponseText))
end function
function __LoungeBackchannel_method_Open(request as object, messagePort as object) as void
    m.statusCode = 0
    m.closeReason = invalid
    m.polledCommandIndex = m.ackedCommandIndex
    m.pending = request.QueryParam("AID", m.ackedCommandIndex).NoCache().RetryCount(0).AttemptTimeoutMs(m.pollTimeoutMs).SendOn(messagePort)
end function
function __LoungeBackchannel_method_Close() as void
    if m.pending <> invalid
        m.pending.Cancel()
        m.pending = invalid
    end if
end function
function __LoungeBackchannel_method_IsPolling() as boolean
    return m.pending <> invalid
end function
function __LoungeBackchannel_method_MaxWaitMs() as integer
    if m.pending = invalid
        return 0
    end if
    return m.pending.MaxWaitMs()
end function
function __LoungeBackchannel_method_Handle(message as dynamic) as dynamic
    if m.pending = invalid
        return []
    end if
    response = m.pending.Handle(message)
    if response = invalid
        return []
    end if
    m.pending = invalid
    m.statusCode = response.StatusCode()
    if response.IsTimedOut()
        m.closeReason = "timeout"
        return []
    end if
    if m.statusCode = 0
        m.closeReason = "not_sent"
        return []
    end if
    if m.statusCode < 200 or m.statusCode >= 300
        m.closeReason = "http"
        return []
    end if
    frames = m.ExtractFrames(response.Text())
    if frames.Count() = 0
        m.closeReason = "empty"
        return []
    end if
    commands = m.Receive(frames)
    
    if m.ackedCommandIndex = m.polledCommandIndex
        m.closeReason = "stalled"
        m.stalledPolls += 1
    else
        m.closeReason = "complete"
        m.stalledPolls = 0
    end if
    return commands
end function
function __LoungeBackchannel_method_ExtractFrames(text as string) as object
    body = CreateObject("roByteArray")
    body.FromAsciiString(text)
    frames = []
    count = body.Count()
    cursor = 0
    while cursor < count
        if body[cursor] = 10 or body[cursor] = 13
            cursor += 1
            continue while
        end if
        frameStart = cursor
        frameLength = 0
        
        while cursor < count and body[cursor] >= 48 and body[cursor] <= 57 and frameLength <= count
            frameLength = frameLength * 10 + body[cursor] - 48
            cursor += 1
        end while
        if cursor < count and body[cursor] = 13
            cursor += 1
        end if
        if cursor >= count or body[cursor] <> 10 or frameLength = 0 or count - cursor - 1 < frameLength
            LogTelemetryEvent({
                level: "warning"
                message: ("Lounge answer has a malformed or cut-off frame at byte " + bslib_toString(frameStart) + " of " + bslib_toString(count) + ": " + bslib_toString(text))
                fingerprint: "lounge-partial-frame"
            })
            exit while
        end if
        dataStart = cursor + 1
        frames.Push(ByteArrayUtils_Slice(body, dataStart, dataStart + frameLength).ToAsciiString())
        cursor = dataStart + frameLength
    end while
    return frames
end function
function __LoungeBackchannel_method_Receive(frames as object) as dynamic
    commands = []
    for each frame in frames
        entries = StringUtils_ParseJsonSafe(frame)
        if not IsArray(entries)
            LogTelemetryEvent({
                level: "error"
                message: "Lounge frame did not parse to a command array: " + frame.Left(256)
                fingerprint: "lounge-unparseable-frame"
            })
            continue for
        end if
        for each entry in entries
            if not IsArray(entry) or entry.Count() = 0 or not IsInt(entry[0])
                m.LogMalformedCommand(entry)
                continue for
            end if
            index = entry[0]
            if index <= m.ackedCommandIndex
                
                continue for
            end if
            
            m.ackedCommandIndex = index
            data = entry[1]
            if not IsArray(data) or data.Count() = 0 or not IsString(data[0])
                m.LogMalformedCommand(entry)
                continue for
            end if
            commands.Push({
                index: index
                type: data[0]
                args: data[1]
            })
        end for
    end for
    return commands
end function
function __LoungeBackchannel_method_LogMalformedCommand(entry as dynamic) as void
    LogTelemetryEvent({
        level: "error"
        message: "Malformed lounge command: " + FormatJson(entry).Left(256)
        fingerprint: "lounge-malformed-command"
    })
end function
function __LoungeBackchannel_builder()
    instance = {}
    instance.new = __LoungeBackchannel_method_new
    ' A new session restarts command indices from 0.
    instance.StartSession = __LoungeBackchannel_method_StartSession
    instance.Open = __LoungeBackchannel_method_Open
    instance.Close = __LoungeBackchannel_method_Close
    instance.IsPolling = __LoungeBackchannel_method_IsPolling
    instance.MaxWaitMs = __LoungeBackchannel_method_MaxWaitMs
    instance.Handle = __LoungeBackchannel_method_Handle
    ' Frame = `<byteLength>\n<json>`, the length counted in BYTES. The answer is complete, so a malformed or cut-off
    ' frame ends the extraction: no later read can complete it.
    instance.ExtractFrames = __LoungeBackchannel_method_ExtractFrames
    instance.Receive = __LoungeBackchannel_method_Receive
    instance.LogMalformedCommand = __LoungeBackchannel_method_LogMalformedCommand
    return instance
end function
function LoungeBackchannel()
    instance = __LoungeBackchannel_builder()
    instance.new()
    return instance
end function