'import "pkg:/components/Services/LoungeService/LoungeService.types.bs"


function LoungeSession_StepAfterPoll(closeReason as object, statusCode as integer, stalledPolls as integer, sessionGone as boolean, tokenExpired as boolean, msSinceDelivered as integer) as object
    
    needsRebind = statusCode = 400 or statusCode = 410 or sessionGone or stalledPolls > 1
    needsNewToken = statusCode = 401 or tokenExpired
    if closeReason = "complete" and not needsRebind and not needsNewToken
        return "poll"
    end if
    if msSinceDelivered >= 300000
        return "drop"
    end if
    if needsNewToken
        return "rebind_with_new_token"
    end if
    if needsRebind
        return "rebind"
    end if
    return "retry"
end function