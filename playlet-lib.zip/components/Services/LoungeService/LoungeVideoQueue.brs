'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/components/Services/LoungeService/LoungeConstants.bs"
'import "pkg:/components/VideoQueue/Notifications/VideoQueueNotificationUtils.bs"
function LoungeVideoQueue_SetPlaylist(videoQueueNode as object, invService as object, playlistData as object)
    LoungeVideoQueue_HandleLoungePlaylist(videoQueueNode, invService, playlistData)
end function

function LoungeVideoQueue_UpdatePlaylist(videoQueueNode as object, invService as object, playlistData as object)
    LoungeVideoQueue_HandleLoungePlaylist(videoQueueNode, invService, playlistData)
end function

function LoungeVideoQueue_HandleLoungePlaylist(videoQueueNode as object, invService as object, playlistData as object) as void
    videoIds = playlistData["videoIds"]
    if StringUtils_IsNullOrEmpty(videoIds)
        videoQueueNode.clearQueue = true
        return
    end if
    videoIds = videoIds.Split(",")
    queueContent = videoQueueNode.content
    currentQueueNodes = queueContent.getChildren(-1, 0)
    queueNodesDict = {}
    for each node in currentQueueNodes
        queueNodesDict[node.id] = node
    end for
    instance = invalid
    newQueueNodes = []
    for each vId in videoIds
        if queueNodesDict.DoesExist(vId)
            newQueueNodes.Push(queueNodesDict[vId])
        else
            payload = LoungeVideoQueue_CreateVideoPayload(vId)
            if instance = invalid
                instance = invService.GetInstance()
            end if
            contentNode = InvidiousContent_ToVideoContentNode(invalid, payload, instance)
            newQueueNodes.Push(contentNode)
        end if
    end for
    index = -1
    currentIndex = playlistData["currentIndex"]
    if IsString(currentIndex)
        currentIndex = CInt(Val(currentIndex))
        index = currentIndex
    else
        index = videoQueueNode.index
    end if
    videoQueueNode.setQueueAndIndex = {
        videoNodes: newQueueNodes
        index: index
    }
    videoId = playlistData["videoId"]
    timestamp = playlistData["currentTime"]
    if not StringUtils_IsNullOrEmpty(videoId)
        if not StringUtils_IsNullOrEmpty(timestamp)
            timestamp = CInt(Val(timestamp))
            if timestamp > 0
                node = newQueueNodes[index]
                node.timestamp = timestamp
            end if
        end if
        videoQueueNode.play = true
    end if
    if StringUtils_IsNullOrEmpty(videoId)
        
        eventDetails = playlistData["eventDetails"]
        if IsString(eventDetails)
            eventDetails = StringUtils_ParseJsonSafe(eventDetails)
        end if
        if eventDetails <> invalid and eventDetails["eventType"] = "VIDEO_ADDED"
            eventVideoId = eventDetails["videoId"]
            if not StringUtils_IsNullOrEmpty(eventVideoId)
                preferences = videoQueueNode.preferences
                queueNotifications = preferences["misc.queue_notifications"]
                if queueNotifications
                    payload = LoungeVideoQueue_CreateVideoPayload(eventVideoId)
                    if instance = invalid
                        instance = invService.GetInstance()
                    end if
                    node = InvidiousContent_ToVideoContentNode(invalid, payload, instance)
                    notifications = videoQueueNode.notifications
                    hintVisible = videoQueueNode.player = invalid or not videoQueueNode.videoContainer.fullscreen
                    VideoQueue_ShowNotifcation(notifications, node, hintVisible)
                end if
            end if
        end if
    end if
end function

function LoungeVideoQueue_CreateVideoPayload(videoId as string) as object
    return {
        "type": "video"
        "videoId": videoId
        "videoThumbnails": [
            {
                "quality": "maxres"
                "url": ("https://i.ytimg.com/vi/" + bslib_toString(videoId) + "/maxresdefault.jpg")
                "width": 1280
                "height": 720
            }
            {
                "quality": "sddefault"
                "url": ("https://i.ytimg.com/vi/" + bslib_toString(videoId) + "/sddefault.jpg")
                "width": 640
                "height": 480
            }
            {
                "quality": "high"
                "url": ("https://i.ytimg.com/vi/" + bslib_toString(videoId) + "/hqdefault.jpg")
                "width": 480
                "height": 360
            }
            {
                "quality": "medium"
                "url": ("https://i.ytimg.com/vi/" + bslib_toString(videoId) + "/mqdefault.jpg")
                "width": 320
                "height": 180
            }
        ]
    }
end function