'import "pkg:/components/parts/AutoBind/OnNodeReadyNoOp.bs"
'import "pkg:/components/Services/LoungeService/LoungeApi.bs"
'import "pkg:/components/Services/LoungeService/LoungeService.types.bs"
'import "pkg:/components/Services/LoungeService/LoungeSession.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.top.functionName = "LoungeServiceLoop"
    deviceInfo = CreateObject("roDeviceInfo")
    m.top.deviceId = deviceInfo.GetRandomUUID()
    deviceFriendlyName = deviceInfo.GetFriendlyName()
    if StringUtils_IsNullOrEmpty(deviceFriendlyName)
        deviceFriendlyName = "TV"
    end if
    m.top.deviceName = "Playlet on " + deviceFriendlyName
end function

function StartService(_unused as dynamic) as boolean
    if m.top.isRunning = true
        return true
    end if
    m.top.isRunning = true
    m.top.control = "run"
    return true
end function

function StopService(_unused as dynamic) as void
    if m.top.isRunning = false
        return
    end if
    m.top.shouldQuit = true
end function

function LoungeServiceLoop() as void
    messagePort = CreateObject("roMessagePort")
    m.top.observeField("shouldQuit", messagePort)
    api = LoungeApi(m.top, m.top.videoQueue, m.top.notifications, m.top.invidious, messagePort)
    
    api.DisconnectFromLastLounge()
    
    while WaitForJoin(messagePort)
        quitRequested = RunSession(api, messagePort)
        api.EndSession()
        m.top.unobserveField("outgoingMessages")
        m.top.loungeToken = ""
        if quitRequested
            exit while
        end if
    end while
    LogInfo2("[LoungeService.bs:58]", "Lounge service stopped")
    m.top.unobserveField("shouldQuit")
    m.top.isRunning = false
end function

function WaitForJoin(messagePort as object) as boolean
    m.top.observeField("join", messagePort)
    joinRequested = false
    while true
        message = wait(0, messagePort)
        if IsQuitRequested([
            message
        ])
            exit while
        end if
        if type(message) = "roSGNodeEvent" and message.GetField() = "join"
            joinRequested = true
            exit while
        end if
    end while
    m.top.unobserveField("join")
    return joinRequested
end function

function RunSession(api as object, messagePort as object) as boolean
    screenId = api.GetScreenId()
    if StringUtils_IsNullOrEmpty(screenId)
        LogInfo2("[LoungeService.bs:83]", "Lounge session ended: no screen ID")
        return false
    end if
    m.top.screenId = screenId
    loungeToken = api.GetToken()
    if StringUtils_IsNullOrEmpty(loungeToken)
        LogInfo2("[LoungeService.bs:90]", "Lounge session ended: no lounge token")
        return false
    end if
    m.top.loungeToken = loungeToken
    m.top.observeField("outgoingMessages", messagePort)
    if not api.Bind()
        LogInfo2("[LoungeService.bs:98]", "Lounge session ended: bind failed")
        return false
    end if
    api.StartPoll()
    backchannel = api.backchannel
    reconnectAttempts = 0
    sinceDelivered = CreateObject("roTimespan")
    outgoingLoungeMessages = []
    portMessages = []
    while true
        portMessages.Clear()
        portMessages.Push(wait(api.MaxWaitMs(), messagePort))
        
        while messagePort.PeekMessage() <> invalid
            portMessages.Push(messagePort.GetMessage())
        end while
        if IsQuitRequested(portMessages)
            return true
        end if
        
        outgoingLoungeMessages.Clear()
        for each portMessage in portMessages
            if type(portMessage) = "roSGNodeEvent" and portMessage.GetField() = "outgoingMessages"
                outgoingLoungeMessages.Append(portMessage.GetData())
            end if
            api.HandleMessage(portMessage, outgoingLoungeMessages)
        end for
        api.SendMessages(outgoingLoungeMessages)
        if backchannel.IsPolling()
            continue while
        end if
        if backchannel.closeReason = "complete"
            sinceDelivered.Mark()
        end if
        
        nextStep = LoungeSession_StepAfterPoll(backchannel.closeReason, backchannel.statusCode, backchannel.stalledPolls, api.sessionGone, api.tokenExpired, sinceDelivered.TotalMilliseconds())
        if nextStep = "poll"
            reconnectAttempts = 0
            api.StartPoll()
            continue while
        end if
        
        if nextStep = "drop"
            LogTelemetryEvent({
                level: "error"
                message: ("Lounge session dropped: no poll delivered for " + bslib_toString(sinceDelivered.TotalSeconds()) + " s, last close: " + bslib_toString(backchannel.closeReason) + " " + bslib_toString(backchannel.statusCode))
                fingerprint: [
                    "lounge-session-dropped"
                    backchannel.closeReason
                    backchannel.statusCode
                ]
            })
            return false
        end if
        if nextStep = "retry" and backchannel.closeReason <> "timeout"
            LogTelemetryEvent({
                level: "warning"
                message: ("Lounge backchannel failure: " + bslib_toString(backchannel.closeReason) + " " + bslib_toString(backchannel.statusCode))
                fingerprint: [
                    "lounge-backchannel"
                    backchannel.closeReason
                    backchannel.statusCode
                ]
            })
        end if
        sleep(ComputeReconnectBackoffMs(reconnectAttempts))
        reconnectAttempts += 1
        if nextStep <> "retry"
            if not api.Rebind(nextStep = "rebind_with_new_token")
                LogInfo2("[LoungeService.bs:175]", "Lounge session ended: rebind failed")
                return false
            end if
            m.top.loungeToken = api.loungeToken
        end if
        api.StartPoll()
    end while
    return false
end function

function IsQuitRequested(portMessages as object) as boolean
    for each portMessage in portMessages
        if type(portMessage) = "roSGNodeEvent" and portMessage.GetField() = "shouldQuit" and portMessage.GetData() = true
            return true
        end if
    end for
    return false
end function

' Full jitter (random in [0, window)) avoids a fleet-wide thundering-herd reconnect.
function ComputeReconnectBackoffMs(attempts as integer) as integer
    capped = attempts
    if capped > 6
        capped = 6
    end if
    windowMs = 1000 * (2 ^ capped)
    if windowMs > 30000
        windowMs = 30000
    end if
    return 500 + Int(Rnd(0) * windowMs)
end function