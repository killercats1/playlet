'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

' TODO:P1 Web app support
' TODO:P1 Web apis and open api spec updates
'
' From the main screen:
'    When a video is selected:
'      - "Play" - DONE
'      - "Queue" - DONE
'      - "Open Channel" - DONE
'      - "Add to "Videos" bookmark" - DONE
'      - If video is already in a bookmark, "Remove from Bookmarks" - DONE
'
'    When a channel is selected:
'      - "Open" - DONE
'      - "Add to "Channels" bookmark" - DONE
'      - "Add to <ChannelName> bookmark" - DONE
'      - If channel is already in a bookmark, "Remove from Bookmarks" - DONE
'      - PlaylistId starting with "IV" cannot be added to a bookmark - DONE
'
'    When a playlist is selected:
'      - "Play" - DONE
'      - "Queue" - DONE
'      - "Open" - DONE
'      - "Add to "Playlists" bookmark" - DONE
'      - "Add to <PlaylistName> bookmark" - DONE
'      - If playlist is already in a bookmark, "Remove from Bookmarks" - DONE
'    When any:
'      - "Reload feed" - DONE
'
' From Playlist view:
'    When a video is selected:
'      - "Play" - DONE
'      - "Queue" - DONE
'      - "Play video" - DONE
'      - "Queue video" - DONE
'      - "Open Channel" - DONE
'      - "Add to "Playlists" bookmark" - DONE
'      - "Add to <PlaylistName> bookmark" - DONE
'      - "Add to "Videos" bookmark" - DONE
'
' From Channel view:
'    When a video is selected:
'      - "Play" - DONE
'      - "Queue" - DONE
'      - "Add to "Channels" bookmark" - DONE
'      - "Add to <ChannelName> - <feed> bookmark" feed being latest videos, live, shorts, etc - DONE
'      - "Add to "Videos" bookmark" - DONE
'
'    When a playlist is selected:
'      - "Play" - DONE
'      - "Queue" - DONE
'      - "Open" - DONE
'      - "Add to "Channels" bookmark" - DONE
'      - "Add to <ChannelName> - <feed> bookmark" feed being latest videos, live, shorts, etc - DONE
'      - "Add to "Playlists" bookmark" - DONE
'      - "Add to <PlaylistName> bookmark" - DONE
'
' From search view:
'    When a video/channel/playlist is selected:
'      - Inherit options - DONE
'      - "Add to "Search - ${q}" bookmark" - this includes the search filters used - DONE
'
' From bookmarks view:
'    When a video/channel/playlist is selected:
'      - Inherit options
'      - "Remove item from Bookmarks"
'      - "Remove group from Bookmarks"
'      - "Reload bookmarks" - DONE
'
' TODO:P1 Context menu might need sections. Example:
' In a Channel view, while selecting a playlist:
'    - Channel
'      - Add to "Channels" bookmark
'      - Other "Channels" related context menu items
'    - Playlist
'      - Add to "Playlists" bookmark
'      - "Play/Queue"
'      - Other "Playlists" related context menu items
function Init()
    m.optionsList = m.top.findNode("optionsList")
    m.showAnimation = m.top.findNode("showAnimation")
end function

function Show(_unused as dynamic)
    m.optionsList.ObserveField("itemSelected", FuncName(OnItemSelected))
    m.showAnimation.control = "start"
end function

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.optionsList, true)
end function

function OnOptionsSet() as void
    options = m.top.options
    if options = invalid
        return
    end if
    content = CreateObject("roSGNode", "ContentNode")
    for each option in options
        optionNode = CreateObject("roSGNode", "ContentNode")
        optionNode.title = option.title
        content.appendChild(optionNode)
    end for
    m.optionsList.content = content
end function

function OnItemSelected(event as object) as void
    index = event.getData()
    button = m.optionsList.content.getChild(index)
    Close()
    LogInfo3("[ContextMenu.bs:121]", "Menu button selected:", button.title)
    options = m.top.options
    if index >= options.count()
        LogError3("[ContextMenu.bs:125]", "Menu button index out of range:", index)
        return
    end if
    option = options[index]
    node = option.node
    func = option.func
    args = option.args
    if node = invalid or StringUtils_IsNullOrEmpty(func) or args = invalid
        LogError2("[ContextMenu.bs:136]", "Menu button action is invalid")
        return
    end if
    if args.count() = 1
        node.callFunc(func, args[0])
    else if args.count() = 2
        node.callFunc(func, args[0], args[1])
    else if args.count() = 3
        node.callFunc(func, args[0], args[1], args[2])
    else if args.count() = 4
        node.callFunc(func, args[0], args[1], args[2], args[3])
    else if args.count() = 5
        node.callFunc(func, args[0], args[1], args[2], args[3], args[4])
    else
        LogError2("[ContextMenu.bs:151]", "Menu button action has too many arguments")
    end if
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if press = false
        return false
    end if
    if key = "back"
        Close()
        return true
    end if
    if key = "up"
        m.optionsList.jumpToItem = m.optionsList.content.getChildCount() - 1
        return true
    end if
    if key = "down"
        m.optionsList.jumpToItem = 0
        return true
    end if
    return false
end function

function Close()
    m.top.appController.callfunc("PopScreen", invalid)
end function