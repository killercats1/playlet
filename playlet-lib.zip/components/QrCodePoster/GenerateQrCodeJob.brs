'import "pkg:/source/QrCode/QrImage.bs"
'import "pkg:/source/QrCode/QrMode.bs"
'import "pkg:/source/utils/StringUtils.bs"

function ExecuteJob() as void
    input = JobGetInput()
    poster = input.poster
    mode = input.mode
    text = input.text
    size = input.size
    padding = input.padding
    if mode = invalid
        mode = 4
    end if
    if size = invalid
        size = 200
    end if
    if padding = invalid
        padding = 0
    end if
    qr = QrCode_QRImage()
    imagePath = qr.Generate(text, size, padding, mode)
    if JobIsCancelled()
        JobCancel()
        return
    end if
    if not StringUtils_IsNullOrEmpty(imagePath)
        poster.uri = imagePath
    end if
end function