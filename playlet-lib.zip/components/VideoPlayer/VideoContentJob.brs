'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.bs"
'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/Services/Innertube/InnertubeService.bs"
'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/source/utils/CancellationUtils.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/MessagePortUtils.bs"


function ExecuteJob() as void
    input = JobGetInput()
    contentNode = input.content
    invidiousNode = input.invidious
    innertubeNode = input.innertube
    preferencesNode = input.preferences
    loungeServiceNode = input.loungeService
    playletServerPort = input.playletServerPort
    profilesService = input.profilesService
    if JobIsCancelled()
        JobCancel()
        return
    end if
    if preferencesNode["backend.selected"] = "invidious" and StringUtils_IsNullOrEmpty(preferencesNode["invidious.instance"])
        SwitchBackendToPlaylet(preferencesNode)
    end if
    DeleteFile("cachefs:/last_generated_dash.xml")
    DeleteFile("cachefs:/last_generated_hls.m3u8")
    if StringUtils_IsNullOrEmpty(contentNode.videoId)
        JobError("Can't load video information: videoId is missing")
        return
    end if
    service = Invidious_InvidiousService(invidiousNode)
    backend = preferencesNode["backend.selected"]
    backendId = ResolveBackendId(backend, service)
    contentNode.addFields({
        backend: backendId
    })
    contentNode.backend = backendId
    cancellation = JobGetCancellation()
    if backend = "playlet"
        sessionData = GetSessionData(innertubeNode, cancellation)
        if sessionData.cancel = true
            JobCancel()
            return
        end if
        if sessionData.error <> invalid
            JobError(sessionData.error)
            return
        end if
        accessToken = invalid
        onBehalfOfUser = invalid
        profileNode = invalid
        profile = profilesService.currentProfile
        if profile <> invalid and profile.type = "youtube"
            auth = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(profile)
            if auth.state = "NeedsReauth"
                JobError("The session has expired. Please sign in again with this profile, or switch to another profile.")
                return
            end if
            if auth.state = "Ok"
                accessToken = auth.token
                onBehalfOfUser = auth.activeIdentifyToken
                profileNode = profile
            end if
        end if
        metadata = InnertubeService_GetVideoMetadata(contentNode.videoId, {
            "cancellation": cancellation
            "credentialTransferToken": loungeServiceNode.credentialTransferToken
            "visitorData": sessionData.visitorData
            "livingRoomPoTokenId": sessionData.livingRoomPoTokenId
            "accessToken": accessToken
            "onBehalfOfUser": onBehalfOfUser
            "profileNode": profileNode
            "profilesService": profilesService
        })
        if IsAssociativeArray(metadata)
            contentNode.addFields({
                potAttached: ValidBool(metadata.potAttached)
                potSource: ValidString(metadata.potSource)
                loggedIn: not StringUtils_IsNullOrEmpty(accessToken)
            })
        end if
    else
        metadata = service.GetVideoMetadata(contentNode.videoId, {
            cancellation: m.top.cancellation
        })
    end if
    if JobIsCancelled()
        JobCancel()
        return
    end if
    if metadata = invalid
        JobError("Failed to get video metadata")
        return
    end if
    title = metadata.title
    if not StringUtils_IsNullOrEmpty(title)
        contentNode.title = title
    end if
    author = metadata.author
    if not StringUtils_IsNullOrEmpty(author)
        contentNode.secondaryTitle = metadata.author
    end if
    contentNode.live = metadata.liveNow
    
    videoLoadId = StringUtils_RandomId()
    if metadata.error <> invalid
        
        contentNode.addFields({
            metadata: metadata
            videoLoadId: videoLoadId
        })
        JobError(metadata.error)
        return
    end if
    streamSource = SelectStreamSource(metadata)
    streamUrls = CreateStreamUrls(streamSource, metadata, videoLoadId, service, preferencesNode, backend, playletServerPort)
    if streamUrls.Count() = 0
        contentNode.addFields({
            metadata: metadata
            videoLoadId: videoLoadId
        })
        error = "No playable streams found for this video."
        lastPlayerResponse = ValidString(ReadAsciiFile("cachefs:/last_player_response.json"))
        LogTelemetryEvent({
            level: "error"
            message: error
            fingerprint: error
            attachments: [
                {
                    filename: "last_player_response.json"
                    content_type: "application/json"
                    data: lastPlayerResponse
                }
            ]
        })
        JobError(error)
        return
    end if
    isDrm = not StringUtils_IsNullOrEmpty(metadata.drmParams)
    if isDrm
        licenseServerURL = UrlUtils_BuildUrl(("http://127.0.0.1:" + bslib_toString(playletServerPort) + "/api/innertube/get_drm_license"), invalid, {
            videoId: metadata.videoId
            videoLoadId: videoLoadId
            drmParams: metadata.drmParams
            drmSessionId: metadata.drmSessionId
            cpn: metadata.cpn
        })
        contentNode.drmParams = {
            keySystem: "Widevine"
            licenseServerURL: licenseServerURL
        }
    end if
    
    contentNode.ForwardQueryStringParams = false
    contentNode.addFields({
        metadata: metadata
        videoLoadId: videoLoadId
        ' StreamUrls is taken
        playletStreamUrls: streamUrls
        playletStreamUrlIndex: 0
        playletStreamSource: streamSource
    })
    firstUrl = streamUrls[0]
    
    if StringUtils_IsNullOrEmpty(firstUrl)
        LogError2("[VideoContentJob.bs:185]", "First stream URL is empty!")
    end if
    contentNode.url = firstUrl
    SetCaptions(metadata, service, contentNode)
    if metadata.liveNow = true
        contentNode.Live = true
    end if
end function

function GetSessionData(innertubeNode as object, cancellation as object) as object
    sessionData = innertubeNode.sessionData
    if SessionDataComplete(sessionData)
        return sessionData
    end if
    callback = innertubeNode.callFunc("EnsureSessionDataJob", invalid)
    port = CreateObject("roMessagePort")
    MessagePortUtils_ObserveFieldScopedExSafe(innertubeNode, "sessionData", port)
    MessagePortUtils_ObserveFieldScopedExSafe(callback, "done", port)
    CancellationUtils_ObserveCancellationScoped(cancellation, port)
    cancelled = false
    while not SessionDataComplete(innertubeNode.sessionData) and callback.done <> true
        message = wait(30000, port)
        if message = invalid
            exit while
        end if
        if CancellationUtils_IsCancellationEvent(cancellation, message)
            cancelled = true
            exit while
        end if
    end while
    innertubeNode.unobserveFieldScoped("sessionData")
    callback.unobserveFieldScoped("done")
    CancellationUtils_UnobserveCancellationScoped(cancellation)
    if cancelled
        return {
            cancel: true
        }
    end if
    sessionData = innertubeNode.sessionData
    if SessionDataComplete(sessionData)
        return sessionData
    end if
    return {
        error: "Failed to get session data. Please try again later."
    }
end function

function SessionDataComplete(sessionData as object) as boolean
    return IsAssociativeArray(sessionData) and not StringUtils_IsNullOrEmpty(sessionData.visitorData) and not StringUtils_IsNullOrEmpty(sessionData.livingRoomPoTokenId)
end function

function SwitchBackendToPlaylet(preferencesNode as object) as void
    preferencesNode["backend.selected"] = "playlet"
    dialog = DialogUtils_ShowDialogEx({
        title: Tr("Backend changed")
        message: Tr("Backend changed to Playlet, because no Invidious instance is set.")
    })
    if dialog = invalid
        return
    end if
    port = CreateObject("roMessagePort")
    MessagePortUtils_ObserveFieldScopedExSafe(dialog, "wasClosed", port)
    wait(0, port)
    dialog.unobserveFieldScoped("wasClosed")
end function

function ResolveBackendId(backend as string, service as object) as string
    if backend = "playlet"
        return "playlet"
    end if
    if service.GetInstance() = "http://127.0.0.1:8888/playlet-invidious-backend"
        return "built-in"
    end if
    return "invidious"
end function

function SelectStreamSource(metadata as object) as string
    if SupportsDrmDashManifestUrl(metadata)
        return "dashUrl"
    else if SupportsDash(metadata)
        return "adaptiveFormats"
    else if SupportsMuxedFormats(metadata)
        return "formatStreams"
    else if SupportsHls(metadata)
        return "hlsUrl"
    end if
    return ""
end function

function CreateStreamUrls(source as string, metadata as object, videoLoadId as string, service as object, preferences as object, backend as string, playletServerPort as integer) as object
    instance = service.GetInstance()
    proxyVideos = preferences["invidious.proxy_videos"]
    preferredQuality = preferences["playback.preferred_quality"]
    streamUrls = []
    if source = "dashUrl"
        dashUrl = UrlUtils_AppendQueryParams(("http://127.0.0.1:" + bslib_toString(playletServerPort) + "/api/dash"), {
            url: metadata.dashUrl
        })
        streamUrls.push(dashUrl)
    else if source = "adaptiveFormats"
        AddDashUrls(streamUrls, metadata, videoLoadId, preferredQuality, backend, proxyVideos, playletServerPort)
    else if source = "formatStreams"
        for each stream in metadata.formatStreams
            if StringUtils_IsNullOrEmpty(stream.url)
                continue for
            end if
            stream.url = AddInstanceToUrlIfNeeded(stream.url, instance)
            streamUrls.push(stream.url)
        end for
    else if source = "hlsUrl"
        metadata.hlsUrl = AddInstanceToUrlIfNeeded(metadata.hlsUrl, instance)
        AddHlsUrls(streamUrls, metadata, preferredQuality, backend, proxyVideos, playletServerPort)
    end if
    return streamUrls
end function

function SupportsHls(metadata as object) as boolean
    return not StringUtils_IsNullOrEmpty(metadata.hlsUrl)
end function

function SupportsDash(metadata as object) as boolean
    if not IsArray(metadata.adaptiveFormats) or metadata.adaptiveFormats.Count() = 0
        return false
    end if
    for each fmt in metadata.adaptiveFormats
        if not StringUtils_IsNullOrEmpty(fmt.url)
            return true
        end if
    end for
    return false
end function

function SupportsMuxedFormats(metadata as object) as boolean
    return IsArray(metadata.formatStreams) and metadata.formatStreams.Count() > 0
end function

function SupportsDrmDashManifestUrl(metadata as object) as boolean
    if StringUtils_IsNullOrEmpty(metadata.drmParams)
        return false
    end if
    if StringUtils_IsNullOrEmpty(metadata.dashUrl)
        return false
    end if
    if StringUtils_IsNullOrEmpty(metadata.drmSessionId)
        return false
    end if
    if StringUtils_IsNullOrEmpty(metadata.cpn)
        return false
    end if
    if not IsArray(metadata.licenseInfos) or metadata.licenseInfos.Count() = 0
        return false
    end if
    return true
end function

function AddHlsUrls(streamUrls as object, metadata as object, preferredQuality as string, backend as string, proxyVideos as string, playletServerPort as integer)
    hlsUrl = metadata.hlsUrl
    hlsUrlLocal = invalid
    hlsUrlFiltered = invalid
    hlsUrlFilteredLocal = invalid
    supportsProxying = backend <> "playlet"
    hasQuality = not StringUtils_IsNullOrEmpty(preferredQuality) and preferredQuality <> "auto"
    if supportsProxying
        hlsUrlLocal = UrlUtils_AppendQueryParams(hlsUrl, {
            local: "true"
        })
    end if
    
    hlsUrl = UrlUtils_AppendQueryParams(("http://127.0.0.1:" + bslib_toString(playletServerPort) + "/api/hls"), {
        url: hlsUrl
        v: metadata.videoId
    })
    if supportsProxying
        hlsUrlLocal = UrlUtils_AppendQueryParams(("http://127.0.0.1:" + bslib_toString(playletServerPort) + "/api/hls"), {
            url: hlsUrlLocal
            v: metadata.videoId
        })
    end if
    if hasQuality
        hlsUrlFiltered = UrlUtils_AppendQueryParams(hlsUrl, {
            quality: preferredQuality
        })
        if supportsProxying
            hlsUrlFilteredLocal = UrlUtils_AppendQueryParams(hlsUrlLocal, {
                quality: preferredQuality
            })
        end if
    end if
    AddUrls(streamUrls, hlsUrl, hlsUrlLocal, hlsUrlFiltered, hlsUrlFilteredLocal, proxyVideos)
end function

function AddDashUrls(streamUrls as object, metadata as object, videoLoadId as string, preferredQuality as string, backend as string, proxyVideos as string, playletServerPort as integer) as void
    
    dashUrl = UrlUtils_AppendQueryParams(("http://127.0.0.1:" + bslib_toString(playletServerPort) + "/api/dash"), {
        v: metadata.videoId
        "videoLoadId": videoLoadId
    })
    dashUrlLocal = invalid
    dashUrlFiltered = invalid
    dashUrlFilteredLocal = invalid
    supportsProxying = backend <> "playlet"
    hasQuality = not StringUtils_IsNullOrEmpty(preferredQuality) and preferredQuality <> "auto"
    if supportsProxying
        dashUrlLocal = UrlUtils_AppendQueryParams(dashUrl, {
            local: "true"
        })
    end if
    if hasQuality
        dashUrlFiltered = UrlUtils_AppendQueryParams(dashUrl, {
            quality: preferredQuality
        })
        if supportsProxying
            dashUrlFilteredLocal = UrlUtils_AppendQueryParams(dashUrlLocal, {
                quality: preferredQuality
            })
        end if
    end if
    AddUrls(streamUrls, dashUrl, dashUrlLocal, dashUrlFiltered, dashUrlFilteredLocal, proxyVideos)
end function

function AddUrls(streamUrls as object, url as string, urlLocal as dynamic, urlFiltered as dynamic, urlFilteredLocal as dynamic, proxyVideos as string)
    if proxyVideos = "if_needed"
        if urlFiltered <> invalid
            streamUrls.push(urlFiltered)
        end if
        streamUrls.push(url)
        if urlFilteredLocal <> invalid
            streamUrls.push(urlFilteredLocal)
        end if
        if urlLocal <> invalid
            streamUrls.push(urlLocal)
        end if
    else if proxyVideos = "never"
        if urlFiltered <> invalid
            streamUrls.push(urlFiltered)
        end if
        streamUrls.push(url)
    else if proxyVideos = "always"
        if urlFilteredLocal <> invalid
            streamUrls.push(urlFilteredLocal)
        end if
        if urlLocal <> invalid
            streamUrls.push(urlLocal)
        end if
    end if
    if streamUrls.Count() = 0
        if urlFiltered <> invalid
            streamUrls.push(urlFiltered)
        end if
        streamUrls.push(url)
        if urlFilteredLocal <> invalid
            streamUrls.push(urlFilteredLocal)
        end if
        if urlLocal <> invalid
            streamUrls.push(urlLocal)
        end if
    end if
end function

function AddInstanceToUrlIfNeeded(url as dynamic, instance as string) as dynamic
    if IsString(url) and url.StartsWith("/")
        return instance + url
    end if
    return url
end function

function SetCaptions(metadata as object, service as object, contentNode as object) as void
    if metadata.captions.Count() = 0
        return
    end if
    isoLanguageList = StringUtils_ParseJsonSafe(ReadAsciiFile("libpkg:/config/ISO-639-1-to-ISO-639-2T.json5"))
    if not IsAssociativeArray(isoLanguageList)
        LogError2("[VideoContentJob.bs:474]", "Failed to load ISO-639 language map; skipping captions")
        return
    end if
    instance = service.GetInstance()
    subtitleTracks = []
    for each caption in metadata.captions
        code = caption.language_code
        if StringUtils_IsNullOrEmpty(code)
            continue for
        end if
        if code.InStr("-") <> -1
            code = code.Split("-")[0]
        end if
        if code.len() = 2
            if not isoLanguageList.DoesExist(code)
                continue for
            end if
            code = isoLanguageList[code]
        end if
        url = caption.url
        if not url.StartsWith("http")
            url = instance + url
        end if
        subtitleTracks.Push({
            Description: caption.label
            Language: code
            TrackName: url
        })
    end for
    contentNode.ClosedCaptions = True
    contentNode.SubtitleTracks = subtitleTracks
end function