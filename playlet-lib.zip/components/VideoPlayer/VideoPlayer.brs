'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.types.bs"
'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/Services/Innertube/Constants.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/components/VideoPlayer/Lounge.bs"
'import "pkg:/components/VideoPlayer/SponsorBlock.bs"
'import "pkg:/components/VideoPlayer/VideoPlayerStyle.bs"
'import "pkg:/components/VideoQueue/VideoQueueUtils.bs"
'import "pkg:/source/utils/ErrorUtils.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"


function Init()
    InitializeBindings() ' auto-generated!
    SetPlayerStyle()
    SetupAnimation()
    m.fullScreenHint = m.top.findNode("fullScreenHint")
    m.fullScreenHintLabel = m.top.findNode("fullScreenHintLabel")
    m.fullScreenHintTimer = m.top.findNode("fullScreenHintTimer")
    m.fullScreenHintTimer.ObserveField("fire", FuncName(OnFullScreenHintTimer))
    m.trickplayUITimer = m.top.findNode("trickplayUITimer")
    m.trickplayUITimer.ObserveField("fire", FuncName(OnTrickplayUITimer))
    m.top.notificationInterval = 1
    
    m.videoPlayingSuccess = false
    
    m.ignoreNextFinishedState = false
    
    m.isSeekingPosition = false
    
    m.showUIEnabled = m.top.hasField("showUI")
    
    
    if m.top.hasField("asyncStopSemantics")
        m.top.asyncStopSemantics = true
    end if
    httpAgent = m.top.getHttpAgent()
    
    httpAgent.AddHeader("User-Agent", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:150.0) Gecko/20100101 Firefox/150.0")
end function

function OnNodeReady()
    minRect = m.top.minRect
    if m.container.fullscreen then
        rect = m.top.maxRect
    else
        rect = minRect
    end if
    m.top.width = rect.width
    m.top.height = rect.height
    m.top.translation = [
        rect.x
        rect.y
    ]
    m.fullScreenHint.width = minRect.width
    m.fullScreenHintLabel.width = minRect.width
    m.fullScreenHint.translation = [
        0
        minRect.height - m.fullScreenHint.height
    ]
    
    m.top.enableUI = m.container.fullscreen
    m.top.showFullScreenHint = not m.container.fullscreen
    m.container.observeFieldScoped("fullscreen", FuncName(OnFullScreenChange))
    m.top.ObserveField("state", FuncName(OnVideoPlayerStateChange))
    SponsorBlock_SetupSponsorBlock()
end function

function PlayWithContent(contentNode as object)
    videoContentNode = CreateObject("roSGNode", "ContentNode")
    if not StringUtils_IsNullOrEmpty(contentNode.videoId)
        videoContentNode.AddFields({
            videoId: contentNode.videoId
        })
    end if
    if ValidInt(contentNode.timestamp) <> -1
        videoContentNode.AddFields({
            timestamp: contentNode.timestamp
        })
    else if contentNode.percentDurationWatched > 0 and contentNode.percentDurationWatched < 100
        videoContentNode.AddFields({
            percentDurationWatched: contentNode.percentDurationWatched
        })
    end if
    if not StringUtils_IsNullOrEmpty(contentNode.title)
        videoContentNode.title = contentNode.title
    end if
    
    author = contentNode._author
    if StringUtils_IsNullOrEmpty(author)
        lines = contentNode.lines
        if IsArray(lines) and lines.Count() > 0
            author = lines[0]
        end if
    end if
    if not StringUtils_IsNullOrEmpty(author)
        videoContentNode.secondaryTitle = author
    end if
    metadata = contentNode.metadata
    if IsAssociativeArray(metadata)
        videoContentNode.AddFields({
            metadata: metadata
        })
    end if
    StartVideoContentJob(videoContentNode)
    playbackSpeed = ValidFloat(m.top.playbackSpeed)
    if playbackSpeed <= 0
        playbackSpeed = 1.0
    end if
    Lounge_SendNowPlayingLoading(contentNode.videoId, playbackSpeed)
end function

function StartVideoContentJob(videoContentNode as object)
    if m.videoContentJob <> invalid
        m.videoContentJob.cancel = true
    end if
    m.top.content = videoContentNode
    input = {
        content: videoContentNode
        invidious: m.top.invidious
        innertube: m.top.innertube
        preferences: m.top.preferences
        loungeService: m.top.loungeService
        playletServerPort: m.top.webServer.port
        profilesService: m.top.profilesService
    }
    m.videoContentJob = JobSystem_CreateCallback(OnVideoContentJobDone)
    JobSystem_QueueJob(m.jobQueue, "VideoContentJob", input, m.videoContentJob)
end function

function OnVideoContentJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.videoContentJob = invalid
    info = event.getInfo()
    if info.cancel or m.onCloseCalled = true
        return
    end if
    content = m.top.content
    if not info.success
        videoId = ""
        if content <> invalid
            videoId = content.videoId
        end if
        title = Tr("Video load error")
        message = Tr("Failed to load video information for %1").Replace("%1", videoId) + (chr(10) + bslib_toString(info.error))
        buttons = [
            Tr("Play next video")
            Tr("Cancel")
        ]
        dialog = DialogUtils_ShowTimedDialogButtons(message, title, buttons, 0, 10, true)
        if dialog <> invalid
            dialog.observeFieldScoped("wasClosed", FuncName(OnVideoContentJobErrorDialogResponse))
        else
            OnVideoContentJobErrorDialogResponse(invalid)
        end if
        Lounge_SendOnStateChange()
        return
    end if
    metadata = content.metadata
    SponsorBlock_FetchSponsorBlock(metadata)
    SeekToInitialPosition(content)
    PlayAfterPreviousPlayerHasStopped()
    MarkVideoWatched(content.videoId, metadata.playbackTrackingUrls, metadata.cpn)
end function

function SeekToInitialPosition(content as object) as void
    if content = invalid
        return
    end if
    
    if content.Live = true
        LogInfo2("[VideoPlayer.bs:249]", "Seeking to enge of live stream")
        m.top.seek = 999999
        return
    end if
    timestamp = ValidInt(content.timestamp)
    if timestamp > 0
        LogInfo3("[VideoPlayer.bs:256]", "Seeking to timestamp:", timestamp)
        m.top.seek = content.timestamp
        return
    end if
    percentDurationWatched = ValidFloat(content.percentDurationWatched)
    if percentDurationWatched > 0
        m.seekToPercent = percentDurationWatched
        SeekToPercentOfDuration()
    end if
end function

function SeekToPercentOfDuration() as void
    m.top.UnobserveField("duration")
    seekToPercent = m.seekToPercent
    if seekToPercent = invalid
        return
    end if
    duration = m.top.duration
    if duration = 0
        
        m.top.ObserveField("duration", FuncName(SeekToPercentOfDuration))
        return
    end if
    
    if duration < 30
        return
    end if
    m.seekToPercent = invalid
    seek = (MathUtils_Clamp(seekToPercent, 0, 100) / 100.0) * duration
    if seek > 0
        LogInfo3("[VideoPlayer.bs:291]", "Seeking to percent duration watched", seek)
        m.top.seek = seek
    end if
end function

function PlayAfterPreviousPlayerHasStopped() as void
    previousPlayer = m.top.previousPlayer
    m.top.previousPlayer = invalid
    
    m.previousPlayer = invalid
    if previousPlayer = invalid
        m.top.control = "play"
        return
    end if
    previousPlayerState = previousPlayer.state
    LogInfo3("[VideoPlayer.bs:309]", "Previous player state:", previousPlayerState)
    if previousPlayerState = "stopping"
        previousPlayer.observeFieldScoped("state", FuncName(OnPreviousPlayerState))
        return
    end if
    m.top.control = "play"
end function

function OnPreviousPlayerState(event as object) as void
    previousPlayer = event.getRoSGNode()
    if m.onCloseCalled = true
        previousPlayer.unobserveFieldScoped("state")
        return
    end if
    previousPlayerState = previousPlayer.state
    LogInfo3("[VideoPlayer.bs:328]", "Previous player state change:", previousPlayerState)
    if previousPlayerState = "stopped" or previousPlayerState = "error" or previousPlayerState = "finished" or previousPlayerState = "none"
        previousPlayer.unobserveFieldScoped("state")
        m.top.control = "play"
    end if
end function

function OnVideoContentJobErrorDialogResponse(event as object)
    shouldPlayNext = false
    if event <> invalid
        dialog = event.getRoSGNode()
        if m.errorDialog <> invalid and dialog.isSameNode(m.errorDialog)
            m.errorDialog = invalid
        end if
        dialog.unobserveFieldScoped("wasClosed")
        shouldPlayNext = dialog.actualButtonSelected = 0
    end if
    if not shouldPlayNext or not VideoQueueUtils_PlayNext(m.videoQueue, m.invidious, m.preferences)
        if m.top.isSameNode(m.videoQueue.player)
            m.videoQueue.closePlayer = true
        end if
    end if
end function

function MarkVideoWatched(videoId as dynamic, playbackTrackingUrls as dynamic, cpn as dynamic) as void
    if StringUtils_IsNullOrEmpty(videoId)
        return
    end if
    profile = m.top.profilesService.currentProfile
    if profile = invalid
        return
    end if
    if profile.authState = "NeedsReauth"
        return
    end if
    if m.markVideoWatchedJob <> invalid
        m.markVideoWatchedJob.cancel = true
    end if
    input = {
        videoId: videoId
        invidious: m.top.invidious
        profile: profile
        playbackTrackingUrls: playbackTrackingUrls
        cpn: cpn
    }
    m.markVideoWatchedJob = JobSystem_CreateCallback()
    m.markVideoWatchedJob.addField("watchTime", "float", false)
    JobSystem_QueueJob(m.jobQueue, "MarkVideoWatchedJob", input, m.markVideoWatchedJob)
    if profile.type <> "youtube"
        return
    end if
    
    m.watchTimeMarker = -1
    m.top.ObserveFieldScoped("position", FuncName(OnPositionChangeMarkWatchTime))
end function

function OnPositionChangeMarkWatchTime(event as object) as void
    if m.markVideoWatchedJob = invalid
        return
    end if
    currentPosition = event.getData()
    currentWatchTimeMarker = m.watchTimeMarker
    m.watchTimeMarker = (currentPosition \ 20) * 20
    if currentWatchTimeMarker = currentPosition
        return
    end if
    m.markVideoWatchedJob.watchTime = m.watchTimeMarker
end function

function OnSetSeek() as void
    m.top.seek = m.top.setSeek
end function

function OnClose()
    m.onCloseCalled = true
    m.top.previousPlayer = invalid
    if m.markVideoWatchedJob <> invalid
        m.markVideoWatchedJob.cancel = true
        m.markVideoWatchedJob = invalid
    end if
    if m.videoContentJob <> invalid
        m.videoContentJob.cancel = true
        m.videoContentJob = invalid
    end if
    if m.sponsorBlockSegmentsJob <> invalid
        m.sponsorBlockSegmentsJob.cancel = true
        m.sponsorBlockSegmentsJob = invalid
    end if
    parent = m.top.getParent()
    if parent <> invalid
        parent.RemoveChild(m.top)
    end if
    SponsorBlock_RemoveNotifcation(m.notifications)
    
    try
        m.top.control = "stop"
    catch error
        errorMessage = ErrorUtils_Format(error)
        LogError3("[VideoPlayer.bs:441]", "Error stopping video:", errorMessage)
        DialogUtils_ShowDialogEx({
            message: errorMessage
            title: Tr("Error closing video")
            large: true
        })
    end try
    m.top.content = invalid
end function

function OnVideoPlayerStateChange() as void
    Lounge_SendOnStateChange()
    state = m.top.state
    content = m.top.content
    
    if state = "playing"
        m.isSeekingPosition = false
        
        errorDialog = m.errorDialog
        if errorDialog <> invalid
            m.errorDialog = invalid
            errorDialog.unobserveFieldScoped("wasClosed")
            errorDialog.close = true
        end if
    end if
    
    if state = "playing" and not m.videoPlayingSuccess
        LogInfo2("[VideoPlayer.bs:474]", ("Now playing video " + bslib_toString(content.url)))
        m.videoPlayingSuccess = true
    end if
    errorData = invalid
    if state = "error"
        errorInfo = m.top.errorInfo
        errorData = GetPlayerErrorData(content.videoId, errorInfo)
        LogErrorNoTelemetry3("[VideoPlayer.bs:483]", errorData.title, errorData.body)
        if m.videoPlayingSuccess <> true
            
            if errorInfo.category = "http" or errorInfo.category = "mediaerror"
                playletStreamUrls = content.playletStreamUrls
                currentUrlIndex = content.playletStreamUrlIndex
                nextUrlIndex = currentUrlIndex + 1
                content.playletStreamUrlIndex = nextUrlIndex
                if nextUrlIndex < playletStreamUrls.Count()
                    currentUrl = content.url
                    nextUrl = playletStreamUrls[nextUrlIndex]
                    if StringUtils_IsNullOrEmpty(nextUrl)
                        LogError2("[VideoPlayer.bs:497]", "Next stream URL is empty, cannot try next stream")
                    end if
                    content.url = nextUrl
                    SeekToInitialPosition(content)
                    
                    m.ignoreNextFinishedState = true
                    m.top.control = "play"
                    timestamp = content.timestamp
                    hasTimestamp = IsInt(timestamp)
                    if hasTimestamp and timestamp > 0
                        m.top.seek = content.timestamp
                    end if
                    msg = ("Stream " + bslib_toString(currentUrl) + " failed to play. Trying next stream " + bslib_toString(nextUrl))
                    LogErrorNoTelemetry2("[VideoPlayer.bs:517]", msg)
                    errorData.title = msg + (chr(10)) + errorData.title
                    ReportVideoError(errorData, currentUrl, playletStreamUrls, currentUrlIndex, false)
                    return
                end if
            end if
        end if
    end if
    if state = "finished" and m.ignoreNextFinishedState = true
        m.ignoreNextFinishedState = false
        return
    end if
    if state = "finished"
        OnVideoFinished()
        return
    end if
    if state = "error"
        LogErrorNoTelemetry3("[VideoPlayer.bs:538]", errorData.title, errorData.body)
        ReportVideoError(errorData, content.url, content.playletStreamUrls, content.playletStreamUrlIndex, true)
        buttons = [
            Tr("Play next video")
            Tr("Cancel")
        ]
        dialog = DialogUtils_ShowTimedDialogButtons(errorData.body, errorData.title, buttons, 0, 10, true)
        if dialog <> invalid
            m.errorDialog = dialog
            dialog.observeFieldScoped("wasClosed", FuncName(OnVideoContentJobErrorDialogResponse))
        else
            OnVideoContentJobErrorDialogResponse(invalid)
        end if
        m.ignoreNextFinishedState = true
    end if
end function

function GetPlayerErrorData(videoId as string, errorInfo as object) as object
    if errorInfo = invalid
        return invalid
    end if
    errorMsg = m.top.errorMsg
    errorCode = m.top.errorCode
    errorStr = m.top.errorStr
    title = Tr("Error playing video %1").Replace("%1", videoId)
    body = ("errorMsg: " + bslib_toString(errorMsg) + chr(10) + "errorCode: " + bslib_toString(errorCode) + chr(10) + "errorStr: " + bslib_toString(errorStr))
    for each key in errorInfo
        body += (chr(10) + bslib_toString(key) + ": " + bslib_toString(errorInfo[key]))
    end for
    fingerprint = [
        "Error playing video %1"
        errorMsg
        errorCode
        errorInfo.source
        errorInfo.ignored
        errorInfo.category
        errorInfo.errcode
        errorInfo.drmerrcode
    ]
    return {
        title: title
        body: body
        fingerprint: fingerprint
    }
end function

function ReportVideoError(errorData as object, url as dynamic, urls as object, urlIndex as dynamic, shownInDialog as boolean) as void
    attachments = invalid
    if errorData.body.Instr("malformed data") <> -1 or errorData.body.Instr("invalid pathname") <> -1
        lastGeneratedDash = ValidString(ReadAsciiFile("cachefs:/last_generated_dash.xml"))
        lastGeneratedHls = ValidString(ReadAsciiFile("cachefs:/last_generated_hls.m3u8"))
        lastPlayerResponse = ValidString(ReadAsciiFile("cachefs:/last_player_response.json"))
        attachments = [
            {
                filename: "last_generated_dash.xml"
                content_type: "plain/text"
                data: lastGeneratedDash
            }
            {
                filename: "last_generated_hls.m3u8"
                content_type: "plain/text"
                data: lastGeneratedHls
            }
            {
                filename: "last_player_response.json"
                content_type: "application/json"
                data: lastPlayerResponse
            }
        ]
    end if
    position = m.top.position
    duration = m.top.duration
    videoLoadId = ""
    content = m.top.content
    if content <> invalid
        videoLoadId = ValidString(content.videoLoadId)
    end if
    message = [
        errorData.title
        errorData.body
        ("Dialog shown: " + bslib_toString(shownInDialog))
        ("Position: " + bslib_toString(position))
        ("Duration: " + bslib_toString(duration))
        ("Url: " + bslib_toString(url))
        "Urls: " + ToString(urls)
        ("Url index: " + bslib_toString(urlIndex))
        ("video_load_id: " + bslib_toString(videoLoadId))
    ].Join((chr(10)))
    errorData.fingerprint.push(shownInDialog)
    if shownInDialog
        level = "error"
    else
        level = "warning"
    end if
    LogTelemetryEvent({
        level: level
        message: message
        fingerprint: errorData.fingerprint
        attachments: attachments
    })
end function

function OnVideoFinished() as void
    if not VideoQueueUtils_PlayNext(m.videoQueue, m.invidious, m.preferences)
        m.videoQueue.closePlayer = true
    end if
end function

function IsLiveVideo() as boolean
    content = m.top.content
    return content <> invalid and content.Live = true
end function

function ShowUIAndStartTimer()
    if m.showUIEnabled
        m.top.showUI = {
            "show": true
            "trickPlaybar": true
            "titleAndTime": true
            "trickplayBackgroundOverlay": true
            "focusTrickplayBar": false
        }
        m.trickplayUITimer.control = "start"
    end if
end function

function HideUIAndStopTimer()
    if m.showUIEnabled
        m.top.showUI = {
            "show": false
            "focusTrickplayBar": false
        }
        m.trickplayUITimer.control = "stop"
    end if
end function

function HandleOKPress() as boolean
    if SponsorBlock_ManualSkipSegment()
        return false
    end if
    if not m.showUIEnabled
        return false
    end if
    handled = false
    state = m.top.state
    uiVisible = m.top.trickPlaybar.visible
    isLive = IsLiveVideo()
    
    if state = "playing"
        if not uiVisible
            
            ShowUIAndStartTimer()
        else if not isLive
            
            m.trickplayUITimer.control = "stop"
            m.top.control = "pause"
            ShowUIAndStartTimer()
        else
            HideUIAndStopTimer()
        end if
        handled = true
    else if state = "paused"
        
        if m.isSeekingPosition
            return false
        end if
        if not uiVisible
            
            ShowUIAndStartTimer()
        else
            
            HideUIAndStopTimer()
            m.top.control = "resume"
        end if
        handled = true
    end if
    return handled
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if press = false
        return false
    end if
    
    if key = "down"
        if VideoQueueUtils_ToggleVideoPictureInPicture(m.videoQueue)
            return true
        end if
    end if
    if key = "back"
        m.videoQueue.closePlayer = true
        return true
    end if
    if key = "OK"
        return HandleOKPress()
    end if
    if key = "left" or key = "right" or key = "rewind" or key = "fastforward"
        
        m.isSeekingPosition = true
    end if
    
    m.trickplayUITimer.control = "stop"
    return false
end function

function SetupAnimation()
    m.minimizeAnimation = m.top.findNode("minimizeAnimation")
    m.widthInterpolator = m.top.findNode("widthInterpolator")
    m.heightInterpolator = m.top.findNode("heightInterpolator")
    m.translationInterpolator = m.top.findNode("translationInterpolator")
    minRect = m.top.minRect
    maxRect = m.top.maxRect
    m.widthInterpolator.keyValue = [
        maxRect.width
        (maxRect.width + minRect.width) / 2
        minRect.width
    ]
    m.heightInterpolator.keyValue = [
        maxRect.height
        (maxRect.height + minRect.height) / 2
        minRect.height
    ]
    maxTranslation = [
        maxRect.x
        maxRect.y
    ]
    minTranslation = [
        minRect.x
        minRect.y
    ]
    midTranslation = [
        (maxRect.x + minRect.x) / 2
        (maxRect.y + minRect.y) / 2
    ]
    m.translationInterpolator.keyValue = [
        maxTranslation
        midTranslation
        minTranslation
    ]
end function

function OnFullScreenChange()
    HideUIAndStopTimer()
    m.widthInterpolator.reverse = m.container.fullscreen
    m.heightInterpolator.reverse = m.container.fullscreen
    m.translationInterpolator.reverse = m.container.fullscreen
    m.minimizeAnimation.control = "start"
    m.top.enableUI = m.container.fullscreen
    m.top.showFullScreenHint = not m.container.fullscreen
    SponsorBlock_SetVisible(m.notifications, m.container.fullscreen)
end function

function OnShowFullScreenHint() as void
    m.fullScreenHintTimer.control = "stop"
    if m.container.fullscreen
        m.fullScreenHint.visible = false
        return
    end if
    if m.top.showFullScreenHint
        
        m.fullScreenHintTimer.duration = 1
    else
        
        m.fullScreenHintTimer.duration = 5
    end if
    m.fullScreenHintTimer.control = "start"
end function

function OnTrickplayUITimer()
    HideUIAndStopTimer()
end function

function OnFullScreenHintTimer()
    showFullScreenHint = m.top.showFullScreenHint
    m.fullScreenHint.visible = showFullScreenHint
    if showFullScreenHint
        m.top.showFullScreenHint = false
    end if
end function