'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/Services/SponsorBlock/Notifications/SponsorBlockNotificationUtils.bs"
'import "SponsorBlockSegmentAction.bs"
'import "VideoPlayer.bs"
function SponsorBlock_SetupSponsorBlock() as void
    if not m.preferences["sponsorblock.enabled"]
        return
    end if
    SponsorBlock_SetVisible(m.notifications, m.container.fullscreen)
end function

function SponsorBlock_FetchSponsorBlock(metadata as object) as void
    if not m.preferences["sponsorblock.enabled"]
        return
    end if
    if m.sponsorBlockSegmentsJob <> invalid
        m.sponsorBlockSegmentsJob.cancel = true
    end if
    input = {
        videoId: metadata.videoId
        lengthSeconds: metadata.lengthSeconds
        showNotifications: m.preferences["sponsorblock.show_notifications"]
        categories: m.preferences["sponsorblock.categories"]
    }
    m.sponsorBlockSegmentsJob = JobSystem_CreateCallback(SponsorBlock_OnSponsorBlockSegmentsJobDone)
    JobSystem_QueueJob(m.jobQueue, "SponsorBlockSegmentsJob", input, m.sponsorBlockSegmentsJob)
end function

function SponsorBlock_OnSponsorBlockSegmentsJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.sponsorBlockSegmentsJob = invalid
    info = event.getInfo()
    if not info.success
        return
    end if
    skipSegments = info.data.skipSegments
    if skipSegments = invalid or skipSegments.Count() = 0
        return
    end if
    m.skipSegments = skipSegments
    m.top.seekMode = "accurate"
    barPath = info.data.barPath
    if barPath <> invalid
        m.top.trickPlayBar.trackImageUri = barPath
        m.top.trickPlayBar.filledBarBlendColor = "#FF000080"
    end if
    m.top.ObserveFieldScoped("position", FuncName(SponsorBlock_OnPositionChangeSkipSponsorBlockSections))
    if m.top.hasField("trickPlayPosition")
        SponsorBlock_PositionChapterLabel()
        m.chapterLabelTimer = m.top.findNode("chapterLabelTimer")
        m.chapterLabelTimer.observeField("fire", FuncName(SponsorBlock_OnChapterLabelTimer))
        m._sponsorBlockLastTimeChapterUpdated = 0.0#
        m.top.trickPlayBar.observeField("visible", FuncName(SponsorBlock_OnTrickPlayBarVisible))
    end if
end function

function SponsorBlock_PositionChapterLabel()
    m.chapterLabel = m.top.findNode("chapterLabel")
    
    m.chapterLabel.reparent(m.top.trickPlayBar, false)
    trickPlayBarWidth = m.top.trickPlayBar.boundingRect().width
    m.chapterLabel.translation = [
        trickPlayBarWidth / 4 - m.chapterLabel.width / 2
        25
    ]
end function

function SponsorBlock_OnTrickPlayBarVisible()
    if m.top.trickPlayBar.visible
        m.top.chapter = ""
        m.chapterLabelTimer.control = "start"
    else
        m.chapterLabelTimer.control = "stop"
    end if
end function

function SponsorBlock_OnChapterLabelTimer() as void
    trickPlayPosition = m.top.trickPlayPosition
    if m._sponsorBlockLastTimeChapterUpdated = trickPlayPosition
        return
    end if
    m._sponsorBlockLastTimeChapterUpdated = trickPlayPosition
    SponsorBlock_UpdateSponsorBlockChapter(trickPlayPosition)
end function

function SponsorBlock_UpdateSponsorBlockChapter(time as double) as void
    segments = m.skipSegments
    segment = SponsorBlock_FindSegmentByTime(segments, time)
    if segment = invalid
        m.top.chapter = ""
        return
    end if
    m.top.chapter = segment.title
end function

function SponsorBlock_FindSegmentByTime(segments as object, time as dynamic) as dynamic
    
    low = 0
    high = segments.Count() - 1
    while low <= high
        middle = (low + high) \ 2
        segment = segments[middle]
        if time < segment.start
            high = middle - 1
        else if time > segment.end
            low = middle + 1
        else
            return segment
        end if
    end while
    return invalid
end function

function SponsorBlock_OnPositionChangeSkipSponsorBlockSections(event as object) as void
    segments = m.skipSegments
    position = event.getData()
    segment = SponsorBlock_FindSegmentByTime(segments, position)
    if segment = invalid
        return
    end if
    action = segment.option
    
    if segment.showNotification and Abs(segment.end - position) >= 1
        SponsorBlock_ShowNotifcation(m.notifications, segment)
        if action = "manual_skip"
            
            m.manualSkipSegment = segment
            return
        end if
    end if
    if action = "auto_skip"
        SponsorBlock_SkipSegment(segment, position)
    end if
end function

function SponsorBlock_SkipSegment(segment as object, position as dynamic) as void
    segmentEnd = segment.end
    duration = m.top.duration
    
    if duration > 0 and segmentEnd > duration
        segmentEnd = duration
    end if
    
    if Abs(segmentEnd - position) < 2
        LogInfo2("[SponsorBlock.bs:170]", "Skip position is within 2 seconds of segment end, not skipping")
        return
    end if
    
    if duration > 0 and Abs(segmentEnd - duration) < 2
        LogInfo4("[SponsorBlock.bs:176]", "Skipping section:", segment.category, "at end of video")
        OnVideoFinished()
    else
        LogInfo3("[SponsorBlock.bs:179]", "Skipping section:", segment.category)
        m.top.seek = segmentEnd
    end if
    SponsorBlock_SendSkippedSectionEvent(segment.UUID)
end function

function SponsorBlock_ManualSkipSegment() as boolean
    segment = m.manualSkipSegment
    if segment = invalid
        return false
    end if
    m.manualSkipSegment = invalid
    notification = SponsorBlock_GetCurrentNotification(m.notifications)
    if notification = invalid
        return false
    end if
    notificationSegmentId = notification.segmentId
    if notificationSegmentId <> segment.UUID
        return false
    end if
    position = m.top.position
    if (position < segment.start) or (segment.end < position)
        return false
    end if
    SponsorBlock_SkipSegment(segment, position)
    SponsorBlock_RemoveNotifcation(m.notifications)
    return true
end function

function SponsorBlock_SendSkippedSectionEvent(segmentId as string)
    if m.sponsorSkipEventJob <> invalid
        m.sponsorSkipEventJob.cancel = true
    end if
    m.sponsorSkipEventJob = JobSystem_CreateCallback()
    JobSystem_QueueJob(m.jobQueue, "SponsorBlockSegmentViewedJob", {
        segmentId: segmentId
    }, m.sponsorSkipEventJob)
end function