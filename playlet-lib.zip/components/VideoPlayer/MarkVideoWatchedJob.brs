'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.bs"
'import "pkg:/components/Services/Innertube/InnertubeService.bs"
'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/source/utils/MessagePortUtils.bs"
'import "pkg:/source/utils/TimeUtils.bs"

function ExecuteJob() as void
    input = JobGetInput()
    videoId = input.videoId
    invidiousNode = input.invidious
    profile = input.profile
    playbackTrackingUrls = input.playbackTrackingUrls
    cpn = input.cpn
    cancellation = JobGetCancellation()
    profileType = profile.type
    if profileType <> "invidious" and profileType <> "youtube"
        JobError(("Unsupported profile type: " + bslib_toString(profileType)))
        return
    end if
    auth = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(profile)
    if auth.state <> "Ok"
        return
    end if
    if profileType = "invidious"
        service = Invidious_InvidiousService(invidiousNode)
        service.MarkVideoWatched(auth, videoId, cancellation)
        return
    end if
    accessToken = auth.token
    onBehalfOfUser = auth.activeIdentifyToken
    freshUntilSeconds = auth.freshUntilSeconds
    refreshRequested = WatchTimeAuthRefreshDue(freshUntilSeconds)
    if playbackTrackingUrls = invalid or StringUtils_IsNullOrEmpty(playbackTrackingUrls.videostatsPlaybackUrl) or StringUtils_IsNullOrEmpty(playbackTrackingUrls.videostatsWatchtimeUrl)
        playbackTrackingUrls = InnertubeService_AuthGetPlaybackTrackingUrls(videoId, {
            accessToken: accessToken
            onBehalfOfUser: onBehalfOfUser
            cancellation: cancellation
        })
    end if
    if playbackTrackingUrls.error <> invalid
        JobError(("Failed to get playback tracking URLs: " + bslib_toString(playbackTrackingUrls.error)))
        return
    end if
    if StringUtils_IsNullOrEmpty(playbackTrackingUrls.videostatsPlaybackUrl)
        JobError("videostatsPlaybackUrl is empty")
        return
    end if
    if StringUtils_IsNullOrEmpty(cpn)
        cpn = InnertubeService_CreateClientPlaybackNonce()
    end if
    markedAsWatched = InnertubeService_AuthMarkVideoWatched(playbackTrackingUrls.videostatsPlaybackUrl, {
        accessToken: accessToken
        onBehalfOfUser: onBehalfOfUser
        cpn: cpn
        cancellation: cancellation
    })
    if not markedAsWatched
        JobError("Failed to mark video as watched")
        return
    end if
    if StringUtils_IsNullOrEmpty(playbackTrackingUrls.videostatsWatchtimeUrl)
        JobError("videostatsWatchtimeUrl is empty")
        return
    end if
    if CancellationUtils_IsCancelled(cancellation)
        JobCancel()
        return
    end if
    port = CreateObject("roMessagePort")
    callbackNode = JobGetCallbackNode()
    MessagePortUtils_ObserveFieldScopedExSafe(callbackNode, "watchTime", port)
    
    MessagePortUtils_ObserveFieldScopedExSafe(profile, "authState", port)
    CancellationUtils_ObserveCancellationScoped(cancellation, port)
    successiveFailures = 0
    while true
        message = wait(WatchTimeAuthWaitMs(freshUntilSeconds, refreshRequested), port)
        if CancellationUtils_IsCancellationEvent(cancellation, message)
            JobCancel()
            return
        end if
        if message = invalid
            if refreshRequested or WatchTimeAuthRefreshDue(freshUntilSeconds)
                auth = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(profile)
                if auth.state <> "Ok"
                    return
                end if
                accessToken = auth.token
                onBehalfOfUser = auth.activeIdentifyToken
                freshUntilSeconds = auth.freshUntilSeconds
                refreshRequested = WatchTimeAuthRefreshDue(freshUntilSeconds)
            end if
            continue while
        end if
        watchTime = invalid
        if IsWatchTimeEvent(callbackNode, message)
            watchTime = message.getData()
        else if IsAuthStateEvent(profile, message)
            auth = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(profile)
            if auth.state <> "Ok"
                return
            end if
            accessToken = auth.token
            onBehalfOfUser = auth.activeIdentifyToken
            freshUntilSeconds = auth.freshUntilSeconds
            refreshRequested = WatchTimeAuthRefreshDue(freshUntilSeconds)
        end if
        
        newMessage = port.GetMessage()
        while newMessage <> invalid
            if CancellationUtils_IsCancellationEvent(cancellation, newMessage)
                JobCancel()
                return
            else if IsWatchTimeEvent(callbackNode, newMessage)
                watchTime = newMessage.getData()
            else if IsAuthStateEvent(profile, newMessage)
                auth = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(profile)
                if auth.state <> "Ok"
                    return
                end if
                accessToken = auth.token
                onBehalfOfUser = auth.activeIdentifyToken
                freshUntilSeconds = auth.freshUntilSeconds
                refreshRequested = WatchTimeAuthRefreshDue(freshUntilSeconds)
            end if
            newMessage = port.GetMessage()
        end while
        if watchTime = invalid
            continue while
        end if
        success = InnertubeService_AuthMarkVideoWatchTime(watchTime, playbackTrackingUrls.videostatsWatchtimeUrl, {
            accessToken: accessToken
            onBehalfOfUser: onBehalfOfUser
            cpn: cpn
            ' TODO:P1 if we pass cancellation here, http client will remove scoped
            ' observer, which is stored on the current node.
            ' This requires an extra observer node to be independent.
            cancellation: invalid
        })
        if success
            successiveFailures = 0
        else
            successiveFailures += 1
        end if
        
        if successiveFailures >= 5
            return
        end if
    end while
end function

function WatchTimeAuthRefreshDue(freshUntilSeconds as dynamic) as boolean
    if not IsNumber(freshUntilSeconds) or freshUntilSeconds <= 0
        return false
    end if
    return TimeUtils_Now().AsSeconds() >= freshUntilSeconds
end function

function WatchTimeAuthWaitMs(freshUntilSeconds as dynamic, refreshRequested as boolean) as integer
    if refreshRequested or not IsNumber(freshUntilSeconds) or freshUntilSeconds <= 0
        return 60000
    end if
    secondsUntilRefresh = freshUntilSeconds - TimeUtils_Now().AsSeconds()
    if secondsUntilRefresh <= 0
        return 1
    end if
    if secondsUntilRefresh > 60
        return 60000
    end if
    return secondsUntilRefresh * 1000
end function

function IsWatchTimeEvent(callbackNode as object, message as dynamic) as boolean
    if type(message) <> "roSGNodeEvent"
        return false
    end if
    node = message.getRoSGNode()
    return node <> invalid and node.isSameNode(callbackNode) and message.getField() = "watchTime"
end function

function IsAuthStateEvent(profile as object, message as dynamic) as boolean
    if type(message) <> "roSGNodeEvent"
        return false
    end if
    node = message.getRoSGNode()
    return node <> invalid and node.isSameNode(profile) and message.getField() = "authState"
end function