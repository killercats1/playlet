'import "pkg:/components/Services/LoungeService/LoungeConstants.bs"
'import "pkg:/components/Services/LoungeService/LoungeMessages.bs"
'import "pkg:/source/utils/StringUtils.bs"
function Lounge_SendNowPlayingLoading(videoId as dynamic, playbackSpeed as float) as void
    if StringUtils_IsNullOrEmpty(m.loungeService.loungeToken)
        return
    end if
    overrides = {}
    overrides["state"] = 3
    loungeStateMsg = LoungeMessages_OnStateChange(m.top, overrides)
    if not StringUtils_IsNullOrEmpty(videoId)
        overrides["videoId"] = videoId
    end if
    nowPlayingMsg = LoungeMessages_NowPlaying(m.top, overrides)
    
    playbackSpeedMsg = LoungeMessages_OnPlaybackSpeedChanged(playbackSpeed)
    m.loungeService.outgoingMessages = [
        nowPlayingMsg
        loungeStateMsg
        playbackSpeedMsg
    ]
end function

function Lounge_SendOnStateChange() as void
    
    if m.onCloseCalled = true or StringUtils_IsNullOrEmpty(m.loungeService.loungeToken)
        return
    end if
    loungeStateMsg = LoungeMessages_OnStateChange(m.top)
    m.loungeService.outgoingMessages = [
        loungeStateMsg
    ]
end function