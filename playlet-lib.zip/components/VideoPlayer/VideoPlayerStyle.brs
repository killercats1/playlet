function SetPlayerStyle()
    m.top.trickPlayBar.filledBarBlendColor = "#FF1C30FF"
    m.top.bufferingBar.filledBarBlendColor = "#FF1C30FF"
    m.top.retrievingBar.filledBarBlendColor = "#FF1C30FF"
    
    busySpinner = FindChildNodeOfType(m.top, "BusySpinner")
    if busySpinner <> invalid
        busySpinner.poster.blendColor = "#FF1C30FF"
    end if
end function

function FindChildNodeOfType(node as object, nodeType as string) as object
    if node.subtype() = nodeType
        return node
    end if
    childCount = node.getChildCount()
    children = node.getChildren(childCount, 0)
    for i = 0 to childCount - 1
        child = FindChildNodeOfType(children[i], nodeType)
        if child <> invalid
            return child
        end if
    end for
    return invalid
end function