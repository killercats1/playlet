' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "appController": "/AppController", 
            "jobQueue": "/JobQueue", 
            "container": "..", 
            "notifications": "../../Notifications", 
            "videoQueue": "../../VideoQueue", 
            "preferences": "../../Preferences", 
            "innertube": "../../Innertube", 
            "invidious": "../../Invidious", 
            "webServer": "../../WebServer", 
            "loungeService": "../../LoungeService", 
            "profilesService": "../../ProfilesService"
        },
        childProps: {
    
        }
    }
end function