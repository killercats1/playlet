'import "pkg:/source/utils/Types.bs"

function Init()
    m.top.font.size = 18
    m.top.horizAlign = "right"
    m.top.translation = [
        1034
        34
    ]
    m.top.width = 200
    m.dateTime = CreateObject("roDateTime")
    Update()
    seconds = m.dateTime.GetSeconds()
    m.timer = CreateObject("roSGNode", "Timer")
    
    m.timer.duration = 60 - seconds + 2
    m.timer.repeat = false
    m.timer.ObserveField("fire", FuncName(FirstUpdate))
    m.timer.control = "start"
end function

function FirstUpdate()
    m.timer.control = "stop"
    m.timer.unobserveField("fire")
    m.timer.ObserveField("fire", FuncName(Update))
    m.timer.duration = 60
    m.timer.repeat = true
    m.timer.control = "start"
    Update()
end function

' format time "H:MM a.m./p.m." (12-hour, no leading zero on the hour)
function Update()
    m.dateTime.Mark()
    m.dateTime.ToLocalTime()
    hours = m.dateTime.GetHours()
    minutes = m.dateTime.GetMinutes()
    if hours >= 12
        ampm = "p.m."
    else
        ampm = "a.m."
    end if
    hours12 = hours mod 12
    if hours12 = 0
        hours12 = 12
    end if
    m.top.text = hours12.ToStr() + ":" + minutes.ToStr("%02d") + " " + ampm
end function

function OnDispose()
    m.timer.control = "stop"
    m.timer.unobserveField("fire")
end function