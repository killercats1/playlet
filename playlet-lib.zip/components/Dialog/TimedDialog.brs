'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    m.top.observeField("buttonSelected", FuncName(OnButtonSelected))
    m.top.observeField("wasClosed", FuncName(OnDialogClosed))
end function

function OnStartCountdown()
    actualButtons = m.top.actualButtons
    defaultButtonIndex = m.top.defaultButtonIndex
    defaultActionTimeoutSeconds = m.top.defaultActionTimeoutSeconds
    buttons = []
    for i = 0 to actualButtons.Count() - 1
        if i = defaultButtonIndex
            buttons.push((bslib_toString(actualButtons[i]) + " (" + bslib_toString(defaultActionTimeoutSeconds) + ")"))
        else
            buttons.push(actualButtons[i])
        end if
    end for
    m.top.buttons = buttons
    CancelTimer()
    m.timer = CreateObject("roSGNode", "Timer")
    m.timer.repeat = true
    m.timer.observeFieldScoped("fire", FuncName(TimerUpdateButtons))
    m.currentCountDown = defaultActionTimeoutSeconds
    m.timer.control = "start"
    FindButtonComponent()
end function

function OnFocusDefaultButton() as void
    FindButtonComponent()
    if m.buttonComponents = invalid
        return
    end if
    defaultButtonIndex = m.top.defaultButtonIndex
    if m.buttonComponents.Count() <= defaultButtonIndex
        return
    end if
    button = m.buttonComponents[defaultButtonIndex]
    NodeSetFocus(button, true)
end function

function TimerUpdateButtons() as void
    m.currentCountDown -= 1
    if m.currentCountDown <= 0
        m.top.actualButtonSelected = m.top.defaultButtonIndex
        m.top.close = true
        return
    end if
    SetDefaultButtonText(m.currentCountDown)
end function

function OnButtonSelected()
    m.top.actualButtonSelected = m.top.buttonSelected
    m.top.close = true
end function

function OnDialogClosed()
    CancelTimer()
end function

function OnKeyEvent(_key as string, _press as boolean) as boolean
    if m.timer = invalid
        return false
    end if
    CancelTimer()
    FindButtonComponent()
    SetDefaultButtonText(0)
    return false
end function

function CancelTimer()
    if m.timer <> invalid
        m.timer.control = "stop"
        m.timer.unobserveFieldScoped("fire")
        m.timer = invalid
    end if
end function

function SetDefaultButtonText(timeLeft as integer) as void
    if m.buttonComponents = invalid
        return
    end if
    defaultButtonIndex = m.top.defaultButtonIndex
    if timeLeft > 0
        m.buttonComponents[defaultButtonIndex].text = (bslib_toString(m.top.actualButtons[defaultButtonIndex]) + " (" + bslib_toString(timeLeft) + ")")
    else
        m.buttonComponents[defaultButtonIndex].text = m.top.actualButtons[defaultButtonIndex]
    end if
end function

function FindButtonComponent() as void
    if m.buttonComponents <> invalid
        return
    end if
    areas = m.top.getChildren(-1, 0)
    for each area in areas
        if area.subtype() = "StdDlgButtonArea"
            m.buttonComponents = area.getChildren(-1, 0)
            return
        end if
    end for
    LogWarn2("[TimedDialog.bs:113]", "No buttons found in dialog")
end function