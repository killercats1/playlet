'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/Dialog/YouTubeLoginAccountItemUtils.bs"
'import "pkg:/components/Services/Innertube/InnertubeService.bs"
'import "pkg:/source/utils/CancellationUtils.bs"
'import "pkg:/source/utils/Logging.bs"

function ExecuteJob() as void
    input = JobGetInput()
    profilesNode = input.profilesService
    dialogNode = input.dialog
    cancellation = JobGetCancellation()
    
    authCode = InnertubeService_AuthGetCode(cancellation)
    if CancellationUtils_IsCancelled(cancellation)
        JobCancel()
        return
    end if
    if authCode.error <> invalid
        JobError(authCode.error)
        return
    end if
    url = InnertubeService_AuthGetActivationUrl(authCode)
    LogInfo3("[YouTubeLoginJob.bs:29]", "Login url:", url)
    dialogNode.url = url
    dialogNode.code = authCode.userCode
    accessToken = InnertubeService_AuthPollForAccessToken(authCode, cancellation)
    if CancellationUtils_IsCancelled(cancellation)
        JobCancel()
        return
    end if
    if accessToken.error <> invalid
        JobError(accessToken.error)
        return
    end if
    accounts = InnertubeService_AuthListAccounts(accessToken.accessToken, cancellation)
    if CancellationUtils_IsCancelled(cancellation)
        JobCancel()
        return
    end if
    if IsAssociativeArray(accounts) and accounts.error <> invalid
        JobError(accounts.error)
        return
    end if
    if not IsArray(accounts) or accounts.Count() = 0
        JobError(Tr("No valid accounts found for YouTube login."))
        return
    end if
    
    if accounts.Count() = 1
        profile = YouTubeLoginAccountItemUtils_CreateProfileContentNode(accounts[0], accessToken)
        profilesNode.callfunc("LoginWithProfile", profile)
        return
    end if
    JobSuccessData({
        accounts: accounts
        accessToken: accessToken
    })
end function