'import "pkg:/source/utils/StringUtils.bs"
function YouTubeLoginAccountItemUtils_CreateProfileContentNode(accountItem as object, accessToken as object) as object
    profile = CreateObject("roSGNode", "ProfileContentNode")
    profile.type = "youtube"
    profile.serverUrl = "http://127.0.0.1:8888/playlet-invidious-backend"
    username = accountItem.channelHandle
    if StringUtils_IsNullOrEmpty(username)
        username = accountItem.accountByline
    end if
    profile.username = username
    profile.activeIdentifyToken = accountItem.activeIdentifyToken
    profile.thumbnail = accountItem.accountPhoto
    profile.accessToken = accessToken.accessToken
    profile.refreshToken = accessToken.refreshToken
    profile.scope = accessToken.scope
    profile.tokenType = accessToken.tokenType
    profile.expiresIn = accessToken.expiresIn
    profile.expiresTimestamp = accessToken.expiresTimestamp
    profile.clientId = accessToken.clientId
    profile.clientSecret = accessToken.clientSecret
    return profile
end function