' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "profilesService": "/ProfilesService", 
            "appController": "/AppController", 
            "jobQueue": "/JobQueue"
        },
        childProps: {
    
        }
    }
end function