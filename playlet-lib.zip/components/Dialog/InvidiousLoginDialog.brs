'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
'import "pkg:/source/utils/UrlUtils.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.urlLabel = m.top.findNode("urlLabel")
    m.qrCode = m.top.findNode("QrCodePoster")
    m.top.width = "920"
    m.top.observeFieldScoped("buttonSelected", FuncName(Close))
    scanLabel = m.top.findNode("scanLabel")
    scanLabel.text = Tr("Scan the QR code")
end function

function OnNodeReady()
    address = m.webserver.callfunc("GetServerAddress", invalid)
    isValidAddress = not StringUtils_IsNullOrEmpty(address)
    if isValidAddress
        url = (bslib_toString(address) + "/invidious/login")
        profileId = m.top.profileId
        if not StringUtils_IsNullOrEmpty(profileId)
            url = UrlUtils_AppendQueryParams(url, {
                profile: profileId
            })
        end if
        m.top.url = url
    else
        m.urlLabel.text = Tr("IP address not available")
    end if
    m.profilesService.observeFieldScoped("currentProfileChanged", FuncName(OnCurrentProfileChanged))
end function

function Close()
    m.top.close = true
end function

function OnUrlSet()
    url = m.top.url
    m.urlLabel.text = url
    m.qrCode.text = url
end function

function OnCurrentProfileChanged()
    m.profilesService.unobserveFieldScoped("currentProfileChanged")
    Close()
end function