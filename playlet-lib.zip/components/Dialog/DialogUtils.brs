'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/RegistryUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
' Very large messages can lead to execution timeout




function DialogUtils_ShowDialogEx(options as object) as object
    currentDialog = m.top.getScene().dialog
    alwaysOnTop = false
    if options.DoesExist("alwaysOnTop")
        alwaysOnTop = options.alwaysOnTop
    end if
    if currentDialog <> invalid and ValidBool(currentDialog.alwaysOnTop)
        if not alwaysOnTop
            return invalid
        end if
    end if
    dialog = CreateObject("roSGNode", "SimpleDialog")
    dialog.alwaysOnTop = alwaysOnTop
    if options.DoesExist("message")
        message = options.message
        if IsString(message)
            if message.Len() > 1000
                message = message.Left(1000) + "..."
            end if
            message = message.Tokenize((chr(10))).ToArray()
        end if
        dialog.message = message
    end if
    if options.DoesExist("bulletText")
        bulletText = options.bulletText
        if IsString(bulletText)
            bulletText = bulletText.Tokenize((chr(10))).ToArray()
        end if
        dialog.bulletText = bulletText
    end if
    if options.DoesExist("bottomMessage")
        bottomMessage = options.bottomMessage
        if IsString(bottomMessage)
            bottomMessage = bottomMessage.Tokenize((chr(10))).ToArray()
        end if
        dialog.bottomMessage = bottomMessage
    end if
    if options.DoesExist("title")
        dialog.title = options.title
    end if
    if options.DoesExist("buttons")
        dialog.buttons = options.buttons
    else
        dialog.buttons = [
            Tr("OK")
        ]
    end if
    if options.DoesExist("large") and options.large
        if m._deviceDisplayWidth = invalid
            deviceInfo = CreateObject("roDeviceInfo")
            displaySize = deviceInfo.GetDisplaySize()
            m._deviceDisplayWidth = displaySize.w
        end if
        dialog.width = m._deviceDisplayWidth - 100
    else if options.DoesExist("marginWidth")
        if m._deviceDisplayWidth = invalid
            deviceInfo = CreateObject("roDeviceInfo")
            displaySize = deviceInfo.GetDisplaySize()
            m._deviceDisplayWidth = displaySize.w
        end if
        dialog.width = m._deviceDisplayWidth - options.marginWidth
    end if
    m.top.getScene().dialog = dialog
    return dialog
end function

function DialogUtils_ShowTimedDialogButtons(message as dynamic, title as string, buttons as object, defaultButton as integer, timeoutSeconds as integer, large = false as boolean) as object
    currentDialog = m.top.getScene().dialog
    if currentDialog <> invalid and ValidBool(currentDialog.alwaysOnTop)
        return invalid
    end if
    dialog = CreateObject("roSGNode", "TimedDialog")
    if IsString(message)
        if message.Len() > 1000
            message = message.Left(1000) + "..."
        end if
        message = message.Tokenize((chr(10))).ToArray()
    end if
    dialog.message = message
    dialog.title = title
    dialog.actualButtons = buttons
    if large
        if m._deviceDisplayWidth = invalid
            deviceInfo = CreateObject("roDeviceInfo")
            displaySize = deviceInfo.GetDisplaySize()
            m._deviceDisplayWidth = displaySize.w
        end if
        dialog.width = m._deviceDisplayWidth - 100
    end if
    dialog.defaultButtonIndex = defaultButton
    dialog.defaultActionTimeoutSeconds = timeoutSeconds
    dialog.startCountdown = true
    m.top.getScene().dialog = dialog
    dialog.focusDefaultButton = true
    return dialog
end function

function DialogUtils_ShowOnScreenCodeDialog(purpose as object, title as string) as object
    if m._onScreenCodeShownTimer = invalid
        m._onScreenCodeShownTimer = CreateObject("roTimespan")
    else if m._onScreenCodeShownTimer.TotalMilliseconds() < 2000
        return invalid
    end if
    m._onScreenCodeShownTimer.Mark()
    dialog = CreateObject("roSGNode", "OnScreenCodeDialog")
    dialog.purpose = purpose
    dialog.title = title
    m.top.getScene().dialog = dialog
    return dialog
end function

function DialogUtils_ConsumeOnScreenCode(purpose as object, code as dynamic) as boolean
    dialog = m.top.getScene().dialog
    if dialog = invalid or dialog.subtype() <> "OnScreenCodeDialog"
        return false
    end if
    return dialog.callfunc("Consume", purpose, code)
end function

function DialogUtils_ShowDialogOnce(options as object) as object
    messageId = ValidString(options.messageId)
    hasMessageId = messageId <> ""
    if hasMessageId
        messages = RegistryUtils_Read("messages")
        if not StringUtils_IsNullOrEmpty(messages)
            messages = StringUtils_ParseJsonSafe(messages)
            if IsAssociativeArray(messages)
                savedMessageId = ValidString(messages["messageId"])
                if savedMessageId = messageId
                    return invalid
                end if
            end if
        end if
    end if
    options.buttons = [
        Tr("OK")
        (bslib_toString(Tr("OK")) + " - " + bslib_toString(Tr("Do not show again")))
    ]
    dialog = DialogUtils_ShowDialogEx(options)
    if dialog = invalid
        return invalid
    end if
    dialog.AddFields({
        "messageId": messageId
    })
    dialog.ObserveField("buttonSelected", FuncName(DialogUtils_OnShowDialogOnceButtonSelected))
    return dialog
end function

function DialogUtils_OnShowDialogOnceButtonSelected(event as object) as void
    buttonSelected = event.getData()
    if buttonSelected <> 1
        return
    end if
    dialog = event.GetRoSGNode()
    messageId = dialog.messageId
    if messageId = ""
        return
    end if
    messages = {
        "messageId": messageId
    }
    RegistryUtils_Write("messages", FormatJson(messages))
end function