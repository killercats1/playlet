' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "webServer": "/WebServer", 
            "profilesService": "/ProfilesService"
        },
        childProps: {
    
        }
    }
end function