function ChannelUtils_Open(contentNode as object, appController = invalid as object)
    channelView = CreateObject("roSGNode", "ChannelView")
    if appController = invalid
        appController = m.appController
    end if
    appController.callfunc("PushScreen", channelView)
    channelView.callfunc("BindNode", invalid)
    channelView.content = contentNode
end function