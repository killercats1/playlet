'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.bs"
'import "pkg:/components/Services/Innertube/InnertubeService.bs"
'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/source/utils/CancellationUtils.bs"

function ExecuteJob() as void
    input = JobGetInput()
    channelView = input.channelView
    ucid = input.ucid
    invidiousNode = input.invidious
    profile = input.profile
    if JobIsCancelled()
        JobCancel()
        return
    end if
    cancellation = JobGetCancellation()
    auth = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(profile)
    if auth.state <> "Ok"
        JobError("No usable access token to fetch subscription status: " + auth.state)
        return
    end if
    if profile.type = "youtube"
        subscriptionStatus = InnertubeService_GetSubscriptionStatusForChannel(ucid, {
            cancellation: cancellation
            accessToken: auth.token
            onBehalfOfUser: auth.activeIdentifyToken
        })
        if subscriptionStatus.error <> invalid
            JobError("Failed to fetch subscription status: " + ToString(subscriptionStatus.error))
            return
        end if
        channelView.isSubscribed = subscriptionStatus.isSubscribed
    else
        service = Invidious_InvidiousService(invidiousNode)
        subscriptionsResponse = service.GetSubscriptions(auth, cancellation)
        if not subscriptionsResponse.IsSuccess()
            JobError("Failed to fetch subscriptions: " + subscriptionsResponse.ErrorMessage())
            return
        end if
        subscriptions = subscriptionsResponse.Json()
        isSubscribed = false
        for each subscription in subscriptions
            if subscription.authorId = ucid
                isSubscribed = true
                exit for
            end if
        end for
        channelView.isSubscribed = isSubscribed
    end if
end function