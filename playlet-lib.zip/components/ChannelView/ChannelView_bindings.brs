' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "appController": "/AppController", 
            "invidious": "/Invidious", 
            "profilesService": "/ProfilesService", 
            "preferences": "/Preferences", 
            "jobQueue": "/JobQueue", 
            "bookmarksService": "/BookmarksService"
        },
        childProps: {
    
        }
    }
end function