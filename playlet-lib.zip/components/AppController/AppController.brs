'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/Navigation/LongPress.bs"
'import "pkg:/components/VideoQueue/VideoQueueUtils.bs"
'import "pkg:/components/VideoQueue/VideoQueueViewUtils.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.screens = {}
    m.firstScreenCalled = false
end function

function OnNodeReady()
    InitializeLongPress([
        "options"
    ])
    NodeSetFocus(m.top.root, true)
end function

function PushScreen(node as object)
    m.stack.appendChild(node)
    FocusTopScreen(invalid)
end function

function PopScreen(_unused as dynamic)
    childCount = m.stack.getChildCount()
    if childCount > 1
        m.stack.removeChildIndex(childCount - 1)
        FocusTopScreen(invalid)
    end if
end function

function FocusTopScreen(_unused as dynamic)
    childCount = m.stack.getChildCount()
    topScreen = m.stack.getChild(childCount - 1)
    NodeSetFocus(topScreen, true)
end function

function HideRootScreen(screenName as string) as void
    if StringUtils_IsNullOrEmpty(screenName)
        return
    end if
    if not m.screens.DoesExist(screenName)
        return
    end if
    screen = m.screens[screenName]
    if screen = invalid
        return
    end if
    screen.visible = false
end function

function ShowRootScreen(screenName as string) as void
    if StringUtils_IsNullOrEmpty(screenName)
        return
    end if
    if not m.screens.DoesExist(screenName)
        screen = CreateObject("roSGNode", screenName)
        screen.id = screenName
        m.screens[screenName] = screen
        
        m.screensContainer.insertChild(screen, 0)
        if screen.hasField("binding_done")
            screen.callfunc("BindNode", invalid)
        end if
    end if
    screen = m.screens[screenName]
    if screen = invalid
        return
    end if
    screen.visible = true
    if not m.firstScreenCalled
        m.firstScreenCalled = true
        NodeSetFocus(screen, true)
    end if
end function

function GetRootScreen(screenName as string) as object
    if StringUtils_IsNullOrEmpty(screenName)
        return invalid
    end if
    if not m.screens.DoesExist(screenName)
        return invalid
    end if
    return m.screens[screenName]
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if LongPressHandler(key, press)
        return true
    end if
    if key = "OPTIONS_LONG_PRESS" and press
        LogInfo2("[AppController.bs:95]", "Opening VideoQueueView")
        VideoQueueViewUtils_Open(m.top.videoQueue, m.top)
        return true
    end if
    if key = "options" and not press
        if VideoQueueUtils_ToggleVideoPictureInPicture(m.top.videoQueue)
            return true
        end if
    end if
    if not press
        return false
    end if
    if key = "play"
        if VideoQueueUtils_TogglePause(m.top.videoQueue)
            return true
        end if
    end if
    if key = "pause"
        if VideoQueueUtils_Pause(m.top.videoQueue)
            return true
        end if
    end if
    if key = "playonly"
        if VideoQueueUtils_Play(m.top.videoQueue)
            return true
        end if
    end if
    if key = "back"
        if VideoQueueUtils_IsVideoPlayerOpen(m.top.videoQueue) and not VideoQueueUtils_IsVideoPlayerFullScreen(m.top.videoQueue)
            if VideoQueueUtils_ToggleVideoPictureInPicture(m.top.videoQueue)
                return true
            end if
        end if
        dialog = DialogUtils_ShowDialogEx({
            message: Tr("Do you want to exit Playlet?")
            title: Tr("Exit")
            buttons: [
                Tr("Exit")
                Tr("Cancel")
            ]
        })
        if dialog <> invalid
            dialog.observeField("buttonSelected", FuncName(OnExitDialog), [
                "buttonSelected"
            ])
        end if
        return true
    end if
    return false
end function

function OnExitDialog(event as object)
    buttonIndex = event.GetData()
    if buttonIndex = 0 
        LogInfo2("[AppController.bs:151]", "Exiting app")
        m.top.getScene().exitChannel = true
    end if
end function