function PlaylistUtils_Open(contentNode as object, appController = invalid as object)
    playlistView = CreateObject("roSGNode", "PlaylistView")
    if appController = invalid
        appController = m.appController
    end if
    appController.callfunc("PushScreen", playlistView)
    playlistView.callfunc("BindNode", invalid)
    
    playlistView.content = contentNode.clone(false)
end function