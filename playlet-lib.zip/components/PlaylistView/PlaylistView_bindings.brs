' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "appController": "/AppController", 
            "invidious": "/Invidious", 
            "jobQueue": "/JobQueue", 
            "videoQueue": "/VideoQueue", 
            "bookmarksService": "/BookmarksService"
        },
        childProps: {
    
        }
    }
end function