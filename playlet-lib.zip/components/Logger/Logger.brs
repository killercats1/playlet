'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/MessagePortUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"






function Init()
    m.top.functionName = "LoggerLoop"
    port = CreateObject("roMessagePort")
    m.top.ObserveField("logLine", port)
    scene = m.top.getScene()
    if scene.hasField("systemLogEvent")
        MessagePortUtils_ObserveFieldScopedExSafe(scene, "systemLogEvent", port)
        if scene.hasField("enableSystemLogType")
            scene.enableSystemLogType = "http.error"
        end if
    end if
    m.port = port
    StartLogger(m.top, 2)
end function

function StartLogger(logger as object, logLevel = 2 as object) as void
    if m.global.logger <> invalid
        return
    end if
    logger.logLevel = logLevel
    m.global.addFields({
        logger: logger
    })
    logger.control = "run"
end function

function LoggerLoop()
    port = m.port
    buffer = CreateObject("roByteArray")
    logsFile = "cachefs:/logs" + "/" + "app_logs.txt"
    previousLogsFile = "cachefs:/logs" + "/" + "app_logs_previous.txt"
    dateTime = CreateObject("roDateTime")
    CreateDirectory("cachefs:/logs")
    DeleteFile(previousLogsFile)
    MoveFile(logsFile, previousLogsFile)
    
    startUpLogs = ReadAsciiFile("cachefs:/playlet_startup_logs.txt")
    if not StringUtils_IsNullOrEmpty(startUpLogs)
        line = ("************* Startup Logs *************" + chr(10) + bslib_toString(startUpLogs) + "*********** End Startup Logs ***********" + chr(10))
        
        buffer.FromAsciiString(line)
        buffer.AppendFile(logsFile)
    end if
    m.eventThrottleTimer = CreateObject("roTimespan")
    appMemoryMonitor = CreateObject("roAppMemoryMonitor")
    if appMemoryMonitor <> invalid and FindMemberFunction(appMemoryMonitor, "EnableMemoryWarningEvent") <> invalid
        appMemoryMonitor.SetMessagePort(port)
        appMemoryMonitor.EnableMemoryWarningEvent(true)
    end if
    deviceInfo = CreateObject("roDeviceInfo")
    deviceInfo.SetMessagePort(port)
    deviceInfo.EnableLowGeneralMemoryEvent(true)
    m.lastDeviceInfoMemoryLevel = ""
    while true
        msg = wait(0, port)
        msgType = type(msg)
        if msgType = "roSGNodeEvent"
            field = msg.getField()
            if field = "logLine"
                OnLineLog(msg, dateTime, logsFile, buffer)
            else if field = "systemLogEvent"
                OnLineSysLog(msg, dateTime, logsFile, buffer)
            end if
        else if msgType = "roAppMemoryNotificationEvent"
            OnLineLogMonitorMemoryWarning(msg, dateTime, logsFile, buffer)
        else if msgType = "roDeviceInfoEvent"
            OnLineLogDeviceInfoMemoryWarning(msg, dateTime, logsFile, buffer)
        end if
    end while
end function

function OnLineLog(event as object, dateTime as object, logsFile as string, buffer as object)
    line = FormatTime(dateTime) + event.getData()
    
    buffer.FromAsciiString(line + (chr(10)))
    buffer.AppendFile(logsFile)
end function

function OnLineSysLog(event as object, dateTime as object, logsFile as string, buffer as object) as void
    info = event.getData()
    if info.LogType <> "http.error"
        return
    end if
    httpCode = ValidInt(info.HttpCode)
    if httpCode >= 200 and httpCode < 300
        return
    end if
    line = FormatTime(dateTime) + "[ERROR][SysLog] " + ToString(info)
    
    buffer.FromAsciiString(line + (chr(10)))
    buffer.AppendFile(logsFile)
    urlType = GetSysLogUrlType(info.OrigUrl)
    fingerprint = ("SysLog-" + bslib_toString(urlType) + "-" + bslib_toString(info.Status) + "-" + bslib_toString(info.LogType) + "-" + bslib_toString(httpCode) + "-" + bslib_toString(info.Method))
    if ThrottleEvent("SysLogError" + urlType, fingerprint, 60)
        return
    end if
    LogTelemetryEvent({
        level: "error"
        message: line + (chr(10) + "CurrentTime: " + bslib_toString(m.eventThrottleTimer.TotalSeconds()))
        fingerprint: [
            fingerprint
        ]
    })
end function

function GetSysLogUrlType(url as dynamic) as string
    if not IsString(url)
        return "other"
    end if
    if url.InStr("/api/timedtext") <> -1 or url.InStr("/api/v1/captions/") <> -1
        return "captions"
    end if
    if url.InStr("/videoplayback") <> -1
        return "videoplayback"
    end if
    if url.InStr("/api/manifest/") <> -1 or url.InStr("/api/dash") <> -1 or url.InStr("/api/hls") <> -1
        return "manifest"
    end if
    return "other"
end function

function OnLineLogMonitorMemoryWarning(event as object, dateTime as object, logsFile as string, buffer as object) as void
    info = event.getInfo()
    message = "[WARN][AppMonitorMemory] " + ToString(info)
    line = FormatTime(dateTime) + message
    
    buffer.FromAsciiString(line + (chr(10)))
    buffer.AppendFile(logsFile)
    if ThrottleEvent("AppMonitorMemoryWarning", message, 60)
        return
    end if
    
end function

function OnLineLogDeviceInfoMemoryWarning(event as object, dateTime as object, logsFile as string, buffer as object) as void
    info = event.getInfo()
    if not IsString(info.generalMemoryLevel)
        return
    end if
    if ThrottleEvent("DeviceInfoMemoryWarning", info.generalMemoryLevel, 60)
        return
    end if
    message = "[WARN][DeviceInfoMemory] " + ToString(info)
    line = FormatTime(dateTime) + message
    
    buffer.FromAsciiString(line + (chr(10)))
    buffer.AppendFile(logsFile)
    
end function

' Returns true if the event should be throttled
function ThrottleEvent(key as string, fingerprint as string, throttleSeconds as integer) as boolean
    lastSentTime = ValidInt(m[key])
    currentTime = m.eventThrottleTimer.TotalSeconds()
    if ((currentTime - lastSentTime) < throttleSeconds) and (m[key + "Fingerprint"] = fingerprint)
        return true
    end if
    m[key] = currentTime
    m[key + "Fingerprint"] = fingerprint
    return false
end function

' Note: although the timestamp should be captured in the caller, not the logger,
' it is done here to avoid adding overhead to the caller thread.
function FormatTime(dateTime as object) as string
    dateTime.Mark()
    dateTime.ToLocalTime()
    hours = dateTime.GetHours().ToStr("%02d")
    minutes = dateTime.GetMinutes().ToStr("%02d")
    seconds = dateTime.GetSeconds().ToStr("%02d")
    milliseconds = dateTime.GetMilliseconds().ToStr("%03d")
    return "[" + hours + ":" + minutes + ":" + seconds + "." + milliseconds + "]"
end function