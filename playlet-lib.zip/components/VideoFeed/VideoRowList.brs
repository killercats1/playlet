'import "pkg:/components/ChannelView/ChannelUtils.bs"
'import "pkg:/components/ContextMenu/ContextMenuUtils.bs"
'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/Navigation/LongPress.bs"
'import "pkg:/components/PlaylistView/PlaylistUtils.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/components/VideoDetailsView/VideoDetailsUtils.bs"
'import "pkg:/components/VideoFeed/FeedLoadState.bs"
'import "pkg:/source/utils/DisposableObserve.bs"
'import "pkg:/source/utils/ErrorUtils.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"

' TODO:P1 add the option to remove a row if it does not have any content
' E.g. Subscriptions, Watch History and Playlists can be empty
function Init()
    InitializeBindings() ' auto-generated!
    m.pendingLoadJobs = {}
end function

function OnNodeReady()
    DisposableObserveField(m.top, "itemFocused", FuncName(OnItemFocused))
    DisposableObserveField(m.top, "rowItemFocused", FuncName(OnRowItemFocused))
    DisposableObserveField(m.top, "rowItemSelected", FuncName(OnRealRowItemSelected))
    DisposableObserveField(m.top, "focusedChild", FuncName(OnFocusedChildChange))
    DisposableObserveField(m.top, "visible", FuncName(OnVisibilityChange))
    
    DisposableObserveFieldScoped(m.profilesService, "currentProfileChanged", FuncName(OnCurrentProfileChanged))
    InitializeLongPress([
        "OK"
    ])
end function

function OnFocusedChildChange() as void
    if m.top.hasFocus()
        LoadRowsIfNeeded()
    end if
end function

function OnVisibilityChange()
    if m.top.visible = true
        LoadRowsIfNeeded()
    end if
end function

function OnFeedsChange() as void
    InitContent()
end function

function OnItemFocused()
    LoadRowsIfNeeded()
end function

function OnRowItemFocused(event as object) as void
    index = event.GetData()
    if index = invalid or index.count() <> 2
        LogWarn3("[VideoRowList.bs:56]", "Invalid index:", index)
        return
    end if
    rowIndex = index[0]
    rowItemIndex = index[1]
    row = m.top.content.GetChild(rowIndex)
    if not row.loadState = "LoadedPage"
        return
    end if
    
    if rowItemIndex > row.getChildCount() - 5
        LoadRowContent(row)
    end if
end function

function OnRowItemSelected(index as object) as void
    content = m.top.content
    if content = invalid
        return
    end if
    if index = invalid or index.count() <> 2
        LogWarn3("[VideoRowList.bs:80]", "Invalid index:", index)
        return
    end if
    rowIndex = index[0]
    rowItemIndex = index[1]
    if rowIndex < 0 or rowIndex >= content.GetChildCount()
        LogWarn3("[VideoRowList.bs:88]", "Invalid row index:", rowIndex)
        return
    end if
    row = content.GetChild(rowIndex)
    if rowItemIndex < 0 or rowItemIndex >= row.GetChildCount()
        LogWarn3("[VideoRowList.bs:94]", "Invalid row item index:", rowItemIndex)
        return
    end if
    rowItem = row.GetChild(rowItemIndex)
    if rowItem.type = "video" and IsShortsRow(row)
        PlayShortsFrom(row, rowItemIndex)
    else if rowItem.type = "video"
        videoId = rowItem.videoId
        LogInfo2("[VideoRowList.bs:103]", "Play video: " + videoId)
        m.videoQueue.playVideo = rowItem
    else if rowItem.type = "playlist"
        playlistId = rowItem.playlistId
        LogInfo2("[VideoRowList.bs:107]", "Open playlist: " + playlistId)
        OpenPlaylist(rowItem)
    else if rowItem.type = "channel"
        authorId = rowItem.authorId
        LogInfo2("[VideoRowList.bs:111]", "Open channel: " + authorId)
        OpenChannel(rowItem)
    else
        LogWarnNoTelemetry3("[VideoRowList.bs:114]", "Unknown row item type:", rowItem.type)
    end if
end function

function OnRowItemLongPressed(index as object) as void
    content = m.top.content
    if content = invalid
        return
    end if
    if not IsArray(index) or index.count() <> 2
        LogWarn3("[VideoRowList.bs:125]", "Invalid index:", index)
        return
    end if
    rowIndex = index[0]
    rowItemIndex = index[1]
    if not IsInt(rowIndex) or rowIndex < 0 or rowIndex >= content.GetChildCount()
        LogWarn3("[VideoRowList.bs:133]", "Invalid row index:", rowIndex)
        return
    end if
    row = content.GetChild(rowIndex)
    if not IsInt(rowItemIndex) or rowItemIndex < 0 or rowItemIndex >= row.GetChildCount()
        LogWarn3("[VideoRowList.bs:139]", "Invalid row item index:", rowItemIndex)
        return
    end if
    rowItem = row.GetChild(rowItemIndex)
    contextMenuProviders = [
        m.top
        m.bookmarksService
        m.top.screen
    ]
    ContextMenuUtils_Open(contextMenuProviders, m.appController, rowItem)
end function

function GetContextMenuOptionsForItem(rowItem as object) as object
    options = []
    if rowItem.type = "video"
        options.push(ContextMenuUtils_CreateOption(Tr("Play Video"), m.videoQueue, "FuncPlayVideo", [
            rowItem
        ]))
        options.push(ContextMenuUtils_CreateOption(Tr("Play next"), m.videoQueue, "FuncPlayNextVideo", [
            rowItem
        ]))
        options.push(ContextMenuUtils_CreateOption(Tr("Queue Video"), m.videoQueue, "FuncAddToQueueVideo", [
            rowItem
        ]))
        options.push(ContextMenuUtils_CreateOption(Tr("Video details"), m.top, "OpenVideoDetails", [
            rowItem
        ]))
        options.push(ContextMenuUtils_CreateOption(Tr("Start mix"), m.top, "StartMix", [
            rowItem
        ]))
        
        profile = m.top.profilesService.currentProfile
        if profile <> invalid and profile.type = "youtube"
            
            options.push(ContextMenuUtils_CreateOption(Tr("Not interested"), m.top, "SendFeedback", [
                rowItem
                "notInterested"
            ]))
            if not StringUtils_IsNullOrEmpty(rowItem.authorId)
                options.push(ContextMenuUtils_CreateOption(Tr("Don't recommend channel"), m.top, "SendFeedback", [
                    rowItem
                    "channel"
                ]))
            end if
            
            rowFeedId = RowFeedSourceId(rowItem)
            if rowFeedId = "inv_auth_watch_later"
                options.push(ContextMenuUtils_CreateOption(Tr("Remove from Watch later"), m.top, "RemoveFromList", [
                    rowItem
                    "watchLater"
                ]))
            else
                options.push(ContextMenuUtils_CreateOption(Tr("Save to Watch later"), m.top, "SaveToWatchLater", [
                    rowItem
                ]))
            end if
            if rowFeedId = "inv_auth_liked_videos"
                options.push(ContextMenuUtils_CreateOption(Tr("Remove from Liked videos"), m.top, "RemoveFromList", [
                    rowItem
                    "liked"
                ]))
            end if
            if not StringUtils_IsNullOrEmpty(rowItem.removeFromHistoryToken)
                options.push(ContextMenuUtils_CreateOption(Tr("Remove from watch history"), m.top, "RemoveFromList", [
                    rowItem
                    "history"
                ]))
            end if
        end if
        authorId = rowItem.authorId
        if not StringUtils_IsNullOrEmpty(authorId)
            options.push(ContextMenuUtils_CreateOption(Tr("Open Channel"), m.top, "OpenVideoChannel", [
                rowItem
            ]))
        end if
    else if rowItem.type = "playlist"
        options.push(ContextMenuUtils_CreateOption(Tr("Play Playlist"), m.videoQueue, "FuncPlayPlaylist", [
            rowItem
            0
        ]))
        options.push(ContextMenuUtils_CreateOption(Tr("Shuffle play"), m.videoQueue, "FuncShufflePlaylist", [
            rowItem
        ]))
        options.push(ContextMenuUtils_CreateOption(Tr("Queue Playlist"), m.videoQueue, "FuncAddToQueuePlaylist", [
            rowItem
        ]))
        options.push(ContextMenuUtils_CreateOption(Tr("Open Playlist"), m.top, "OpenPlaylist", [
            rowItem
        ]))
        authorId = rowItem.authorId
        if not StringUtils_IsNullOrEmpty(authorId)
            options.push(ContextMenuUtils_CreateOption(Tr("Open Channel"), m.top, "OpenPlaylistChannel", [
                rowItem
            ]))
        end if
    else if rowItem.type = "channel"
        options.push(ContextMenuUtils_CreateOption(Tr("Open Channel"), m.top, "OpenChannel", [
            rowItem
        ]))
    else
        LogWarnNoTelemetry3("[VideoRowList.bs:199]", "Unknown long pressed item type:", rowItem.type)
        return []
    end if
    return options
end function

' The Home Shorts row plays like the Shorts tab: all its Shorts queued, Up/Down flips, endless.
function IsShortsRow(row as object) as boolean
    feedSources = row.feedSources
    return IsArray(feedSources) and feedSources.Count() > 0 and feedSources[0].id = "inv_auth_shorts"
end function

function PlayShortsFrom(row as object, index as integer) as void
    nodes = []
    startIndex = 0
    children = row.getChildren(-1, 0)
    for i = 0 to children.Count() - 1
        video = children[i]
        if i = index
            startIndex = nodes.Count()
        end if
        if video.type = "video" and not StringUtils_IsNullOrEmpty(video.videoId)
            node = video.clone(false)
            node.addFields({
                isShort: true
            })
            nodes.Push(node)
        end if
    end for
    if nodes.Count() = 0 or startIndex >= nodes.Count()
        return
    end if
    lastNode = nodes[nodes.Count() - 1]
    lastNode.addFields({
        shortsMore: "v:" + lastNode.videoId
    })
    m.videoQueue.setQueueAndIndex = {
        videoNodes: nodes
        index: startIndex
    }
    m.videoQueue.play = true
end function

function OpenPlaylist(playlist as object)
    PlaylistUtils_Open(playlist)
end function

function OpenChannel(channel as object)
    ChannelUtils_Open(channel)
end function

' "Not interested" (kind "notInterested") or "Don't recommend channel" (kind "channel"): tells YouTube, and takes
' the video (or every video of that channel in the row) off the screen right away.
function SendFeedback(video as object, kind as string) as void
    token = ValidString(video.notInterestedToken)
    if kind = "channel"
        token = ValidString(video.dontRecommendChannelToken)
    end if
    authorId = ""
    if video.hasField("authorId")
        authorId = ValidString(video.authorId)
    end if
    videoId = ValidString(video.videoId)
    cardHeading = Tr("Removed from your feeds")
    if kind = "channel"
        cardHeading = Tr("Channel hidden from your feeds")
    end if
    JobSystem_QueueJob(m.jobQueue, "FeedbackJob", {
        token: token
        profile: m.top.profilesService.currentProfile
        kind: kind
        videoId: videoId
        authorId: authorId
    }, CardCallback(cardHeading, video))
    row = video.getParent()
    if row = invalid
        return
    end if
    
    rows = [
        row
    ]
    root = row.getParent()
    if root <> invalid
        rows = root.getChildren(-1, 0)
    end if
    for each feedRow in rows
        for each item in feedRow.getChildren(-1, 0)
            if kind = "channel" and authorId <> ""
                if item.hasField("authorId") and item.authorId = authorId
                    feedRow.removeChild(item)
                end if
            else if videoId <> "" and item.hasField("videoId") and item.videoId = videoId
                feedRow.removeChild(item)
            end if
        end for
    end for
    if video.getParent() <> invalid
        video.getParent().removeChild(video)
    end if
end function

' A job callback that shows the card when the job is done, like Save to Watch later's (which does show: a card
' shown right away, from the options menu, never appeared).
function CardCallback(heading as string, video as object) as object
    callback = JobSystem_CreateCallback(OnCardJobDone)
    callback.addFields({
        cardHeading: heading
        cardVideo: video
    })
    return callback
end function

function OnCardJobDone(event as object) as void
    callback = event.getRoSGNode()
    JobSystem_UnobserveCallback(callback)
    heading = callback.cardHeading
    
    info = event.getInfo()
    if info.success <> true and info.cancel <> true
        LogWarn3("[VideoRowList.bs:309]", "Options menu action failed:", info.error)
        heading = Tr("That didn't work, try again")
    end if
    ShowRowListNotification(heading, callback.cardVideo)
end function

'  "Start mix": YouTube's endless mix (radio) of songs/videos like this one, the "RD<videoId>" playlist.
function StartMix(video as object) as void
    videoId = ValidString(video.videoId)
    if videoId = ""
        return
    end if
    
    m.videoQueue.playVideo = video
    if m.pendingMix <> invalid
        m.pendingMix.unobserveFieldScoped("loadState")
    end if
    mix = CreateObject("roSGNode", "PlaylistContentNode")
    mix.loadState = "None"
    mix.type = "playlist"
    mix.playlistId = "RD" + videoId
    mix.videoId = videoId
    mix.title = Tr("Mix - %1").Replace("%1", ValidString(video.title))
    m.pendingMix = mix
    mix.observeFieldScoped("loadState", FuncName(OnMixLoadState))
    mix.callfunc("LoadPlaylistPage", m.top.invidious, m.jobQueue)
end function

function OnMixLoadState() as void
    mix = m.pendingMix
    if mix = invalid
        return
    end if
    loadState = mix.loadState
    if loadState = "Loading"
        return
    end if
    mix.unobserveFieldScoped("loadState")
    m.pendingMix = invalid
    if loadState = "Error" or loadState = "None"
        return
    end if
    nodes = []
    for each node in mix.getChildren(-1, 0)
        if node.hasField("videoId") and node.videoId <> mix.videoId
            nodes.Push(node)
        end if
    end for
    if nodes.Count() > 0
        m.videoQueue.addToQueue = nodes
    end if
end function

function RowFeedSourceId(rowItem as object) as string
    row = rowItem.getParent()
    if row = invalid or not row.hasField("feedSources")
        return ""
    end if
    feedSources = row.feedSources
    if not IsArray(feedSources) or feedSources.Count() = 0
        return ""
    end if
    return ValidString(feedSources[0].id)
end function

' Takes a video out of one of the account's lists. list: "watchLater", "liked" or "history".
function RemoveFromList(video as object, list as string) as void
    profile = m.top.profilesService.currentProfile
    videoId = ValidString(video.videoId)
    if videoId = ""
        return
    end if
    if list = "watchLater"
        JobSystem_QueueJob(m.jobQueue, "WatchLaterJob", {
            videoId: videoId
            profile: profile
            remove: true
        }, CardCallback(Tr("Removed from Watch later"), video))
    else if list = "liked"
        JobSystem_QueueJob(m.jobQueue, "LikeJob", {
            videoId: videoId
            action: "removelike"
            profile: profile
        }, CardCallback(Tr("Removed from Liked videos"), video))
    else if list = "history"
        JobSystem_QueueJob(m.jobQueue, "FeedbackJob", {
            token: video.removeFromHistoryToken
            profile: profile
            kind: "history"
            videoId: videoId
        }, CardCallback(Tr("Removed from watch history"), video))
    else
        return
    end if
    row = video.getParent()
    if row <> invalid
        row.removeChild(video)
    end if
end function

function SaveToWatchLater(video as object) as void
    if StringUtils_IsNullOrEmpty(video.videoId)
        return
    end if
    m.watchLaterVideo = video
    m.watchLaterJob = JobSystem_CreateCallback(OnWatchLaterJobDone)
    JobSystem_QueueJob(m.jobQueue, "WatchLaterJob", {
        videoId: video.videoId
        profile: m.top.profilesService.currentProfile
    }, m.watchLaterJob)
end function

function OnWatchLaterJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.watchLaterJob = invalid
    info = event.getInfo()
    heading = Tr("Saved to Watch later")
    if info.success <> true
        LogWarn3("[VideoRowList.bs:414]", "Save to Watch later failed:", info.error)
        heading = Tr("Couldn't save to Watch later")
    end if
    ShowRowListNotification(heading, m.watchLaterVideo)
    m.watchLaterVideo = invalid
end function

' A small card that slides in at the top right (the "Added to queue" card, with another heading).
function ShowRowListNotification(heading as string, video as dynamic) as void
    notifications = m.videoQueue.notifications
    if notifications = invalid
        return
    end if
    notification = notifications.findNode("RowListNotification")
    if notification = invalid
        notification = notifications.createChild("VideoQueueNotification")
        notification.id = "RowListNotification"
    end if
    notification.heading = heading
    notification.hintVisible = false
    if video <> invalid
        notification.content = video
    end if
    notification.show = true
end function

function OpenVideoDetails(video as object) as void
    VideoDetailsUtils_Open(video, m.appController)
end function

function OpenVideoChannel(video as object) as void
    authorId = video.authorId
    if StringUtils_IsNullOrEmpty(authorId)
        LogWarn3("[VideoRowList.bs:447]", "Invalid authorId:", authorId)
        return
    end if
    channel = InvidiousContent_ToChannelContentNode(invalid, {
        authorId: authorId
    })
    ChannelUtils_Open(channel)
end function

function OpenPlaylistChannel(playlist as object) as void
    authorId = playlist.authorId
    if StringUtils_IsNullOrEmpty(authorId)
        LogWarn3("[VideoRowList.bs:457]", "Invalid authorId:", authorId)
        return
    end if
    channel = InvidiousContent_ToChannelContentNode(invalid, {
        authorId: authorId
    })
    ChannelUtils_Open(channel)
end function

function Refresh(_unused as dynamic)
    InitContent()
end function

function OnCurrentProfileChanged()
    
    InitContent()
end function

function InitContent() as void
    CancelCurrentJobs()
    if m.top.feeds = invalid
        m.top.content = invalid
        return
    end if
    input = {
        node: m.top
        feeds: m.top.feeds
    }
    callback = JobSystem_CreateCallback(OnVideoRowListContentJobDone)
    m.pendingLoadJobs[callback.id] = {
        callback: callback
    }
    JobSystem_QueueJob(m.jobQueue, "VideoRowListContentJob", input, callback)
end function

function CancelCurrentJobs()
    pendingLoadJobs = m.pendingLoadJobs
    for each id in pendingLoadJobs
        callback = pendingLoadJobs[id].callback
        callback.cancel = true
    end for
    m.pendingLoadJobs = {}
end function

function OnVideoRowListContentJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.pendingLoadJobs.Delete(event.getNode())
    info = event.getInfo()
    if info.cancel
        return
    end if
    LoadRowsIfNeeded()
end function

function LoadRowsIfNeeded() as void
    if m.top.content = invalid or not m.top.visible
        return
    end if
    itemsToLoad = GetRowsToLoad()
    for each item in itemsToLoad
        LoadRowContent(item)
    end for
end function

function GetRowsToLoad() as object
    focus = m.top.itemFocused
    if focus = -1
        focus = 0
    end if
    contentNode = m.top.content
    rowCount = contentNode.getChildCount()
    if rowCount = 0
        return []
    end if
    subContentNodes = []
    range = m.top.numRows + 1
    for i = -range to range
        index = focus + i
        if index < 0
            continue for
        end if
        if index >= rowCount
            continue for
        end if
        subContentNode = contentNode.getChild(index)
        if subContentNode.loadState <> "None"
            continue for
        end if
        subContentNodes.push(subContentNode)
    end for
    return subContentNodes
end function

function LoadRowContent(contentNode as object) as void
    
    for each id in m.pendingLoadJobs
        job = m.pendingLoadJobs[id]
        if contentNode.isSameNode(job.content) and not job.callback.done
            LogInfo3("[VideoRowList.bs:561]", "Row content already loading:", contentNode.title)
            return
        end if
    end for
    LogInfo3("[VideoRowList.bs:566]", "Loading row content:", contentNode.title)
    contentNode.loadState = "Loading"
    input = {
        rowList: m.top
        feedContentNode: contentNode
        invidious: m.invidious
    }
    callback = JobSystem_CreateCallback(OnVideoRowListRowContentJobDone)
    m.pendingLoadJobs[callback.id] = {
        callback: callback
        content: contentNode
    }
    JobSystem_QueueJob(m.jobQueue, "VideoRowListRowContentJob", input, callback)
end function

function OnVideoRowListRowContentJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.pendingLoadJobs.Delete(event.getNode())
    info = event.getInfo()
    if info.cancel
        return
    end if
    LoadRowsIfNeeded()
end function

function OnRealRowItemSelected()
    
    LongPressHandler("OK", true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    
    if not (key = "OK" and press)
        if LongPressHandler(key, press)
            return true
        end if
    end if
    if key = "OK_LONG_PRESS" and press
        OnRowItemLongPressed(m.top.rowItemFocused)
        return true
    end if
    if key = "OK" and not press
        
        OnRowItemSelected(m.top.rowItemSelected)
        return true
    end if
    return false
end function

function OnDispose()
    CancelCurrentJobs()
    DisposeObservers()
    m.top.screen = invalid
    m.top.content = invalid
    m.top.itemComponentName = invalid
end function