'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.bs"
'import "pkg:/components/Services/FeedFilters/FeedFilters.bs"
'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/source/services/HttpClient.bs"

' Sends YouTube a "Not interested" / "Don't recommend channel" for the signed-in account (feedback token from
' the feed item's menu), and remembers the video/channel on the TV so feeds drop it right away.
' input: { token, profile, kind: "notInterested"|"channel", videoId, authorId }
function ExecuteJob() as void
    input = JobGetInput()
    token = ValidString(input.token)
    profile = input.profile
    kind = ValidString(input.kind)
    if kind = "channel"
        FeedFilters_Remember("channel", ValidString(input.authorId))
    else if kind <> "history"
        FeedFilters_Remember("video", ValidString(input.videoId))
    end if
    if token = ""
        
        JobSuccess()
        return
    end if
    if profile = invalid or profile.type <> "youtube"
        JobError("Feedback needs a YouTube account")
        return
    end if
    auth = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(profile)
    if auth.state <> "Ok"
        JobError("No usable access token to send feedback: " + auth.state)
        return
    end if
    options = {
        accessToken: auth.token
    }
    if not StringUtils_IsNullOrEmpty(auth.activeIdentifyToken)
        options.onBehalfOfUser = auth.activeIdentifyToken
    end if
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/feedback?prettyPrint=false&alt=json").JsonBody({
        "context": Innertube_CreateContext("TV", CreateObject("roDeviceInfo"), options)
        "feedbackTokens": [
            token
        ]
        "isFeedbackTokenUnencrypted": false
        "shouldMerge": false
    })
    request.Headers(Innertube_CreateHeaders("TV"))
    request.Header("Authorization", "Bearer " + auth.token)
    request.Cancellation(JobGetCancellation())
    response = request.Await()
    if not response.IsSuccess()
        JobError("Failed to send feedback: " + response.ErrorMessage())
        return
    end if
    JobSuccess()
end function