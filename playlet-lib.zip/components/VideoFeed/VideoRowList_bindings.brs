' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "appController": "/AppController", 
            "invidious": "/Invidious", 
            "profilesService": "/ProfilesService", 
            "videoQueue": "/VideoQueue", 
            "bookmarksService": "/BookmarksService", 
            "jobQueue": "/JobQueue"
        },
        childProps: {
    
        }
    }
end function