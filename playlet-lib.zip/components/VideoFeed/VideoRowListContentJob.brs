'import "pkg:/components/VideoFeed/FeedLoadState.bs"
'import "pkg:/source/utils/StringUtils.bs"

function ExecuteJob() as void
    input = JobGetInput()
    feeds = input.feeds
    rowList = input.node
    contentNode = CreateObject("roSGNode", "ContentNode")
    for each feed in feeds
        feedContentNode = CreateObject("roSGNode", "FeedContentNode")
        feedContentNode.title = feed.title
        feedContentNode.feedSourcesIndex = 0
        feedContentNode.loadState = "None"
        feedSources = feed.feedSources
        for i = 0 to feedSources.count() - 1
            feedSources[i].state = {
                loadState: "None"
            }
        end for
        feedContentNode.feedSources = feedSources
        for i = 1 to 4
            feedContentNode.createChild("LoadingContentNode")
        end for
        contentNode.appendChild(feedContentNode)
    end for
    rowList.content = contentNode
end function