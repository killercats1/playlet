'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.bs"
'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/source/services/HttpClient.bs"

' Saves a video to (or, with remove: true, removes it from) the signed-in YouTube account's Watch later
' playlist. input: { videoId, profile, remove }
function ExecuteJob() as void
    input = JobGetInput()
    videoId = ValidString(input.videoId)
    profile = input.profile
    if videoId = ""
        JobError("No video to save")
        return
    end if
    if profile = invalid or profile.type <> "youtube"
        JobError("Watch later needs a YouTube account")
        return
    end if
    auth = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(profile)
    if auth.state <> "Ok"
        JobError("No usable access token to save the video: " + auth.state)
        return
    end if
    options = {
        accessToken: auth.token
    }
    if not StringUtils_IsNullOrEmpty(auth.activeIdentifyToken)
        options.onBehalfOfUser = auth.activeIdentifyToken
    end if
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/browse/edit_playlist?prettyPrint=false&alt=json").JsonBody({
        "context": Innertube_CreateContext("TV", CreateObject("roDeviceInfo"), options)
        "playlistId": "WL"
        "actions": [
            WatchLaterAction(videoId, input.remove = true)
        ]
    })
    request.Headers(Innertube_CreateHeaders("TV"))
    request.Header("Authorization", "Bearer " + auth.token)
    request.Cancellation(JobGetCancellation())
    response = request.Await()
    if not response.IsSuccess()
        JobError("Failed to save to Watch later: " + response.ErrorMessage())
        return
    end if
    json = response.Json()
    if IsAssociativeArray(json) and IsString(json.status) and json.status <> "STATUS_SUCCEEDED"
        JobError("Watch later refused: " + json.status)
        return
    end if
    JobSuccess()
end function

function WatchLaterAction(videoId as string, remove as boolean) as object
    if remove
        return {
            "action": "ACTION_REMOVE_VIDEO_BY_VIDEO_ID"
            "removedVideoId": videoId
        }
    end if
    return {
        "action": "ACTION_ADD_VIDEO"
        "addedVideoId": videoId
    }
end function