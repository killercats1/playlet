'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/Services/Invidious/InvidiousService.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"

function ExecuteJob() as void
    try
        input = JobGetInput()
        rowList = input.rowList
        feedContentNode = input.feedContentNode
        invidiousNode = input.invidious
        callbackNode = JobGetCallbackNode()
        cancellation = CancellationUtils_CreateCancellation(callbackNode, "cancel", true)
        service = Invidious_InvidiousService(invidiousNode)
        instance = service.GetInstance()
        totalfetchedItems = 0
        someContentReadySet = false
        while true
            if JobIsCancelled()
                feedContentNode.loadState = "None"
                JobCancel()
                return
            end if
            feedSources = feedContentNode.feedSources
            feedSourcesIndex = feedContentNode.feedSourcesIndex
            if feedSourcesIndex >= feedSources.Count()
                feedContentNode.loadState = "Loaded"
                if not someContentReadySet
                    rowList.someContentReady = false
                end if
                JobSuccess()
                return
            end if
            feedSource = feedSources[feedSourcesIndex]
            if feedSource.state.loadState = "Loaded" or feedSource.state.loadState = "Error"
                feedSourcesIndex += 1
                if feedSourcesIndex >= feedSources.Count()
                    feedContentNode.loadState = "Loaded"
                    if not someContentReadySet
                        rowList.someContentReady = false
                    end if
                    JobSuccess()
                    return
                end if
                feedContentNode.feedSourcesIndex = feedSourcesIndex
                continue while
            end if
            feedSource = service.MarkFeedPagination(feedContentNode)
            hadContinuation = not StringUtils_IsNullOrEmpty(feedSource.state.continuation)
            response = service.MakeRequest(feedSource, {
                additionalQueryParams: feedSource.state.queryParams
                cancellation: cancellation
            })
            if not response.success
                if RemoveSingleFailedRow(response.error, feedSource, feedSources, feedContentNode)
                    JobSuccess()
                    return
                end if
                feedSource.state.loadState = "Error"
                feedSources[feedSourcesIndex] = feedSource
                feedContentNode.feedSources = feedSources
                isCancelled = response.cancelled = true
                if not isCancelled
                    if feedContentNode.title.instr(" (Failed to load)") = -1
                        feedContentNode.title += " (Failed to load)"
                    end if
                end if
                HandleFeedLoadErrorDialog(response.error, isCancelled, rowList)
                continue while
            end if
            
            if feedSource.useResponseTitle = true and IsString(response.result.title) and response.result.title <> ""
                feedContentNode.title = response.result.title
            end if
            itemNodes = []
            for each item in response.result.items
                itemNode = InvidiousContent_ToRowCellContentNode(item, instance)
                if itemNode <> invalid
                    itemNode.feedSourcesIndex = feedSourcesIndex
                    itemNodes.Push(itemNode)
                end if
            end for
            RemovePlaceHolderItems(feedContentNode)
            addedItemCount = 0
            
            if feedSource.id = "inv_auth_playlists"
                addedItemCount = DeduplicateAppendAuthPlaylists(feedContentNode, itemNodes)
            else
                feedContentNode.appendChildren(itemNodes)
                addedItemCount = itemNodes.Count()
            end if
            hasContinuation = not StringUtils_IsNullOrEmpty(response.result.continuation)
            feedSource.state.continuation = ValidString(response.result.continuation)
            if response.result.sortOptions <> invalid
                feedSource.state.sortOptions = response.result.sortOptions
            end if
            if addedItemCount > 0
                pageType = feedSource.state.paginationType
                if response.result.isLastPage = true or (hadContinuation and not hasContinuation)
                    feedSource.state.loadState = "Loaded"
                else if hasContinuation
                    feedSource.state.loadState = "LoadedPage"
                else if pageType = "Pages"
                    feedSource.state.loadState = "LoadedPage"
                else
                    feedSource.state.loadState = "Loaded"
                end if
            else
                feedSource.state.loadState = "Loaded"
            end if
            feedSources[feedSourcesIndex] = feedSource
            feedContentNode.feedSources = feedSources
            if feedSource.state.loadState = "Loaded" and feedSourcesIndex = feedSources.Count() - 1
                feedContentNode.loadState = "Loaded"
            else
                feedContentNode.loadState = "LoadedPage"
            end if
            if addedItemCount > 0 and not someContentReadySet
                someContentReadySet = true
                rowList.someContentReady = true
            end if
            totalfetchedItems += addedItemCount
            if totalfetchedItems > 3
                exit while
            end if
        end while
    catch error
        HandleFeedLoadErrorDialog(error, false, rowList)
        JobError(error)
        return
    end try
end function

function RemovePlaceHolderItems(contentNode as object)
    childCount = contentNode.getChildCount()
    removeIndex = childCount
    removeCount = 0
    index = childCount - 1
    isLoading = true
    while isLoading and index >= 0
        child = contentNode.getChild(index)
        isLoading = ValidString(child.type) = "loading"
        if not isLoading
            exit while
        end if
        removeCount += 1
        removeIndex -= 1
        index -= 1
    end while
    if removeCount > 0
        contentNode.removeChildrenIndex(removeCount, removeIndex)
    end if
end function

function DeduplicateAppendAuthPlaylists(feedContentNode as object, itemNodes as object) as integer
    if itemNodes.Count() = 0
        return 0
    end if
    currentChildCount = feedContentNode.getChildCount()
    if currentChildCount = 0
        feedContentNode.appendChildren(itemNodes)
        return itemNodes.Count()
    end if
    currentChildren = feedContentNode.getChildren(-1, 0)
    currentChildrenMap = {}
    for i = 0 to currentChildCount - 1
        playlistId = currentChildren[i].playlistId
        if StringUtils_IsNullOrEmpty(playlistId)
            continue for
        end if
        currentChildrenMap[playlistId] = true
    end for
    nodesToAdd = []
    for i = 0 to itemNodes.Count() - 1
        itemNode = itemNodes[i]
        playlistId = itemNode.playlistId
        if StringUtils_IsNullOrEmpty(playlistId)
            continue for
        end if
        if currentChildrenMap[playlistId] = true
            continue for
        end if
        currentChildrenMap[playlistId] = true
        nodesToAdd.Push(itemNode)
    end for
    if nodesToAdd.Count() = 0
        return 0
    end if
    feedContentNode.appendChildren(nodesToAdd)
    return nodesToAdd.Count()
end function

function RemoveSingleFailedRow(error as dynamic, feedSource as object, feedSources as object, feedContentNode as object) as boolean
    error = ValidString(error)
    LogWarnNoTelemetry4("[VideoRowListRowContentJob.bs:230]", feedSource.id, "feedSource not available:", error)
    if feedSources.Count() <> 1
        return false
    end if
    isError = error = "Not authenticated"
    
    isError = isError or error.instr("Administrator has disabled this endpoint") <> -1
    isError = isError or error.instr("API disabled") <> -1
    
    isError = isError or feedSource.id = "inv_popular"
    
    isError = isError or feedSource.id = "music_recommended"
    
    isError = isError or feedSource.id = "inv_auth_shorts"
    
    isError = isError or feedSource.id = "inv_auth_liked_videos" or feedSource.id = "inv_auth_watch_later"
    
    isError = isError or ValidString(feedSource.id).StartsWith("inv_auth_home_shelf") or feedSource.id = "inv_auth_continue_watching"
    isError = isError or feedSource.id = "inv_auth_channels"
    isError = isError or ValidString(feedSource.id).StartsWith("inv_auth_topic_shelf")
    if not isError
        return false
    end if
    parent = feedContentNode.getParent()
    if parent <> invalid
        parent.removeChild(feedContentNode)
    end if
    return true
end function

function HandleFeedLoadErrorDialog(error as object, isCancelled as boolean, rowList as object) as void
    error = ErrorUtils_Format(error)
    if isCancelled
        LogErrorNoTelemetry2("[VideoRowListRowContentJob.bs:267]", error)
    else
        LogError2("[VideoRowListRowContentJob.bs:269]", error)
    end if
    rowList.onError = error
    if rowList.hasField("dispose") and rowList.dispose
        return
    end if
    if isCancelled
        return
    end if
    DialogUtils_ShowDialogEx({
        message: error
        title: "Failed to load feed"
        large: true
    })
end function