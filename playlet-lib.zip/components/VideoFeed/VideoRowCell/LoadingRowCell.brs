'import "pkg:/source/utils/Types.bs"

function Init()
    
    m.top.observeField("visible", FuncName(OnVisibleChanged))
    OnVisibleChanged()
end function

function OnVisibleChanged()
    Animate()
end function

function OnIndexSet()
    m.top.animationDelay = (m.top.index mod 5) * 0.2
    Animate()
end function

function Animate()
    if m.top.visible then
        m.top.animationControl = "start"
    else
        m.top.animationControl = "stop"
    end if
end function