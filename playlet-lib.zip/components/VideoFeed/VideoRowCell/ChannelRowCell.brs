'import "pkg:/source/utils/StringUtils.bs"

function OnContentSet() as void
    content = m.top.itemContent
    if content = invalid
        return
    end if
    
    m.top._author = content._author
    subCountText = content.authorSubTitle
    if StringUtils_IsNullOrEmpty(subCountText)
        if content.subCount > 0
            subCountText = content.subCountText
            if StringUtils_IsNullOrEmpty(subCountText)
                subCountText = content.videoCountText
            end if
        else
            subCountText = content.videoCountText
            if StringUtils_IsNullOrEmpty(subCountText)
                subCountText = content.subCountText
            end if
        end if
    end if
    m.top.subCountText = subCountText
    m.top.channelHandle = content.channelHandle
    m.top.thumbnail = content.thumbnail
end function