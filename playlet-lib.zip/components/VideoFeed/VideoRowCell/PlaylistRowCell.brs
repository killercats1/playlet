'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    m.videoCountRect = m.top.FindNode("videoCountRect")
    m.videoCountLabel = m.top.FindNode("videoCountLabel")
end function

function OnContentSet() as void
    content = m.top.itemContent
    if content = invalid
        return
    end if
    m.top.title = content.title
    lines = content.lines
    
    author = content._author
    if StringUtils_IsNullOrEmpty(author)
        if IsArray(lines) and lines.Count() > 0
            author = lines[0]
        end if
    end if
    m.top.author = author
    updatedText = content.updatedText
    if StringUtils_IsNullOrEmpty(updatedText)
        if IsArray(lines) and lines.Count() > 1
            updatedText = lines[1]
        end if
    end if
    m.top.updated = updatedText
    m.top.thumbnailUri = content.thumbnail
    SetVideoCount(content.videoCountText)
end function

function SetVideoCount(videoCountText as string) as void
    hasText = videoCountText <> ""
    m.top.videoCountRectVisible = hasText
    if not hasText
        return
    end if
    m.top.videoCount = videoCountText
    label = m.videoCountLabel
    rect = m.videoCountRect
    if label = invalid or rect = invalid
        return
    end if
    rectParent = rect.getParent()
    size = label.localBoundingRect()
    rect.width = size.width + 16
    rect.translation = [
        rectParent.width - rect.width
        rect.translation[1]
    ]
end function