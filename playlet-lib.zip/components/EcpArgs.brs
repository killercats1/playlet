'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function InitEcpArgs()
    m.videoQueue = m.top.findNode("VideoQueue")
    LaunchArgumentsReceived()
    m.scene.ObserveField("inputArgs", FuncName(InputArgumentsReceived))
    if m.scene.inputArgs <> invalid
        InputArgumentsReceived()
    end if
end function

function LaunchArgumentsReceived() as void
    launchArgs = m.scene.launchArgs
    LogInfo3("[EcpArgs.bs:16]", "LaunchArgumentsReceived", launchArgs)
    ProcessArguments(launchArgs)
end function

function InputArgumentsReceived() as void
    inputArgs = m.scene.inputArgs
    LogInfo3("[EcpArgs.bs:22]", "InputArgumentsReceived", inputArgs)
    ProcessArguments(inputArgs)
end function

function ProcessArguments(args as object) as void
    if args = invalid
        return
    end if
    if not StringUtils_IsNullOrEmpty(args.contentId) and StringUtils_IsNullOrEmpty(args.videoId)
        args.videoId = args.contentId
    end if
    if args.timestamp <> invalid
        args.timestamp = args.timestamp.ToInt()
    end if
    if not StringUtils_IsNullOrEmpty(args.videoId)
        node = CreateObject("roSGNode", "VideoContentNode")
        node.videoId = args.videoId
        if args.timestamp <> invalid
            node.timestamp = args.timestamp
        end if
        m.videoQueue.playVideo = node
    end if
end function