'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
' Pure error decisions for the video player: retry the next stream URL vs. show the error dialog. No node,
' no state — the coordinator owns the dialog node and applies the retry.


' A content-job failure means no stream loaded at all -> always a dialog.
function ErrorDialogController_DecideContentJobFailure(content as object, error as dynamic) as object
    videoId = ""
    if content <> invalid
        videoId = ValidString(content.videoId)
    end if
    message = Tr("Failed to load video information for %1").Replace("%1", videoId)
    errStr = ValidString(error)
    if errStr <> ""
        message = message + (chr(10)) + errStr
    end if
    return {
        action: 0
        title: Tr("Video load error")
        message: message
    }
end function

' A Video state=error. Before the first successful play, whatever the error, retry the next stream URL if one
' exists; otherwise a dialog. The URLs are variants of one source (quality-filtered first, then unfiltered,
' then proxied), and a filtered manifest the device can't play fails under more than one category
' (telemetry: mediaplayer and mediaerror). On retry the coordinator re-applies the initial seek
' (SeekToInitialPosition).
function ErrorDialogController_DecideVideoError(content as object, videoPlayedSuccessfully as boolean) as object
    if not videoPlayedSuccessfully and content <> invalid
        nextUrl = ErrorDialogController_NextStreamUrl(content)
        if nextUrl <> invalid
            return {
                action: 1
                nextUrl: nextUrl
            }
        end if
    end if
    return {
        action: 0
    }
end function

' Advance content.playletStreamUrlIndex to the next non-empty stream URL (also sets content.url), or
' invalid if there is none. Mutates the content node in place.
function ErrorDialogController_NextStreamUrl(content as object) as dynamic
    urls = content.playletStreamUrls
    if not IsArray(urls)
        return invalid
    end if
    nextIndex = ValidInt(content.playletStreamUrlIndex) + 1
    if nextIndex >= urls.Count()
        return invalid
    end if
    nextUrl = urls[nextIndex]
    if StringUtils_IsNullOrEmpty(nextUrl)
        return invalid
    end if
    content.playletStreamUrlIndex = nextIndex
    content.url = nextUrl
    return nextUrl
end function