'import "pkg:/components/Services/Dash/LiveLoadCounts.bs"
'import "pkg:/components/Services/Innertube/DrmLicenseRequests.bs"
'import "pkg:/components/Telemetry/VideoLoadHandoff.bs"
'import "pkg:/components/VideoPlayerDev/VideoNode.bs"
'import "pkg:/source/utils/ErrorUtils.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"






function PlaybackTelemetry_ContentBackend(content as object) as string
    if content <> invalid and not StringUtils_IsNullOrEmpty(content.backend)
        return content.backend
    end if
    return "unknown"
end function

function PlaybackTelemetry_ContentVideoLoadId(content as object) as string
    if content = invalid
        return ""
    end if
    return ValidString(content.videoLoadId)
end function

' The summary's wire rule: false, 0, "", [] and invalid are omitted, at every depth; a reader takes an absent
' field as that default.
function PlaybackTelemetry_OmitDefaults(value as dynamic) as dynamic
    if IsAssociativeArray(value)
        result = {}
        for each key in value
            item = PlaybackTelemetry_OmitDefaults(value[key])
            if not PlaybackTelemetry_IsDefault(item)
                result[key] = item
            end if
        end for
        return result
    end if
    if IsArray(value)
        result = []
        for each item in value
            result.Push(PlaybackTelemetry_OmitDefaults(item))
        end for
        return result
    end if
    return value
end function

function PlaybackTelemetry_IsDefault(value as dynamic) as boolean
    if value = invalid
        return true
    end if
    if IsBool(value)
        return not value
    end if
    if IsNumber(value)
        return value = 0
    end if
    if IsString(value)
        return value = ""
    end if
    if IsArray(value)
        return value.Count() = 0
    end if
    return false
end function
function __PlaybackTelemetry_Recorder_method_new(deps as object)
    m.playerTimer = invalid
    m.transport = invalid
    m.top = invalid
    m.outcome = "closed"
    m.metadataDoneAtMs = -1
    m.firstPlayingAtMs = -1
    m.playStartInfos = invalid
    m.playStartCount = 0
    m.span = 0
    m.spanStartMs = 0
    m.lastIsUnderrun = false
    m.playingMs = 0
    m.underrunCount = 0
    m.underrunMs = 0
    m.underrunSamples = invalid
    m.bufferingsWithoutStatusCount = 0
    m.isUnderrunChangeCount = 0
    m.errorCount = 0
    m.healCount = 0
    m.healSamples = invalid
    m.tailResolveCount = 0
    m.tailResolveSamples = invalid
    m.startSegmentBitrateBps = 0
    m.startMeasuredBitrateBps = 0
    m.playerTimer = deps.playerTimer
    m.transport = deps.transport
    m.top = deps.top
    m.playStartInfos = []
    m.underrunSamples = []
    m.healSamples = []
    m.tailResolveSamples = []
end function
function __PlaybackTelemetry_Recorder_method_OnMetadataDone() as void
    m.metadataDoneAtMs = m.playerTimer.TotalMilliseconds()
end function
function __PlaybackTelemetry_Recorder_method_OnState(state as string) as void
    nowMs = m.playerTimer.TotalMilliseconds()
    m.CloseSpan(nowMs, state)
    m.spanStartMs = nowMs
    if state = "playing"
        m.span = 1
        if m.firstPlayingAtMs < 0
            m.firstPlayingAtMs = nowMs
            m.startMeasuredBitrateBps = ValidInt(ValidAssociativeArray(m.top.streamInfo).measuredBitrate)
        end if
        
        if m.outcome = "error"
            m.outcome = "closed"
        end if
    else if state = "buffering"
        m.span = 2
    else
        m.span = 0
    end if
end function
function __PlaybackTelemetry_Recorder_method_OnBufferingStatus(status as object) as void
    if status = invalid or not IsBool(status.isUnderrun)
        return
    end if
    isUnderrun = status.isUnderrun
    if m.span = 2
        if isUnderrun
            m.span = 3
        else
            m.span = 4
        end if
        m.lastIsUnderrun = isUnderrun
    else if (m.span = 3 or m.span = 4) and isUnderrun <> m.lastIsUnderrun
        m.isUnderrunChangeCount += 1
        m.lastIsUnderrun = isUnderrun
    end if
end function
function __PlaybackTelemetry_Recorder_method_OnPlayStartInfo(info as object) as void
    if info = invalid
        return
    end if
    m.playStartCount += 1
    if m.playStartInfos.Count() < 10
        m.playStartInfos.Push(info)
    end if
end function
function __PlaybackTelemetry_Recorder_method_OnStreamingSegment(segment as object) as boolean
    if segment = invalid or not IsInt(segment.segType)
        return false
    end if
    if segment.segType <> 0 and segment.segType <> 2
        return false
    end if
    m.startSegmentBitrateBps = ValidInt(segment.segBitrateBps)
    return true
end function
function __PlaybackTelemetry_Recorder_method_OnErrorDialog() as void
    m.outcome = "error"
end function
function __PlaybackTelemetry_Recorder_method_OnFinished() as void
    m.outcome = "finished"
end function
function __PlaybackTelemetry_Recorder_method_RecordHeal(source as string) as void
    m.healCount += 1
    positionMs = Int(m.top.position * 1000)
    floorMs = m.transport.SafetyFloorMs()
    
    if m.healSamples.Count() < 3
        m.healSamples.Push({
            "at_ms": m.playerTimer.TotalMilliseconds()
            "source": source
            "mode": m.transport.transportMode
            "position_ms": positionMs
            "cursor_ms": m.transport.cursorMs
            "edge_ms": m.transport.edgeMs
            "floor_ms": floorMs ' -1 = no floor: VOD, or a live stream with an unknown window
        })
    end if
end function
function __PlaybackTelemetry_Recorder_method_RecordTailResolve(source as string) as void
    m.tailResolveCount += 1
    positionMs = Int(m.top.position * 1000)
    floorMs = m.transport.SafetyFloorMs()
    
    if m.tailResolveSamples.Count() < 3
        m.tailResolveSamples.Push({
            "at_ms": m.playerTimer.TotalMilliseconds()
            "source": source
            "position_ms": positionMs
            "cursor_ms": m.transport.cursorMs
            "floor_ms": floorMs
            "edge_ms": m.transport.edgeMs
        })
    end if
end function
function __PlaybackTelemetry_Recorder_method_ReportVideoError(errorData as object, errorInfo as object, url as dynamic, urlIndex as dynamic, shownInDialog as boolean) as void
    m.errorCount += 1
    attachments = invalid
    if errorData.body.Instr("malformed data") <> -1 or errorData.body.Instr("invalid pathname") <> -1 or ((errorInfo = invalid or errorInfo.category <> "http") and errorData.body.Instr("last_err:") = -1)
        attachments = [
            {
                filename: "last_generated_dash.xml"
                content_type: "plain/text"
                data: ValidString(ReadAsciiFile("cachefs:/last_generated_dash.xml"))
            }
            {
                filename: "last_generated_hls.m3u8"
                content_type: "plain/text"
                data: ValidString(ReadAsciiFile("cachefs:/last_generated_hls.m3u8"))
            }
            {
                filename: "last_player_response.json"
                content_type: "application/json"
                data: ValidString(ReadAsciiFile("cachefs:/last_player_response.json"))
            }
        ]
    end if
    potAttached = false
    potSource = "none"
    loggedIn = false
    urls = invalid
    content = m.top.content
    if content <> invalid
        urls = content.playletStreamUrls
        potAttached = ValidBool(content.potAttached)
        loggedIn = ValidBool(content.loggedIn)
        if not StringUtils_IsNullOrEmpty(content.potSource)
            potSource = content.potSource
        end if
    end if
    backend = PlaybackTelemetry_ContentBackend(content)
    isLive = m.transport.isLive
    message = [
        errorData.title
        errorData.body
        ("Dialog shown: " + bslib_toString(shownInDialog))
        ("Position: " + bslib_toString(m.top.position))
        ("Duration: " + bslib_toString(m.top.duration))
        ("Url: " + bslib_toString(url))
        "Urls: " + FormatJson(urls)
        ("Url index: " + bslib_toString(urlIndex))
        ("pot_attached: " + bslib_toString(potAttached))
        ("pot_source: " + bslib_toString(potSource))
        ("logged_in: " + bslib_toString(loggedIn))
        ("backend: " + bslib_toString(backend))
        ("is_live: " + bslib_toString(isLive))
        ("video_load_id: " + bslib_toString(PlaybackTelemetry_ContentVideoLoadId(content)))
    ].Join(Chr(10))
    fingerprint = [
        "Error playing video %1"
        m.top.errorMsg
        m.top.errorCode
    ]
    if errorInfo <> invalid
        fingerprint.Append([
            errorInfo.source
            errorInfo.ignored
            errorInfo.category
            errorInfo.errcode
            errorInfo.drmerrcode
        ])
    end if
    fingerprint.Append([
        shownInDialog
        potAttached
        potSource
        loggedIn
        backend
        isLive
    ])
    if shownInDialog
        level = "error"
    else
        level = "warning"
    end if
    LogTelemetryEvent({
        level: level
        message: message
        fingerprint: fingerprint
        attachments: attachments
    })
end function
function __PlaybackTelemetry_Recorder_method_ReportContentJobFailure(error as dynamic) as void
    LogError2("[PlaybackTelemetry.bs:311]", ("VideoContentJob FAILED: " + bslib_toString(error) + chr(10) + "backend: " + bslib_toString(PlaybackTelemetry_ContentBackend(m.top.content))))
end function
function __PlaybackTelemetry_Recorder_method_ReportStopFailure(error as object) as void
    LogError3("[PlaybackTelemetry.bs:315]", "error stopping video:", ErrorUtils_Format(error))
end function
function __PlaybackTelemetry_Recorder_method_SendSummary() as void
    lifetimeMs = m.playerTimer.TotalMilliseconds()
    endedInUnderrun = m.span = 3
    m.CloseSpan(lifetimeMs, "")
    m.span = 0
    content = m.top.content
    summary = {
        "live": m.transport.isLive
        "backend": PlaybackTelemetry_ContentBackend(content)
        "video_load_id": PlaybackTelemetry_ContentVideoLoadId(content)
        "outcome": m.outcome
        "metadata_done_at_ms": m.metadataDoneAtMs
        "first_playing_at_ms": m.firstPlayingAtMs
        "play_start_infos": m.playStartInfos
        "play_start_count": m.playStartCount
        "lifetime_ms": lifetimeMs
        "playing_ms": m.playingMs
        "underrun_count": m.underrunCount
        "underrun_ms": m.underrunMs
        "underrun_samples": m.underrunSamples
        "ended_in_underrun": endedInUnderrun
        "bufferings_without_status_count": m.bufferingsWithoutStatusCount
        "is_underrun_change_count": m.isUnderrunChangeCount
        "error_count": m.errorCount
        "heal_count": m.healCount
        "heal_samples": m.healSamples
        "tail_resolve_count": m.tailResolveCount
        "tail_resolve_samples": m.tailResolveSamples
    }
    if m.transport.isLive
        liveLoadCounts = ValidAssociativeArray(VideoLoadHandoff_ReadAndDelete("tmp:/live_load_counts.json", summary["video_load_id"]))
        summary["live_head"] = liveLoadCounts["live_head"]
        summary["live_timeline"] = liveLoadCounts["live_timeline"]
        summary["start_segment_bitrate_bps"] = m.startSegmentBitrateBps
        summary["start_measured_bitrate_bps"] = m.startMeasuredBitrateBps
    end if
    if content <> invalid
        summary["video_id"] = content.videoId
        summary["stream_source"] = content.playletStreamSource
        summary["drm"] = not StringUtils_IsNullOrEmpty(ValidAssociativeArray(content.drmParams).keySystem)
        summary["stream_url_index"] = content.playletStreamUrlIndex
        if summary["drm"]
            summary["drm_license_requests"] = VideoLoadHandoff_ReadAndDelete("tmp:/drm_license_requests.json", summary["video_load_id"])
            summary["widevine_security_level"] = ValidAssociativeArray(CreateObject("roDeviceInfo").GetDrmInfoEx().Widevine).securityLevel
            hdmiStatus = CreateObject("roHdmiStatus")
            if hdmiStatus <> invalid
                summary["hdcp_version"] = hdmiStatus.GetHdcpVersion()
            end if
        end if
    end if
    LogTelemetryEvent({
        level: "info"
        message: FormatJson(PlaybackTelemetry_OmitDefaults(summary))
        fingerprint: [
            "playback summary"
        ]
    })
end function
function __PlaybackTelemetry_Recorder_method_CloseSpan(nowMs as integer, nextState as string) as void
    durationMs = nowMs - m.spanStartMs
    if m.span = 1
        m.playingMs += durationMs
    else if m.span = 3
        m.underrunCount += 1
        m.underrunMs += durationMs
        if m.underrunCount <= 10
            m.underrunSamples.Push({
                "at_ms": m.spanStartMs
                "ms": durationMs
            })
        end if
    else if m.span = 2 and nextState = "playing"
        m.bufferingsWithoutStatusCount += 1
    end if
end function
function __PlaybackTelemetry_Recorder_builder()
    instance = {}
    ' started with the player: every *Ms is ms on it
    instance.new = __PlaybackTelemetry_Recorder_method_new
    instance.OnMetadataDone = __PlaybackTelemetry_Recorder_method_OnMetadataDone
    instance.OnState = __PlaybackTelemetry_Recorder_method_OnState
    ' Measured: a seek, resume, startup or retry buffering reports isUnderrun false; only a playback that ran
    ' dry reports true.
    instance.OnBufferingStatus = __PlaybackTelemetry_Recorder_method_OnBufferingStatus
    instance.OnPlayStartInfo = __PlaybackTelemetry_Recorder_method_OnPlayStartInfo
    ' True once the first segment carrying video started streaming: its bitrate is the one kept.
    instance.OnStreamingSegment = __PlaybackTelemetry_Recorder_method_OnStreamingSegment
    instance.OnErrorDialog = __PlaybackTelemetry_Recorder_method_OnErrorDialog
    instance.OnFinished = __PlaybackTelemetry_Recorder_method_OnFinished
    instance.RecordHeal = __PlaybackTelemetry_Recorder_method_RecordHeal
    instance.RecordTailResolve = __PlaybackTelemetry_Recorder_method_RecordTailResolve
    instance.ReportVideoError = __PlaybackTelemetry_Recorder_method_ReportVideoError
    instance.ReportContentJobFailure = __PlaybackTelemetry_Recorder_method_ReportContentJobFailure
    instance.ReportStopFailure = __PlaybackTelemetry_Recorder_method_ReportStopFailure
    instance.SendSummary = __PlaybackTelemetry_Recorder_method_SendSummary
    ' A buffering that got no status counts only when it reached playing: a close, pause or error can land before
    ' the first status, which follows the buffering edge by up to ~65 ms (measured).
    instance.CloseSpan = __PlaybackTelemetry_Recorder_method_CloseSpan
    return instance
end function
function PlaybackTelemetry_Recorder(deps as object)
    instance = __PlaybackTelemetry_Recorder_builder()
    instance.new(deps)
    return instance
end function