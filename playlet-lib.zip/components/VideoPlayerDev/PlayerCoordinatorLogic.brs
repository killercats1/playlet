'import "pkg:/components/VideoPlayerDev/TransportController.bs"
'import "pkg:/components/VideoPlayerDev/VideoNode.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"
' Pure decisions for the video player: the remote-key-to-command map, the OK/Select action, and the
' buffering-spinner gate. None of these touch a node, so they are plain functions of their inputs; the player
' applies the results to the Video node, the chrome, and the renderers.
' The chrome fade state the coordinator owns (the Chrome group opacity as one unit). Declared here (file
' scope, not in the namespace) because the Back ladder decides over it; the coordinator keeps using the
' bare ChromeMode.* names via its import of this file.

' What an OK/Select press does while no transport is active. Live toggles the HUD without pausing; VOD
' depends on both the play state and whether the HUD is already shown.


' The Back ladder. Priority = enum order: an active transport outranks the chrome, which outranks
' closing — a Back while ANY chrome is on screen never exits.

' The buttons in the row above the trackbar, in focus order (the index). The COUNT is owned by ButtonRow
' (m.buttons / its buttonCount field) — there is no separate count constant to keep in sync.

' The two focus targets above/at the trackbar: the bar itself (Left/Right scrub, the cursor grows) and the
' button row above it (Left/Right move between buttons). Up/Down move between the two tiers.


' The transport command for a remote key, or Command.None for a key the player handles itself.
function PlayerCoordinatorLogic_KeyToCommand(key as string) as integer
    if key = "left"
        return 1
    else if key = "right"
        return 2
    else if key = "fastforward"
        return 4
    else if key = "rewind"
        return 3
    else if key = "replay"
        return 5
    end if
    return 0
end function

' The OK/Select outcome while idle. chromeShown means the HUD is shown or fading in.
function PlayerCoordinatorLogic_OkActionInIdle(state as string, chromeShown as boolean, isLive as boolean) as integer
    if isLive
        return 3
    end if
    if state = "playing"
        if chromeShown
            return 1
        end if
        return 0
    end if
    if chromeShown
        return 2
    end if
    return 0
end function

' The Back decision. A press while the chrome is still visible in ANY form never exits: shown/fading-in
' dismisses (animated); mid fade-out the dismissal is already underway, so the press is consumed and the
' fade just finishes (the user can still see the UI, so Back must not read as "nothing left to undo").
' Only a fully hidden chrome falls through to Close.
function PlayerCoordinatorLogic_BackActionFor(transportMode as integer, chrome as integer) as integer
    if transportMode <> 0
        return 0
    end if
    if chrome = 2 or chrome = 1
        return 1
    end if
    if chrome = 3
        return 2
    end if
    return 3
end function

' The mid-stream buffering spinner shows only after the first frame, while idle, and while fullscreen.
function PlayerCoordinatorLogic_ShouldShowBuffering(firstFrameSeen as boolean, transportMode as integer, fullscreen as boolean) as boolean
    return firstFrameSeen and transportMode = 0 and fullscreen
end function

' Only a video actively PLAYING under a transport must be re-paused. Every other state is already
' not-advancing or owned elsewhere: buffering = a seek/rebuffer the bif covers; paused = the desired frozen
' state; none/stopping/stopped = teardown; finished/error = handled in their own OnVideoState branches.
' EXCEPTION (VOD): playing at the very end while the transport cursor is ALSO at the end — the device refuses
' to stay paused at EOF (the freeze would loop forever), and the user is at the end anyway: finish instead.
' A cursor rewound away from the end keeps the freeze (the user is heading backwards).
' EXCEPTION (live): the sliding DVR tail overtaking the frozen playhead — the device force-resumes such a
' pause on every manifest refresh (from ~10s above the advertised floor), so a re-pause cannot stick and the
' freeze would loop forever; resolve forward instead. liveFloorMs is the availability floor (edge − window),
' or -1 when the window is unknown (no floor knowledge -> plain freeze).
function PlayerCoordinatorLogic_TransportSafetyAction(deviceState as string, inTransport as boolean, isLive as boolean, positionMs as integer, cursorMs as integer, durationMs as integer, liveFloorMs as integer) as integer
    if not inTransport or deviceState <> "playing"
        return 0
    end if
    if isLive
        if liveFloorMs >= 0 and positionMs < liveFloorMs + 30000
            return 3
        end if
        return 1
    end if
    atEof = durationMs > 0 and positionMs >= durationMs - 2000
    cursorAtEof = cursorMs >= durationMs - 2000
    if atEof and cursorAtEof
        return 2
    end if
    return 1
end function

' Clamp a button index into [0, count).
function PlayerCoordinatorLogic_ClampButtonIndex(index as integer, count as integer) as integer
    if index < 0
        return 0
    end if
    if index >= count
        return count - 1
    end if
    return index
end function

' The focused button after a Left/Right press, clamped at the ends (no wrap). count = the row's button count.
function PlayerCoordinatorLogic_NextButtonIndex(current as integer, key as string, count as integer) as integer
    if key = "left"
        return PlayerCoordinatorLogic_ClampButtonIndex(current - 1, count)
    else if key = "right"
        return PlayerCoordinatorLogic_ClampButtonIndex(current + 1, count)
    end if
    return PlayerCoordinatorLogic_ClampButtonIndex(current, count)
end function

' Move focus between the tiers: Down goes buttons -> bar; Up goes bar -> buttons. No wrap (the buttons are
' the top tier, the bar the bottom).
function PlayerCoordinatorLogic_NextFocusTarget(current as integer, key as string) as integer
    if key = "down" and current = 1
        return 0
    else if key = "up" and current = 0
        return 1
    end if
    return current
end function

' Pick the first usable tile-set from the OS's native Video.thumbnailTiles field, or invalid. thumbnailTiles
' is documented (Video node docs) as {tile_id: [tile_set, ...]}; a tile_set carries htiles/vtiles (grid),
' tiles (sheet array, tiles[i][0] = sheet url), duration (seconds per sheet), and final_time (total seconds).
' BifDisplay reads those native fields directly; the coordinator uses TileSetIntervalMs for the scrub step.
function PlayerCoordinatorLogic_PickThumbnailTileSet(tiles as object) as object
    if not IsAssociativeArray(tiles)
        return invalid
    end if
    for each key in tiles
        entry = tiles[key]
        if IsArray(entry) and entry.Count() > 0 and IsAssociativeArray(entry[0])
            tileSet = entry[0]
            if ValidInt(tileSet.htiles) > 0 and ValidInt(tileSet.vtiles) > 0 and IsArray(tileSet.tiles) and tileSet.tiles.Count() > 0 and IsNumber(tileSet.duration) and tileSet.duration > 0
                return tileSet
            end if
        end if
    end for
    return invalid
end function

' Milliseconds covered by one thumbnail in a tile-set: per-sheet duration / thumbnails-per-sheet. 0 if
' degenerate. (duration is a Double on-device; read raw + coerce arithmetically, not via ValidDouble.)
function PlayerCoordinatorLogic_TileSetIntervalMs(tileSet as object) as integer
    if not IsAssociativeArray(tileSet)
        return 0
    end if
    tilesPerSheet = ValidInt(tileSet.htiles) * ValidInt(tileSet.vtiles)
    if tilesPerSheet <= 0 or not IsNumber(tileSet.duration) or tileSet.duration <= 0
        return 0
    end if
    return Int(tileSet.duration * 1000.0 / tilesPerSheet)
end function