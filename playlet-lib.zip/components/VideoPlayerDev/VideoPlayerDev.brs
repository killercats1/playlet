'import "pkg:/components/ContentNode/ProfileContentAuthTokenUtils.types.bs"
'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/Services/FeedFilters/FeedFilters.bs"
'import "pkg:/components/Services/Innertube/Constants.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/components/VideoPlayer/Lounge.bs"
'import "pkg:/components/VideoPlayerDev/ErrorDialogController.bs"
'import "pkg:/components/VideoPlayerDev/PlaybackTelemetry.bs"
'import "pkg:/components/VideoPlayerDev/PlayerCoordinatorLogic.bs"
'import "pkg:/components/VideoPlayerDev/SponsorBlockController.bs"
'import "pkg:/components/VideoPlayerDev/TransportController.bs"
'import "pkg:/components/VideoPlayerDev/VideoNode.bs"
'import "pkg:/components/VideoQueue/VideoQueueUtils.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RegistryUtils.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
' Coordinator for the custom video player. extends Video, enableUI=false.
'
' Owns the focused Video node + key router, the Chrome-group fade, PiP resize, and lifecycle plumbing. All
' transport decisions live in m.transport (TransportController — a plain .bs module, not a node). Per device
' signal: route -> apply the module's outputs to m.top -> push its scalar outputs onto the renderer components'
' fields. Renderers self-derive visibility from transportMode (commit sets mode=idle and the bif vanishes by
' its own rule — no hide call needed).
' ChromeMode (the Chrome group fade state, owned here as one unit) lives in PlayerCoordinatorLogic.bs —
' the Back ladder decides over it.
' Int values the coordinator pushes onto LoadBufferSpinner.mode. Kept local to avoid importing the component's
' .bs (which would collide on Init).


' Init() lives in the tiny VideoPlayerDevInit.bs because the @oninit/AutoBind injection requires Init in exactly
' one component scope; this file is shared with the test mock (tests/VideoPlayerDevMock).
function Initialize()
    m.top.notificationInterval = 1
    m.transport = TransportController_Controller()
    m.playbackTelemetry = PlaybackTelemetry_Recorder({
        playerTimer: CreateObject("roTimespan")
        transport: m.transport
        top: m.top
    })
    m.videoContentJob = invalid
    m.sponsorBlockSegmentsJob = invalid
    m.markVideoWatchedJob = invalid
    m.watchTimeMarker = -1
    m.reportWatchTime = false
    m.onCloseCalled = false
    
    m.loadingSetSeekMs = -1
    m.errorDialogNode = invalid
    m.ignoreNextFinished = false 
    m.videoPlayedSuccessfully = false 
    m.chromeMode = 0
    m.liveBadgeHoldActive = false 
    m.firstFrameSeen = false
    m.showFullScreenHint = false
    m.focusTarget = 0
    m.focusedButton = 0
    m.armedTimerId = 0 
    m.lastCommitSeq = 0
    m.lastFinishSeq = 0
    
    m.repauseAfterSeek = false
    
    m.liveAstSeconds = -1
    m.liveFallbackEdgeMs = -1
    m.liveFallbackAtSeconds = 0
    m.nowDateTime = CreateObject("roDateTime")
    
    m.chrome = m.top.findNode("Chrome")
    m.titleLabel = m.top.findNode("titleLabel")
    m.secondaryTitleLabel = m.top.findNode("secondaryTitleLabel")
    m.clock = m.top.findNode("clock")
    m.bifDisplay = m.top.findNode("bifDisplay")
    m.trickPlayBar = m.top.findNode("trickPlayBar")
    m.spinner = m.top.findNode("spinner")
    m.largePause = m.top.findNode("largePause")
    m.buttonRow = m.top.findNode("buttonRow")
    m.fullScreenHint = m.top.findNode("fullScreenHint")
    m.captionsOverlay = m.top.findNode("captionsOverlay")
    m.upNextPanel = m.top.findNode("upNextPanel")
    m.upNextOpen = false
    
    m.likeState = 0
    m.likeJob = invalid
    m.subscribeJob = invalid
    m.subscriptionStatusFetched = false
    m.likeStatusFetched = false
    
    m.upNextDialog = invalid
    m.countdownTimer = invalid
    
    m.watchLaterJob = invalid
    m.watchLaterSaved = false
    
    m.waitingForShorts = false
    
    m.captionsEnabled = RegistryUtils_Read("captions_enabled") = "true"
    m.autoHide = m.top.findNode("autoHide")
    m.transportTimer = m.top.findNode("transportTimer")
    m.liveBadgeHold = m.top.findNode("liveBadgeHold")
    m.liveEdgeClock = m.top.findNode("liveEdgeClock")
    m.fullScreenHintTimer = m.top.findNode("fullScreenHintTimer")
    m.chromeFadeIn = m.top.findNode("chromeFadeIn")
    m.chromeFadeOut = m.top.findNode("chromeFadeOut")
    m.minimize = m.top.findNode("minimize")
    m.autoHide.ObserveField("fire", FuncName(OnAutoHideFire))
    m.transportTimer.ObserveField("fire", FuncName(OnTransportTimerFire))
    m.liveBadgeHold.ObserveField("fire", FuncName(OnLiveBadgeHoldFire))
    m.liveEdgeClock.ObserveField("fire", FuncName(OnLiveEdgeClockFire))
    m.fullScreenHintTimer.ObserveField("fire", FuncName(OnFullScreenHintTimer))
    m.chromeFadeIn.ObserveField("state", FuncName(OnChromeFadeInState))
    m.chromeFadeOut.ObserveField("state", FuncName(OnChromeFadeOutState))
    
    if m.top.hasField("asyncStopSemantics")
        m.top.asyncStopSemantics = true
    end if
    
    if m.top.hasField("enableLiveAvailabilityWindow")
        m.top.enableLiveAvailabilityWindow = true
    end if
    httpAgent = m.top.getHttpAgent()
    httpAgent.AddHeader("User-Agent", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:150.0) Gecko/20100101 Firefox/150.0")
end function

' Called by AutoBind once the bound interface fields (container, jobQueue, services, ...) resolve.
function OnNodeReady()
    
    m.sponsorblock = SponsorBlockController_Controller({
        jobQueue: m.jobQueue
        preferences: m.top.preferences
        notifications: m.top.notifications
        top: m.top
    })
    
    m.top.enableUI = false
    minRect = m.top.minRect
    if m.container.fullscreen
        rect = m.top.maxRect
    else
        rect = minRect
    end if
    m.top.width = rect.width
    m.top.height = rect.height
    m.top.translation = [
        rect.x
        rect.y
    ]
    
    hintLabel = m.top.findNode("fullScreenHintLabel")
    m.fullScreenHint.width = minRect.width
    hintLabel.width = minRect.width
    m.fullScreenHint.translation = [
        0
        minRect.height - m.fullScreenHint.height
    ]
    
    m.container.observeFieldScoped("fullscreen", FuncName(OnFullScreenChange))
    m.top.ObserveField("state", FuncName(OnVideoState))
    m.top.ObserveField("position", FuncName(OnPosition))
    m.top.ObserveField("duration", FuncName(OnDuration))
    m.top.ObserveField("close", FuncName(OnClose))
    
    m.top.ObserveField("thumbnailTiles", FuncName(OnThumbnailTiles))
    
    m.top.ObserveField("control", FuncName(OnControlChange))
    m.top.ObserveField("setSeek", FuncName(OnSetSeek))
    m.top.ObserveField("bufferingStatus", FuncName(OnBufferingStatus))
    m.top.ObserveField("playStartInfo", FuncName(OnPlayStartInfo))
    m.top.ObserveField("streamingSegment", FuncName(OnStreamingSegment))
    m.top.ObserveField("isSubscribed", FuncName(OnIsSubscribedChange))
    
    m.showFullScreenHint = not m.container.fullscreen
    RefreshFullScreenHint()
    if m.captionsOverlay <> invalid
        m.captionsOverlay.jobQueue = m.jobQueue
        if m.preferences <> invalid and IsString(m.preferences["playback.caption_size"])
            m.captionsOverlay.captionSize = m.preferences["playback.caption_size"]
        end if
        m.captionsOverlay.chrome = m.chrome
        m.captionsOverlay.fullscreen = m.container.fullscreen
        m.captionsOverlay.enabled = m.captionsEnabled
        m.captionsOverlay.video = m.top
    end if
    m.buttonRow.captionsOn = m.captionsEnabled
    UpdateSleepTimerLabel(false)
    UpdateSpeedLabel(false)
    if m.captionsEnabled
        ApplyCaptionSuppression()
    end if
    
    if m.container.fullscreen
        m.spinner.mode = 1
    end if
end function

'===============================================================================
' Drain the transport module after every interaction: apply its video intent (-> m.top.control / m.top.seek)
' and timer command (-> the single transportTimer), then push its scalar outputs onto the renderers.
'===============================================================================
function ApplyTransport() as void
    
    autoplayAfterSeek = (m.transport.transportMode = 0) or m.transport.seekSettling
    if m.top.autoplayAfterSeek <> autoplayAfterSeek
        m.top.autoplayAfterSeek = autoplayAfterSeek
    end if
    intent = m.transport.TakeVideoIntent()
    if intent <> invalid
        if intent.control = 1
            m.repauseAfterSeek = false
            m.top.control = "pause"
        else if intent.control = 2
            m.repauseAfterSeek = false
            m.top.control = "resume"
        end if
        if intent.hasSeek
            
            if intent.control = 0 and m.top.state = "paused"
                m.repauseAfterSeek = true
            end if
            ApplySeek(intent.seekMs)
        end if
    end if
    tc = m.transport.TakeTimerCmd()
    if tc <> invalid
        if tc.action = 1
            
            m.armedTimerId = tc.id
            m.transportTimer.control = "stop"
            if tc.delayMs >= 0
                m.transportTimer.duration = tc.delayMs / 1000.0
            end if
            m.transportTimer.repeat = tc.repeat
            m.transportTimer.control = "start"
        else if tc.action = 2
            m.transportTimer.control = "stop"
            m.armedTimerId = 0
        end if
    end if
    
    mode = m.transport.transportMode
    
    if mode <> 0
        CancelLiveBadgeHold()
    end if
    chromeVisible = (m.chromeMode = 2 or m.chromeMode = 1)
    if mode <> 0 or chromeVisible
        PushTransportToRenderers()
    end if
    
    if mode <> 0 or m.transport.commitSeq <> m.lastCommitSeq
        
    end if
    
    if m.transport.commitSeq <> m.lastCommitSeq
        m.lastCommitSeq = m.transport.commitSeq
        if m.spinner.mode = 2
            m.spinner.mode = 0
        end if
        HideChrome()
    end if
    
    if m.transport.finishSeq <> m.lastFinishSeq
        m.lastFinishSeq = m.transport.finishSeq
        LogInfo2("[VideoPlayerDev.bs:313]", "commit at end of content -> finish")
        OnPlaybackFinished()
    end if
end function

' Push the module's scalar outputs onto the renderer components. Split by mode so an idle VOD bar (which reads
' positionMs and ignores the cursor) doesn't get a cursorMs change that fires a Repaint painting nothing new.
' Cursor + live offset/edge go only when a transport is active OR on a live stream (the live bar's fill is
' proportional to the cursor even at rest). Called from ApplyTransport (when visible) and ShowChrome (reveal sync).
function PushTransportToRenderers() as void
    mode = m.transport.transportMode
    isLive = m.transport.isLive
    m.trickPlayBar.transportMode = mode
    m.trickPlayBar.glyph = m.transport.glyph
    m.trickPlayBar.isLive = isLive
    m.trickPlayBar.positionMs = m.transport.positionMs
    m.trickPlayBar.durationMs = m.transport.durationMs
    if mode <> 0 or isLive
        m.trickPlayBar.liveFloorMs = m.transport.LiveFloorMs()
        m.trickPlayBar.cursorMs = m.transport.cursorMs
        m.trickPlayBar.liveOffsetMs = m.transport.liveOffsetMs
        m.trickPlayBar.atLiveEdge = m.transport.atLiveEdge
        m.bifDisplay.cursorMs = m.transport.cursorMs
    end if
    
    m.bifDisplay.transportMode = mode
    m.buttonRow.transportMode = mode
    
    chapterText = ""
    if m.sponsorblock.HasSegments()
        chapterText = m.sponsorblock.ChapterTextForCursor(m.transport.cursorMs)
    end if
    if chapterText = ""
        chapterText = YouTubeChapterAt(m.transport.cursorMs)
    end if
    if chapterText <> m.trickPlayBar.chapterText
        m.trickPlayBar.chapterText = chapterText
    end if
end function

' The title of the video's chapter at ms, "" when it has no chapters.
function YouTubeChapterAt(ms as integer) as string
    content = m.top.content
    if content = invalid or not content.hasField("metadata") or not IsAssociativeArray(content.metadata)
        return ""
    end if
    videoChapters = content.metadata.chapters
    if not IsArray(videoChapters)
        return ""
    end if
    title = ""
    for each chapter in videoChapters
        if chapter.startMs > ms
            exit for
        end if
        title = ValidString(chapter.title)
    end for
    return title
end function

' Apply a seek (ms): the one writer of the device's `seek`. The live "jump to edge" sentinel maps to the
' live-end seek the OS understands.
function ApplySeek(seekMs as integer) as void
    m.sponsorblock.OnSeek(seekMs)
    if TransportController_IsLiveEdgeSentinelMs(seekMs)
        m.top.seek = 999999
        return
    end if
    m.top.seek = seekMs / 1000.0
end function

'===============================================================================
' Key router — route intent, hold no behavior.
'===============================================================================
function OnKeyEvent(key as string, press as boolean) as boolean
    
    if m.upNextOpen
        return HandleUpNextKey(key, press)
    end if
    
    if press and key = "OK" and TrySponsorBlockSkip()
        return true
    end if
    if press and key = "back" and m.sponsorblock.DismissManual()
        return true
    end if
    
    if press and (key = "up" or key = "down") and IsPlayingShort() and not CanFocusInteract() and m.transport.transportMode = 0
        FlipShort(key = "down")
        return true
    end if
    
    if press and CanFocusInteract()
        
        if key = "up" or key = "down"
            newTarget = PlayerCoordinatorLogic_NextFocusTarget(m.focusTarget, key)
            if newTarget <> m.focusTarget
                SetFocusTarget(newTarget)
            else if m.focusTarget = 1
                m.buttonRow.nudge = true
                ArmAutoHide()
            else if key = "down"
                
                OpenUpNext()
            end if
            return true
        end if
        
        if m.focusTarget = 1 and HandleButtonsKey(key)
            return true
        end if
    end if
    
    if press and (key = "up" or key = "down") and m.transport.transportMode = 0
        if not (m.chromeMode = 2 or m.chromeMode = 1)
            ShowChrome()
            return true
        end if
    end if
    
    cmd = PlayerCoordinatorLogic_KeyToCommand(key)
    if cmd <> 0
        if press
            
            m.focusTarget = 0
        end if
        m.transport.HandleKey(cmd, press)
        ApplyTransport()
        
        if press and (m.transport.transportMode <> 0 or m.transport.glyph <> 0)
            ShowChrome(true)
        end if
        return true
    end if
    
    if not press
        return false
    end if
    if key = "OK"
        return OnOkPress()
    else if key = "play" or key = "playonly"
        return OnPlayPress()
    else if key = "back"
        return OnBackPress()
    end if
    return false
end function

' SponsorBlock manual-skip: if a manual segment is armed + we're still inside it, OK skips it (seek to its
' end, or finish if it's at the very end) and dismisses the notification. Called FIRST in OnKeyEvent — the
' on-screen "Press OK to skip" must win over the button/bar focus tiers.
function TrySponsorBlockSkip() as boolean
    skip = m.sponsorblock.TrySkip(Int(m.top.position * 1000))
    if skip = (-1)
        return false
    end if
    
    if skip = (-2)
        OnPlaybackFinished()
    else
        
        m.transport.ForceIdleSeek(skip, true)
        ApplyTransport()
    end if
    return true
end function

' OK/Select — the one shared key. Priority (after the SponsorBlock skip, handled in OnKeyEvent): commit (if a
' transport is active) -> chrome/pause toggle. OK is the VOD pause key. So
' while idle: VOD = play/pause toggle (reveals chrome + LargePause); live = chrome toggle only (no pause).
function OnOkPress() as boolean
    
    if m.transport.transportMode <> 0
        
        m.transport.HandleCommand(6)
        ApplyTransport()
        return true
    end if
    
    chromeShown = (m.chromeMode = 2 or m.chromeMode = 1)
    action = PlayerCoordinatorLogic_OkActionInIdle(m.top.state, chromeShown, m.transport.isLive)
    
    ApplyOkAction(action)
    return true
end function

' Apply an OK/Select action to the Video node, the chrome, and the large pause poster.
'   pause        -> pause, show the pause poster, keep the HUD up.
'   resume       -> resume, cancel the pause poster, hide the HUD.
'   reveal       -> show the HUD, leave playback as-is.
'   toggleChrome -> live: toggle the HUD, never pause.
function ApplyOkAction(action as integer) as void
    if action = 1
        m.repauseAfterSeek = false
        m.top.control = "pause"
        m.largePause.trigger = true
        ShowChrome()
    else if action = 2
        m.repauseAfterSeek = false
        m.top.control = "resume"
        m.largePause.cancel = true
        HideChrome()
    else if action = 3
        ToggleChromeOrPause()
    else
        ShowChrome() 
    end if
end function

' Play — commit if a transport is active, else toggle play/pause (LargePause on the pause edge).
function OnPlayPress() as boolean
    if m.transport.transportMode <> 0
        m.transport.HandleCommand(6)
        ApplyTransport()
        return true
    end if
    TogglePlayPause()
    return true
end function

' Back — a ladder: a transport active > the chrome visible in any form > nothing left to dismiss.
'   1. transport active        -> cancel it (keep watching, never exit; live also resumes)
'   2. idle, chrome shown      -> dismiss it (the same animated fade auto-hide uses)
'   3. idle, chrome fading out -> no-op: the dismissal is already underway (a visible chrome never closes)
'   4. idle, chrome hidden     -> close the player
function OnBackPress() as boolean
    action = PlayerCoordinatorLogic_BackActionFor(m.transport.transportMode, m.chromeMode)
    ApplyBackAction(action)
    return true
end function

' Apply the Back decision to the transport / chrome / player.
function ApplyBackAction(action as integer) as void
    if action = 0
        m.transport.CancelTransport() 
        ApplyTransport() 
        
        ArmAutoHide()
    else if action = 1
        HideChrome() 
    else if action = 3
        ClosePlayer()
    end if
    
end function

'===============================================================================
' FOCUS (two-tier virtual focus) — the real focus stays on the Video node. Two tiers: the BAR (default on
' reveal; Left/Right scrub, the cursor grows) and the BUTTONS. Up/Down move between them; both exist only while
' the chrome is up and idle.
'===============================================================================
function CanFocusInteract() as boolean
    chromeShown = (m.chromeMode = 2 or m.chromeMode = 1)
    return chromeShown and m.transport.transportMode = 0
end function

' Move focus to a tier (bar / buttons). Re-entering the buttons returns to the last-focused button — the
' highlight is only reset to play/pause on a fresh reveal (ShowChrome), i.e. whenever the row was hidden.
function SetFocusTarget(target as integer) as void
    m.focusTarget = target
    SyncFocus()
    ArmAutoHide()
end function

' Route a key while the BUTTON tier holds focus: Left/Right move the highlight, OK activates. Play is NOT
' an activator — it always means play/pause, whatever button is highlighted, so it falls through to
' OnPlayPress. (Up/Down are handled one level up by NextFocusTarget.) Returns false for keys the buttons
' don't own (Play/Rev/Fwd/Replay/Back) so those fall through to the transport / play-pause / close.
function HandleButtonsKey(key as string) as boolean
    if key = "left" or key = "right"
        newIndex = PlayerCoordinatorLogic_NextButtonIndex(m.focusedButton, key, m.buttonRow.buttonCount)
        if newIndex = m.focusedButton
            
            m.buttonRow.nudge = true
        end if
        m.focusedButton = newIndex
        SyncFocus()
        ArmAutoHide()
        return true
    else if key = "OK"
        ActivateButton(m.focusedButton)
        return true
    end if
    return false
end function

' Run the action for the focused button.
function ActivateButton(index as integer) as void
    if index = 0
        TogglePlayPause()
    else if index = 1
        PlayNextVideo()
    else if index = 2
        MinimizeReset()
        VideoQueueUtils_ToggleVideoPictureInPicture(m.videoQueue)
    else if index = 3
        ToggleCaptions()
    else if index = 4
        Rate(1)
    else if index = 5
        Rate(2)
    else if index = 6
        ToggleSubscribe()
    else if index = 7
        CycleSleepTimer()
    else if index = 8
        CyclePlaybackSpeed()
    else if index = 9
        SaveToWatchLater()
    end if
    SyncFocus()
end function

''-------------------------------------------------------------------------------
' Like / Dislike / Subscribe. Likes need a YouTube account; subscribing works with either account type (the
' channel page's jobs). Without what they need, the button pulses. The like state starts empty (YouTube's
' current rating isn't loaded) and updates right away, going back if the request fails.
'-------------------------------------------------------------------------------
function CurrentProfile() as dynamic
    profilesService = m.top.profilesService
    if profilesService = invalid
        return invalid
    end if
    return profilesService.currentProfile
end function

' target: 1 like, 2 dislike. Pressing the active one again clears the rating.
function Rate(target as integer) as void
    profile = CurrentProfile()
    content = m.top.content
    if profile = invalid or profile.type <> "youtube" or content = invalid or StringUtils_IsNullOrEmpty(content.videoId)
        m.buttonRow.nudge = true
        return
    end if
    newState = target
    action = "like"
    if target = 2
        action = "dislike"
    end if
    if m.likeState = target
        newState = 0
        action = "removelike"
    end if
    if m.likeJob <> invalid
        m.likeJob.cancel = true
    end if
    m.likeJob = JobSystem_CreateCallback(OnLikeJobDone)
    m.likeJob.addFields({
        previousLikeState: m.likeState
    })
    JobSystem_QueueJob(m.jobQueue, "LikeJob", {
        videoId: content.videoId
        action: action
        profile: profile
    }, m.likeJob)
    m.likeState = newState
    m.buttonRow.likeState = newState
end function

function OnLikeJobDone(event as object) as void
    callback = event.getRoSGNode()
    JobSystem_UnobserveCallback(callback)
    if m.likeJob = invalid or not m.likeJob.isSameNode(callback)
        return
    end if
    m.likeJob = invalid
    info = event.getInfo()
    if not info.success and not info.cancel
        LogWarn3("[VideoPlayerDev.bs:707]", "Rating the video failed:", info.error)
        m.likeState = callback.previousLikeState
        m.buttonRow.likeState = m.likeState
    end if
end function

' The channel of the playing video: from the row it was picked in, or the loaded video info.
function CurrentChannelId() as string
    content = m.top.content
    if content = invalid
        return ""
    end if
    if not StringUtils_IsNullOrEmpty(content.authorId)
        return content.authorId
    end if
    if content.hasField("metadata") and IsAssociativeArray(content.metadata)
        return ValidString(content.metadata.authorId)
    end if
    return ""
end function

function ToggleSubscribe() as void
    profile = CurrentProfile()
    channelId = CurrentChannelId()
    if profile = invalid or channelId = ""
        m.buttonRow.nudge = true
        return
    end if
    if m.subscribeJob <> invalid
        m.subscribeJob.cancel = true
    end if
    m.subscribeJob = JobSystem_CreateCallback()
    JobSystem_QueueJob(m.jobQueue, "SubscribeJob", {
        channelView: m.top
        invidious: m.invidious
        ucid: channelId
        subscribe: not m.top.isSubscribed
        profile: profile
    }, m.subscribeJob)
end function

' Loads whether the account follows this channel, once per video, the first time the controls show.
function FetchSubscriptionStatusOnce() as void
    if m.subscriptionStatusFetched
        return
    end if
    profile = CurrentProfile()
    channelId = CurrentChannelId()
    if profile = invalid or channelId = ""
        return
    end if
    m.subscriptionStatusFetched = true
    JobSystem_QueueJob(m.jobQueue, "FetchSubscriptionStatusJob", {
        channelView: m.top
        ucid: channelId
        profile: profile
        invidious: m.invidious
    }, JobSystem_CreateCallback())
end function

function FetchLikeStatusOnce() as void
    if m.likeStatusFetched
        return
    end if
    profile = CurrentProfile()
    content = m.top.content
    if profile = invalid or profile.type <> "youtube" or content = invalid or StringUtils_IsNullOrEmpty(content.videoId)
        return
    end if
    m.likeStatusFetched = true
    JobSystem_QueueJob(m.jobQueue, "LikeStatusJob", {
        videoId: content.videoId
        profile: profile
    }, JobSystem_CreateCallback(OnLikeStatusJobDone))
end function

' Only fills in the buttons while they are untouched: a press in the meantime wins.
function OnLikeStatusJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    if m.onCloseCalled = true
        return
    end if
    info = event.getInfo()
    if not info.success or not IsAssociativeArray(info.data)
        return
    end if
    if m.likeJob <> invalid or m.likeState <> 0
        return
    end if
    m.likeState = ValidInt(info.data.likeState)
    m.buttonRow.likeState = m.likeState
end function

function OnIsSubscribedChange() as void
    m.buttonRow.subscribed = m.top.isSubscribed
end function

'-------------------------------------------------------------------------------
' Up next: the related videos YouTube sent with this video (the ones autoplay picks from), in a strip
' along the bottom. Left/Right move, OK plays, Up/Down/Back close it; any other key closes it and acts.
'-------------------------------------------------------------------------------
function OpenUpNext() as boolean
    content = BuildUpNextContent()
    if content = invalid
        return false
    end if
    m.upNextPanel.content = content
    m.upNextPanel.focusedIndex = 0
    HideChromeNow()
    m.upNextPanel.visible = true
    m.upNextOpen = true
    return true
end function

function CloseUpNext(revealChrome as boolean) as void
    if not m.upNextOpen
        return
    end if
    m.upNextOpen = false
    m.upNextPanel.visible = false
    if revealChrome
        ShowChrome()
    end if
end function

function BuildUpNextContent() as dynamic
    content = m.top.content
    if content = invalid or not content.hasField("metadata")
        return invalid
    end if
    metadata = content.metadata
    if not IsAssociativeArray(metadata) or not IsArray(metadata.recommendedVideos)
        return invalid
    end if
    instance = m.invidious.callfunc("GetInstance", invalid)
    videos = CreateObject("roSGNode", "ContentNode")
    
    hidden = FeedFilters_LoadLookup()
    for each item in metadata.recommendedVideos
        if IsAssociativeArray(item) and IsString(item.videoId) and item.videoId <> "" and VideoQueueUtils_IsWatchableRecommendation(item, hidden, false)
            videos.appendChild(InvidiousContent_ToVideoContentNode(invalid, item, instance))
            if videos.getChildCount() >= 12
                exit for
            end if
        end if
    end for
    if videos.getChildCount() = 0
        return invalid
    end if
    return videos
end function

function HandleUpNextKey(key as string, press as boolean) as boolean
    if not press
        
        return key = "left" or key = "right" or key = "OK" or key = "up" or key = "down" or key = "back"
    end if
    index = m.upNextPanel.focusedIndex
    if key = "left"
        if index > 0
            m.upNextPanel.focusedIndex = index - 1
        end if
        return true
    else if key = "right"
        if index < m.upNextPanel.itemCount - 1
            m.upNextPanel.focusedIndex = index + 1
        end if
        return true
    else if key = "OK"
        video = m.upNextPanel.content.getChild(index)
        CloseUpNext(false)
        if video <> invalid
            m.videoQueue.playVideo = video
        end if
        return true
    else if key = "up" or key = "down" or key = "back"
        CloseUpNext(true)
        return true
    end if
    
    CloseUpNext(false)
    return OnKeyEvent(key, press)
end function

' Sleep timer (the moon button): the queue owns the timer, so it keeps counting across videos and closes the
' player when it runs out.
function SleepTimerMinutesLeft() as integer
    endsAt = ValidInt(m.videoQueue.sleepTimerEndsAt)
    if endsAt <= 0
        return 0
    end if
    left = endsAt - CreateObject("roDateTime").AsSeconds()
    if left <= 0
        return 0
    end if
    return (left + 59) \ 60
end function

' Each press of the moon steps the timer up: off -> 15 -> 30 -> 60 -> 120 minutes -> off (from a running timer,
' to the next step above what's left). The label above the buttons shows what the timer says.
'-------------------------------------------------------------------------------
' Playback speed (Speed button): 1x, 1.25x, 1.5x, 1.75x, 2x, 0.5x, 0.75x, then 1x again. Kept for the next
' videos (on the video queue) until changed. Live streams always play at 1x. Not every Roku can change the speed:
' then the button says so.
'-------------------------------------------------------------------------------
function wasHiddenBeforeReveal() as boolean
    return m.chromeMode = 0 or m.chromeMode = 3
end function

function RememberSpeed() as boolean
    return m.preferences <> invalid and m.preferences["playback.remember_speed"] = true
end function

function SpeedSupported() as boolean
    return m.top.hasField("playbackSpeed")
end function

function PreferredSpeed() as float
    
    if m.videoQueue.playbackSpeedRestored <> true
        m.videoQueue.playbackSpeedRestored = true
        if RememberSpeed()
            saved = ValidString(RegistryUtils_Read("playback_speed")).ToFloat()
            if saved >= 0.25 and saved <= 4
                m.videoQueue.preferredPlaybackSpeed = saved
            end if
        end if
    end if
    speed = ValidFloat(m.videoQueue.preferredPlaybackSpeed)
    if speed <= 0
        speed = 1.0
    end if
    return speed
end function

function CyclePlaybackSpeed() as void
    if not SpeedSupported()
        m.buttonRow.statusText = Tr("This TV can't change the playback speed")
        m.buttonRow.nudge = true
        ArmAutoHide()
        return
    end if
    steps = [
        1.0
        1.25
        1.5
        1.75
        2.0
        0.5
        0.75
    ]
    current = PreferredSpeed()
    nextSpeed = 1.0
    for i = 0 to steps.Count() - 1
        if Abs(steps[i] - current) < 0.01
            nextSpeed = steps[(i + 1) mod steps.Count()]
            exit for
        end if
    end for
    m.videoQueue.preferredPlaybackSpeed = nextSpeed
    if RememberSpeed()
        RegistryUtils_Write("playback_speed", nextSpeed.ToStr())
    end if
    ApplyPlaybackSpeed()
    
    if m.firstFrameSeen and m.top.state = "playing"
        m.top.control = "pause"
        ApplyPlaybackSpeed()
        m.top.control = "resume"
    end if
    UpdateSpeedLabel(true)
    ArmAutoHide()
end function

function ApplyPlaybackSpeed() as void
    if not SpeedSupported()
        return
    end if
    speed = PreferredSpeed()
    content = m.top.content
    if content <> invalid and content.Live = true
        speed = 1.0
    end if
    if Abs(ValidFloat(m.top.playbackSpeed) - speed) > 0.01
        m.top.playbackSpeed = speed
    end if
end function

function UpdateSpeedLabel(justChanged as boolean) as void
    speed = PreferredSpeed()
    if Abs(speed - 1.0) > 0.01
        m.buttonRow.statusText = Tr("Speed: %1").Replace("%1", FormatSpeed(speed))
    else if justChanged
        m.buttonRow.statusText = Tr("Speed: Normal")
    else
        m.buttonRow.statusText = ""
    end if
end function

' 1.25 -> "1.25x", 2 -> "2x"
function FormatSpeed(speed as float) as string
    hundredths = CInt(speed * 100)
    text = (hundredths \ 100).ToStr()
    remainder = hundredths mod 100
    if remainder > 0
        if remainder mod 10 = 0
            text += "." + (remainder \ 10).ToStr()
        else
            text += "." + Right("0" + remainder.ToStr(), 2)
        end if
    end if
    return text + "x"
end function

'-------------------------------------------------------------------------------
' Watch later button: saves the playing video to the account's Watch later playlist (YouTube accounts).
'-------------------------------------------------------------------------------
function SaveToWatchLater() as void
    profile = CurrentProfile()
    content = m.top.content
    if profile = invalid or profile.type <> "youtube" or content = invalid or StringUtils_IsNullOrEmpty(content.videoId)
        m.buttonRow.statusText = Tr("Couldn't save to Watch later")
        m.buttonRow.nudge = true
        return
    end if
    if m.watchLaterJob <> invalid
        return
    end if
    
    remove = m.watchLaterSaved
    m.watchLaterSaved = not remove
    m.buttonRow.watchLaterSaved = m.watchLaterSaved
    if remove
        m.buttonRow.statusText = Tr("Removed from Watch later")
    else
        m.buttonRow.statusText = Tr("Saved to Watch later")
    end if
    m.watchLaterJob = JobSystem_CreateCallback(OnWatchLaterJobDone)
    m.watchLaterJob.addFields({
        wasSaved: remove
    })
    JobSystem_QueueJob(m.jobQueue, "WatchLaterJob", {
        videoId: content.videoId
        profile: profile
        remove: remove
    }, m.watchLaterJob)
    ArmAutoHide()
end function

function OnWatchLaterJobDone(event as object) as void
    callback = event.getRoSGNode()
    JobSystem_UnobserveCallback(callback)
    if m.watchLaterJob = invalid or not m.watchLaterJob.isSameNode(callback)
        return
    end if
    m.watchLaterJob = invalid
    info = event.getInfo()
    if not info.success and not info.cancel
        LogWarn3("[VideoPlayerDev.bs:1055]", "Watch later failed:", info.error)
        m.watchLaterSaved = callback.wasSaved
        m.buttonRow.watchLaterSaved = m.watchLaterSaved
        m.buttonRow.statusText = Tr("Couldn't save to Watch later")
    end if
end function

' Off -> 15 -> 30 -> 60 -> 120 minutes -> End of video -> Off.
function CycleSleepTimer() as void
    if m.videoQueue.sleepAfterVideo = true
        m.videoQueue.sleepAfterVideo = false
        m.videoQueue.sleepTimerMinutes = 0
        UpdateSleepTimerLabel(true)
        ArmAutoHide()
        return
    end if
    
    steps = [
        15
        30
        60
        120
    ]
    chosen = 0
    if SleepTimerMinutesLeft() > 0
        chosen = ValidInt(m.videoQueue.sleepTimerMinutes)
    end if
    minutes = 0
    for each stepMinutes in steps
        if stepMinutes > chosen
            minutes = stepMinutes
            exit for
        end if
    end for
    if minutes = 0 and chosen > 0
        
        m.videoQueue.sleepTimerMinutes = 0
        m.videoQueue.sleepAfterVideo = true
        UpdateSleepTimerLabel(true)
        ArmAutoHide()
        return
    end if
    m.videoQueue.sleepTimerMinutes = minutes
    UpdateSleepTimerLabel(true)
    ArmAutoHide()
end function

' justChanged: also say "off" (otherwise the label only shows while a timer runs)
function UpdateSleepTimerLabel(justChanged as boolean) as void
    left = SleepTimerMinutesLeft()
    if m.videoQueue.sleepAfterVideo = true
        m.buttonRow.sleepTimerOn = true
        m.buttonRow.sleepTimerText = Tr("Playback stops at the end of this video.")
        return
    end if
    m.buttonRow.sleepTimerOn = left > 0
    if left > 0
        m.buttonRow.sleepTimerText = Tr("Playback stops in %1 minutes.").Replace("%1", left.ToStr())
    else if justChanged
        m.buttonRow.sleepTimerText = Tr("Sleep timer") + ": " + Tr("Off")
    else
        m.buttonRow.sleepTimerText = ""
    end if
end function

' Content queued from the Shorts tab carries isShort.
function IsPlayingShort() as boolean
    content = m.top.content
    return content <> invalid and content.hasField("isShort") and content.isShort = true
end function

' Next/previous Short. At the end of the queue it never drops into a regular video: it waits (spinner) for the
' queue's next batch of Shorts, and if none comes, plays the current Short again, like YouTube loops them.
function FlipShort(forward as boolean) as void
    if not forward
        if m.videoQueue.hasPrevious
            m.videoQueue.previous = true
        end if
        return
    end if
    if m.videoQueue.hasNext
        m.videoQueue.next = true
        return
    end if
    if m.waitingForShorts
        return
    end if
    m.waitingForShorts = true
    m.spinner.mode = 2
    m.videoQueue.observeFieldScoped("shortsLoading", FuncName(OnShortsLoadingChange))
    m.videoQueue.loadMoreShorts = true
    OnShortsLoadingChange()
end function

function OnShortsLoadingChange() as void
    if not m.waitingForShorts or m.videoQueue.shortsLoading
        return
    end if
    StopWaitingForShorts()
    if m.videoQueue.hasNext
        m.videoQueue.next = true
    else
        m.top.control = "replay"
    end if
end function

function StopWaitingForShorts() as void
    if not m.waitingForShorts
        return
    end if
    m.waitingForShorts = false
    m.videoQueue.unobserveFieldScoped("shortsLoading")
    if m.spinner.mode = 2
        m.spinner.mode = 0
    end if
end function

' The Next button: the next video in the queue, or else the first recommended one (even with autoplay off).
' Nothing to play: the button pulses.
function PlayNextVideo() as void
    if not VideoQueueUtils_PlayNext(m.videoQueue, m.invidious, m.preferences, true)
        m.buttonRow.nudge = true
    end if
end function

' The CC button: Playlet draws the captions itself (CaptionsOverlay), so the TV's own caption setting is never
' touched. The choice is remembered for the next videos.
function ToggleCaptions() as void
    m.captionsEnabled = not m.captionsEnabled
    RegistryUtils_Write("captions_enabled", m.captionsEnabled.ToStr())
    if m.captionsOverlay <> invalid
        m.captionsOverlay.enabled = m.captionsEnabled
    end if
    m.buttonRow.captionsOn = m.captionsEnabled
    ApplyCaptionSuppression()
end function

' The device's own captions (which follow the TV-wide caption setting) are hidden while minimized, and while
' Playlet draws its own so they don't show twice.
function ApplyCaptionSuppression() as void
    m.top.suppressCaptions = (not m.container.fullscreen) or m.captionsEnabled
end function

' Push the focus state to the renderers. The button row highlights its focused button while the BUTTON tier
' holds focus; the trackbar's cursor grows while the BAR tier holds focus. Both are gated on the chrome being
' up, so nothing reads as focused while the chrome is hidden.
function SyncFocus() as void
    chromeShown = (m.chromeMode = 2 or m.chromeMode = 1)
    m.buttonRow.transportMode = m.transport.transportMode
    m.buttonRow.rowFocused = chromeShown and (m.focusTarget = 1)
    m.buttonRow.focusedIndex = m.focusedButton
    m.buttonRow.playing = (m.top.state = "playing")
    m.trickPlayBar.focused = chromeShown and (m.focusTarget = 0)
end function

'===============================================================================
' Chrome — the coordinator owns the Chrome group fade as a unit.
'===============================================================================
' OK/Select in idle. Live: toggle chrome only (no pause). VOD: also a chrome toggle (Play is the pause key);
' reveal -> auto-hide, shown -> hide.
function ToggleChromeOrPause() as void
    if m.chromeMode = 2 or m.chromeMode = 1
        HideChrome()
    else
        ShowChrome()
    end if
end function

' VOD OK/Play in idle. Pause-from-playing pulses the LargePause trigger (the only trigger path) + reveals
' chrome; resume cancels LargePause + hides chrome. The transport freeze-pause is a different code path and
' never touches the trigger, so LargePause can't fire on a scrub/scan/live freeze.
function TogglePlayPause() as void
    m.repauseAfterSeek = false 
    if m.top.state = "playing"
        m.top.control = "pause"
        m.largePause.trigger = true
        ShowChrome() 
    else
        m.top.control = "resume"
        m.largePause.cancel = true
        HideChrome()
    end if
end function

' Minimize: reset any active transport to idle (clears the bif/glyph, stops the transport timer) and hide the
' chrome, leaving the underlying play/pause state untouched.
function MinimizeReset() as void
    if m.transport.transportMode <> 0
        m.transport.ResetTransport()
        ApplyTransport() 
    end if
    HideChrome()
end function

' Reveal: unhide + fade-in 0.5s linear + (re)arm the 5s auto-hide. The fade-in fires once on a hidden->shown
' transition; while already shown or mid fade-in, a repeat reveal (e.g. a second Left while the chrome is
' coming up) must not restart the animation — it just refreshes the bar + re-arms auto-hide.
function ShowChrome(instant = false as boolean) as void
    
    if not m.container.fullscreen
        return
    end if
    
    if not m.firstFrameSeen
        return
    end if
    
    FetchSubscriptionStatusOnce()
    
    FetchLikeStatusOnce()
    UpdateSleepTimerLabel(false)
    
    if wasHiddenBeforeReveal()
        UpdateSpeedLabel(false)
    end if
    wasHidden = (m.chromeMode = 0 or m.chromeMode = 3)
    m.chromeFadeOut.control = "stop"
    m.chrome.visible = true
    if wasHidden
        if instant
            
            m.chromeFadeIn.control = "stop"
            m.chrome.opacity = 1.0
            m.chromeMode = 2
        else
            
            m.chromeMode = 1
            m.chromeFadeIn.control = "start"
        end if
        
        if m.transport.isLive and m.transport.transportMode = 0
            StartLiveBadgeHold()
        end if
    end if
    
    if wasHidden and not instant and m.transport.transportMode = 0
        m.focusTarget = 0
        m.focusedButton = 0
    end if
    PushTransportToRenderers()
    SyncFocus()
    ArmAutoHide()
end function

' Force the bar to show "● LIVE" briefly after a live reveal, then release so it swaps to the offset M:SS
' when behind the edge.
function StartLiveBadgeHold() as void
    m.liveBadgeHoldActive = true
    m.trickPlayBar.forceLiveBadge = true
    m.liveBadgeHold.control = "stop"
    m.liveBadgeHold.control = "start"
end function

function OnLiveBadgeHoldFire() as void
    m.liveBadgeHoldActive = false
    m.trickPlayBar.forceLiveBadge = false
end function

' Release the hold early (a transport started mid-hold). Guarded so the per-drain call from ApplyTransport
' is free when no hold is running.
function CancelLiveBadgeHold() as void
    if not m.liveBadgeHoldActive
        return
    end if
    m.liveBadgeHoldActive = false
    m.liveBadgeHold.control = "stop"
    m.trickPlayBar.forceLiveBadge = false
end function

' Fade-out 0.3s linear (no-op if already hidden).
function HideChrome() as void
    if m.chromeMode = 0 or m.chromeMode = 3
        return
    end if
    m.autoHide.control = "stop"
    m.chromeFadeIn.control = "stop"
    m.chromeMode = 3
    m.chromeFadeOut.control = "start"
    SyncFocus()
end function

' Hide the chrome immediately (no fade). Used on minimize so no UI lingers in the PiP window.
function HideChromeNow() as void
    m.chromeFadeIn.control = "stop"
    m.chromeFadeOut.control = "stop"
    m.autoHide.control = "stop"
    m.chrome.opacity = 0
    m.chrome.visible = false
    m.chromeMode = 0
    SyncFocus()
end function

' (re)arm the 5s auto-hide. Only matters while shown; OnAutoHideFire re-checks the idle gate.
function ArmAutoHide() as void
    m.autoHide.control = "stop"
    m.autoHide.control = "start"
end function

function OnAutoHideFire() as void
    
    if m.transport.transportMode = 0
        HideChrome()
    end if
end function

function OnChromeFadeInState() as void
    if m.chromeFadeIn.state = "stopped"
        m.chromeMode = 2
    end if
end function

function OnChromeFadeOutState() as void
    if m.chromeFadeOut.state = "stopped"
        m.chromeMode = 0
        m.chrome.visible = false
    end if
end function

'===============================================================================
' Device signal handlers (state / position / duration / timers / fullscreen).
'===============================================================================
' Device signal observers take the event and read the changed value from it — event.getData() hands over the
' value the notification carried, instead of a second read of the node field (which copies again).
function OnVideoState(event as object) as void
    if m.onCloseCalled = true
        return
    end if
    state = event.getData()
    LogInfo3("[VideoPlayerDev.bs:1388]", "videoState ->", state)
    m.playbackTelemetry.OnState(state)
    
    Lounge_SendOnStateChange()
    SyncFocus()
    if state = "playing"
        
        ApplyPlaybackSpeed()
        if not m.firstFrameSeen
            m.firstFrameSeen = true
            m.transport.OnReady()
            m.spinner.mode = 0
            LogInfo2("[VideoPlayerDev.bs:1403]", "first frame: ready=true, loading overlay off")
        end if
        
        m.transport.MarkSeekSettled()
        EnforceTransportFreeze("OnVideoState")
        
        if m.repauseAfterSeek
            m.repauseAfterSeek = false
            m.top.control = "pause"
        end if
        
        m.videoPlayedSuccessfully = true
        
        DismissErrorDialog()
        
        if m.spinner.mode = 2
            m.spinner.mode = 0
        end if
    else if state = "buffering"
        
        if PlayerCoordinatorLogic_ShouldShowBuffering(m.firstFrameSeen, m.transport.transportMode, m.container.fullscreen)
            m.spinner.mode = 2
        end if
    else if state = "finished"
        
        if m.ignoreNextFinished
            m.ignoreNextFinished = false
            return
        end if
        OnPlaybackFinished()
    else if state = "error"
        OnVideoError()
    end if
end function

function OnBufferingStatus(event as object) as void
    if m.onCloseCalled = true
        return
    end if
    m.playbackTelemetry.OnBufferingStatus(event.getData())
end function

function OnPlayStartInfo(event as object) as void
    if m.onCloseCalled = true
        return
    end if
    m.playbackTelemetry.OnPlayStartInfo(event.getData())
end function

' Only the first video segment is wanted: no callback per segment for the rest of the play.
function OnStreamingSegment(event as object) as void
    if m.onCloseCalled = true
        return
    end if
    if m.playbackTelemetry.OnStreamingSegment(event.getData())
        m.top.unobserveField("streamingSegment")
    end if
end function

' A transport freezes the video; if the device is playing under an active transport (Roku resumes a paused
' Video on a seek, or a freeze command was dropped), re-pause. The transport stays active so the bif stays
' visible over the now-paused video. Called from OnVideoState (the change edge) and OnPosition (the net —
' OnPosition fires only while playing, so a transport-under-playing always trips it even with no state-change
' event). Re-pausing yields state=paused -> OnPosition stops -> no loop.
function EnforceTransportFreeze(source as string) as void
    inTransport = (m.transport.transportMode <> 0)
    action = PlayerCoordinatorLogic_TransportSafetyAction(m.top.state, inTransport, m.transport.isLive, Int(m.top.position * 1000), m.transport.cursorMs, m.transport.durationMs, m.transport.SafetyFloorMs())
    if action = 1
        m.top.control = "pause"
        
        m.top.autoplayAfterSeek = false
        m.playbackTelemetry.RecordHeal(source)
    else if action = 3
        
        m.playbackTelemetry.RecordTailResolve(source)
        m.transport.ResolveLiveTail()
        ApplyTransport()
    else if action = 2
        
        LogInfo2("[VideoPlayerDev.bs:1486]", "transport at end of content -> finish")
        m.transport.ResetTransport()
        ApplyTransport()
        OnPlaybackFinished()
    end if
end function

' The Video node reached state=error. ErrorDialogController decides retry-vs-dialog; the coordinator applies
' (replay the next URL, or show the scene-level TimedDialog).
function OnVideoError() as void
    
    if m.transport.transportMode <> 0
        m.transport.ResetTransport()
        ApplyTransport()
    end if
    content = m.top.content
    errorInfo = m.top.errorInfo
    errorData = GetPlayerErrorData(content.videoId, errorInfo)
    
    LogErrorNoTelemetry3("[VideoPlayerDev.bs:1506]", errorData.title, errorData.body)
    
    failedUrl = content.url
    failedUrlIndex = content.playletStreamUrlIndex
    decision = ErrorDialogController_DecideVideoError(content, m.videoPlayedSuccessfully)
    if decision.action = 1
        LogInfo3("[VideoPlayerDev.bs:1514]", "error retry -> next stream url=", decision.nextUrl)
        m.playbackTelemetry.ReportVideoError(errorData, errorInfo, failedUrl, failedUrlIndex, false)
        
        m.ignoreNextFinished = true
        m.repauseAfterSeek = false 
        SeekToInitialPosition(content)
        m.top.control = "play"
        return
    end if
    
    m.playbackTelemetry.ReportVideoError(errorData, errorInfo, failedUrl, failedUrlIndex, true)
    m.ignoreNextFinished = true
    ShowErrorDialog({
        title: errorData.title
        message: errorData.body
    })
end function

function OnPosition(event as object) as void
    if m.onCloseCalled = true
        return
    end if
    posMs = Int(event.getData() * 1000)
    m.transport.OnPosition(posMs)
    ApplyTransport()
    EnforceTransportFreeze("OnPosition") 
    
    if m.onCloseCalled = true
        return
    end if
    
    skipMs = m.sponsorblock.OnPosition(posMs)
    if skipMs = (-2)
        OnPlaybackFinished()
    else if skipMs <> (-1)
        m.transport.ForceIdleSeek(skipMs, true) 
        ApplyTransport()
    end if
    
    if m.reportWatchTime and m.markVideoWatchedJob <> invalid
        marker = (posMs \ 20000) * 20
        if marker <> m.watchTimeMarker
            m.watchTimeMarker = marker
            m.markVideoWatchedJob.watchTime = marker
        end if
    end if
end function

function OnDuration(event as object) as void
    if m.onCloseCalled = true
        return
    end if
    durMs = Int(event.getData() * 1000)
    m.transport.OnDuration(durMs) 
    
    if m.transport.isLive and m.liveAstSeconds <= 0 and durMs > 0 and not TransportController_IsLiveEdgeSentinelMs(durMs)
        m.liveFallbackEdgeMs = durMs
        m.liveFallbackAtSeconds = NowSeconds()
        PushLiveEdge()
    end if
    ApplyTransport()
end function

' Current wall-clock epoch seconds, off the cached roDateTime.
function NowSeconds() as integer
    m.nowDateTime.Mark()
    return m.nowDateTime.AsSeconds()
end function

' The live edge on the manifest timeline (ms): wall clock minus the availabilityStartTime anchor (or the
' duration-report fallback). 0 when no anchor is known yet.
function ComputeLiveEdgeMs() as integer
    epochSeconds = NowSeconds()
    if m.liveAstSeconds > 0
        return (epochSeconds - m.liveAstSeconds) * 1000
    end if
    if m.liveFallbackEdgeMs >= 0
        return m.liveFallbackEdgeMs + (epochSeconds - m.liveFallbackAtSeconds) * 1000
    end if
    return 0
end function

function PushLiveEdge() as void
    edgeMs = ComputeLiveEdgeMs()
    if edgeMs > 0
        m.transport.OnLiveEdge(edgeMs)
    end if
end function

' the 1s live heartbeat: keep the brain's edge current (and the on-screen offset counting) even while the
' device is paused/frozen and emits no events. ApplyTransport's render gating keeps the idle-hidden case free.
function OnLiveEdgeClockFire() as void
    if m.onCloseCalled = true
        return
    end if
    PushLiveEdge()
    ApplyTransport()
end function

' the single transport timer fired -> Tick the module with the currently-armed timer id, then drain it.
function OnTransportTimerFire() as void
    if m.armedTimerId = 0
        return
    end if
    
    firedId = m.armedTimerId
    if not m.transportTimer.repeat
        m.armedTimerId = 0
    end if
    m.transport.Tick(firedId)
    ApplyTransport()
end function

function OnFullScreenChange() as void
    
    if m.onCloseCalled = true
        return
    end if
    fullscreen = m.container.fullscreen
    
    
    m.sponsorblock.SetVisible(fullscreen)
    
    if m.captionsOverlay <> invalid
        m.captionsOverlay.fullscreen = fullscreen
    end if
    ApplyCaptionSuppression()
    if not fullscreen
        CloseUpNext(false)
    end if
    
    if not fullscreen
        if m.transport.transportMode <> 0
            m.transport.ResetTransport()
            ApplyTransport()
        end if
        HideChromeNow()
        m.spinner.mode = 0
        m.largePause.cancel = true
    end if
    
    for each id in [
        "widthInterpolator"
        "heightInterpolator"
        "translationInterpolator"
    ]
        interp = m.top.findNode(id)
        if interp <> invalid
            interp.reverse = fullscreen
        end if
    end for
    m.minimize.control = "start"
    
    m.showFullScreenHint = not fullscreen
    RefreshFullScreenHint()
end function

' (re)arm the hint timer for the current phase: while minimized, 1s before showing (let the shrink finish),
' then 5s before hiding. Fullscreen hides it immediately.
function RefreshFullScreenHint() as void
    m.fullScreenHintTimer.control = "stop"
    if m.container.fullscreen
        m.fullScreenHint.visible = false
        return
    end if
    if m.showFullScreenHint
        m.fullScreenHintTimer.duration = 1
    else
        m.fullScreenHintTimer.duration = 5
    end if
    m.fullScreenHintTimer.control = "start"
end function

' phase 1 (showFullScreenHint=true) reveals the strip then arms the 5s hide; phase 2 (false) hides it.
function OnFullScreenHintTimer() as void
    m.fullScreenHint.visible = m.showFullScreenHint
    if m.showFullScreenHint
        m.showFullScreenHint = false
        RefreshFullScreenHint()
    end if
end function

' A resume/play arriving while a transport is active is necessarily external: VPD only ever resumes/plays at
' idle, so this is the linked phone (Lounge) resuming. The phone action wins — cancel the scrub/scan (the bif +
' chrome clear) and let the video play.
function OnControlChange(event as object) as void
    if m.onCloseCalled = true
        return
    end if
    control = event.getData()
    if (control = "resume" or control = "play") and m.transport.transportMode <> 0
        LogInfo2("[VideoPlayerDev.bs:1710]", "external resume under transport -> take over (cancel transport)")
        m.transport.ResetTransport()
        ApplyTransport()
        HideChromeNow()
        m.repauseAfterSeek = false 
        m.top.autoplayAfterSeek = true
        m.top.control = "resume"
    end if
end function

' Keeps the play state; a frozen transport resumes, as its commit would.
function OnSetSeek(event as object) as void
    if m.onCloseCalled = true
        return
    end if
    seekMs = Int(event.getData() * 1000)
    
    if m.videoContentJob <> invalid
        m.loadingSetSeekMs = seekMs
        return
    end if
    wasTransport = (m.transport.transportMode <> 0)
    m.transport.ForceIdleSeek(seekMs, not wasTransport)
    ApplyTransport()
    if wasTransport
        HideChromeNow()
    end if
end function

'===============================================================================
' Content load, initial seek, previous-player handoff, close.
'===============================================================================
function PlayWithContent(contentNode as object)
    LogInfo5("[VideoPlayerDev.bs:1743]", "PlayWithContent videoId=", contentNode.videoId, " title=", contentNode.title)
    videoContentNode = CreateObject("roSGNode", "ContentNode")
    if not StringUtils_IsNullOrEmpty(contentNode.videoId)
        videoContentNode.AddFields({
            videoId: contentNode.videoId
        })
    end if
    if ValidInt(contentNode.timestamp) <> -1
        videoContentNode.AddFields({
            timestamp: contentNode.timestamp
        })
    else if contentNode.percentDurationWatched > 0 and contentNode.percentDurationWatched < 100
        videoContentNode.AddFields({
            percentDurationWatched: contentNode.percentDurationWatched
        })
    end if
    if not StringUtils_IsNullOrEmpty(contentNode.title)
        videoContentNode.title = contentNode.title
    end if
    
    author = contentNode._author
    if StringUtils_IsNullOrEmpty(author)
        lines = contentNode.lines
        if IsArray(lines) and lines.Count() > 0
            author = lines[0]
        end if
    end if
    if not StringUtils_IsNullOrEmpty(author)
        videoContentNode.secondaryTitle = author
    end if
    metadata = contentNode.metadata
    if IsAssociativeArray(metadata)
        videoContentNode.AddFields({
            metadata: metadata
        })
    end if
    
    if contentNode.hasField("isShort") and contentNode.isShort = true
        videoContentNode.AddFields({
            isShort: true
        })
    end if
    if not StringUtils_IsNullOrEmpty(contentNode.authorId)
        videoContentNode.AddFields({
            authorId: contentNode.authorId
        })
    end if
    StartVideoContentJob(videoContentNode)
    
    playbackSpeed = ValidFloat(m.top.playbackSpeed)
    if playbackSpeed <= 0
        playbackSpeed = 1.0
    end if
    Lounge_SendNowPlayingLoading(contentNode.videoId, playbackSpeed)
end function

function StartVideoContentJob(videoContentNode as object)
    if m.videoContentJob <> invalid
        m.videoContentJob.cancel = true
    end if
    m.top.content = videoContentNode
    m.top.content.ObserveField("title", FuncName(OnContentMetaChange))
    m.top.content.ObserveField("secondaryTitle", FuncName(OnContentMetaChange))
    UpdateOverlayMeta()
    input = {
        content: videoContentNode
        invidious: m.top.invidious
        innertube: m.top.innertube
        preferences: m.top.preferences
        loungeService: m.top.loungeService
        playletServerPort: m.top.webServer.port
        profilesService: m.top.profilesService
    }
    m.videoContentJob = JobSystem_CreateCallback(OnVideoContentJobDone)
    JobSystem_QueueJob(m.jobQueue, "VideoContentJob", input, m.videoContentJob)
    
end function

function OnVideoContentJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.videoContentJob = invalid
    info = event.getInfo()
    if info.cancel = true or m.onCloseCalled = true
        
        return
    end if
    m.playbackTelemetry.OnMetadataDone()
    content = m.top.content
    if not info.success
        m.playbackTelemetry.ReportContentJobFailure(info.error)
        decision = ErrorDialogController_DecideContentJobFailure(content, info.error)
        ShowErrorDialog(decision)
        Lounge_SendOnStateChange()
        return
    end if
    LogInfo3("[VideoPlayerDev.bs:1836]", "VideoContentJob success, url=", content.url)
    metadata = content.metadata
    
    isLive = content <> invalid and content.Live = true
    m.transport.SetContent(isLive, 2000, false)
    
    m.transport.SetLiveDvrWindow(ValidInt(metadata.liveSeekableWindowSec) * 1000)
    m.trickPlayBar.isLive = isLive
    m.bifDisplay.tileSet = invalid
    
    m.liveAstSeconds = -1
    m.liveFallbackEdgeMs = -1
    m.liveFallbackAtSeconds = 0
    if isLive
        ast = ValidString(metadata.liveAvailabilityStartUtc)
        if ast <> ""
            astDate = CreateObject("roDateTime")
            astDate.FromISO8601String(ast)
            if astDate.AsSeconds() > 0
                m.liveAstSeconds = astDate.AsSeconds()
            end if
        end if
        PushLiveEdge()
        m.liveEdgeClock.control = "start"
    else
        m.liveEdgeClock.control = "stop"
    end if
    
    sbInput = m.sponsorblock.OnContentReady(metadata, isLive)
    if sbInput <> invalid
        m.sponsorBlockSegmentsJob = JobSystem_CreateCallback(OnSponsorBlockSegmentsJobDone)
        JobSystem_QueueJob(m.jobQueue, "SponsorBlockSegmentsJob", sbInput, m.sponsorBlockSegmentsJob)
        
    end if
    UpdateOverlayMeta()
    SeekToInitialPosition(content)
    PlayAfterPreviousPlayerHasStopped()
    MarkVideoWatched(content.videoId, metadata.playbackTrackingUrls, metadata.cpn)
end function

' The coordinator-owned SB job callback (node scope). Hands the result to the controller (it stores segments +
' sets seekMode), then pushes the bar tint fields when segments exist.
function OnSponsorBlockSegmentsJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.sponsorBlockSegmentsJob = invalid
    info = event.getInfo()
    
    if info.cancel = true or m.onCloseCalled = true
        return
    end if
    m.sponsorblock.OnSegmentsJobDone(event)
    if m.sponsorblock.HasSegments() and IsAssociativeArray(info) and IsAssociativeArray(info.data)
        barPath = info.data.barPath
        m.trickPlayBar.sbBarUri = barPath
        m.trickPlayBar.sbFillBlend = &hFF000080
        
    end if
end function

' Report the video as watched to the account: a one-shot history ping plus, for YouTube profiles, a watch-time
' position loop (reported in 20-second steps from OnPosition). No-op without a signed-in account or a videoId.
function MarkVideoWatched(videoId as dynamic, playbackTrackingUrls as dynamic, cpn as dynamic) as void
    if StringUtils_IsNullOrEmpty(videoId)
        return
    end if
    profile = m.top.profilesService.currentProfile
    if profile = invalid
        return
    end if
    if profile.authState = "NeedsReauth"
        return
    end if
    if m.markVideoWatchedJob <> invalid
        m.markVideoWatchedJob.cancel = true
    end if
    input = {
        videoId: videoId
        invidious: m.top.invidious
        profile: profile
        playbackTrackingUrls: playbackTrackingUrls
        cpn: cpn
    }
    m.markVideoWatchedJob = JobSystem_CreateCallback()
    m.markVideoWatchedJob.addField("watchTime", "float", false)
    JobSystem_QueueJob(m.jobQueue, "MarkVideoWatchedJob", input, m.markVideoWatchedJob)
    
    m.watchTimeMarker = -1
    m.reportWatchTime = (profile.type = "youtube")
end function

function SeekToInitialPosition(content as object) as void
    if content = invalid
        return
    end if
    if m.loadingSetSeekMs <> -1
        
        ApplySeek(m.loadingSetSeekMs)
        m.loadingSetSeekMs = -1
        return
    end if
    if content.Live = true
        
        ApplySeek(999999000)
        return
    end if
    timestamp = ValidInt(content.timestamp)
    if timestamp > 0
        
        ApplySeek(timestamp * 1000)
        return
    end if
    percentDurationWatched = ValidFloat(content.percentDurationWatched)
    if percentDurationWatched <= 0
        return
    end if
    
    lengthSeconds = ValidInt(ValidAssociativeArray(content.metadata).lengthSeconds)
    if lengthSeconds <= 0
        LogWarn3("[VideoPlayerDev.bs:1968]", "no lengthSeconds to resume the percent watched from; starting from the beginning. videoId:", content.videoId)
        return
    end if
    if lengthSeconds < 30
        return
    end if
    seekMs = Int(percentDurationWatched / 100.0 * lengthSeconds * 1000)
    
    ApplySeek(seekMs)
end function

function PlayAfterPreviousPlayerHasStopped() as void
    previousPlayer = m.top.previousPlayer
    m.top.previousPlayer = invalid
    
    m.previousPlayer = invalid
    if previousPlayer = invalid
        
        m.top.control = "play"
        return
    end if
    previousPlayerState = previousPlayer.state
    
    if previousPlayerState = "stopping"
        previousPlayer.observeFieldScoped("state", FuncName(OnPreviousPlayerState))
        return
    end if
    m.top.control = "play"
end function

function OnPreviousPlayerState(event as object) as void
    previousPlayer = event.getRoSGNode()
    if m.onCloseCalled = true
        previousPlayer.unobserveFieldScoped("state")
        return
    end if
    previousPlayerState = previousPlayer.state
    
    if previousPlayerState = "stopped" or previousPlayerState = "error" or previousPlayerState = "finished" or previousPlayerState = "none"
        previousPlayer.unobserveFieldScoped("state")
        m.top.control = "play"
    end if
end function

'-------------------------------------------------------------------------------
' Title / secondary-title overlay (plumbing, fed from content). The wall clock is the sibling Clock component,
' which self-updates once a minute — no plumbing here.
'-------------------------------------------------------------------------------
function OnContentMetaChange()
    UpdateOverlayMeta()
end function

function UpdateOverlayMeta() as void
    content = m.top.content
    if content = invalid
        return
    end if
    title = ValidString(content.title)
    secondaryTitle = ValidString(content.secondaryTitle)
    m.titleLabel.text = title
    m.secondaryTitleLabel.text = secondaryTitle
    
    m.spinner.title = title
    m.spinner.secondaryTitle = secondaryTitle
end function

'-------------------------------------------------------------------------------
' Storyboards — sourced from the native Video.thumbnailTiles field (the OS populates it from the DASH image
' AdaptationSet; the DASH builder equalizes @bandwidth across levels and orders sharpest-first so the OS
' selects the sharpest — see GenerateImageAdaptationSets). Live has none.
'-------------------------------------------------------------------------------
' Reads the tiles from the event — thumbnailTiles is a large AA (every sheet url), and a m.top read would
' copy the whole thing a second time.
function OnThumbnailTiles(event as object) as void
    if m.onCloseCalled = true
        return
    end if
    if m.transport.isLive
        return
    end if
    tileSet = PlayerCoordinatorLogic_PickThumbnailTileSet(event.getData())
    if tileSet = invalid
        return
    end if
    m.bifDisplay.tileSet = tileSet
    intervalMs = PlayerCoordinatorLogic_TileSetIntervalMs(tileSet)
    m.transport.UpdateStoryboards(intervalMs, true)
    
end function

'-------------------------------------------------------------------------------
' EOF / close lifecycle.
'-------------------------------------------------------------------------------
function OnPlaybackFinished() as void
    
    m.playbackTelemetry.OnFinished()
    
    
    if m.videoQueue.sleepAfterVideo = true
        LogInfo2("[VideoPlayerDev.bs:2075]", "Sleep timer: end of video, stopping playback")
        m.videoQueue.sleepAfterVideo = false
        ClosePlayer()
        return
    end if
    
    if IsPlayingShort()
        FlipShort(true)
        return
    end if
    
    if ShowAutoplayCountdown()
        return
    end if
    if not VideoQueueUtils_PlayNext(m.videoQueue, m.invidious, m.preferences)
        ClosePlayer()
    end if
end function

'-------------------------------------------------------------------------------
' Error dialog — the coordinator owns the scene-level TimedDialog node + the response observer (node-scoped;
' the retry-vs-dialog decision is ErrorDialogController). 10s countdown on "Play next video"(default) /
' "Cancel"; any key cancels the countdown; response -> PlayNext or close.
'-------------------------------------------------------------------------------
' Always returns a record — callers dereference .title/.body unconditionally, so a state=error with no errorInfo
' must still produce one.
function GetPlayerErrorData(videoId as string, errorInfo as object) as object
    title = Tr("Error playing video %1").Replace("%1", videoId)
    body = ("errorMsg: " + bslib_toString(m.top.errorMsg) + chr(10) + "errorCode: " + bslib_toString(m.top.errorCode) + chr(10) + "errorStr: " + bslib_toString(m.top.errorStr))
    if errorInfo <> invalid
        for each key in errorInfo
            body += (chr(10) + bslib_toString(key) + ": " + bslib_toString(errorInfo[key]))
        end for
    end if
    return {
        title: title
        body: body
    }
end function

function ShowErrorDialog(decision as object) as void
    
    m.playbackTelemetry.OnErrorDialog()
    buttons = [
        Tr("Play next video")
        Tr("Cancel")
    ]
    dialog = DialogUtils_ShowTimedDialogButtons(decision.message, decision.title, buttons, 0, 10, true)
    if dialog <> invalid
        m.errorDialogNode = dialog
        dialog.observeFieldScoped("wasClosed", FuncName(OnErrorDialogResponse))
    else
        
        OnErrorDialogResponse(invalid)
    end if
end function

' Close our error dialog if playback recovered while it was up.
function DismissErrorDialog() as void
    dialog = m.errorDialogNode
    if dialog <> invalid
        m.errorDialogNode = invalid
        dialog.unobserveFieldScoped("wasClosed")
        dialog.close = true
    end if
end function

' button 0 (Play next video) / 10s timeout -> PlayNext (-> close if none); button 1 (Cancel) -> close.
function OnErrorDialogResponse(event as object) as void
    shouldPlayNext = false
    if event <> invalid
        dialog = event.getRoSGNode()
        if m.errorDialogNode <> invalid and dialog.isSameNode(m.errorDialogNode)
            m.errorDialogNode = invalid
        end if
        dialog.unobserveFieldScoped("wasClosed")
        shouldPlayNext = (dialog.actualButtonSelected = 0)
    end if
    if not shouldPlayNext or not VideoQueueUtils_PlayNext(m.videoQueue, m.invidious, m.preferences)
        ClosePlayer()
    end if
end function

'-------------------------------------------------------------------------------
' Autoplay countdown ("Autoplay countdown" setting, on by default): when the queue is done and autoplay is about
' to pick a related video, a dialog names it and counts down; Play now / the countdown play it, Cancel or Back
' close the player.
'-------------------------------------------------------------------------------
function ShowAutoplayCountdown() as boolean
    if m.preferences = invalid or m.preferences["playback.autoplay_countdown"] <> true
        return false
    end if
    nextVideo = NextAutoplayVideo()
    if nextVideo = invalid
        return false
    end if
    message = ValidString(nextVideo.title)
    if IsString(nextVideo.author) and nextVideo.author <> ""
        message += (chr(10)) + nextVideo.author
    end if
    buttons = [
        Tr("Play now")
        Tr("Cancel")
    ]
    dialog = DialogUtils_ShowTimedDialogButtons(message, Tr("Up next"), buttons, 0, 8)
    if dialog = invalid
        return false
    end if
    m.upNextDialog = dialog
    dialog.observeFieldScoped("wasClosed", FuncName(OnAutoplayCountdownClosed))
    
    if m.countdownTimer = invalid
        m.countdownTimer = m.top.createChild("Timer")
        m.countdownTimer.repeat = false
        m.countdownTimer.observeFieldScoped("fire", FuncName(OnAutoplayCountdownTimer))
    end if
    m.countdownTimer.duration = 8
    m.countdownTimer.control = "start"
    return true
end function

function OnAutoplayCountdownTimer() as void
    dialog = m.upNextDialog
    if dialog = invalid or m.onCloseCalled = true
        return
    end if
    m.upNextDialog = invalid
    dialog.unobserveFieldScoped("wasClosed")
    dialog.close = true
    if not VideoQueueUtils_PlayNext(m.videoQueue, m.invidious, m.preferences)
        ClosePlayer()
    end if
end function

' The related video autoplay would play (VideoQueueUtils.PlayNext's pick), or invalid when it wouldn't autoplay.
function NextAutoplayVideo() as dynamic
    if m.videoQueue.hasNext or m.preferences["playback.autoplay"] <> true
        return invalid
    end if
    content = m.top.content
    if content = invalid or not content.hasField("metadata") or not IsAssociativeArray(content.metadata)
        return invalid
    end if
    return VideoQueueUtils_PickRecommended(content.metadata.recommendedVideos, m.videoQueue.content)
end function

function OnAutoplayCountdownClosed(event as object) as void
    dialog = event.getRoSGNode()
    dialog.unobserveFieldScoped("wasClosed")
    if m.upNextDialog <> invalid and dialog.isSameNode(m.upNextDialog)
        m.upNextDialog = invalid
    end if
    if m.countdownTimer <> invalid
        m.countdownTimer.control = "stop"
    end if
    if m.onCloseCalled = true
        return
    end if
    if dialog.actualButtonSelected = 0 and VideoQueueUtils_PlayNext(m.videoQueue, m.invidious, m.preferences)
        return
    end if
    ClosePlayer()
end function

function ClosePlayer() as void
    if m.videoQueue <> invalid
        m.videoQueue.closePlayer = true
    end if
end function

function OnClose() as void
    
    if m.onCloseCalled = true
        return
    end if
    m.onCloseCalled = true
    m.top.previousPlayer = invalid
    m.playbackTelemetry.SendSummary()
    
    m.container.unobserveFieldScoped("fullscreen")
    m.top.unobserveField("state")
    m.top.unobserveField("position")
    m.top.unobserveField("duration")
    m.top.unobserveField("thumbnailTiles")
    m.top.unobserveField("control")
    m.top.unobserveField("setSeek")
    m.top.unobserveField("bufferingStatus")
    m.top.unobserveField("playStartInfo")
    m.top.unobserveField("streamingSegment")
    m.top.unobserveField("close")
    content = m.top.content
    if content <> invalid
        content.unobserveField("title")
        content.unobserveField("secondaryTitle")
    end if
    m.autoHide.unobserveField("fire")
    m.transportTimer.unobserveField("fire")
    m.liveBadgeHold.unobserveField("fire")
    m.liveEdgeClock.unobserveField("fire")
    m.fullScreenHintTimer.unobserveField("fire")
    m.chromeFadeIn.unobserveField("state")
    m.chromeFadeOut.unobserveField("state")
    if m.captionsOverlay <> invalid
        m.captionsOverlay.video = invalid
    end if
    StopWaitingForShorts()
    
    m.autoHide.control = "stop"
    m.transportTimer.control = "stop"
    m.liveBadgeHold.control = "stop"
    m.liveEdgeClock.control = "stop"
    m.fullScreenHintTimer.control = "stop"
    m.clock.dispose = true
    if m.videoContentJob <> invalid
        m.videoContentJob.cancel = true
        m.videoContentJob = invalid
    end if
    if m.markVideoWatchedJob <> invalid
        m.markVideoWatchedJob.cancel = true
        m.markVideoWatchedJob = invalid
    end if
    if m.watchLaterJob <> invalid
        JobSystem_UnobserveCallback(m.watchLaterJob)
        m.watchLaterJob = invalid
    end if
    if m.upNextDialog <> invalid
        m.upNextDialog.unobserveFieldScoped("wasClosed")
        m.upNextDialog.close = true
        m.upNextDialog = invalid
    end if
    if m.countdownTimer <> invalid
        m.countdownTimer.control = "stop"
        m.countdownTimer.unobserveFieldScoped("fire")
    end if
    if m.sponsorBlockSegmentsJob <> invalid
        m.sponsorBlockSegmentsJob.cancel = true
        m.sponsorBlockSegmentsJob = invalid
    end if
    if m.sponsorblock <> invalid
        m.sponsorblock.Dispose()
        m.sponsorblock = invalid
    end if
    DismissErrorDialog()
    parent = m.top.getParent()
    if parent <> invalid
        parent.RemoveChild(m.top)
    end if
    try
        m.top.control = "stop"
    catch error
        m.playbackTelemetry.ReportStopFailure(error)
    end try
    m.top.content = invalid
end function