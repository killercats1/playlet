' Init is kept in its own file so VideoPlayerDev.bs can be imported by the test mock without AutoBind/@oninit
' rejecting an Init in two component scopes (BS1819). Real work is Initialize() in VideoPlayerDev.bs.
function Init()
    InitializeBindings() ' auto-generated!
    Initialize()
end function