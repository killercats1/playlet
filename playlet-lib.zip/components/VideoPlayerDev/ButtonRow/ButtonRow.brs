'import "pkg:/components/VideoPlayerDev/TransportController.bs"
'import "pkg:/source/utils/Types.bs"
' Trackbar track spans x=68..1212: right cluster right-aligns to 1212, center cluster centers on 640.






function Init()
    
    m.buttons = [
        m.top.findNode("PlayPauseButton")
        m.top.findNode("NextButton")
        m.top.findNode("MinimizeButton")
        m.top.findNode("CaptionsButton")
        m.top.findNode("LikeButton")
        m.top.findNode("DislikeButton")
        m.top.findNode("SubscribeButton")
        m.top.findNode("SleepTimerButton")
        m.top.findNode("SpeedButton")
        m.top.findNode("WatchLaterButton")
    ]
    m.centerCluster = m.top.findNode("CenterCluster")
    m.rightCluster = m.top.findNode("RightCluster")
    LayoutClusters()
    m.top.buttonCount = m.buttons.Count() 
    for each field in [
        "transportMode"
        "rowFocused"
        "focusedIndex"
        "playing"
        "captionsOn"
        "likeState"
        "subscribed"
        "sleepTimerOn"
        "watchLaterSaved"
    ]
        m.top.ObserveField(field, FuncName(Repaint))
    end for
    m.top.ObserveField("nudge", FuncName(OnNudge))
    Repaint()
end function

' Forward the nudge to the focused button (an out-of-range focusedIndex indexes to invalid -> no-op).
function OnNudge() as void
    button = m.buttons[m.top.focusedIndex]
    if button <> invalid
        button.nudge = true
    end if
end function

' Position the buttons inside each cluster and the clusters on screen, all from child count, so adding a
' button auto-positions without hardcoded offsets.
function LayoutClusters() as void
    LayoutButtons(m.centerCluster)
    LayoutButtons(m.rightCluster)
    m.centerCluster.translation = [
        640 - ClusterWidth(m.centerCluster) / 2
        560
    ]
    m.rightCluster.translation = [
        1212 - ClusterWidth(m.rightCluster)
        560
    ]
end function

function LayoutButtons(cluster as object) as void
    for i = 0 to cluster.getChildCount() - 1
        cluster.getChild(i).translation = [
            i * (42 + 20)
            0
        ]
    end for
end function

function ClusterWidth(cluster as object) as integer
    n = cluster.getChildCount()
    if n <= 0
        return 0
    end if
    return n * 42 + (n - 1) * 20
end function

function Repaint() as void
    
    m.top.visible = (m.top.transportMode = 0)
    m.buttons[0].toggleState = not m.top.playing 
    m.buttons[3].toggleState = m.top.captionsOn 
    m.buttons[4].toggleState = m.top.likeState = 1 
    m.buttons[5].toggleState = m.top.likeState = 2 
    m.buttons[6].toggleState = m.top.subscribed 
    m.buttons[7].toggleState = m.top.sleepTimerOn 
    m.buttons[9].toggleState = m.top.watchLaterSaved 
    for i = 0 to m.buttons.Count() - 1
        m.buttons[i].focused = m.top.rowFocused and i = m.top.focusedIndex
    end for
end function