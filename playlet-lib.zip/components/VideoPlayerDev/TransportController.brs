' Pure-logic "brain" of the video player transport.
'
' The coordinator (VideoPlayerDev) holds one instance in m.transport, forwards device signals to its methods,
' and reads its scalar OUTPUT fields to drive the Video node + the renderers. Renders nothing and owns no Timer:
' it publishes a timer SCHEDULE (timerCmd) the coordinator mirrors onto a real Timer and calls Tick(timerId) when
' it fires; in tests Tick() is called directly (no device, no clock), which makes tick-driven behaviour testable.
' All finite state is an int enum; the only AA crossing per event is the small `videoIntent` (control + seek).
'
' LIVE model: the edge comes from OnLiveEdge — the coordinator computes it from the wall clock anchored at the
' manifest's availabilityStartTime (which Playlet itself generates), so it advances continuously: through
' pauses, rebuffers and startup. atLiveEdge is a pure derivation (offset <= jitter band) and the latency
' baseline is just the smallest (edge - position) ever observed — no fall-behind heuristics.








' Hold-to-seek acceleration. A held Left/Right steps the flat storyboard grid for the first
' RAMP_DELAY ticks — a fine-adjust window before speed builds — then each tick grows the step by
' 1/RAMP_DIVISOR of its remaining gap to the cap: an exponential approach to a terminal velocity.
' The cap, CAP_SQRT_COEFF * sqrt(durationMs) per tick, scales with the SQUARE ROOT of the duration,
' so the hold time to cross a whole video grows sublinearly: a many-hour VOD stays reachable in a
' few seconds of holding without making short videos twitchy.






 ' seek target that means "jump to the live edge"
' Video.position is single-precision, so the 999999s sentinel echoes back as 999998.976s and
' Int(position * 1000) lands 24ms UNDER the constant. Sentinel checks take this slack — nothing
' legitimate on the window timeline gets near 11.5 days.

' The device will not hold a pause this close to the sliding DVR tail: it force-resumes ~1/s
' (each manifest refresh), starting ~10s ABOVE the advertised floor (measured on device). The
' tail resolution resumes at least this far above the floor so the resumed playhead isn't
' immediately overtaken again.

' Live scan base scales with DVR window length: base = effectiveEdge / DIVISOR, floored at the storyboard
' interval so short DVRs are unchanged. 4000 -> ~10.8s base on a 12h DVR -> L3 ~65s/tick.


' A VOD commit landing within this of the duration means "watched to the end" -> finish (PlayNext/close),
' not a seek into the last instants (which just re-buffers and fights the device's EOF auto-resume).
' Matches the SponsorBlock finish rule (SponsorBlockController.SkipTargetMs).

 ' how long the transient InstantReplay icon stays before it self-clears
' "● LIVE" shows while the offset is within this jitter band of the inherent latency; beyond it the bar
' shows the time-behind. The clock-anchored edge advances smoothly, so this only needs to absorb position
' notification granularity (~1s) plus a little buffering slack.

' Leaving the edge while passively TRACKING (idle playback) takes a wider band: position notifications lag
' the clock-driven edge in bursts (segment fetches, brief stalls), and flipping the badge to "0:04" and
' back on every burst reads as flicker. User actions (rewind/seek/commit) keep the tight band.


' Whether a device-reported ms value is the live-edge seek sentinel echoing back through the
' single-precision position/duration fields (see LIVE_EDGE_SENTINEL_SLACK_MS): such values are
' seek plumbing, not positions.
function TransportController_IsLiveEdgeSentinelMs(ms as integer) as boolean
    return ms >= 999999000 - 100000
end function

' The hold-seek per-tick step cap (see the SCRUB_HOLD_* constants). Floors at the storyboard step
' so a short or unknown duration keeps the flat grid step.
function TransportController_ScrubHoldCapMs(durationMs as integer, storyboardStepMs as integer) as integer
    cap = Int(61 * Sqr(durationMs))
    if cap < storyboardStepMs
        return storyboardStepMs
    end if
    return cap
end function
' The transport state machine.
sub __TransportController_Controller_method_new()
    m.isLive = false
    m.hasStoryboards = false
    m.storyboardStepMs = 2000
    m.dvrWindowMs = 0
    m.positionMs = 0
    m.durationMs = 0
    m.ready = false
    m.transportMode = 0
    m.cursorMs = 0
    m.glyph = 0
    m.scanLevel = 0
    m.liveOffsetMs = 0
    m.atLiveEdge = true
    m.videoIntent = invalid
    m.intentSeq = 0
    m.commitSeq = 0
    m.finishSeq = 0
    m.timerCmdAction = 0
    m.timerCmdId = 0
    m.timerCmdDelayMs = 0
    m.timerCmdRepeat = false
    m.scanDir = 0
    m.scrubHeldDir = 0
    m.scrubHoldTicks = 0
    m.scrubStepMs = 2000
    m.edgeMs = 0
    m.liveMinGapMs = -1
    m.liveMinCandidateMs = -1
    m.replayPending = false
    m.replayTargetMs = 0
    m.seekSettling = false
end sub
function __TransportController_Controller_method_SetContent(isLive as boolean, storyboardStepMs as integer, hasStoryboards as boolean) as void
    m.isLive = isLive
    m.hasStoryboards = hasStoryboards
    if storyboardStepMs > 0
        m.storyboardStepMs = storyboardStepMs
    end if
    m.scrubHoldTicks = 0 
    m.scrubStepMs = m.storyboardStepMs
    m.dvrWindowMs = 0 
    m.edgeMs = 0
    m.liveMinGapMs = -1 
    m.liveMinCandidateMs = -1
    m.atLiveEdge = true
    m.replayPending = false 
    m.replayTargetMs = 0
end function
function __TransportController_Controller_method_SetLiveDvrWindow(windowMs as integer) as void
    if windowMs > 0
        m.dvrWindowMs = windowMs
    else
        m.dvrWindowMs = 0
    end if
end function
function __TransportController_Controller_method_LiveFloorMs() as integer
    if m.dvrWindowMs <= 0
        return 0
    end if
    floor = m.edgeMs - m.dvrWindowMs
    if floor < 0
        return 0
    end if
    return floor
end function
function __TransportController_Controller_method_SafetyFloorMs() as integer
    if not m.isLive or m.dvrWindowMs <= 0
        return -1
    end if
    return m.LiveFloorMs()
end function
function __TransportController_Controller_method_UpdateStoryboards(storyboardStepMs as integer, hasStoryboards as boolean) as void
    m.hasStoryboards = hasStoryboards
    if storyboardStepMs > 0
        m.storyboardStepMs = storyboardStepMs
    end if
    
    if m.scrubStepMs < m.storyboardStepMs
        m.scrubStepMs = m.storyboardStepMs
    end if
end function
function __TransportController_Controller_method_OnReady() as void
    m.ready = true
end function
function __TransportController_Controller_method_MarkSeekSettled() as void
    m.seekSettling = false
end function
function __TransportController_Controller_method_OnPosition(ms as integer) as void
    if m.isLive and TransportController_IsLiveEdgeSentinelMs(ms)
        return
    end if
    m.positionMs = ms
    
    if m.replayPending and Abs(ms - m.replayTargetMs) < 3000
        m.replayPending = false
    end if
    if m.isLive
        
        if ms > m.edgeMs
            m.edgeMs = ms
        end if
        
        gap = m.edgeMs - ms
        if m.liveMinGapMs < 0 or gap < m.liveMinGapMs
            if m.liveMinCandidateMs >= 0 and Abs(gap - m.liveMinCandidateMs) <= 3000
                m.liveMinGapMs = gap
                m.liveMinCandidateMs = -1
            else
                m.liveMinCandidateMs = gap
            end if
        else
            m.liveMinCandidateMs = -1 
        end if
    end if
    if m.transportMode = 0
        m.cursorMs = ms
        if m.isLive
            m.RecomputeLive(true) 
        end if
    end if
end function
function __TransportController_Controller_method_OnDuration(ms as integer) as void
    if m.isLive
        return
    end if
    m.durationMs = ms
    m.ClampIdleCursor()
    
    cap = TransportController_ScrubHoldCapMs(m.durationMs, m.storyboardStepMs)
    if m.scrubStepMs > cap
        m.scrubStepMs = cap
    end if
end function
function __TransportController_Controller_method_OnLiveEdge(ms as integer) as void
    if not m.isLive or ms <= 0 or TransportController_IsLiveEdgeSentinelMs(ms)
        return
    end if
    m.edgeMs = ms
    m.ClampIdleCursor() 
    if m.transportMode = 0
        m.RecomputeLive(true) 
    else if m.transportMode = 3
        m.RecomputeLive() 
    end if
end function
function __TransportController_Controller_method_ClampIdleCursor() as void
    if m.transportMode <> 0
        return
    end if
    hi = m.durationMs
    if m.isLive
        hi = m.edgeMs
    end if
    if hi > 0 and m.cursorMs > hi
        m.cursorMs = hi
    end if
end function
function __TransportController_Controller_method_HandleKey(command as integer, isDown as boolean) as void
    if not m.ready
        return
    end if
    if not isDown
        
        isScrubKey = (command = 1 or command = 2)
        if m.transportMode = 1 and isScrubKey
            m.scrubHeldDir = 0
            m.glyph = 0
            m.StopTimer(1)
        else if m.transportMode = 3 and m.scrubHeldDir <> 0 and isScrubKey
            
            m.scrubHeldDir = 0
            m.glyph = 0
            m.StopTimer(1)
        end if
        return
    end if
    m.HandleCommand(command)
end function
function __TransportController_Controller_method_HandleCommand(command as integer) as void
    if not m.ready
        return
    end if
    
    if command <> 5
        m.replayPending = false
    end if
    if command = 6
        m.Commit()
        return
    end if
    if command = 5
        m.Replay()
        return
    end if
    if m.isLive
        if command = 1
            m.LiveStep(-1)
        else if command = 2
            m.LiveStep(1)
        else if command = 3
            m.EnterLiveScan(-1)
        else if command = 4
            m.EnterLiveScan(1)
        end if
        return
    end if
    if command = 1
        m.EnterScrub(-1)
    else if command = 2
        m.EnterScrub(1)
    else if command = 4
        m.EnterScan(1)
    else if command = 3
        m.EnterScan(-1)
    end if
end function
function __TransportController_Controller_method_EnterScrub(dir as integer) as void
    firstEnter = (m.transportMode <> 1)
    if firstEnter
        if m.transportMode = 0
            m.FreezeForTransport() 
            m.cursorMs = m.SnapToGrid(m.cursorMs, m.storyboardStepMs)
        end if
        m.transportMode = 1
        m.scanLevel = 0
        m.scanDir = 0
        m.StopTimer(2)
    end if
    m.scrubHeldDir = dir
    m.scrubHoldTicks = 0 
    m.scrubStepMs = m.storyboardStepMs
    if dir < 0
        m.glyph = 1
    else
        m.glyph = 2
    end if
    m.ScrubStep(dir)
    m.ArmTimer(1, 510, false)
end function
function __TransportController_Controller_method_ScrubStep(dir as integer) as void
    m.cursorMs = m.Clamp(m.cursorMs + dir * m.scrubStepMs, 0, m.durationMs)
end function
function __TransportController_Controller_method_AdvanceScrubHold() as void
    m.scrubHoldTicks = m.scrubHoldTicks + 1
    if m.scrubHoldTicks <= 8
        return
    end if
    cap = TransportController_ScrubHoldCapMs(m.durationMs, m.storyboardStepMs)
    if m.scrubStepMs >= cap
        m.scrubStepMs = cap
        return
    end if
    grow = (cap - m.scrubStepMs) \ 11
    if grow < 1
        grow = cap - m.scrubStepMs
    end if
    m.scrubStepMs = m.scrubStepMs + grow
end function
function __TransportController_Controller_method_EnterScan(dir as integer) as void
    if m.transportMode <> 2
        if m.transportMode = 0
            m.FreezeForTransport()
        end if
        m.transportMode = 2
        m.scrubHeldDir = 0
        m.StopTimer(1)
        m.scanDir = 0
        m.scanLevel = 0
    end if
    m.AdvanceLadder(dir)
    m.ArmTimer(2, m.ScanCadenceMs(m.scanLevel), true)
end function
function __TransportController_Controller_method_AdvanceLadder(dir as integer) as void
    if m.scanDir <> dir or m.scanLevel < 1
        m.scanDir = dir
        m.scanLevel = 1
    else
        m.scanLevel = (m.scanLevel mod 3) + 1
    end if
    m.glyph = m.ScanGlyph(m.scanDir, m.scanLevel)
end function
function __TransportController_Controller_method_ScanTick() as void
    jump = m.ScanJumpMs(m.scanLevel)
    
    m.cursorMs = m.Clamp(m.cursorMs + m.scanDir * jump, 0, m.durationMs)
end function
function __TransportController_Controller_method_EnterLiveDvr() as boolean
    if m.transportMode = 3
        return false
    end if
    m.transportMode = 3
    m.scanLevel = 0
    m.scanDir = 0
    m.RecomputeLive()
    return true
end function
function __TransportController_Controller_method_LiveStep(dir as integer) as void
    fresh = m.EnterLiveDvr()
    m.scanDir = 0 
    m.scanLevel = 0
    m.scrubHeldDir = dir
    if dir < 0
        m.glyph = 1
    else
        m.glyph = 2
    end if
    
    if fresh
        m.EmitIntent(1, false, 0)
    end if
    
    if m.LiveHoldStep(dir)
        m.ArmTimer(1, 510, false)
    end if
end function
function __TransportController_Controller_method_LiveHoldStep(dir as integer) as boolean
    target = m.cursorMs + dir * 5000
    if dir > 0 and target >= m.LiveEdgeMs()
        m.CommitToLiveEdge()
        return false
    end if
    m.cursorMs = m.Clamp(target, m.LiveFloorMs(), m.LiveEdgeMs())
    m.RecomputeLive() 
    return true
end function
function __TransportController_Controller_method_EnterLiveScan(dir as integer) as void
    fresh = m.EnterLiveDvr()
    if fresh
        m.EmitIntent(1, false, 0) 
    end if
    m.scrubHeldDir = 0 
    m.AdvanceLadder(dir)
    m.RecomputeLive()
    m.ArmTimer(2, m.ScanCadenceMs(m.scanLevel), true)
end function
function __TransportController_Controller_method_LiveScanTick() as void
    jump = m.ScanJumpMs(m.scanLevel)
    target = m.cursorMs + m.scanDir * jump
    if m.scanDir > 0 and target >= m.LiveEdgeMs()
        m.CommitToLiveEdge()
        return
    end if
    m.cursorMs = m.Clamp(target, m.LiveFloorMs(), m.LiveEdgeMs())
    m.RecomputeLive()
end function
function __TransportController_Controller_method_CommitToLiveEdge() as void
    m.ResetToIdle()
    m.cursorMs = m.LiveEdgeMs() 
    m.RecomputeLive()
    m.EmitIntent(2, true, 999999000)
    m.commitSeq = m.commitSeq + 1
end function
function __TransportController_Controller_method_ResolveLiveTail() as void
    if m.transportMode <> 3
        return 
    end if
    floorSafe = m.LiveFloorMs() + 2 * 30000
    if m.cursorMs < floorSafe
        m.cursorMs = m.Clamp(floorSafe, 0, m.LiveEdgeMs())
    end if
    m.Commit()
end function
function __TransportController_Controller_method_LiveEdgeMs() as integer
    gap = m.liveMinGapMs
    if gap < 0
        gap = 0
    end if
    e = m.edgeMs - gap
    if e < 0
        e = 0
    end if
    return e
end function
function __TransportController_Controller_method_RecomputeLive(tracking = false as boolean) as void
    raw = m.edgeMs - m.cursorMs
    if raw < 0
        raw = 0
    end if
    gap = m.liveMinGapMs
    if gap < 0
        
        gap = m.edgeMs - m.positionMs
        if gap < 0
            gap = 0
        end if
    end if
    offset = raw - gap
    if offset < 0
        offset = 0
    end if
    m.liveOffsetMs = offset
    threshold = 3000
    if tracking and m.atLiveEdge
        threshold = 6000
    end if
    m.atLiveEdge = (offset <= threshold)
end function
function __TransportController_Controller_method_Commit() as void
    mode = m.transportMode
    if mode = 0
        return 
    end if
    if mode = 3
        
        if m.cursorMs >= m.LiveEdgeMs()
            m.CommitToLiveEdge()
            return
        end if
        target = m.cursorMs
        m.ResetToIdle() 
        m.cursorMs = target
        m.RecomputeLive()
        m.EmitIntent(2, true, target)
        m.commitSeq = m.commitSeq + 1
        return
    end if
    
    target = m.cursorMs
    if m.durationMs > 0 and target >= m.durationMs - 2000
        m.ResetToIdle()
        m.finishSeq = m.finishSeq + 1
        return
    end if
    
    m.positionMs = target
    m.ResetToIdle() 
    m.EmitIntent(2, true, target)
    m.commitSeq = m.commitSeq + 1
end function
function __TransportController_Controller_method_Replay() as void
    
    wasTransport = (m.transportMode <> 0)
    
    if m.replayPending
        base = m.replayTargetMs
    else
        base = m.cursorMs
    end if
    control = 0 
    if wasTransport
        control = 2 
    end if
    m.ResetToIdle()
    if m.isLive
        target = m.Clamp(base - 20000, m.LiveFloorMs(), m.edgeMs)
        m.cursorMs = target
        m.RecomputeLive() 
    else
        target = m.Clamp(base - 20000, 0, m.durationMs)
        m.cursorMs = target
    end if
    m.EmitIntent(control, true, target) 
    m.replayTargetMs = target 
    m.replayPending = true
    
    m.glyph = 9
    m.ArmTimer(4, 700, false)
end function
function __TransportController_Controller_method_ResetToIdle() as void
    m.transportMode = 0
    m.glyph = 0
    m.scanLevel = 0
    m.scanDir = 0
    m.scrubHeldDir = 0
    m.scrubHoldTicks = 0
    m.scrubStepMs = m.storyboardStepMs
    m.StopTimer(1)
    m.StopTimer(2)
    m.cursorMs = m.positionMs
end function
function __TransportController_Controller_method_ResetTransport() as void
    m.ResetToIdle()
end function
function __TransportController_Controller_method_CancelTransport() as void
    m.ResetToIdle()
    if m.isLive
        m.EmitIntent(2, false, 0)
    end if
end function
function __TransportController_Controller_method_ForceIdleSeek(targetMs as integer, keepPlaying as boolean) as void
    m.ResetToIdle()
    m.replayPending = false
    if m.isLive
        if TransportController_IsLiveEdgeSentinelMs(targetMs) or (m.edgeMs > 0 and targetMs >= m.LiveEdgeMs())
            targetMs = 999999000
            m.cursorMs = m.LiveEdgeMs()
        else
            targetMs = m.ClampToTimeline(targetMs, m.LiveFloorMs(), m.edgeMs)
            m.cursorMs = targetMs
        end if
        m.RecomputeLive()
    else
        targetMs = m.ClampToTimeline(targetMs, 0, m.durationMs)
        m.positionMs = targetMs 
        m.cursorMs = targetMs
    end if
    control = 2
    if keepPlaying
        control = 0
    end if
    m.EmitIntent(control, true, targetMs)
end function
function __TransportController_Controller_method_Tick(timerId as integer) as void
    if timerId = 1
        if m.transportMode = 1 and m.scrubHeldDir <> 0
            m.AdvanceScrubHold()
            m.ScrubStep(m.scrubHeldDir)
            m.ArmTimer(1, 120, false)
        else if m.transportMode = 3 and m.scrubHeldDir <> 0
            if m.LiveHoldStep(m.scrubHeldDir)
                m.ArmTimer(1, 120, false)
            end if
        end if
        return
    end if
    if timerId = 2
        if m.transportMode = 2
            m.ScanTick()
        else if m.transportMode = 3
            m.LiveScanTick()
        end if
        return
    end if
    if timerId = 4
        
        if m.transportMode = 0 and m.glyph = 9
            m.glyph = 0
        end if
        return
    end if
end function
function __TransportController_Controller_method_TakeVideoIntent() as object
    intent = m.videoIntent
    m.videoIntent = invalid
    return intent
end function
function __TransportController_Controller_method_TakeTimerCmd() as object
    if m.timerCmdAction = 0
        return invalid
    end if
    cmd = {
        action: m.timerCmdAction
        id: m.timerCmdId
        delayMs: m.timerCmdDelayMs
        repeat: m.timerCmdRepeat
    }
    m.timerCmdAction = 0
    return cmd
end function
function __TransportController_Controller_method_FreezeForTransport() as void
    if not m.seekSettling
        m.EmitIntent(1, false, 0)
    end if
end function
function __TransportController_Controller_method_EmitIntent(control as integer, hasSeek as boolean, seekMs as integer) as void
    m.intentSeq = m.intentSeq + 1
    m.videoIntent = {
        control: control
        hasSeek: hasSeek
        seekMs: seekMs
        seq: m.intentSeq
    }
    
    if hasSeek and control <> 1
        m.seekSettling = true
    end if
end function
function __TransportController_Controller_method_ArmTimer(id as integer, delayMs as integer, repeat as boolean) as void
    m.timerCmdAction = 1
    m.timerCmdId = id
    m.timerCmdDelayMs = delayMs
    m.timerCmdRepeat = repeat
end function
function __TransportController_Controller_method_StopTimer(id as integer) as void
    m.timerCmdAction = 2
    m.timerCmdId = id
    m.timerCmdDelayMs = 0
    m.timerCmdRepeat = false
end function
function __TransportController_Controller_method_ClampToTimeline(value as integer, lo as integer, hi as integer) as integer
    if hi <= 0
        hi = -1
    end if
    return m.Clamp(value, lo, hi)
end function
function __TransportController_Controller_method_Clamp(value as integer, lo as integer, hi as integer) as integer
    if value < lo
        return lo
    end if
    if hi >= lo and value > hi
        return hi
    end if
    return value
end function
function __TransportController_Controller_method_SnapToGrid(ms as integer, stepMs as integer) as integer
    if stepMs <= 0
        return ms
    end if
    return (ms \ stepMs) * stepMs
end function
function __TransportController_Controller_method_ScanJumpMs(level as integer) as integer
    
    base = m.storyboardStepMs
    if m.isLive
        
        windowBase = (m.LiveEdgeMs() - m.LiveFloorMs()) \ 4000
        if windowBase > base
            base = windowBase
        end if
    end if
    mult = 1
    if level = 2
        mult = 3
    else if level >= 3
        mult = 6
    end if
    return base * mult
end function
function __TransportController_Controller_method_ScanCadenceMs(level as integer) as integer
    if level = 2
        return 330
    end if
    if level >= 3
        return 260
    end if
    return 600
end function
function __TransportController_Controller_method_ScanGlyph(dir as integer, level as integer) as integer
    if dir > 0
        if level >= 3
            return 5
        end if
        if level = 2
            return 4
        end if
        return 3
    end if
    if level >= 3
        return 8
    end if
    if level = 2
        return 7
    end if
    return 6
end function
function __TransportController_Controller_builder()
    instance = {}
    instance.new = __TransportController_Controller_method_new
    ' ---- content facts (set once at contentReady) ----
    ' VOD per-tap step + scan base (storyboard L2 interval)
    ' Live DVR window length (0 = unknown); see LiveFloorMs.
    ' ---- inputs pushed by the coordinator (OnPosition / OnDuration / OnReady) ----
    ' drop all transport input until first frame
    ' ---- OUTPUT CONTRACT (read by the coordinator + renderers) ----
    ' Mode.Idle
    ' Glyph.None
    ' The one AA crossing to the coordinator {control, hasSeek, seekMs, seq}, drained via TakeVideoIntent.
    ' commitSeq / finishSeq — pulse counters the coordinator compares to its last-seen value. finishSeq
    ' pulses when a VOD commit lands at the very end (-> the coordinator finishes playback).
    ' timerCmd — the timer schedule the coordinator mirrors onto a real Timer node.
    ' TimerAction.None
    ' Timer.None
    ' ---- private scratch ----
    ' consecutive hold-repeat ticks of the current hold (drives the accel ramp)
    ' current per-step size: storyboardStepMs until the hold ramp grows it
    ' the live edge, fed by OnLiveEdge (the coordinator's wall-clock computation)
    ' Inherent live latency: the smallest CONFIRMED (edge - position) observed this content — the closest
    ' we have ever been IS how close this stream can get. The offset reads relative to it, so steady
    ' playback shows ~0 / "● LIVE" whatever the buffer latency is. -1 until learned. Confirmation = two
    ' consecutive samples agreeing within the jitter band: a single glitched near-edge sample (e.g. the
    ' initial jump-to-live seek echoing an optimistic position) must not poison the floor for the session.
    ' an InstantReplay seek is in flight (position hasn't reached it yet)
    ' the last InstantReplay target; spamming replay accumulates from THIS
    ' A keep-playing/resume seek is in flight and has NOT yet reached "playing". While true, a new transport
    ' must NOT slam control=pause: a pause landing mid-seek wedges the Video (buffering<->paused, esp. near
    ' EOF). Set on every non-pause seek emit; cleared by MarkSeekSettled when the device reaches playing.
    ' ------------------------------------------------------------------------------------------------
    ' Content / live inputs
    ' ------------------------------------------------------------------------------------------------
    instance.SetContent = __TransportController_Controller_method_SetContent
    ' Live DVR window length (ms); 0/negative = unknown (the rewind floor stays at 0).
    instance.SetLiveDvrWindow = __TransportController_Controller_method_SetLiveDvrWindow
    ' The rewind FLOOR: the oldest still-available position. t=0 is the oldest segment at manifest build
    ' time (the stream's start on a stream younger than the window), so as the session outlives the window
    ' the floor advances (edge - window); 0 while unknown or until then.
    instance.LiveFloorMs = __TransportController_Controller_method_LiveFloorMs
    ' The floor for the coordinator's tail-overtake safety decision: the availability floor when
    ' the window is known, -1 when it is not (without floor knowledge the safety verdict stays a
    ' plain freeze).
    instance.SafetyFloorMs = __TransportController_Controller_method_SafetyFloorMs
    ' Storyboards arrive late (the native Video.thumbnailTiles field populates after the manifest loads),
    ' so the coordinator updates the scrub step + bif gate here without the live-edge / replay resets that
    ' SetContent does for new content.
    instance.UpdateStoryboards = __TransportController_Controller_method_UpdateStoryboards
    instance.OnReady = __TransportController_Controller_method_OnReady
    ' Called when the Video reaches state="playing": the in-flight play-through seek has landed, so a later
    ' transport may freeze immediately again.
    instance.MarkSeekSettled = __TransportController_Controller_method_MarkSeekSettled
    ' Last real Video position. While idle the cursor tracks it; while a transport is active the machine owns
    ' the cursor. Drops the live-edge seek sentinel echo (see OnDuration).
    instance.OnPosition = __TransportController_Controller_method_OnPosition
    ' VOD length. On live the device's `duration` is IGNORED — it freezes during pause and snaps on resume;
    ' the edge comes from OnLiveEdge instead (clock-anchored, continuous). durationMs therefore stays 0 on
    ' live, which also keeps the VOD-only end-of-content commit rule inert there.
    instance.OnDuration = __TransportController_Controller_method_OnDuration
    ' The live edge (ms on the manifest timeline), computed by the coordinator from the wall clock anchored
    ' at the manifest's availabilityStartTime and pushed ~1/s. Advances through pauses, rebuffers and
    ' startup — the offset/badge math needs no event-pattern heuristics on top.
    instance.OnLiveEdge = __TransportController_Controller_method_OnLiveEdge
    ' Re-clamp a stale idle cursor when the duration/edge moves BELOW it: after a replay/skip the cursor
    ' holds the seek target until the next OnPosition lands, and a duration that regresses in that window
    ' (a live-edge glitch, a shorter retry manifest) would leave the cursor outside the playable range
    ' (INV-B1). Transports clamp on every step, so only the idle cursor needs this.
    instance.ClampIdleCursor = __TransportController_Controller_method_ClampIdleCursor
    ' ------------------------------------------------------------------------------------------------
    ' Key -> command entry
    ' ------------------------------------------------------------------------------------------------
    instance.HandleKey = __TransportController_Controller_method_HandleKey
    instance.HandleCommand = __TransportController_Controller_method_HandleCommand
    ' ------------------------------------------------------------------------------------------------
    ' SCRUB (VOD Left/Right) — first tap freezes + snaps the cursor to the grid; hold repeats.
    ' ------------------------------------------------------------------------------------------------
    instance.EnterScrub = __TransportController_Controller_method_EnterScrub
    instance.ScrubStep = __TransportController_Controller_method_ScrubStep
    ' One hold-repeat tick of the acceleration ramp: flat for the first RAMP_DELAY ticks, then the step
    ' approaches the duration-scaled cap by 1/RAMP_DIVISOR of the remaining gap per tick (the last
    ' sliver, where integer division floors to 0, snaps to the cap).
    instance.AdvanceScrubHold = __TransportController_Controller_method_AdvanceScrubHold
    ' ------------------------------------------------------------------------------------------------
    ' SCAN (VOD Fwd/Rev) — free-run ladder; same-dir tap climbs (wraps L3->L1); opposite flips to L1.
    ' ------------------------------------------------------------------------------------------------
    instance.EnterScan = __TransportController_Controller_method_EnterScan
    ' Shared 3-level ladder climb (VOD scan AND live scan). Same-dir tap climbs L1->2->3 and wraps to L1; a
    ' new/opposite direction resets to L1. Caller owns mode + cursor seeding + the timer.
    instance.AdvanceLadder = __TransportController_Controller_method_AdvanceLadder
    instance.ScanTick = __TransportController_Controller_method_ScanTick
    ' ------------------------------------------------------------------------------------------------
    ' LIVE DVR — Left/Rev = frozen VOD-scrub-shaped rewind (FREEZE, step -5s, hold repeats, NO per-press
    ' seek); Right = +5s toward the edge (reaching it auto-resumes); Fwd = continuous forward preview that
    ' auto-resumes at the edge. Offset = (edge - cursor) - baseline, counts up while frozen.
    ' ------------------------------------------------------------------------------------------------
    instance.EnterLiveDvr = __TransportController_Controller_method_EnterLiveDvr
    instance.LiveStep = __TransportController_Controller_method_LiveStep
    instance.LiveHoldStep = __TransportController_Controller_method_LiveHoldStep
    ' Live Rev/Fwd 3-level scan ladder (mirrors the VOD scan; the mode stays liveDvr). FREEZE on a fresh enter;
    ' the forward ladder auto-resumes when it reaches the edge, the reverse ladder clamps at the DVR floor.
    instance.EnterLiveScan = __TransportController_Controller_method_EnterLiveScan
    ' One ladder tick inside the DVR window. Never seeks mid-scan (preview only); the forward ladder reaching
    ' the edge is the single seek + resume, the seek otherwise waits for a commit.
    instance.LiveScanTick = __TransportController_Controller_method_LiveScanTick
    ' The live auto-resume: one seek to the edge + resume + back to idle.
    instance.CommitToLiveEdge = __TransportController_Controller_method_CommitToLiveEdge
    ' The sliding DVR tail overtook the frozen playhead (SafetyAction.ResumeLiveTail): the device
    ' force-resumes such a pause on every manifest refresh, so freezing again just loops. Resolve
    ' the transport forward instead — a normal commit, with the cursor floored above the tail
    ' (what the stock player does when paused live content expires). The resume parks a FULL margin
    ' above the trigger threshold: parked exactly on it, the floor advancing through the resume's
    ' rebuffer leaves the playhead hovering at the boundary and the very next rewind press would
    ' trip the trigger again and eat itself.
    instance.ResolveLiveTail = __TransportController_Controller_method_ResolveLiveTail
    ' The EFFECTIVE live edge: raw edge minus the latency baseline (where the offset reads 0 / "● LIVE").
    ' Forward commit + cursor clamp use THIS so the offset-hits-0 point and the auto-commit point COINCIDE —
    ' no dead-zone seeking forward past the visible edge.
    instance.LiveEdgeMs = __TransportController_Controller_method_LiveEdgeMs
    ' Recompute the live outputs from first principles — no stateful detection. The offset is how far the
    ' cursor sits behind the edge beyond the stream's inherent latency (liveMinGapMs), and "at the edge" is
    ' simply that offset being inside the jitter band. Pause, rebuffer, rewind, startup: all just make the
    ' offset what it really is.
    ' tracking=true (the idle 1/s position/edge ticks) adds leave-hysteresis on the badge: once at the
    ' edge, only a sustained fall-behind drops it. Re-entry, and every user action, stays on the tight band.
    instance.RecomputeLive = __TransportController_Controller_method_RecomputeLive
    ' ------------------------------------------------------------------------------------------------
    ' COMMIT (Select/OK or Play while a transport is active) — seek to cursor + resume + idle. No
    ' imperative teardown: the bif/glyph self-hide because transportMode -> idle.
    ' ------------------------------------------------------------------------------------------------
    instance.Commit = __TransportController_Controller_method_Commit
    ' ------------------------------------------------------------------------------------------------
    ' INSTANT REPLAY (-20s) — a one-shot seek, KEEP PLAYING. On live it jumps back into the DVR window
    ' (badge swaps "● LIVE" -> offset); on VOD it just seeks -20s.
    ' ------------------------------------------------------------------------------------------------
    instance.Replay = __TransportController_Controller_method_Replay
    ' Flip back to idle + clear scratch/outputs. Renderers self-hide off the mode flip.
    instance.ResetToIdle = __TransportController_Controller_method_ResetToIdle
    ' Reset an active transport to idle WITHOUT a seek/resume/exit pulse: the play/pause state is left
    ' exactly as it was (no videoIntent emitted). Used by the involuntary resets — Minimize (Down), video
    ' error, EOF finish, PiP/Lounge cutovers — which silently return to idle while the player keeps running.
    instance.ResetTransport = __TransportController_Controller_method_ResetTransport
    ' Back's rung-1 cancel: reset to idle, and on LIVE also resume at the frozen playhead (no seek — still
    ' behind the edge). Idle-paused live is a dead end: OK never resumes on live (it only toggles the HUD),
    ' the paused playhead drifts toward the DVR floor, and the device force-resumes it there anyway. VOD
    ' stays exactly where the freeze put it — paused (canceling and committing are intentionally asymmetric).
    instance.CancelTransport = __TransportController_Controller_method_CancelTransport
    ' An EXTERNAL authority seeks while a transport may be active. The cursor goes to the target before the
    ' seek lands, so the idle bar, a Replay, and a transport entered meanwhile all start from it. On live, a
    ' target at or past the effective edge seeks to the edge, as a commit there does.
    instance.ForceIdleSeek = __TransportController_Controller_method_ForceIdleSeek
    ' ------------------------------------------------------------------------------------------------
    ' Tick — the coordinator calls this when the Timer named `timerId` fires.
    ' ------------------------------------------------------------------------------------------------
    instance.Tick = __TransportController_Controller_method_Tick
    ' ------------------------------------------------------------------------------------------------
    ' Output consumers — the coordinator drains these once per its own notification.
    ' ------------------------------------------------------------------------------------------------
    instance.TakeVideoIntent = __TransportController_Controller_method_TakeVideoIntent
    instance.TakeTimerCmd = __TransportController_Controller_method_TakeTimerCmd
    ' ------------------------------------------------------------------------------------------------
    ' Private emit/timer/math helpers
    ' ------------------------------------------------------------------------------------------------
    ' Emit the freeze pause for a transport ENTER from idle, UNLESS a play-through seek is still settling.
    ' Pausing mid-seek wedges the Video (buffering<->paused, esp. near EOF); instead let that seek reach
    ' "playing", where the coordinator freezes cleanly.
    instance.FreezeForTransport = __TransportController_Controller_method_FreezeForTransport
    instance.EmitIntent = __TransportController_Controller_method_EmitIntent
    instance.ArmTimer = __TransportController_Controller_method_ArmTimer
    instance.StopTimer = __TransportController_Controller_method_StopTimer
    ' Clamp to [lo, hi]; hi <= 0 is a timeline end not known yet, so only the floor applies. An external seek
    ' can arrive while the content loads; transport input is dropped until the first frame, when it is known.
    instance.ClampToTimeline = __TransportController_Controller_method_ClampToTimeline
    instance.Clamp = __TransportController_Controller_method_Clamp
    ' Snap a position down to the storyboard grid (the cursor enters scrub on an even step boundary).
    instance.SnapToGrid = __TransportController_Controller_method_SnapToGrid
    instance.ScanJumpMs = __TransportController_Controller_method_ScanJumpMs
    instance.ScanCadenceMs = __TransportController_Controller_method_ScanCadenceMs
    instance.ScanGlyph = __TransportController_Controller_method_ScanGlyph
    return instance
end function
function TransportController_Controller()
    instance = __TransportController_Controller_builder()
    instance.new()
    return instance
end function