'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/Types.bs"






function Init()
    m.strip = m.top.findNode("strip")
    m.top.findNode("headerLabel").text = Tr("Up next")
    m.tiles = []
end function

function OnContentChange() as void
    while m.strip.getChildCount() > 0
        m.strip.removeChildIndex(0)
    end while
    m.tiles = []
    content = m.top.content
    count = 0
    if content <> invalid
        count = content.getChildCount()
    end if
    for i = 0 to count - 1
        video = content.getChild(i)
        tile = CreateObject("roSGNode", "Group")
        tile.translation = [
            i * (280 + 24)
            0
        ]
        poster = tile.createChild("Poster")
        poster.width = 280
        poster.height = 158
        poster.loadWidth = 280
        poster.loadHeight = 158
        poster.loadDisplayMode = "scaleToZoom"
        poster.failedBitmapUri = "pkg:/images/thumbnail-missing.jpg"
        poster.uri = video.thumbnail
        
        outline = tile.createChild("Poster")
        outline.uri = "pkg:/images/focus-outline.$$RES$$.9.png"
        outline.translation = [
            -8
            -8
        ]
        outline.width = 280 + 16
        outline.height = 158 + 16
        outline.visible = false
        title = tile.createChild("Label")
        title.translation = [
            0
            158 + 10
        ]
        title.width = 280
        title.maxLines = 2
        title.wrap = true
        title.color = "#EBEBEBFF"
        titleFont = CreateObject("roSGNode", "Font")
        titleFont.uri = "pkg:/fonts/Roboto-Medium.ttf"
        titleFont.size = 18
        title.font = titleFont
        title.text = video.title
        m.strip.appendChild(tile)
        m.tiles.Push({
            outline: outline
        })
    end for
    m.top.itemCount = count
    OnFocusedIndexChange()
end function

function OnFocusedIndexChange() as void
    index = m.top.focusedIndex
    for i = 0 to m.tiles.Count() - 1
        m.tiles[i].outline.visible = i = index
    end for
    
    tileStride = 280 + 24
    offset = index * tileStride - (1144 - tileStride)
    if offset < 0
        offset = 0
    end if
    m.strip.translation = [
        68 - offset
        484
    ]
end function