'import "pkg:/source/utils/Types.bs"
' Center pause poster. Sequence: scaleIn (0.5s) -> hold (1.0s) -> shrinkOut (0.3s) -> hidden.
' `advance` is a test hook: pulse it to step one phase without waiting on the real animation/timer durations.


function Init()
    m.poster = m.top.findNode("poster")
    m.scaleIn = m.top.findNode("scaleIn")
    m.shrinkOut = m.top.findNode("shrinkOut")
    m.hold = m.top.findNode("hold")
    
    m.scaleIn.ObserveField("state", FuncName(OnScaleInAnimState))
    m.shrinkOut.ObserveField("state", FuncName(OnShrinkOutAnimState))
    m.hold.ObserveField("fire", FuncName(OnHoldFire))
    m.top.ObserveField("trigger", FuncName(OnTrigger))
    m.top.ObserveField("cancel", FuncName(OnCancel))
    m.top.ObserveField("advance", FuncName(OnAdvance))
    m.top.phase = 0
end function

function OnTrigger() as void
    if not m.top.trigger
        return
    end if
    StopAnims()
    m.poster.opacity = 0
    m.poster.scale = [
        0.75
        0.75
    ]
    m.poster.visible = true
    m.top.phase = 1
    m.scaleIn.control = "start"
end function

function OnCancel() as void
    if not m.top.cancel
        return
    end if
    Hide()
end function

function OnAdvance() as void
    if m.top.phase = 1
        OnScaleInState()
    else if m.top.phase = 2
        OnHoldFire()
    else if m.top.phase = 3
        OnShrinkOutState()
    end if
end function

function OnScaleInAnimState() as void
    if m.scaleIn.state = "stopped"
        OnScaleInState()
    end if
end function

function OnShrinkOutAnimState() as void
    if m.shrinkOut.state = "stopped"
        OnShrinkOutState()
    end if
end function

function OnScaleInState() as void
    if m.top.phase <> 1
        return
    end if
    m.top.phase = 2
    m.hold.control = "start"
end function

function OnHoldFire() as void
    if m.top.phase <> 2
        return
    end if
    m.top.phase = 3
    m.shrinkOut.control = "start"
end function

function OnShrinkOutState() as void
    if m.top.phase <> 3
        return
    end if
    Hide()
end function

function Hide() as void
    StopAnims()
    m.hold.control = "stop"
    m.poster.opacity = 0
    m.poster.scale = [
        0.75
        0.75
    ]
    m.poster.visible = false
    m.top.phase = 0
end function

function StopAnims() as void
    m.scaleIn.control = "stop"
    m.shrinkOut.control = "stop"
end function