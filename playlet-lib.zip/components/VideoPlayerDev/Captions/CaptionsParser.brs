'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
' Turns a caption track into cues: [{ s: startSeconds, e: endSeconds, t: text }], sorted by start.
' Handles YouTube's json3 timedtext format and WebVTT.
function CaptionsParser_Parse(body as string) as object
    if StringUtils_IsNullOrEmpty(body)
        return []
    end if
    trimmed = body.Trim()
    if trimmed.StartsWith("{")
        return CaptionsParser_ParseJson3(trimmed)
    end if
    if trimmed.StartsWith("WEBVTT")
        return CaptionsParser_ParseVtt(trimmed)
    end if
    return []
end function

function CaptionsParser_ParseJson3(body as string) as object
    json = StringUtils_ParseJsonSafe(body)
    if not IsAssociativeArray(json) or not IsArray(json.events)
        return []
    end if
    cues = []
    for each event in json.events
        if not IsAssociativeArray(event) or not IsArray(event.segs)
            continue for
        end if
        text = ""
        for each seg in event.segs
            if IsAssociativeArray(seg) and IsString(seg.utf8)
                text += seg.utf8
            end if
        end for
        text = text.Trim()
        if text = ""
            continue for
        end if
        startMs = ValidInt(event.tStartMs)
        durationMs = ValidInt(event.dDurationMs)
        if durationMs <= 0
            continue for
        end if
        cues.Push({
            s: startMs / 1000.0
            e: (startMs + durationMs) / 1000.0
            t: text
        })
    end for
    return cues
end function

function CaptionsParser_ParseVtt(body as string) as object
    lines = body.Replace(Chr(13), "").Split(Chr(10))
    tagRegex = CreateObject("roRegex", "<[^>]*>", "")
    cues = []
    i = 0
    while i < lines.Count()
        line = lines[i]
        arrow = line.InStr("-->")
        if arrow = -1
            i += 1
            continue while
        end if
        startSeconds = CaptionsParser_ParseVttTime(line.Left(arrow).Trim())
        endPart = line.Mid(arrow + 3).Trim()
        
        spaceIndex = endPart.InStr(" ")
        if spaceIndex <> -1
            endPart = endPart.Left(spaceIndex)
        end if
        endSeconds = CaptionsParser_ParseVttTime(endPart)
        textLines = []
        i += 1
        while i < lines.Count() and lines[i].Trim() <> ""
            textLine = CaptionsParser_DecodeEntities(tagRegex.ReplaceAll(lines[i], "")).Trim()
            if textLine <> ""
                textLines.Push(textLine)
            end if
            i += 1
        end while
        if startSeconds >= 0 and endSeconds > startSeconds and textLines.Count() > 0
            cues.Push({
                s: startSeconds
                e: endSeconds
                t: textLines.Join(Chr(10))
            })
        end if
    end while
    return cues
end function

' "01:02:03.456" or "02:03.456" -> seconds, or -1 if it isn't a time.
function CaptionsParser_ParseVttTime(value as string) as float
    parts = value.Split(":")
    if parts.Count() < 2 or parts.Count() > 3
        return -1
    end if
    seconds = 0.0
    for each part in parts
        seconds = seconds * 60 + Val(part)
    end for
    return seconds
end function

function CaptionsParser_DecodeEntities(text as string) as string
    return text.Replace("&nbsp;", " ").Replace("&lt;", "<").Replace("&gt;", ">").Replace("&quot;", (chr(34))).Replace("&#39;", "'").Replace("&amp;", "&")
end function

' The text of every cue showing at `seconds`, in start order, one per line.
function CaptionsParser_ActiveText(cues as object, seconds as float) as string
    count = cues.Count()
    if count = 0
        return ""
    end if
    
    low = 0
    high = count
    while low < high
        middle = (low + high) \ 2
        if cues[middle].s <= seconds
            low = middle + 1
        else
            high = middle
        end if
    end while
    
    lines = []
    firstIndex = low - 8
    if firstIndex < 0
        firstIndex = 0
    end if
    for j = firstIndex to low - 1
        if cues[j].e > seconds
            lines.Push(cues[j].t)
        end if
    end for
    return lines.Join(Chr(10))
end function