'import "pkg:/components/VideoPlayerDev/Captions/CaptionsParser.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/UrlUtils.bs"

' Downloads one caption track and parses it into cues for CaptionsOverlay.
function ExecuteJob() as void
    input = JobGetInput()
    url = ValidString(input.url)
    if url = ""
        JobError("No caption url")
        return
    end if
    
    if url.InStr("/api/timedtext") <> -1
        query = UrlUtils_ParseQueryComponents(url)
        query["fmt"] = "json3"
        url = UrlUtils_SetQueryParams(url, query)
    end if
    request = HttpClient_Get(url)
    request.Cancellation(JobGetCancellation())
    response = request.Await()
    if not response.IsSuccess()
        JobError(response.ErrorMessage())
        return
    end if
    JobSuccessData({
        cues: CaptionsParser_Parse(response.Text())
    })
end function