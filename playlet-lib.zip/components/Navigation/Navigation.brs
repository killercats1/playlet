'import "pkg:/source/utils/FocusManagement.bs"

function SetNavigation(fromNode as object, direction as string, toNode as object, callback = invalid as dynamic)
    if m._navigation = invalid
        m._navigation = {}
    end if
    if not m._navigation.DoesExist(direction)
        m._navigation[direction] = []
    end if
    m._navigation[direction].push({
        fromNode: fromNode
        toNode: toNode
        callback: callback
    })
end function

function NavigationKeyHandler(key as string, press as boolean) as object
    if not press
        return {
            handled: false
            node: invalid
        }
    end if
    navigations = m._navigation[key]
    if navigations = invalid
        return {
            handled: false
            node: invalid
        }
    end if
    for each item in navigations
        if (item.fromNode = invalid or item.fromNode.isInFocusChain()) and item.toNode.focusable
            if item.fromNode <> invalid
                NodeSetFocus(item.fromNode, false)
            end if
            NodeSetFocus(item.toNode, true)
            if item.callback <> invalid
                item.callback()
            end if
            return {
                handled: true
                node: item.toNode
            }
        end if
    end for
    return {
        handled: false
        node: invalid
    }
end function