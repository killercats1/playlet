'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"

function InitializeLongPress(keys as object, duration = 1.0 as float)
    longPressKeyMap = {}
    longPressKeyMap["OK"] = "OK_LONG_PRESS"
    longPressKeyMap["options"] = "OPTIONS_LONG_PRESS"
    m._longPressKeyMap = {}
    for each key in keys
        m._longPressKeyMap[key] = longPressKeyMap[key]
    end for
    m._longPressTimer = CreateObject("roSGNode", "Timer")
    m._longPressTimer.duration = duration
    m._longPressFired = false
    m._pressState = {}
    m._longPressTimer.ObserveField("fire", FuncName(LongPressTimerFired))
end function

function LongPressHandler(key as string, press as boolean) as boolean
    isLongPressKey = m._longPressKeyMap.DoesExist(key)
    if not isLongPressKey
        return false
    end if
    if press
        m._longPressTimer.control = "stop"
        m._longPressTimer.control = "start"
        m._longPressFired = false
        m._longPressKey = key
        m._pressState[key] = true
        return true
    end if
    if not press
        m._longPressTimer.control = "stop"
        if m._longPressFired = true
            m._longPressFired = false
            m._pressState[key] = false
            return true
        end if
        
        wasPressed = m._pressState[key]
        m._pressState[key] = false
        if wasPressed <> true
            return true
        end if
    end if
    return false
end function

function LongPressTimerFired() as void
    m._longPressFired = true
    if StringUtils_IsNullOrEmpty(m._longPressKey) or not m._longPressKeyMap.DoesExist(m._longPressKey)
        return
    end if
    OnKeyEvent(m._longPressKeyMap[m._longPressKey], true)
end function